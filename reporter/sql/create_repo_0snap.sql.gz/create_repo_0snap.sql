--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: statsrepo; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA statsrepo;


SET search_path = statsrepo, pg_catalog;

--
-- Name: del_snapshot(bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION del_snapshot(bigint) RETURNS void
    LANGUAGE sql
    AS $_$
	DELETE FROM statsrepo.snapshot WHERE snapid = $1;
	DELETE FROM statsrepo.autovacuum WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.autoanalyze WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.checkpoint WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
$_$;


--
-- Name: del_snapshot(timestamp with time zone); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION del_snapshot(timestamp with time zone) RETURNS void
    LANGUAGE sql
    AS $_$
	DELETE FROM statsrepo.snapshot WHERE time < $1;
	DELETE FROM statsrepo.autovacuum WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.autoanalyze WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.checkpoint WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
$_$;


--
-- Name: del_snapshot2(timestamp with time zone); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION del_snapshot2(timestamp with time zone) RETURNS void
    LANGUAGE sql
    AS $_$
	SELECT statsrepo.partition_drop(CAST($1 AS DATE), 'statsrepo.table'::regclass);
	SELECT statsrepo.partition_drop(CAST($1 AS DATE), 'statsrepo.index'::regclass);
	SELECT statsrepo.partition_drop(CAST($1 AS DATE), 'statsrepo.column'::regclass);
	SELECT statsrepo.del_snapshot($1);
$_$;


--
-- Name: div(numeric, numeric); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION div(numeric, numeric) RETURNS numeric
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT (CASE WHEN $2 > 0 THEN $1 / $2 END)::numeric(1000, 3)$_$;


--
-- Name: get_autovacuum_activity(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_autovacuum_activity(snapid_begin bigint, snapid_end bigint, OUT datname text, OUT nspname text, OUT relname text, OUT count bigint, OUT avg_index_scans numeric, OUT avg_tup_removed numeric, OUT avg_tup_remain numeric, OUT avg_duration numeric, OUT max_duration numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		database,
		schema,
		"table",
		count(*),
		round(avg(index_scans)::numeric,3),
		round(avg(tup_removed)::numeric,3),
		round(avg(tup_remain)::numeric,3),
		round(avg(duration)::numeric,3),
		round(max(duration)::numeric,3)
	FROM
		statsrepo.autovacuum v,
		(SELECT min(time) AS time FROM statsrepo.snapshot WHERE snapid >= $1) b,
		(SELECT max(time) AS time FROM statsrepo.snapshot WHERE snapid <= $2) e
	WHERE
		v.start BETWEEN b.time AND e.time
		AND v.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
	GROUP BY
		database, schema, "table"
	ORDER BY
		5 DESC;
$_$;


--
-- Name: get_checkpoint_activity(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_checkpoint_activity(snapid_begin bigint, snapid_end bigint, OUT ckpt_total bigint, OUT ckpt_time bigint, OUT ckpt_xlog bigint, OUT avg_write_buff numeric, OUT max_write_buff numeric, OUT avg_duration numeric, OUT max_duration numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		count(*),
		count(nullif(position('time' IN flags), 0)),
		count(nullif(position('xlog' IN flags), 0)),
		round(avg(num_buffers)::numeric,3),
		round(max(num_buffers)::numeric,3),
		round(avg(total_duration)::numeric,3),
		round(max(total_duration)::numeric,3)
	FROM
		statsrepo.checkpoint c,
		(SELECT min(time) AS time FROM statsrepo.snapshot WHERE snapid >= $1) b,
		(SELECT max(time) AS time FROM statsrepo.snapshot WHERE snapid <= $2) e
	WHERE
		c.start BETWEEN b.time AND e.time
		AND c.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2);
$_$;


--
-- Name: get_constraintdef(oid); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_constraintdef(oid) RETURNS SETOF text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
	SELECT
		pg_catalog.pg_get_constraintdef(oid, true) AS condef
	FROM
		pg_constraint
	WHERE
		conrelid = $1 AND contype = 'f';
$_$;


--
-- Name: get_cpu_usage(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_cpu_usage(snapid_begin bigint, snapid_end bigint, OUT "user" numeric, OUT system numeric, OUT idle numeric, OUT iowait numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		(100 * statsrepo.sub(a.cpu_user, b.cpu_user)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2),
		(100 * statsrepo.sub(a.cpu_system, b.cpu_system)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2),
		(100 * statsrepo.sub(a.cpu_idle, b.cpu_idle)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2),
		(100 * statsrepo.sub(a.cpu_iowait, b.cpu_iowait)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2)
	FROM
		(SELECT
			snapid,
			cpu_user,
			cpu_system,
			cpu_idle,
			cpu_iowait, 
			cpu_user + cpu_system + cpu_idle + cpu_iowait AS total
		 FROM
		 	statsrepo.cpu
		 WHERE
		 	snapid = $1) b,
		(SELECT
			snapid,
			cpu_user,
			cpu_system,
			cpu_idle,
			cpu_iowait, 
			cpu_user + cpu_system + cpu_idle + cpu_iowait AS total
		 FROM
		 	statsrepo.cpu
		 WHERE
		 	snapid = $2) a,
		statsrepo.snapshot s
	WHERE
		a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2);
$_$;


--
-- Name: get_cpu_usage_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_cpu_usage_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT "user" numeric, OUT system numeric, OUT idle numeric, OUT iowait numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		t.snapid,
		(100 * statsrepo.div(t.user, t.total))::numeric(5,2),
		(100 * statsrepo.div(t.system, t.total))::numeric(5,2),
		(100 * statsrepo.div(t.idle, t.total))::numeric(5,2),
		(100 * statsrepo.div(t.iowait, t.total))::numeric(5,2)
	FROM
	(
		SELECT
			c.snapid,
			(cpu_user - lag(cpu_user) OVER w) AS user,
			(cpu_system - lag(cpu_system) OVER w) AS system,
			(cpu_idle - lag(cpu_idle) OVER w) AS idle,
			(cpu_iowait - lag(cpu_iowait) OVER w) AS iowait,
			(cpu_user + cpu_system + cpu_idle + cpu_iowait) -
				(lag(cpu_user) OVER w + lag(cpu_system) OVER w + lag(cpu_idle) OVER w + lag(cpu_iowait) OVER w ) AS total
		FROM
			statsrepo.cpu c,
			statsrepo.snapshot s
		WHERE
			c.snapid BETWEEN $1 AND $2
			AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
			AND s.snapid = c.snapid
		WINDOW w AS (PARTITION BY s.instid ORDER BY c.snapid)
		ORDER BY
			c.snapid
	) t
	WHERE
		snapid > $1;
$_$;


--
-- Name: get_dbsize_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_dbsize_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT datname name, OUT size numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		d.snapid,
		d.name,
		sum(size) / 1024 / 1024
	FROM
		statsrepo.database d,
		statsrepo.snapshot s
	WHERE
		d.snapid BETWEEN $1 AND $2
		AND d.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
	GROUP BY
		d.snapid, d.name
	ORDER BY
		d.snapid, d.name;
$_$;


--
-- Name: get_dbstats(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_dbstats(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT size bigint, OUT size_incr bigint, OUT xact_commit_tps numeric, OUT xact_rollback_tps numeric, OUT blks_hit_rate numeric, OUT blks_hit_tps numeric, OUT blks_read_tps numeric, OUT tup_fetch_tps numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		ed.name,
		ed.size / 1024 / 1024,
		statsrepo.sub(ed.size, sd.size) / 1024 / 1024,
		statsrepo.tps(
			statsrepo.sub(ed.xact_commit, sd.xact_commit),
			es.time - ss.time),
		statsrepo.tps(
			statsrepo.sub(ed.xact_rollback, sd.xact_rollback),
			es.time - ss.time),
		statsrepo.div(
			statsrepo.sub(ed.blks_hit, sd.blks_hit),
			statsrepo.sub(ed.blks_read, sd.blks_read) +
			statsrepo.sub(ed.blks_hit, sd.blks_hit)) * 100,
		statsrepo.tps(
			statsrepo.sub(ed.blks_read, sd.blks_read) +
			statsrepo.sub(ed.blks_hit, sd.blks_hit),
			es.time - ss.time),
		statsrepo.tps(
			statsrepo.sub(ed.blks_read, sd.blks_read),
		es.time - ss.time),
		statsrepo.tps(
			statsrepo.sub(ed.tup_returned, sd.tup_returned) +
			statsrepo.sub(ed.tup_fetched, sd.tup_fetched),
			es.time - ss.time)
	FROM
		statsrepo.snapshot ss,
		statsrepo.snapshot es,
		statsrepo.database ed LEFT JOIN statsrepo.database sd
			ON sd.snapid = $1 AND sd.dbid = ed.dbid
	WHERE
		ss.snapid = $1
		AND es.snapid = $2
		AND es.snapid = ed.snapid;
$_$;


--
-- Name: get_disk_usage_table(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_disk_usage_table(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT size bigint, OUT table_reads bigint, OUT index_reads bigint, OUT toast_reads bigint) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		e.size / 1024 / 1024,
		statsrepo.sub(e.heap_blks_read, b.heap_blks_read),
		statsrepo.sub(e.idx_blks_read, b.idx_blks_read),
		statsrepo.sub(e.toast_blks_read, b.toast_blks_read) +
			statsrepo.sub(e.tidx_blks_read, b.tidx_blks_read)
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema')
	ORDER BY
		statsrepo.sub(e.heap_blks_read, b.heap_blks_read) +
			statsrepo.sub(e.idx_blks_read, b.idx_blks_read) +
			statsrepo.sub(e.toast_blks_read, b.toast_blks_read) +
			statsrepo.sub(e.tidx_blks_read, b.tidx_blks_read) DESC;
$_$;


--
-- Name: get_disk_usage_tablespace(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_disk_usage_tablespace(snapid_begin bigint, snapid_end bigint, OUT spcname name, OUT location text, OUT device text, OUT used bigint, OUT avail bigint, OUT remain numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		name,
		location,
		device,
		(total - avail) / 1024 / 1024,
		avail / 1024 / 1024,
		(100.0 * avail / total)::numeric(1000, 3)
	FROM
		statsrepo.tablespace
	WHERE
		snapid = $2
	ORDER BY 1
$_$;


--
-- Name: get_flagmented_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_flagmented_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT attname name, OUT correlation numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		i.database,
		i.schema,
		i.table,
		c.name,
		c.correlation::numeric(4,3)
	FROM
		statsrepo.indexes i,
		statsrepo.column c
	WHERE
		c.snapid = $2
		AND i.snapid = c.snapid
		AND i.tbl = c.tbl
		AND c.attnum = ANY (i.indkey)
		AND i.isclustered
		AND i.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema')
		AND c.correlation < 1
	ORDER BY
		c.correlation;
$_$;


--
-- Name: get_heavily_accessed_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_heavily_accessed_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT seq_scan bigint, OUT seq_tup_read bigint, OUT tup_per_seq numeric, OUT blks_hit_rate numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		statsrepo.sub(e.seq_scan, b.seq_scan),
		statsrepo.sub(e.seq_tup_read, b.seq_tup_read),
		statsrepo.div(
			statsrepo.sub(e.seq_tup_read, b.seq_tup_read),
			statsrepo.sub(e.seq_scan, b.seq_scan)),
		statsrepo.div(
			statsrepo.sub(e.heap_blks_hit, b.heap_blks_hit) +
			statsrepo.sub(e.idx_blks_hit, b.idx_blks_hit) +
			statsrepo.sub(e.toast_blks_hit, b.toast_blks_hit) +
			statsrepo.sub(e.tidx_blks_hit, b.tidx_blks_hit),
			statsrepo.sub(e.heap_blks_hit, b.heap_blks_hit) +
			statsrepo.sub(e.idx_blks_hit, b.idx_blks_hit) +
			statsrepo.sub(e.toast_blks_hit, b.toast_blks_hit) +
			statsrepo.sub(e.tidx_blks_hit, b.tidx_blks_hit) +
			statsrepo.sub(e.heap_blks_read, b.heap_blks_read) +
			statsrepo.sub(e.idx_blks_read, b.idx_blks_read) +
			statsrepo.sub(e.toast_blks_read, b.toast_blks_read) +
			statsrepo.sub(e.tidx_blks_read, b.tidx_blks_read)) * 100
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema')
		AND statsrepo.sub(e.seq_tup_read, b.seq_tup_read) > 0
	ORDER BY
		6 DESC;
$_$;


--
-- Name: get_heavily_updated_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_heavily_updated_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT n_tup_ins bigint, OUT n_tup_upd bigint, OUT n_tup_del bigint, OUT n_tup_total bigint, OUT hot_upd_rate numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		statsrepo.sub(e.n_tup_ins, b.n_tup_ins),
		statsrepo.sub(e.n_tup_upd, b.n_tup_upd),
		statsrepo.sub(e.n_tup_del, b.n_tup_del),
		statsrepo.sub(e.n_tup_ins, b.n_tup_ins) +
			statsrepo.sub(e.n_tup_upd, b.n_tup_upd) +
			statsrepo.sub(e.n_tup_del, b.n_tup_del),
		statsrepo.div(
			statsrepo.sub(e.n_tup_hot_upd, b.n_tup_hot_upd),
			statsrepo.sub(e.n_tup_upd, b.n_tup_upd)) * 100
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
	ORDER BY
		7 DESC,
		4 DESC,
		5 DESC,
		6 DESC;
$_$;


--
-- Name: get_io_usage(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_io_usage(snapid_begin bigint, snapid_end bigint, OUT device_name text, OUT device_tblspaces name[], OUT total_read bigint, OUT total_write bigint, OUT total_read_time bigint, OUT total_write_time bigint, OUT io_queue bigint, OUT total_io_time bigint) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		a.device_name,
		a.device_tblspaces,
		statsrepo.sub(a.drs, b.drs) / 2 / 1024,
		statsrepo.sub(a.dws, b.dws) / 2 / 1024,
		statsrepo.sub(a.drt, b.drt),
		statsrepo.sub(a.dwt, b.dwt),
		statsrepo.sub(a.diq, b.diq),
		statsrepo.sub(a.dit, b.dit)
	FROM
		(SELECT
			snapid,
			device_name,
			device_tblspaces,
			device_readsector as drs,
			device_readtime as drt,
			device_writesector as dws,
			device_writetime as dwt, 
			device_ioqueue as diq,
			device_iototaltime as dit
		 FROM
		 	statsrepo.device
		 WHERE
		 	snapid = $1) b,
		(SELECT
			snapid,
			device_name,
			device_tblspaces,
			device_readsector as drs,
			device_readtime as drt,
			device_writesector as dws,
			device_writetime as dwt, 
			device_ioqueue as diq,
			device_iototaltime as dit
		 FROM
		 	statsrepo.device
		 WHERE
		 	snapid = $2) a,
		statsrepo.snapshot s
	WHERE
		a.snapid = s.snapid
		AND a.device_name = b.device_name
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2);
$_$;


--
-- Name: get_io_usage_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_io_usage_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT device_name text, OUT read_size_tps numeric, OUT write_size_tps numeric, OUT read_time_tps numeric, OUT write_time_tps numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		snapid,
		dev_name,
		read_size_tps,
		write_size_tps,
		read_time_tps,
		write_time_tps
	FROM
	(
		SELECT
			d.snapid,
			dev_name,
			coalesce((rs - lag(rs) OVER w) / 2 / duration, 0)::numeric(1000,2) AS read_size_tps,
			coalesce((ws - lag(ws) OVER w) / 2 / duration, 0)::numeric(1000,2) AS write_size_tps,
			coalesce((rt - lag(rt) OVER w) / duration, 0)::numeric(1000,2) AS read_time_tps,
			coalesce((wt - lag(wt) OVER w) / duration, 0)::numeric(1000,2) AS write_time_tps
		FROM
			(SELECT
				d.snapid,
				d.device_name as dev_name,
				sum(device_readsector) AS rs,
				sum(device_writesector) AS ws,
				sum(device_readtime) AS rt,
				sum(device_writetime) AS wt
			 FROM
				statsrepo.device d,
				statsrepo.snapshot s
			 WHERE
				d.snapid BETWEEN $1 AND $2
				AND d.snapid = s.snapid
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
			 GROUP BY
				d.snapid, d.device_name) AS d,
			(SELECT
				snapid,
				extract(epoch FROM time - lag(time) OVER (ORDER BY snapid))::float AS duration
			 FROM
			 	statsrepo.snapshot
			 WHERE
			 	instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)) AS s
		WHERE
			s.snapid = d.snapid
		WINDOW w AS (PARTITION BY d.dev_name ORDER BY d.snapid)
		ORDER BY
			d.snapid, d.dev_name
	) t
	WHERE
		snapid > $1;
$_$;


--
-- Name: get_long_transactions(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_long_transactions(snapid_begin bigint, snapid_end bigint, OUT pid integer, OUT client inet, OUT start timestamp without time zone, OUT duration numeric, OUT query text) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		max_xact_pid,
		max_xact_client,
		max_xact_start::timestamp(0),
		max_xact_duration::numeric(1000, 3),
		max_xact_query
	FROM
		statsrepo.activity a,
		statsrepo.snapshot s
	WHERE
		a.snapid BETWEEN $1 AND $2
		AND a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
		AND max_xact_pid <> 0
	ORDER BY
		max_xact_duration DESC;
$_$;


--
-- Name: get_low_density_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_low_density_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT n_live_tup bigint, OUT logical_pages bigint, OUT physical_pages bigint, OUT tratio bigint) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		database,
		schema,
		"table",
		n_live_tup,
		logical_pages,
		physical_pages,
		CASE physical_pages
			WHEN 0 THEN NULL ELSE logical_pages * 100 / physical_pages END AS tratio
	FROM
	(
		SELECT
			t.database, 
			t.schema, 
	 		t.table, 
			t.n_live_tup,
			ceil(t.n_live_tup::real / (8168 * statsrepo.pg_fillfactor(t.reloptions, 0) / 100 /
				(width + 28)))::bigint AS logical_pages,
			(t.size + CASE t.toastrelid WHEN 0 THEN 0 ELSE tt.size END) / 8192 AS physical_pages
		 FROM
		 	statsrepo.tables t
		 	LEFT JOIN
		 		(SELECT
		 			snapid, dbid, tbl, sum(avg_width)::integer + 7 & ~7 AS width
				 FROM
				 	statsrepo."column" 
				 WHERE
				 	attnum > 0
				 GROUP BY
				 	snapid, dbid, tbl) stat 
			ON t.snapid=stat.snapid AND t.dbid=stat.dbid AND t.tbl=stat.tbl
			LEFT JOIN
				(SELECT
					snapid, dbid, nsp, tbl, size
				 FROM
				 	statsrepo.tables ) tt 
			ON t.snapid=tt.snapid AND t.dbid=tt.dbid AND t.toastrelid=tt.tbl
		 WHERE
		 	t.relkind = 'r'
		 	AND t.schema NOT IN ('pg_catalog', 'information_schema', 'statsrepo')
		 	AND t.snapid = $2
	) fill
	WHERE
		physical_pages > 1000
	ORDER BY
		tratio;
$_$;


--
-- Name: get_proc_ratio(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_proc_ratio(snapid_begin bigint, snapid_end bigint, OUT idle numeric, OUT idle_in_xact numeric, OUT waiting numeric, OUT running numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(idle)::float / sum(total)::float4)::numeric(5,2) END,
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(idle_in_xact)::float / sum(total)::float4)::numeric(5,2) END,
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(waiting)::float / sum(total)::float4)::numeric(5,2) END,
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(running)::float / sum(total)::float4)::numeric(5,2) END
	FROM 
		(SELECT
			snapid,
			idle,
			idle_in_xact,
			waiting, running,
			idle + idle_in_xact + waiting + running AS total
		 FROM
		 	statsrepo.activity) a,
		statsrepo.snapshot s
	WHERE
		a.snapid BETWEEN $1 AND $2
		AND a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
$_$;


--
-- Name: get_proc_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_proc_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT idle double precision, OUT idle_in_xact double precision, OUT waiting double precision, OUT running double precision) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		a.snapid,
		idle, 
		idle_in_xact,
		waiting,
		running
	FROM
		statsrepo.activity a,
		statsrepo.snapshot s
	WHERE
		a.snapid BETWEEN $1 AND $2
		AND a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
		AND idle IS NOT NULL
	ORDER BY
		a.snapid;
$_$;


--
-- Name: get_profiles(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_profiles(snapid_begin bigint, snapid_end bigint, OUT processing text, OUT executes numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		processing,
		(sum(execute)::float / ($2::bigint - $1::bigint + 1)::float)::numeric(1000,2) AS executes
	FROM
		statsrepo.profile
	WHERE
		snapid BETWEEN $1 and $2
	GROUP BY
		processing
	ORDER BY
		executes;
$_$;


--
-- Name: get_query_activity_functions(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_query_activity_functions(snapid_begin bigint, snapid_end bigint, OUT funcid oid, OUT datname name, OUT nspname name, OUT proname name, OUT calls bigint, OUT total_time bigint, OUT self_time bigint, OUT time_per_call numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		fe.funcid,
		d.name,
		s.name,
		fe.funcname,
		statsrepo.sub(fe.calls, fb.calls),
		statsrepo.sub(fe.total_time, fb.total_time),
		statsrepo.sub(fe.self_time, fb.self_time),
		statsrepo.div(
			statsrepo.sub(fe.total_time, fb.total_time),
			statsrepo.sub(fe.calls, fb.calls))
	FROM
		statsrepo.function fe LEFT JOIN statsrepo.function fb
			ON fb.snapid = $1 AND fb.dbid = fe.dbid AND fb.nsp = fe.nsp AND fb.funcid = fe.funcid,
		statsrepo.database d,
		statsrepo.schema s
	WHERE
		fe.snapid = $2
		AND d.snapid = $2
		AND s.snapid = $2
		AND d.dbid = fe.dbid
		AND s.dbid = fe.dbid
		AND s.nsp = fe.nsp
	ORDER BY
		6 DESC,
		7 DESC,
		5 DESC;
$_$;


--
-- Name: get_query_activity_statements(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_query_activity_statements(snapid_begin bigint, snapid_end bigint, OUT rolname text, OUT datname name, OUT query text, OUT calls bigint, OUT total_time numeric, OUT time_per_call numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		r.name,
		d.name,
		se.query,
		statsrepo.sub(se.calls, sb.calls),
		statsrepo.sub(se.total_time, sb.total_time)::numeric(1000, 3),
		statsrepo.div(
			statsrepo.sub(se.total_time, sb.total_time)::numeric,
			statsrepo.sub(se.calls, sb.calls))
	FROM
		statsrepo.statement se LEFT JOIN statsrepo.statement sb
			ON sb.snapid = $1 AND sb.dbid = se.dbid AND sb.query = se.query,
		statsrepo.database d,
		statsrepo.role r
	WHERE
		se.snapid = $2
		AND d.snapid = $2
		AND r.snapid = $2
		AND d.dbid = se.dbid
		AND r.userid = se.userid
	ORDER BY
		5 DESC,
		4 DESC;
$_$;


--
-- Name: get_schema_info_indexes(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_schema_info_indexes(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT schemaname name, OUT indexname name, OUT tablename name, OUT size bigint, OUT size_incr bigint, OUT scans bigint, OUT rows_per_scan numeric, OUT blks_read bigint, OUT blks_hit bigint, OUT keys text) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.index,
		e.table,
		e.size / 1024 / 1024,
		statsrepo.sub(e.size, b.size) / 1024 / 1024,
		statsrepo.sub(e.idx_scan, b.idx_scan),
		statsrepo.div(
			statsrepo.sub(e.idx_tup_fetch, b.idx_tup_fetch),
			statsrepo.sub(e.idx_scan, b.idx_scan)),
		statsrepo.sub(e.idx_blks_read, b.idx_blks_read),
		statsrepo.sub(e.idx_blks_hit, b.idx_blks_hit),
		(regexp_matches(e.indexdef, E'.*USING[^\\(]+\\((.*)\\)'))[1]
	FROM
		statsrepo.indexes e LEFT JOIN statsrepo.index b
			ON e.idx = b.idx AND e.tbl = b.tbl AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema', 'statsrepo')
	ORDER BY
		1,
		2,
		3;
$_$;


--
-- Name: get_schema_info_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_schema_info_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT attnum bigint, OUT avg_width bigint, OUT size bigint, OUT size_incr bigint, OUT seq_scan bigint, OUT idx_scan bigint) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		c.columns,
		c.avg_width,
		e.size / 1024 / 1024,
		statsrepo.sub(e.size, b.size) / 1024 / 1024,
		statsrepo.sub(e.seq_scan, b.seq_scan),
		statsrepo.sub(e.idx_scan, b.idx_scan)
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1,
		(SELECT
			dbid,
			tbl,
			count(*) AS "columns",
			sum(avg_width) AS avg_width
		 FROM
		 	statsrepo.column
		 WHERE
		 	snapid = $2
		 GROUP BY
		 	dbid, tbl) AS c
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema', 'statsrepo')
		AND e.tbl = c.tbl
		AND e.dbid = c.dbid
	ORDER BY
		1,
		2,
		3;
$_$;


--
-- Name: get_setting_parameters(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_setting_parameters(snapid_begin bigint, snapid_end bigint, OUT name text, OUT setting text, OUT source text) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		so.name,
		CASE WHEN sa.setting = so.setting THEN
			so.setting
		ELSE
			coalesce(sa.setting, '(default)') || ' -> ' || coalesce(so.setting, '(default)')
		END,
		so.source
	FROM
		statsrepo.setting so LEFT JOIN statsrepo.setting sa
			ON so.name = sa.name AND sa.snapid = $1
	WHERE
		so.snapid = (SELECT MIN(snapid) FROM statsrepo.setting WHERE snapid >= $2);
$_$;


--
-- Name: get_snap_date(bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_snap_date(bigint) RETURNS date
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT CAST(time AS DATE) FROM statsrepo.snapshot WHERE snapid = $1$_$;


--
-- Name: get_summary(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_summary(snapid_begin bigint, snapid_end bigint, OUT instname text, OUT hostname text, OUT port integer, OUT pg_version text, OUT snap_begin timestamp without time zone, OUT snap_end timestamp without time zone, OUT duration interval, OUT total_dbsize text, OUT total_commits numeric, OUT total_rollbacks numeric) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		i.name,
		i.hostname,
		i.port,
		i.pg_version,
		b.time::timestamp(0),
		e.time::timestamp(0),
		(e.time - b.time)::interval(0),
		d.*
	FROM
		statsrepo.instance i,
		statsrepo.snapshot b,
		statsrepo.snapshot e,
		(SELECT
			pg_size_pretty(sum(ed.size)::int8),
			sum(ed.xact_commit) - sum(sd.xact_commit),
			sum(ed.xact_rollback) - sum(sd.xact_rollback)
		 FROM
		 	statsrepo.database sd,
			statsrepo.database ed
		 WHERE
		 	sd.snapid = $1
			AND ed.snapid = $2
			AND sd.dbid = ed.dbid) AS d
	WHERE
		i.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
		AND b.snapid = $1
		AND e.snapid = $2;
$_$;


--
-- Name: get_xact_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION get_xact_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT datname name, OUT commit_tps double precision, OUT rollback_tps double precision) RETURNS SETOF record
    LANGUAGE sql
    AS $_$
	SELECT
		snapid,
		name,
		"commit/s",
		"rollback/s"
	FROM
	(
		SELECT
			d.snapid,
			d.name,
			coalesce((xact_commit - lag(xact_commit) OVER w) / duration, 0) AS "commit/s",
			coalesce((xact_rollback - lag(xact_rollback) OVER w) / duration, 0) AS "rollback/s"
		FROM
			(SELECT
				d.snapid,
				d.name,
				sum(xact_commit) AS xact_commit,
				sum(xact_rollback) AS xact_rollback
			 FROM
				statsrepo.database d,
				statsrepo.snapshot s
			 WHERE
			 	d.snapid BETWEEN $1 AND $2
				AND d.snapid = s.snapid
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
			 GROUP BY
			 	d.snapid, d.name) AS d,
			(SELECT
				snapid,
				extract(epoch FROM time - lag(time) OVER (ORDER BY snapid))::float AS duration
			 FROM
				statsrepo.snapshot
			 WHERE
			 	instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)) AS s
		WHERE
			s.snapid = d.snapid
		WINDOW w AS (PARTITION BY d.name ORDER BY s.snapid)
		ORDER BY
			s.snapid, d.name
	) t
	WHERE
		snapid > $1;
$_$;


--
-- Name: partition_create(); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION partition_create() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
	SET client_min_messages = warning;
	PERFORM statsrepo.partition_new('statsrepo.table'::regclass, CAST(new.time AS DATE));
	PERFORM statsrepo.partition_new('statsrepo.index'::regclass, CAST(new.time AS DATE));
	PERFORM statsrepo.partition_new('statsrepo.column'::regclass, CAST(new.time AS DATE));
	RESET client_min_messages;
	RETURN NULL;
END;
$$;


--
-- Name: partition_drop(date, oid); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION partition_drop(date, oid) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE
	parent_name			name;
	child_name			name;
	tblname				name;
BEGIN
	parent_name := relname FROM pg_class WHERE oid = $2;
	child_name := parent_name || to_char($1, '_YYYYMMDD');

	FOR tblname IN
		SELECT c.relname FROM pg_inherits i LEFT JOIN pg_class c ON c.oid = i.inhrelid
		WHERE i.inhparent = $2 AND c.relname < child_name
	LOOP
		EXECUTE 'DROP TABLE IF EXISTS statsrepo.' || tblname;
	END LOOP;
END;
$_$;


--
-- Name: partition_insert(); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION partition_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
	EXECUTE 'INSERT INTO statsrepo.'
		|| TG_TABLE_NAME || to_char(new.date, '_YYYYMMDD') || ' VALUES(($1).*)' USING new;
	RETURN NULL;
END;
$_$;


--
-- Name: partition_new(oid, date); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION partition_new(parent_oid oid, date date) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	parent_name	name;
	child_name	name;
	condef		text;
BEGIN
	parent_name := relname FROM pg_class WHERE oid = parent_oid;
	child_name := parent_name || to_char(date, '_YYYYMMDD');

	/* child table already exists */
	PERFORM 1 FROM pg_inherits i LEFT JOIN pg_class c ON c.oid = i.inhrelid
	WHERE i.inhparent = parent_oid AND c.relname = child_name;
	IF FOUND THEN
		RETURN;
	END IF;

	/* create child table */
	IF NOT FOUND THEN
		EXECUTE 'CREATE TABLE statsrepo.' || child_name
			|| ' (LIKE statsrepo.' || parent_name
			|| ' INCLUDING INDEXES INCLUDING DEFAULTS INCLUDING CONSTRAINTS,'
			|| ' CHECK (date >= DATE ''' || to_char(date, 'YYYY-MM-DD') || ''''
			|| ' AND date < DATE ''' || to_char(date + 1, 'YYYY-MM-DD') || ''')'
			|| ' ) INHERITS (statsrepo.' || parent_name || ')';
		
		/* add foreign key constraint */
		FOR condef IN SELECT statsrepo.get_constraintdef(parent_oid) LOOP
		    EXECUTE 'ALTER TABLE statsrepo.' || child_name || ' ADD ' || condef;
		END LOOP;
	END IF;
END;
$$;


--
-- Name: pg_fillfactor(text[], oid); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION pg_fillfactor(reloptions text[], relam oid) RETURNS integer
    LANGUAGE sql STABLE
    AS $_$
SELECT (regexp_matches(array_to_string($1, '/'),
        'fillfactor=([0-9]+)'))[1]::integer AS fillfactor
UNION ALL
SELECT CASE $2
       WHEN    0 THEN 100 -- heap
       WHEN  403 THEN  90 -- btree
       WHEN  405 THEN  70 -- hash
       WHEN  783 THEN  90 -- gist
       WHEN 2742 THEN 100 -- gin
       END
LIMIT 1;
$_$;


--
-- Name: sub(anyelement, anyelement); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION sub(anyelement, anyelement) RETURNS anyelement
    LANGUAGE sql
    AS $_$SELECT coalesce($1, 0) - coalesce($2, 0)$_$;


--
-- Name: tps(numeric, interval); Type: FUNCTION; Schema: statsrepo; Owner: -
--

CREATE FUNCTION tps(numeric, interval) RETURNS numeric
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT ($1 / extract(epoch FROM $2))::numeric(1000, 3)$_$;


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: activity; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE activity (
    snapid bigint NOT NULL,
    idle double precision,
    idle_in_xact double precision,
    waiting double precision,
    running double precision,
    max_xact_client inet,
    max_xact_pid integer,
    max_xact_start timestamp with time zone,
    max_xact_duration double precision,
    max_xact_query text
);


--
-- Name: autoanalyze; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE autoanalyze (
    instid bigint,
    start timestamp with time zone,
    database text,
    schema text,
    "table" text,
    duration real
);


--
-- Name: autovacuum; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE autovacuum (
    instid bigint,
    start timestamp with time zone,
    database text,
    schema text,
    "table" text,
    index_scans integer,
    page_removed integer,
    page_remain integer,
    tup_removed bigint,
    tup_remain bigint,
    duration real
);


--
-- Name: checkpoint; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE checkpoint (
    instid bigint,
    start timestamp with time zone,
    flags text,
    num_buffers bigint,
    xlog_added bigint,
    xlog_removed bigint,
    xlog_recycled bigint,
    write_duration real,
    sync_duration real,
    total_duration real
);


--
-- Name: column; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE "column" (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    tbl oid NOT NULL,
    attnum smallint NOT NULL,
    date date,
    name name,
    type text,
    stattarget integer,
    storage "char",
    isnotnull boolean,
    isdropped boolean,
    avg_width integer,
    n_distinct real,
    correlation real
);


--
-- Name: cpu; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE cpu (
    snapid bigint NOT NULL,
    cpu_id text NOT NULL,
    cpu_user bigint,
    cpu_system bigint,
    cpu_idle bigint,
    cpu_iowait bigint
);


--
-- Name: database; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE database (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    name name,
    size bigint,
    age integer,
    xact_commit bigint,
    xact_rollback bigint,
    blks_read bigint,
    blks_hit bigint,
    tup_returned bigint,
    tup_fetched bigint,
    tup_inserted bigint,
    tup_updated bigint,
    tup_deleted bigint
);


--
-- Name: device; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE device (
    snapid bigint NOT NULL,
    device_major text NOT NULL,
    device_minor text NOT NULL,
    device_name text,
    device_readsector bigint,
    device_readtime bigint,
    device_writesector bigint,
    device_writetime bigint,
    device_ioqueue bigint,
    device_iototaltime bigint,
    device_tblspaces name[]
);


--
-- Name: function; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE function (
    snapid bigint,
    dbid oid,
    funcid oid,
    nsp oid,
    funcname name,
    argtypes text,
    calls bigint,
    total_time bigint,
    self_time bigint
);


--
-- Name: index; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE index (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    idx oid NOT NULL,
    tbl oid,
    date date,
    tbs oid,
    name name,
    relam oid,
    relpages integer,
    reltuples real,
    reloptions text[],
    isunique boolean,
    isprimary boolean,
    isclustered boolean,
    isvalid boolean,
    indkey int2vector,
    indexdef text,
    size bigint,
    idx_scan bigint,
    idx_tup_read bigint,
    idx_tup_fetch bigint,
    idx_blks_read bigint,
    idx_blks_hit bigint
);


--
-- Name: schema; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE schema (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    nsp oid NOT NULL,
    name name
);


--
-- Name: table; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE "table" (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    tbl oid NOT NULL,
    nsp oid,
    date date,
    tbs oid,
    name name,
    toastrelid oid,
    toastidxid oid,
    relkind "char",
    relpages integer,
    reltuples real,
    reloptions text[],
    size bigint,
    seq_scan bigint,
    seq_tup_read bigint,
    idx_scan bigint,
    idx_tup_fetch bigint,
    n_tup_ins bigint,
    n_tup_upd bigint,
    n_tup_del bigint,
    n_tup_hot_upd bigint,
    n_live_tup bigint,
    n_dead_tup bigint,
    heap_blks_read bigint,
    heap_blks_hit bigint,
    idx_blks_read bigint,
    idx_blks_hit bigint,
    toast_blks_read bigint,
    toast_blks_hit bigint,
    tidx_blks_read bigint,
    tidx_blks_hit bigint,
    last_vacuum timestamp with time zone,
    last_autovacuum timestamp with time zone,
    last_analyze timestamp with time zone,
    last_autoanalyze timestamp with time zone
);


--
-- Name: indexes; Type: VIEW; Schema: statsrepo; Owner: -
--

CREATE VIEW indexes AS
    SELECT i.snapid, d.name AS database, s.name AS schema, t.name AS "table", i.name AS index, i.dbid, i.idx, i.tbl, i.tbs, i.relpages, i.reltuples, i.reloptions, i.isunique, i.isprimary, i.isclustered, i.isvalid, i.size, i.indkey, i.indexdef, i.idx_scan, i.idx_tup_read, i.idx_tup_fetch, i.idx_blks_read, i.idx_blks_hit FROM database d, schema s, "table" t, index i WHERE (((((((d.snapid = i.snapid) AND (s.snapid = i.snapid)) AND (t.snapid = i.snapid)) AND (i.tbl = t.tbl)) AND (t.nsp = s.nsp)) AND (i.dbid = d.dbid)) AND (s.dbid = d.dbid));


--
-- Name: inherits; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE inherits (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    inhrelid oid NOT NULL,
    inhparent oid,
    inhseqno integer NOT NULL
);


--
-- Name: instance; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE instance (
    instid bigint NOT NULL,
    name text NOT NULL,
    hostname text NOT NULL,
    port integer NOT NULL,
    pg_version text
);


--
-- Name: instance_instid_seq; Type: SEQUENCE; Schema: statsrepo; Owner: -
--

CREATE SEQUENCE instance_instid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: instance_instid_seq; Type: SEQUENCE OWNED BY; Schema: statsrepo; Owner: -
--

ALTER SEQUENCE instance_instid_seq OWNED BY instance.instid;


--
-- Name: instance_instid_seq; Type: SEQUENCE SET; Schema: statsrepo; Owner: -
--

SELECT pg_catalog.setval('instance_instid_seq', 1, false);


--
-- Name: profile; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE profile (
    snapid bigint NOT NULL,
    processing text NOT NULL,
    execute bigint,
    total_exec_time double precision
);


--
-- Name: role; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE role (
    snapid bigint NOT NULL,
    userid oid NOT NULL,
    name text
);


--
-- Name: setting; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE setting (
    snapid bigint NOT NULL,
    name text NOT NULL,
    setting text,
    source text
);


--
-- Name: snapshot; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE snapshot (
    snapid bigint NOT NULL,
    instid bigint,
    "time" timestamp with time zone,
    comment text,
    exec_time interval,
    snapshot_increase_size bigint
);


--
-- Name: snapshot_snapid_seq; Type: SEQUENCE; Schema: statsrepo; Owner: -
--

CREATE SEQUENCE snapshot_snapid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: snapshot_snapid_seq; Type: SEQUENCE OWNED BY; Schema: statsrepo; Owner: -
--

ALTER SEQUENCE snapshot_snapid_seq OWNED BY snapshot.snapid;


--
-- Name: snapshot_snapid_seq; Type: SEQUENCE SET; Schema: statsrepo; Owner: -
--

SELECT pg_catalog.setval('snapshot_snapid_seq', 1, false);


--
-- Name: statement; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE statement (
    snapid bigint,
    dbid oid,
    userid oid,
    query text,
    calls bigint,
    total_time double precision,
    rows bigint,
    shared_blks_hit bigint,
    shared_blks_read bigint,
    shared_blks_written bigint,
    local_blks_hit bigint,
    local_blks_read bigint,
    local_blks_written bigint,
    temp_blks_read bigint,
    temp_blks_written bigint
);


--
-- Name: tables; Type: VIEW; Schema: statsrepo; Owner: -
--

CREATE VIEW tables AS
    SELECT t.snapid, d.name AS database, s.name AS schema, t.name AS "table", t.dbid, t.tbl, t.nsp, t.tbs, t.toastrelid, t.toastidxid, t.relkind, t.reloptions, t.size, t.seq_scan, t.seq_tup_read, t.idx_scan, t.idx_tup_fetch, t.n_tup_ins, t.n_tup_upd, t.n_tup_del, t.n_tup_hot_upd, t.n_live_tup, t.n_dead_tup, t.heap_blks_read, t.heap_blks_hit, t.idx_blks_read, t.idx_blks_hit, t.toast_blks_read, t.toast_blks_hit, t.tidx_blks_read, t.tidx_blks_hit, t.last_vacuum, t.last_autovacuum, t.last_analyze, t.last_autoanalyze, t.relpages FROM database d, schema s, "table" t WHERE (((((d.snapid = t.snapid) AND (s.snapid = t.snapid)) AND (s.nsp = t.nsp)) AND (d.dbid = t.dbid)) AND (s.dbid = t.dbid));


--
-- Name: tablespace; Type: TABLE; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE TABLE tablespace (
    snapid bigint NOT NULL,
    tbs oid,
    name name NOT NULL,
    location text,
    device text,
    avail bigint,
    total bigint,
    spcoptions text[]
);


--
-- Name: instid; Type: DEFAULT; Schema: statsrepo; Owner: -
--

ALTER TABLE instance ALTER COLUMN instid SET DEFAULT nextval('instance_instid_seq'::regclass);


--
-- Name: snapid; Type: DEFAULT; Schema: statsrepo; Owner: -
--

ALTER TABLE snapshot ALTER COLUMN snapid SET DEFAULT nextval('snapshot_snapid_seq'::regclass);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY activity (snapid, idle, idle_in_xact, waiting, running, max_xact_client, max_xact_pid, max_xact_start, max_xact_duration, max_xact_query) FROM stdin;
\.


--
-- Data for Name: autoanalyze; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY autoanalyze (instid, start, database, schema, "table", duration) FROM stdin;
\.


--
-- Data for Name: autovacuum; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY autovacuum (instid, start, database, schema, "table", index_scans, page_removed, page_remain, tup_removed, tup_remain, duration) FROM stdin;
\.


--
-- Data for Name: checkpoint; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY checkpoint (instid, start, flags, num_buffers, xlog_added, xlog_removed, xlog_recycled, write_duration, sync_duration, total_duration) FROM stdin;
\.


--
-- Data for Name: column; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY "column" (snapid, dbid, tbl, attnum, date, name, type, stattarget, storage, isnotnull, isdropped, avg_width, n_distinct, correlation) FROM stdin;
\.


--
-- Data for Name: cpu; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY cpu (snapid, cpu_id, cpu_user, cpu_system, cpu_idle, cpu_iowait) FROM stdin;
\.


--
-- Data for Name: database; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY database (snapid, dbid, name, size, age, xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched, tup_inserted, tup_updated, tup_deleted) FROM stdin;
\.


--
-- Data for Name: device; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY device (snapid, device_major, device_minor, device_name, device_readsector, device_readtime, device_writesector, device_writetime, device_ioqueue, device_iototaltime, device_tblspaces) FROM stdin;
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY function (snapid, dbid, funcid, nsp, funcname, argtypes, calls, total_time, self_time) FROM stdin;
\.


--
-- Data for Name: index; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY index (snapid, dbid, idx, tbl, date, tbs, name, relam, relpages, reltuples, reloptions, isunique, isprimary, isclustered, isvalid, indkey, indexdef, size, idx_scan, idx_tup_read, idx_tup_fetch, idx_blks_read, idx_blks_hit) FROM stdin;
\.


--
-- Data for Name: inherits; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY inherits (snapid, dbid, inhrelid, inhparent, inhseqno) FROM stdin;
\.


--
-- Data for Name: instance; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY instance (instid, name, hostname, port, pg_version) FROM stdin;
\.


--
-- Data for Name: profile; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY profile (snapid, processing, execute, total_exec_time) FROM stdin;
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY role (snapid, userid, name) FROM stdin;
\.


--
-- Data for Name: schema; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY schema (snapid, dbid, nsp, name) FROM stdin;
\.


--
-- Data for Name: setting; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY setting (snapid, name, setting, source) FROM stdin;
\.


--
-- Data for Name: snapshot; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY snapshot (snapid, instid, "time", comment, exec_time, snapshot_increase_size) FROM stdin;
\.


--
-- Data for Name: statement; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY statement (snapid, dbid, userid, query, calls, total_time, rows, shared_blks_hit, shared_blks_read, shared_blks_written, local_blks_hit, local_blks_read, local_blks_written, temp_blks_read, temp_blks_written) FROM stdin;
\.


--
-- Data for Name: table; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY "table" (snapid, dbid, tbl, nsp, date, tbs, name, toastrelid, toastidxid, relkind, relpages, reltuples, reloptions, size, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, n_tup_upd, n_tup_del, n_tup_hot_upd, n_live_tup, n_dead_tup, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read, toast_blks_hit, tidx_blks_read, tidx_blks_hit, last_vacuum, last_autovacuum, last_analyze, last_autoanalyze) FROM stdin;
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: statsrepo; Owner: -
--

COPY tablespace (snapid, tbs, name, location, device, avail, total, spcoptions) FROM stdin;
\.


--
-- Name: activity_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (snapid);


--
-- Name: column_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "column"
    ADD CONSTRAINT column_pkey PRIMARY KEY (snapid, dbid, tbl, attnum);


--
-- Name: cpu_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cpu
    ADD CONSTRAINT cpu_pkey PRIMARY KEY (snapid, cpu_id);


--
-- Name: database_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY database
    ADD CONSTRAINT database_pkey PRIMARY KEY (snapid, dbid);


--
-- Name: device_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY device
    ADD CONSTRAINT device_pkey PRIMARY KEY (snapid, device_major, device_minor);


--
-- Name: index_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_pkey PRIMARY KEY (snapid, dbid, idx);


--
-- Name: inherits_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY inherits
    ADD CONSTRAINT inherits_pkey PRIMARY KEY (snapid, dbid, inhrelid, inhseqno);


--
-- Name: instance_name_hostname_port_key; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY instance
    ADD CONSTRAINT instance_name_hostname_port_key UNIQUE (name, hostname, port);


--
-- Name: instance_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY instance
    ADD CONSTRAINT instance_pkey PRIMARY KEY (instid);


--
-- Name: profile_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT profile_pkey PRIMARY KEY (snapid, processing);


--
-- Name: role_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_pkey PRIMARY KEY (snapid, userid);


--
-- Name: schema_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY schema
    ADD CONSTRAINT schema_pkey PRIMARY KEY (snapid, dbid, nsp);


--
-- Name: setting_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY setting
    ADD CONSTRAINT setting_pkey PRIMARY KEY (snapid, name);


--
-- Name: snapshot_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY snapshot
    ADD CONSTRAINT snapshot_pkey PRIMARY KEY (snapid);


--
-- Name: table_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_pkey PRIMARY KEY (snapid, dbid, tbl);


--
-- Name: tablespace_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tablespace
    ADD CONSTRAINT tablespace_pkey PRIMARY KEY (snapid, name);


--
-- Name: statsrepo_autoanalyze_idx; Type: INDEX; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE INDEX statsrepo_autoanalyze_idx ON autoanalyze USING btree (instid, start);


--
-- Name: statsrepo_autovacuum_idx; Type: INDEX; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE INDEX statsrepo_autovacuum_idx ON autovacuum USING btree (instid, start);


--
-- Name: statsrepo_checkpoint_idx; Type: INDEX; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE INDEX statsrepo_checkpoint_idx ON checkpoint USING btree (instid, start);


--
-- Name: statsrepo_function_idx; Type: INDEX; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE INDEX statsrepo_function_idx ON function USING btree (snapid, dbid);


--
-- Name: statsrepo_statement_idx; Type: INDEX; Schema: statsrepo; Owner: -; Tablespace: 
--

CREATE INDEX statsrepo_statement_idx ON statement USING btree (snapid, dbid);


--
-- Name: partition_create_snapshot; Type: TRIGGER; Schema: statsrepo; Owner: -
--

CREATE TRIGGER partition_create_snapshot AFTER INSERT ON snapshot FOR EACH ROW EXECUTE PROCEDURE partition_create();


--
-- Name: partition_insert_column; Type: TRIGGER; Schema: statsrepo; Owner: -
--

CREATE TRIGGER partition_insert_column BEFORE INSERT ON "column" FOR EACH ROW EXECUTE PROCEDURE partition_insert();


--
-- Name: partition_insert_index; Type: TRIGGER; Schema: statsrepo; Owner: -
--

CREATE TRIGGER partition_insert_index BEFORE INSERT ON index FOR EACH ROW EXECUTE PROCEDURE partition_insert();


--
-- Name: partition_insert_table; Type: TRIGGER; Schema: statsrepo; Owner: -
--

CREATE TRIGGER partition_insert_table BEFORE INSERT ON "table" FOR EACH ROW EXECUTE PROCEDURE partition_insert();


--
-- Name: activity_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT activity_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: autoanalyze_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY autoanalyze
    ADD CONSTRAINT autoanalyze_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: autovacuum_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY autovacuum
    ADD CONSTRAINT autovacuum_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: checkpoint_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY checkpoint
    ADD CONSTRAINT checkpoint_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: column_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY "column"
    ADD CONSTRAINT column_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: column_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY "column"
    ADD CONSTRAINT column_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: cpu_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY cpu
    ADD CONSTRAINT cpu_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: database_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY database
    ADD CONSTRAINT database_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: device_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY device
    ADD CONSTRAINT device_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: function_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY function
    ADD CONSTRAINT function_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: function_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY function
    ADD CONSTRAINT function_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: index_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: index_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: inherits_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY inherits
    ADD CONSTRAINT inherits_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: profile_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT profile_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: role_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: schema_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY schema
    ADD CONSTRAINT schema_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: schema_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY schema
    ADD CONSTRAINT schema_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: setting_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY setting
    ADD CONSTRAINT setting_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: snapshot_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY snapshot
    ADD CONSTRAINT snapshot_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: statement_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY statement
    ADD CONSTRAINT statement_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: statement_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY statement
    ADD CONSTRAINT statement_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: table_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: table_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: table_snapid_fkey2; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_snapid_fkey2 FOREIGN KEY (snapid, dbid, nsp) REFERENCES schema(snapid, dbid, nsp);


--
-- Name: tablespace_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: -
--

ALTER TABLE ONLY tablespace
    ADD CONSTRAINT tablespace_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

