--
-- PostgreSQL database dump
--

SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: statsrepo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA statsrepo;


ALTER SCHEMA statsrepo OWNER TO postgres;

SET search_path = statsrepo, pg_catalog;

--
-- Name: del_snapshot(bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION del_snapshot(bigint) RETURNS void
    AS $_$
	DELETE FROM statsrepo.snapshot WHERE snapid = $1;
	DELETE FROM statsrepo.autovacuum WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.autoanalyze WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.checkpoint WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.del_snapshot(bigint) OWNER TO postgres;

--
-- Name: del_snapshot(timestamp with time zone); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION del_snapshot(timestamp with time zone) RETURNS void
    AS $_$
	DELETE FROM statsrepo.snapshot WHERE time < $1;
	DELETE FROM statsrepo.autovacuum WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.autoanalyze WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
	DELETE FROM statsrepo.checkpoint WHERE start < (SELECT min(time) FROM statsrepo.snapshot);
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.del_snapshot(timestamp with time zone) OWNER TO postgres;

--
-- Name: div(numeric, numeric); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION div(numeric, numeric) RETURNS numeric
    AS $_$SELECT (CASE WHEN $2 > 0 THEN $1 / $2 END)::numeric(1000, 3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION statsrepo.div(numeric, numeric) OWNER TO postgres;

--
-- Name: get_autovacuum_activity(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_autovacuum_activity(snapid_begin bigint, snapid_end bigint, OUT datname text, OUT nspname text, OUT relname text, OUT count bigint, OUT avg_index_scans numeric, OUT avg_tup_removed numeric, OUT avg_tup_remain numeric, OUT avg_duration numeric, OUT max_duration numeric) RETURNS SETOF record
    AS $_$
	SELECT
		database,
		schema,
		"table",
		count(*),
		round(avg(index_scans)::numeric,3),
		round(avg(tup_removed)::numeric,3),
		round(avg(tup_remain)::numeric,3),
		round(avg(duration)::numeric,3),
		round(max(duration)::numeric,3)
	FROM
		statsrepo.autovacuum v,
		(SELECT min(time) AS time FROM statsrepo.snapshot WHERE snapid >= $1) b,
		(SELECT max(time) AS time FROM statsrepo.snapshot WHERE snapid <= $2) e
	WHERE
		v.start BETWEEN b.time AND e.time
		AND v.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
	GROUP BY
		database, schema, "table"
	ORDER BY
		5 DESC;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_autovacuum_activity(snapid_begin bigint, snapid_end bigint, OUT datname text, OUT nspname text, OUT relname text, OUT count bigint, OUT avg_index_scans numeric, OUT avg_tup_removed numeric, OUT avg_tup_remain numeric, OUT avg_duration numeric, OUT max_duration numeric) OWNER TO postgres;

--
-- Name: get_checkpoint_activity(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_checkpoint_activity(snapid_begin bigint, snapid_end bigint, OUT ckpt_total bigint, OUT ckpt_time bigint, OUT ckpt_xlog bigint, OUT avg_write_buff numeric, OUT max_write_buff numeric, OUT avg_duration numeric, OUT max_duration numeric) RETURNS SETOF record
    AS $_$
	SELECT
		count(*),
		count(nullif(position('time' IN flags), 0)),
		count(nullif(position('xlog' IN flags), 0)),
		round(avg(num_buffers)::numeric,3),
		round(max(num_buffers)::numeric,3),
		round(avg(total_duration)::numeric,3),
		round(max(total_duration)::numeric,3)
	FROM
		statsrepo.checkpoint c,
		(SELECT min(time) AS time FROM statsrepo.snapshot WHERE snapid >= $1) b,
		(SELECT max(time) AS time FROM statsrepo.snapshot WHERE snapid <= $2) e
	WHERE
		c.start BETWEEN b.time AND e.time
		AND c.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2);
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_checkpoint_activity(snapid_begin bigint, snapid_end bigint, OUT ckpt_total bigint, OUT ckpt_time bigint, OUT ckpt_xlog bigint, OUT avg_write_buff numeric, OUT max_write_buff numeric, OUT avg_duration numeric, OUT max_duration numeric) OWNER TO postgres;

--
-- Name: get_cpu_usage(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_cpu_usage(snapid_begin bigint, snapid_end bigint, OUT "user" numeric, OUT system numeric, OUT idle numeric, OUT iowait numeric) RETURNS SETOF record
    AS $_$
	SELECT
		(100 * statsrepo.sub(a.cpu_user, b.cpu_user)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2),
		(100 * statsrepo.sub(a.cpu_system, b.cpu_system)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2),
		(100 * statsrepo.sub(a.cpu_idle, b.cpu_idle)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2),
		(100 * statsrepo.sub(a.cpu_iowait, b.cpu_iowait)::float / statsrepo.sub(a.total, b.total)::float4)::numeric(5,2)
	FROM
		(SELECT
			snapid,
			cpu_user,
			cpu_system,
			cpu_idle,
			cpu_iowait, 
			cpu_user + cpu_system + cpu_idle + cpu_iowait AS total
		 FROM
		 	statsrepo.cpu
		 WHERE
		 	snapid = $1) b,
		(SELECT
			snapid,
			cpu_user,
			cpu_system,
			cpu_idle,
			cpu_iowait, 
			cpu_user + cpu_system + cpu_idle + cpu_iowait AS total
		 FROM
		 	statsrepo.cpu
		 WHERE
		 	snapid = $2) a,
		statsrepo.snapshot s
	WHERE
		a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2);
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_cpu_usage(snapid_begin bigint, snapid_end bigint, OUT "user" numeric, OUT system numeric, OUT idle numeric, OUT iowait numeric) OWNER TO postgres;

--
-- Name: get_cpu_usage_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_cpu_usage_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT "user" numeric, OUT system numeric, OUT idle numeric, OUT iowait numeric) RETURNS SETOF record
    AS $_$
	SELECT
		t.snapid,
		(100 * statsrepo.div(t.user, t.total))::numeric(5,2),
		(100 * statsrepo.div(t.system, t.total))::numeric(5,2),
		(100 * statsrepo.div(t.idle, t.total))::numeric(5,2),
		(100 * statsrepo.div(t.iowait, t.total))::numeric(5,2)
	FROM
	(
		SELECT
			ce.snapid,
			ce.cpu_user - cs.cpu_user AS user,
			ce.cpu_system - cs.cpu_system AS system,
			ce.cpu_idle - cs.cpu_idle AS idle,
			ce.cpu_iowait - cs.cpu_iowait AS iowait,
			(ce.cpu_user + ce.cpu_system + ce.cpu_idle + ce.cpu_iowait) -
				(cs.cpu_user + cs.cpu_system + cs.cpu_idle + cs.cpu_iowait) AS total
		FROM
			(SELECT
				s.snapid,
				s.instid,
				c.cpu_user,
				c.cpu_system,
				c.cpu_idle,
				c.cpu_iowait,
				(SELECT max(snapid) FROM statsrepo.snapshot WHERE snapid < s.snapid AND instid = s.instid) AS prev_snapid
			 FROM
				statsrepo.cpu c,
				statsrepo.snapshot s
			 WHERE
				c.snapid BETWEEN $1 AND $2
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
				AND s.snapid = c.snapid) AS ce,
			(SELECT
				s.snapid,
				s.instid,
				c.cpu_user,
				c.cpu_system,
				c.cpu_idle,
				c.cpu_iowait,
				(SELECT min(snapid) FROM statsrepo.snapshot WHERE snapid > s.snapid AND instid = s.instid) AS next_snapid
			 FROM
				statsrepo.cpu c,
				statsrepo.snapshot s
			 WHERE
				c.snapid BETWEEN $1 AND $2
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
				AND s.snapid = c.snapid) AS cs
		WHERE
--			cs.snapid + 1 = ce.snapid
			cs.snapid = ce.prev_snapid
			AND cs.instid = ce.instid
		ORDER BY
			ce.snapid
	) t
	WHERE
		snapid > $1;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_cpu_usage_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT "user" numeric, OUT system numeric, OUT idle numeric, OUT iowait numeric) OWNER TO postgres;

--
-- Name: get_dbsize_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_dbsize_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT datname name, OUT size numeric) RETURNS SETOF record
    AS $_$
	SELECT
		d.snapid,
		d.name,
		sum(size) / 1024 / 1024
	FROM
		statsrepo.database d,
		statsrepo.snapshot s
	WHERE
		d.snapid BETWEEN $1 AND $2
		AND d.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
	GROUP BY
		d.snapid, d.name
	ORDER BY
		d.snapid, d.name;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_dbsize_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT datname name, OUT size numeric) OWNER TO postgres;

--
-- Name: get_dbstats(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_dbstats(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT size bigint, OUT size_incr bigint, OUT xact_commit_tps numeric, OUT xact_rollback_tps numeric, OUT blks_hit_rate numeric, OUT blks_hit_tps numeric, OUT blks_read_tps numeric, OUT tup_fetch_tps numeric) RETURNS SETOF record
    AS $_$
	SELECT
		ed.name,
		ed.size / 1024 / 1024,
		statsrepo.sub(ed.size, sd.size) / 1024 / 1024,
		statsrepo.tps(
			statsrepo.sub(ed.xact_commit, sd.xact_commit),
			es.time - ss.time),
		statsrepo.tps(
			statsrepo.sub(ed.xact_rollback, sd.xact_rollback),
			es.time - ss.time),
		statsrepo.div(
			statsrepo.sub(ed.blks_hit, sd.blks_hit),
			statsrepo.sub(ed.blks_read, sd.blks_read) +
			statsrepo.sub(ed.blks_hit, sd.blks_hit)) * 100,
		statsrepo.tps(
			statsrepo.sub(ed.blks_read, sd.blks_read) +
			statsrepo.sub(ed.blks_hit, sd.blks_hit),
			es.time - ss.time),
		statsrepo.tps(
			statsrepo.sub(ed.blks_read, sd.blks_read),
		es.time - ss.time),
		statsrepo.tps(
			statsrepo.sub(ed.tup_returned, sd.tup_returned) +
			statsrepo.sub(ed.tup_fetched, sd.tup_fetched),
			es.time - ss.time)
	FROM
		statsrepo.snapshot ss,
		statsrepo.snapshot es,
		statsrepo.database ed LEFT JOIN statsrepo.database sd
			ON sd.snapid = $1 AND sd.dbid = ed.dbid
	WHERE
		ss.snapid = $1
		AND es.snapid = $2
		AND es.snapid = ed.snapid;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_dbstats(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT size bigint, OUT size_incr bigint, OUT xact_commit_tps numeric, OUT xact_rollback_tps numeric, OUT blks_hit_rate numeric, OUT blks_hit_tps numeric, OUT blks_read_tps numeric, OUT tup_fetch_tps numeric) OWNER TO postgres;

--
-- Name: get_disk_usage_table(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_disk_usage_table(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT size bigint, OUT table_reads bigint, OUT index_reads bigint, OUT toast_reads bigint) RETURNS SETOF record
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		e.size / 1024 / 1024,
		statsrepo.sub(e.heap_blks_read, b.heap_blks_read),
		statsrepo.sub(e.idx_blks_read, b.idx_blks_read),
		statsrepo.sub(e.toast_blks_read, b.toast_blks_read) +
			statsrepo.sub(e.tidx_blks_read, b.tidx_blks_read)
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema')
	ORDER BY
		statsrepo.sub(e.heap_blks_read, b.heap_blks_read) +
			statsrepo.sub(e.idx_blks_read, b.idx_blks_read) +
			statsrepo.sub(e.toast_blks_read, b.toast_blks_read) +
			statsrepo.sub(e.tidx_blks_read, b.tidx_blks_read) DESC;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_disk_usage_table(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT size bigint, OUT table_reads bigint, OUT index_reads bigint, OUT toast_reads bigint) OWNER TO postgres;

--
-- Name: get_disk_usage_tablespace(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_disk_usage_tablespace(snapid_begin bigint, snapid_end bigint, OUT spcname name, OUT location text, OUT device text, OUT used bigint, OUT avail bigint, OUT remain numeric) RETURNS SETOF record
    AS $_$
	SELECT
		name,
		location,
		device,
		(total - avail) / 1024 / 1024,
		avail / 1024 / 1024,
		(100.0 * avail / total)::numeric(1000, 3)
	FROM
		statsrepo.tablespace
	WHERE
		snapid = $2
	ORDER BY 1
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_disk_usage_tablespace(snapid_begin bigint, snapid_end bigint, OUT spcname name, OUT location text, OUT device text, OUT used bigint, OUT avail bigint, OUT remain numeric) OWNER TO postgres;

--
-- Name: get_flagmented_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_flagmented_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT attname name, OUT correlation numeric) RETURNS SETOF record
    AS $_$
	SELECT
		i.database,
		i.schema,
		i.table,
		c.name,
		c.correlation::numeric(4,3)
	FROM
		statsrepo.indexes i,
		statsrepo.column c
	WHERE
		c.snapid = $2
		AND i.snapid = c.snapid
		AND i.tbl = c.tbl
		AND c.attnum = ANY (i.indkey)
		AND i.isclustered
		AND i.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema')
		AND c.correlation < 1
	ORDER BY
		c.correlation;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_flagmented_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT attname name, OUT correlation numeric) OWNER TO postgres;

--
-- Name: get_heavily_accessed_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_heavily_accessed_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT seq_scan bigint, OUT seq_tup_read bigint, OUT tup_per_seq numeric, OUT blks_hit_rate numeric) RETURNS SETOF record
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		statsrepo.sub(e.seq_scan, b.seq_scan),
		statsrepo.sub(e.seq_tup_read, b.seq_tup_read),
		statsrepo.div(
			statsrepo.sub(e.seq_tup_read, b.seq_tup_read),
			statsrepo.sub(e.seq_scan, b.seq_scan)),
		statsrepo.div(
			statsrepo.sub(e.heap_blks_hit, b.heap_blks_hit) +
			statsrepo.sub(e.idx_blks_hit, b.idx_blks_hit) +
			statsrepo.sub(e.toast_blks_hit, b.toast_blks_hit) +
			statsrepo.sub(e.tidx_blks_hit, b.tidx_blks_hit),
			statsrepo.sub(e.heap_blks_hit, b.heap_blks_hit) +
			statsrepo.sub(e.idx_blks_hit, b.idx_blks_hit) +
			statsrepo.sub(e.toast_blks_hit, b.toast_blks_hit) +
			statsrepo.sub(e.tidx_blks_hit, b.tidx_blks_hit) +
			statsrepo.sub(e.heap_blks_read, b.heap_blks_read) +
			statsrepo.sub(e.idx_blks_read, b.idx_blks_read) +
			statsrepo.sub(e.toast_blks_read, b.toast_blks_read) +
			statsrepo.sub(e.tidx_blks_read, b.tidx_blks_read)) * 100
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema')
		AND statsrepo.sub(e.seq_tup_read, b.seq_tup_read) > 0
	ORDER BY
		6 DESC;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_heavily_accessed_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT seq_scan bigint, OUT seq_tup_read bigint, OUT tup_per_seq numeric, OUT blks_hit_rate numeric) OWNER TO postgres;

--
-- Name: get_heavily_updated_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_heavily_updated_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT n_tup_ins bigint, OUT n_tup_upd bigint, OUT n_tup_del bigint, OUT n_tup_total bigint, OUT hot_upd_rate numeric) RETURNS SETOF record
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		statsrepo.sub(e.n_tup_ins, b.n_tup_ins),
		statsrepo.sub(e.n_tup_upd, b.n_tup_upd),
		statsrepo.sub(e.n_tup_del, b.n_tup_del),
		statsrepo.sub(e.n_tup_ins, b.n_tup_ins) +
			statsrepo.sub(e.n_tup_upd, b.n_tup_upd) +
			statsrepo.sub(e.n_tup_del, b.n_tup_del),
		statsrepo.div(
			statsrepo.sub(e.n_tup_hot_upd, b.n_tup_hot_upd),
			statsrepo.sub(e.n_tup_upd, b.n_tup_upd)) * 100
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
	ORDER BY
		7 DESC,
		4 DESC,
		5 DESC,
		6 DESC;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_heavily_updated_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT n_tup_ins bigint, OUT n_tup_upd bigint, OUT n_tup_del bigint, OUT n_tup_total bigint, OUT hot_upd_rate numeric) OWNER TO postgres;

--
-- Name: get_io_usage(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_io_usage(snapid_begin bigint, snapid_end bigint, OUT device_name text, OUT device_tblspaces name[], OUT total_read bigint, OUT total_write bigint, OUT total_read_time bigint, OUT total_write_time bigint, OUT io_queue bigint, OUT total_io_time bigint) RETURNS SETOF record
    AS $_$
	SELECT
		a.device_name,
		a.device_tblspaces,
		statsrepo.sub(a.drs, b.drs) / 2 / 1024,
		statsrepo.sub(a.dws, b.dws) / 2 / 1024,
		statsrepo.sub(a.drt, b.drt),
		statsrepo.sub(a.dwt, b.dwt),
		statsrepo.sub(a.diq, b.diq),
		statsrepo.sub(a.dit, b.dit)
	FROM
		(SELECT
			snapid,
			device_name,
			device_tblspaces,
			device_readsector as drs,
			device_readtime as drt,
			device_writesector as dws,
			device_writetime as dwt, 
			device_ioqueue as diq,
			device_iototaltime as dit
		 FROM
		 	statsrepo.device
		 WHERE
		 	snapid = $1) b,
		(SELECT
			snapid,
			device_name,
			device_tblspaces,
			device_readsector as drs,
			device_readtime as drt,
			device_writesector as dws,
			device_writetime as dwt, 
			device_ioqueue as diq,
			device_iototaltime as dit
		 FROM
		 	statsrepo.device
		 WHERE
		 	snapid = $2) a,
		statsrepo.snapshot s
	WHERE
		a.snapid = s.snapid
		AND a.device_name = b.device_name
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2);
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_io_usage(snapid_begin bigint, snapid_end bigint, OUT device_name text, OUT device_tblspaces name[], OUT total_read bigint, OUT total_write bigint, OUT total_read_time bigint, OUT total_write_time bigint, OUT io_queue bigint, OUT total_io_time bigint) OWNER TO postgres;

--
-- Name: get_io_usage_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_io_usage_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT device_name text, OUT read_size_tps numeric, OUT write_size_tps numeric, OUT read_time_tps numeric, OUT write_time_tps numeric) RETURNS SETOF record
    AS $_$
	SELECT
		snapid,
		dev_name,
		read_size_tps,
		write_size_tps,
		read_time_tps,
		write_time_tps
	FROM
	(
		SELECT
			de.snapid,
			de.dev_name,
			coalesce((de.rs - ds.rs) / 2 /
				extract(epoch FROM de.time - ds.time), 0)::numeric(1000,2) AS read_size_tps,
			coalesce((de.ws - ds.ws) / 2 /
				extract(epoch FROM de.time - ds.time), 0)::numeric(1000,2) AS write_size_tps,
			coalesce((de.rt - ds.rt) /
				extract(epoch FROM de.time - ds.time), 0)::numeric(1000,2) AS read_time_tps,
			coalesce((de.wt - ds.wt) /
				extract(epoch FROM de.time - ds.time), 0)::numeric(1000,2) AS write_time_tps
		FROM
			(SELECT
				d.snapid,
				d.device_name as dev_name,
				sum(d.device_readsector) AS rs,
				sum(d.device_writesector) AS ws,
				sum(d.device_readtime) AS rt,
				sum(d.device_writetime) AS wt,
				s.time,
				s.instid,
				(SELECT max(snapid) FROM statsrepo.snapshot WHERE snapid < d.snapid AND instid = s.instid) AS prev_snapid
			 FROM
				statsrepo.device d,
				statsrepo.snapshot s
			 WHERE
				d.snapid BETWEEN $1 AND $2
				AND d.snapid = s.snapid
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
			 GROUP BY
				d.snapid, d.device_name, s.time, s.instid) AS de,
			(SELECT
				d.snapid,
				d.device_name as dev_name,
				sum(d.device_readsector) AS rs,
				sum(d.device_writesector) AS ws,
				sum(d.device_readtime) AS rt,
				sum(d.device_writetime) AS wt,
				s.time,
				s.instid,
				(SELECT min(snapid) FROM statsrepo.snapshot WHERE snapid > d.snapid AND instid = s.instid) AS next_snapid
			 FROM
				statsrepo.device d,
				statsrepo.snapshot s
			 WHERE
				d.snapid BETWEEN $1 AND $2
				AND d.snapid = s.snapid
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
			 GROUP BY
				d.snapid, d.device_name, s.time, s.instid) AS ds
		WHERE
--			ds.snapid + 1 = de.snapid
			ds.snapid = de.prev_snapid
			AND ds.dev_name = de.dev_name
		ORDER BY
			de.snapid, de.dev_name
	) t
	WHERE
		snapid > $1;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_io_usage_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT device_name text, OUT read_size_tps numeric, OUT write_size_tps numeric, OUT read_time_tps numeric, OUT write_time_tps numeric) OWNER TO postgres;

--
-- Name: get_long_transactions(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_long_transactions(snapid_begin bigint, snapid_end bigint, OUT pid integer, OUT client inet, OUT start timestamp without time zone, OUT duration numeric, OUT query text) RETURNS SETOF record
    AS $_$
	SELECT
		max_xact_pid,
		max_xact_client,
		max_xact_start::timestamp(0),
		max_xact_duration::numeric(1000, 3),
		max_xact_query
	FROM
		statsrepo.activity a,
		statsrepo.snapshot s
	WHERE
		a.snapid BETWEEN $1 AND $2
		AND a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
		AND max_xact_pid <> 0
	ORDER BY
		max_xact_duration DESC;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_long_transactions(snapid_begin bigint, snapid_end bigint, OUT pid integer, OUT client inet, OUT start timestamp without time zone, OUT duration numeric, OUT query text) OWNER TO postgres;

--
-- Name: get_low_density_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_low_density_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT n_live_tup bigint, OUT logical_pages bigint, OUT physical_pages bigint, OUT tratio bigint) RETURNS SETOF record
    AS $_$
	SELECT
		database,
		schema,
		"table",
		n_live_tup,
		logical_pages,
		physical_pages,
		CASE physical_pages
			WHEN 0 THEN NULL ELSE logical_pages * 100 / physical_pages END AS tratio
	FROM
	(
		SELECT
			t.database, 
			t.schema, 
	 		t.table, 
			t.n_live_tup,
			ceil(t.n_live_tup::real / (8168 * statsrepo.pg_fillfactor(t.reloptions, 0) / 100 /
				(width + 28)))::bigint AS logical_pages,
			(t.size + CASE t.toastrelid WHEN 0 THEN 0 ELSE tt.size END) / 8192 AS physical_pages
		 FROM
		 	statsrepo.tables t
		 	LEFT JOIN
		 		(SELECT
		 			snapid, dbid, tbl, sum(avg_width)::integer + 7 & ~7 AS width
				 FROM
				 	statsrepo."column" 
				 WHERE
				 	attnum > 0
				 GROUP BY
				 	snapid, dbid, tbl) stat 
			ON t.snapid=stat.snapid AND t.dbid=stat.dbid AND t.tbl=stat.tbl
			LEFT JOIN
				(SELECT
					snapid, dbid, nsp, tbl, size
				 FROM
				 	statsrepo.tables ) tt 
			ON t.snapid=tt.snapid AND t.dbid=tt.dbid AND t.toastrelid=tt.tbl
		 WHERE
		 	t.relkind = 'r'
		 	AND t.schema NOT IN ('pg_catalog', 'information_schema', 'statsrepo')
		 	AND t.snapid = $2
	) fill
	WHERE
		physical_pages > 1000
	ORDER BY
		tratio;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_low_density_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT n_live_tup bigint, OUT logical_pages bigint, OUT physical_pages bigint, OUT tratio bigint) OWNER TO postgres;

--
-- Name: get_proc_ratio(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_proc_ratio(snapid_begin bigint, snapid_end bigint, OUT idle numeric, OUT idle_in_xact numeric, OUT waiting numeric, OUT running numeric) RETURNS SETOF record
    AS $_$
	SELECT
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(idle)::float / sum(total)::float4)::numeric(5,2) END,
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(idle_in_xact)::float / sum(total)::float4)::numeric(5,2) END,
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(waiting)::float / sum(total)::float4)::numeric(5,2) END,
		CASE WHEN sum(total)::float4 = 0 THEN 0
			ELSE (100 * sum(running)::float / sum(total)::float4)::numeric(5,2) END
	FROM 
		(SELECT
			snapid,
			idle,
			idle_in_xact,
			waiting, running,
			idle + idle_in_xact + waiting + running AS total
		 FROM
		 	statsrepo.activity) a,
		statsrepo.snapshot s
	WHERE
		a.snapid BETWEEN $1 AND $2
		AND a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_proc_ratio(snapid_begin bigint, snapid_end bigint, OUT idle numeric, OUT idle_in_xact numeric, OUT waiting numeric, OUT running numeric) OWNER TO postgres;

--
-- Name: get_proc_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_proc_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT idle double precision, OUT idle_in_xact double precision, OUT waiting double precision, OUT running double precision) RETURNS SETOF record
    AS $_$
	SELECT
		a.snapid,
		idle, 
		idle_in_xact,
		waiting,
		running
	FROM
		statsrepo.activity a,
		statsrepo.snapshot s
	WHERE
		a.snapid BETWEEN $1 AND $2
		AND a.snapid = s.snapid
		AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
		AND idle IS NOT NULL
	ORDER BY
		a.snapid;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_proc_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT idle double precision, OUT idle_in_xact double precision, OUT waiting double precision, OUT running double precision) OWNER TO postgres;

--
-- Name: get_profiles(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_profiles(snapid_begin bigint, snapid_end bigint, OUT processing text, OUT executes numeric) RETURNS SETOF record
    AS $_$
	SELECT
		processing,
		(sum(execute)::float / ($2::bigint - $1::bigint + 1)::float)::numeric(1000,2) AS executes
	FROM
		statsrepo.profile
	WHERE
		snapid BETWEEN $1 and $2
	GROUP BY
		processing
	ORDER BY
		executes;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_profiles(snapid_begin bigint, snapid_end bigint, OUT processing text, OUT executes numeric) OWNER TO postgres;

--
-- Name: get_query_activity_functions(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_query_activity_functions(snapid_begin bigint, snapid_end bigint, OUT funcid oid, OUT datname name, OUT nspname name, OUT proname name, OUT calls bigint, OUT total_time bigint, OUT self_time bigint, OUT time_per_call numeric) RETURNS SETOF record
    AS $_$
	SELECT
		fe.funcid,
		d.name,
		s.name,
		fe.funcname,
		statsrepo.sub(fe.calls, fb.calls),
		statsrepo.sub(fe.total_time, fb.total_time),
		statsrepo.sub(fe.self_time, fb.self_time),
		statsrepo.div(
			statsrepo.sub(fe.total_time, fb.total_time),
			statsrepo.sub(fe.calls, fb.calls))
	FROM
		statsrepo.function fe LEFT JOIN statsrepo.function fb
			ON fb.snapid = $1 AND fb.dbid = fe.dbid AND fb.nsp = fe.nsp AND fb.funcid = fe.funcid,
		statsrepo.database d,
		statsrepo.schema s
	WHERE
		fe.snapid = $2
		AND d.snapid = $2
		AND s.snapid = $2
		AND d.dbid = fe.dbid
		AND s.dbid = fe.dbid
		AND s.nsp = fe.nsp
	ORDER BY
		6 DESC,
		7 DESC,
		5 DESC;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_query_activity_functions(snapid_begin bigint, snapid_end bigint, OUT funcid oid, OUT datname name, OUT nspname name, OUT proname name, OUT calls bigint, OUT total_time bigint, OUT self_time bigint, OUT time_per_call numeric) OWNER TO postgres;

--
-- Name: get_query_activity_statements(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_query_activity_statements(snapid_begin bigint, snapid_end bigint, OUT rolname text, OUT datname name, OUT query text, OUT calls bigint, OUT total_time numeric, OUT time_per_call numeric) RETURNS SETOF record
    AS $_$
	SELECT
		r.name,
		d.name,
		se.query,
		statsrepo.sub(se.calls, sb.calls),
		statsrepo.sub(se.total_time, sb.total_time)::numeric(1000, 3),
		statsrepo.div(
			statsrepo.sub(se.total_time, sb.total_time)::numeric,
			statsrepo.sub(se.calls, sb.calls))
	FROM
		statsrepo.statement se LEFT JOIN statsrepo.statement sb
			ON sb.snapid = $1 AND sb.dbid = se.dbid AND sb.query = se.query,
		statsrepo.database d,
		statsrepo.role r
	WHERE
		se.snapid = $2
		AND d.snapid = $2
		AND r.snapid = $2
		AND d.dbid = se.dbid
		AND r.userid = se.userid
	ORDER BY
		5 DESC,
		4 DESC;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_query_activity_statements(snapid_begin bigint, snapid_end bigint, OUT rolname text, OUT datname name, OUT query text, OUT calls bigint, OUT total_time numeric, OUT time_per_call numeric) OWNER TO postgres;

--
-- Name: get_schema_info_indexes(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_schema_info_indexes(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT schemaname name, OUT indexname name, OUT tablename name, OUT size bigint, OUT size_incr bigint, OUT scans bigint, OUT rows_per_scan numeric, OUT blks_read bigint, OUT blks_hit bigint, OUT keys text) RETURNS SETOF record
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.index,
		e.table,
		e.size / 1024 / 1024,
		statsrepo.sub(e.size, b.size) / 1024 / 1024,
		statsrepo.sub(e.idx_scan, b.idx_scan),
		statsrepo.div(
			statsrepo.sub(e.idx_tup_fetch, b.idx_tup_fetch),
			statsrepo.sub(e.idx_scan, b.idx_scan)),
		statsrepo.sub(e.idx_blks_read, b.idx_blks_read),
		statsrepo.sub(e.idx_blks_hit, b.idx_blks_hit),
		(regexp_matches(e.indexdef, E'.*USING[^\\(]+\\((.*)\\)'))[1]
	FROM
		statsrepo.indexes e LEFT JOIN statsrepo.index b
			ON e.idx = b.idx AND e.tbl = b.tbl AND e.dbid = b.dbid AND b.snapid = $1
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema', 'statsrepo')
	ORDER BY
		1,
		2,
		3;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_schema_info_indexes(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT schemaname name, OUT indexname name, OUT tablename name, OUT size bigint, OUT size_incr bigint, OUT scans bigint, OUT rows_per_scan numeric, OUT blks_read bigint, OUT blks_hit bigint, OUT keys text) OWNER TO postgres;

--
-- Name: get_schema_info_tables(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_schema_info_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT attnum bigint, OUT avg_width bigint, OUT size bigint, OUT size_incr bigint, OUT seq_scan bigint, OUT idx_scan bigint) RETURNS SETOF record
    AS $_$
	SELECT
		e.database,
		e.schema,
		e.table,
		c.columns,
		c.avg_width,
		e.size / 1024 / 1024,
		statsrepo.sub(e.size, b.size) / 1024 / 1024,
		statsrepo.sub(e.seq_scan, b.seq_scan),
		statsrepo.sub(e.idx_scan, b.idx_scan)
	FROM
		statsrepo.tables e LEFT JOIN statsrepo.table b
			ON e.tbl = b.tbl AND e.nsp = b.nsp AND e.dbid = b.dbid AND b.snapid = $1,
		(SELECT
			dbid,
			tbl,
			count(*) AS "columns",
			sum(avg_width) AS avg_width
		 FROM
		 	statsrepo.column
		 WHERE
		 	snapid = $2
		 GROUP BY
		 	dbid, tbl) AS c
	WHERE
		e.snapid = $2
		AND e.schema NOT IN ('pg_catalog', 'pg_toast', 'information_schema', 'statsrepo')
		AND e.tbl = c.tbl
		AND e.dbid = c.dbid
	ORDER BY
		1,
		2,
		3;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_schema_info_tables(snapid_begin bigint, snapid_end bigint, OUT datname name, OUT nspname name, OUT relname name, OUT attnum bigint, OUT avg_width bigint, OUT size bigint, OUT size_incr bigint, OUT seq_scan bigint, OUT idx_scan bigint) OWNER TO postgres;

--
-- Name: get_setting_parameters(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_setting_parameters(snapid_begin bigint, snapid_end bigint, OUT name text, OUT setting text, OUT source text) RETURNS SETOF record
    AS $_$
	SELECT
		so.name,
		CASE WHEN sa.setting = so.setting THEN
			so.setting
		ELSE
			coalesce(sa.setting, '(default)') || ' -> ' || coalesce(so.setting, '(default)')
		END,
		so.source
	FROM
		statsrepo.setting so LEFT JOIN statsrepo.setting sa
			ON so.name = sa.name AND sa.snapid = $1
	WHERE
		so.snapid = (SELECT MIN(snapid) FROM statsrepo.setting WHERE snapid >= $2);
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_setting_parameters(snapid_begin bigint, snapid_end bigint, OUT name text, OUT setting text, OUT source text) OWNER TO postgres;

--
-- Name: get_snap_date(bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_snap_date(bigint) RETURNS date
    AS $_$SELECT CAST(time AS DATE) FROM statsrepo.snapshot WHERE snapid = $1$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION statsrepo.get_snap_date(bigint) OWNER TO postgres;

--
-- Name: get_summary(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_summary(snapid_begin bigint, snapid_end bigint, OUT instname text, OUT hostname text, OUT port integer, OUT pg_version text, OUT snap_begin timestamp without time zone, OUT snap_end timestamp without time zone, OUT duration interval, OUT total_dbsize text, OUT total_commits numeric, OUT total_rollbacks numeric) RETURNS SETOF record
    AS $_$
	SELECT
		i.name,
		i.hostname,
		i.port,
		i.pg_version,
		b.time::timestamp(0),
		e.time::timestamp(0),
		(e.time - b.time)::interval(0),
		d.*
	FROM
		statsrepo.instance i,
		statsrepo.snapshot b,
		statsrepo.snapshot e,
		(SELECT
			pg_size_pretty(sum(ed.size)::int8),
			sum(ed.xact_commit) - sum(sd.xact_commit),
			sum(ed.xact_rollback) - sum(sd.xact_rollback)
		 FROM
		 	statsrepo.database sd,
			statsrepo.database ed
		 WHERE
		 	sd.snapid = $1
			AND ed.snapid = $2
			AND sd.dbid = ed.dbid) AS d
	WHERE
		i.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
		AND b.snapid = $1
		AND e.snapid = $2;
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_summary(snapid_begin bigint, snapid_end bigint, OUT instname text, OUT hostname text, OUT port integer, OUT pg_version text, OUT snap_begin timestamp without time zone, OUT snap_end timestamp without time zone, OUT duration interval, OUT total_dbsize text, OUT total_commits numeric, OUT total_rollbacks numeric) OWNER TO postgres;

--
-- Name: get_xact_tendency(bigint, bigint); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION get_xact_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT datname name, OUT commit_tps double precision, OUT rollback_tps double precision) RETURNS SETOF record
    AS $_$
	SELECT
		snapid,
		name,
		"commit/s",
		"rollback/s"
	FROM
	(
		SELECT
			de.snapid,
			de.name,
			coalesce((de.xact_commit - ds.xact_commit) / extract(epoch FROM de.time - ds.time), 0) AS "commit/s",
			coalesce((de.xact_rollback - de.xact_rollback) / extract(epoch FROM de.time - ds.time), 0) AS "rollback/s"
		FROM
			(SELECT
				d.snapid,
				d.name,
				s.time,
				s.instid,
				sum(xact_commit) AS xact_commit,
				sum(xact_rollback) AS xact_rollback,
				(SELECT max(snapid) FROM statsrepo.snapshot WHERE snapid < d.snapid AND instid = s.instid) AS prev_snapid
			 FROM
			 	statsrepo.database d,
				statsrepo.snapshot s
			 WHERE
			 	d.snapid BETWEEN $1 AND $2
				AND d.snapid = s.snapid
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
			 GROUP BY
			 	d.snapid, d.name, s.time, s.instid) AS de,
			(SELECT
				d.snapid,
				d.name,
				s.time,
				s.instid,
				sum(xact_commit) AS xact_commit,
				sum(xact_rollback) AS xact_rollback,
				(SELECT min(snapid) FROM statsrepo.snapshot WHERE snapid > d.snapid AND instid = s.instid) AS next_snapid
			 FROM
			 	statsrepo.database d,
				statsrepo.snapshot s
			 WHERE
			 	d.snapid BETWEEN $1 AND $2
				AND d.snapid = s.snapid
				AND s.instid = (SELECT instid FROM statsrepo.snapshot WHERE snapid = $2)
			 GROUP BY
			 	d.snapid, d.name, s.time, s.instid) AS ds
		WHERE
			ds.snapid = de.prev_snapid
			AND de.snapid = ds.next_snapid
			AND ds.name = de.name
		ORDER BY
			de.snapid, de.name
	) t
	WHERE
		snapid > $1
$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.get_xact_tendency(snapid_begin bigint, snapid_end bigint, OUT snapid bigint, OUT datname name, OUT commit_tps double precision, OUT rollback_tps double precision) OWNER TO postgres;

--
-- Name: pg_fillfactor(text[], oid); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION pg_fillfactor(reloptions text[], relam oid) RETURNS integer
    AS $_$
SELECT (regexp_matches(array_to_string($1, '/'),
        'fillfactor=([0-9]+)'))[1]::integer AS fillfactor
UNION ALL
SELECT CASE $2
       WHEN    0 THEN 100 -- heap
       WHEN  403 THEN  90 -- btree
       WHEN  405 THEN  70 -- hash
       WHEN  783 THEN  90 -- gist
       WHEN 2742 THEN 100 -- gin
       END
LIMIT 1;
$_$
    LANGUAGE sql STABLE;


ALTER FUNCTION statsrepo.pg_fillfactor(reloptions text[], relam oid) OWNER TO postgres;

--
-- Name: sub(anyelement, anyelement); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION sub(anyelement, anyelement) RETURNS anyelement
    AS $_$SELECT coalesce($1, 0) - coalesce($2, 0)$_$
    LANGUAGE sql;


ALTER FUNCTION statsrepo.sub(anyelement, anyelement) OWNER TO postgres;

--
-- Name: tps(numeric, interval); Type: FUNCTION; Schema: statsrepo; Owner: postgres
--

CREATE FUNCTION tps(numeric, interval) RETURNS numeric
    AS $_$SELECT ($1 / extract(epoch FROM $2))::numeric(1000, 3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION statsrepo.tps(numeric, interval) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: activity; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE activity (
    snapid bigint NOT NULL,
    idle double precision,
    idle_in_xact double precision,
    waiting double precision,
    running double precision,
    max_xact_client inet,
    max_xact_pid integer,
    max_xact_start timestamp with time zone,
    max_xact_duration double precision,
    max_xact_query text
);


ALTER TABLE statsrepo.activity OWNER TO postgres;

--
-- Name: autoanalyze; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE autoanalyze (
    instid bigint,
    start timestamp with time zone,
    database text,
    schema text,
    "table" text,
    duration real
);


ALTER TABLE statsrepo.autoanalyze OWNER TO postgres;

--
-- Name: autovacuum; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE autovacuum (
    instid bigint,
    start timestamp with time zone,
    database text,
    schema text,
    "table" text,
    index_scans integer,
    page_removed integer,
    page_remain integer,
    tup_removed bigint,
    tup_remain bigint,
    duration real
);


ALTER TABLE statsrepo.autovacuum OWNER TO postgres;

--
-- Name: checkpoint; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE checkpoint (
    instid bigint,
    start timestamp with time zone,
    flags text,
    num_buffers bigint,
    xlog_added bigint,
    xlog_removed bigint,
    xlog_recycled bigint,
    write_duration real,
    sync_duration real,
    total_duration real
);


ALTER TABLE statsrepo.checkpoint OWNER TO postgres;

--
-- Name: column; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE "column" (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    tbl oid NOT NULL,
    attnum smallint NOT NULL,
    date date,
    name name,
    type text,
    stattarget integer,
    storage "char",
    isnotnull boolean,
    isdropped boolean,
    avg_width integer,
    n_distinct real,
    correlation real
);


ALTER TABLE statsrepo."column" OWNER TO postgres;

--
-- Name: column_20110816; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE column_20110816 (
    snapid bigint,
    dbid oid,
    tbl oid,
    attnum smallint,
    date date,
    name name,
    type text,
    stattarget integer,
    storage "char",
    isnotnull boolean,
    isdropped boolean,
    avg_width integer,
    n_distinct real,
    correlation real,
    CONSTRAINT column_20110816_date_check CHECK (((date >= '2011-08-16'::date) AND (date < '2011-08-17'::date)))
)
INHERITS ("column");


ALTER TABLE statsrepo.column_20110816 OWNER TO postgres;

--
-- Name: cpu; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE cpu (
    snapid bigint NOT NULL,
    cpu_id text NOT NULL,
    cpu_user bigint,
    cpu_system bigint,
    cpu_idle bigint,
    cpu_iowait bigint
);


ALTER TABLE statsrepo.cpu OWNER TO postgres;

--
-- Name: database; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE database (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    name name,
    size bigint,
    age integer,
    xact_commit bigint,
    xact_rollback bigint,
    blks_read bigint,
    blks_hit bigint,
    tup_returned bigint,
    tup_fetched bigint,
    tup_inserted bigint,
    tup_updated bigint,
    tup_deleted bigint
);


ALTER TABLE statsrepo.database OWNER TO postgres;

--
-- Name: device; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE device (
    snapid bigint NOT NULL,
    device_major text NOT NULL,
    device_minor text NOT NULL,
    device_name text,
    device_readsector bigint,
    device_readtime bigint,
    device_writesector bigint,
    device_writetime bigint,
    device_ioqueue bigint,
    device_iototaltime bigint,
    device_tblspaces name[]
);


ALTER TABLE statsrepo.device OWNER TO postgres;

--
-- Name: function; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE function (
    snapid bigint,
    dbid oid,
    funcid oid,
    nsp oid,
    funcname name,
    argtypes text,
    calls bigint,
    total_time bigint,
    self_time bigint
);


ALTER TABLE statsrepo.function OWNER TO postgres;

--
-- Name: index; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE index (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    idx oid NOT NULL,
    tbl oid,
    date date,
    tbs oid,
    name name,
    relam oid,
    relpages integer,
    reltuples real,
    reloptions text[],
    isunique boolean,
    isprimary boolean,
    isclustered boolean,
    isvalid boolean,
    indkey int2vector,
    indexdef text,
    size bigint,
    idx_scan bigint,
    idx_tup_read bigint,
    idx_tup_fetch bigint,
    idx_blks_read bigint,
    idx_blks_hit bigint
);


ALTER TABLE statsrepo.index OWNER TO postgres;

--
-- Name: index_20110816; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE index_20110816 (
    snapid bigint,
    dbid oid,
    idx oid,
    tbl oid,
    date date,
    tbs oid,
    name name,
    relam oid,
    relpages integer,
    reltuples real,
    reloptions text[],
    isunique boolean,
    isprimary boolean,
    isclustered boolean,
    isvalid boolean,
    indkey int2vector,
    indexdef text,
    size bigint,
    idx_scan bigint,
    idx_tup_read bigint,
    idx_tup_fetch bigint,
    idx_blks_read bigint,
    idx_blks_hit bigint,
    CONSTRAINT index_20110816_date_check CHECK (((date >= '2011-08-16'::date) AND (date < '2011-08-17'::date)))
)
INHERITS (index);


ALTER TABLE statsrepo.index_20110816 OWNER TO postgres;

--
-- Name: schema; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE schema (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    nsp oid NOT NULL,
    name name
);


ALTER TABLE statsrepo.schema OWNER TO postgres;

--
-- Name: table; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE "table" (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    tbl oid NOT NULL,
    nsp oid,
    date date,
    tbs oid,
    name name,
    toastrelid oid,
    toastidxid oid,
    relkind "char",
    relpages integer,
    reltuples real,
    reloptions text[],
    size bigint,
    seq_scan bigint,
    seq_tup_read bigint,
    idx_scan bigint,
    idx_tup_fetch bigint,
    n_tup_ins bigint,
    n_tup_upd bigint,
    n_tup_del bigint,
    n_tup_hot_upd bigint,
    n_live_tup bigint,
    n_dead_tup bigint,
    heap_blks_read bigint,
    heap_blks_hit bigint,
    idx_blks_read bigint,
    idx_blks_hit bigint,
    toast_blks_read bigint,
    toast_blks_hit bigint,
    tidx_blks_read bigint,
    tidx_blks_hit bigint,
    last_vacuum timestamp with time zone,
    last_autovacuum timestamp with time zone,
    last_analyze timestamp with time zone,
    last_autoanalyze timestamp with time zone
);


ALTER TABLE statsrepo."table" OWNER TO postgres;

--
-- Name: indexes; Type: VIEW; Schema: statsrepo; Owner: postgres
--

CREATE VIEW indexes AS
    SELECT i.snapid, d.name AS database, s.name AS schema, t.name AS "table", i.name AS index, i.dbid, i.idx, i.tbl, i.tbs, i.relpages, i.reltuples, i.reloptions, i.isunique, i.isprimary, i.isclustered, i.isvalid, i.size, i.indkey, i.indexdef, i.idx_scan, i.idx_tup_read, i.idx_tup_fetch, i.idx_blks_read, i.idx_blks_hit FROM database d, schema s, "table" t, index i WHERE (((((((d.snapid = i.snapid) AND (s.snapid = i.snapid)) AND (t.snapid = i.snapid)) AND (i.tbl = t.tbl)) AND (t.nsp = s.nsp)) AND (i.dbid = d.dbid)) AND (s.dbid = d.dbid));


ALTER TABLE statsrepo.indexes OWNER TO postgres;

--
-- Name: inherits; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE inherits (
    snapid bigint NOT NULL,
    dbid oid NOT NULL,
    inhrelid oid NOT NULL,
    inhparent oid,
    inhseqno integer NOT NULL
);


ALTER TABLE statsrepo.inherits OWNER TO postgres;

--
-- Name: instance; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE instance (
    instid bigint NOT NULL,
    name text NOT NULL,
    hostname text NOT NULL,
    port integer NOT NULL,
    pg_version text
);


ALTER TABLE statsrepo.instance OWNER TO postgres;

--
-- Name: instance_instid_seq; Type: SEQUENCE; Schema: statsrepo; Owner: postgres
--

CREATE SEQUENCE instance_instid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE statsrepo.instance_instid_seq OWNER TO postgres;

--
-- Name: instance_instid_seq; Type: SEQUENCE OWNED BY; Schema: statsrepo; Owner: postgres
--

ALTER SEQUENCE instance_instid_seq OWNED BY instance.instid;


--
-- Name: instance_instid_seq; Type: SEQUENCE SET; Schema: statsrepo; Owner: postgres
--

SELECT pg_catalog.setval('instance_instid_seq', 1, true);


--
-- Name: profile; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE profile (
    snapid bigint NOT NULL,
    processing text NOT NULL,
    execute bigint,
    total_exec_time double precision
);


ALTER TABLE statsrepo.profile OWNER TO postgres;

--
-- Name: role; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE role (
    snapid bigint NOT NULL,
    userid oid NOT NULL,
    name text
);


ALTER TABLE statsrepo.role OWNER TO postgres;

--
-- Name: setting; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE setting (
    snapid bigint NOT NULL,
    name text NOT NULL,
    setting text,
    source text
);


ALTER TABLE statsrepo.setting OWNER TO postgres;

--
-- Name: snapshot; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE snapshot (
    snapid bigint NOT NULL,
    instid bigint,
    "time" timestamp with time zone,
    comment text,
    exec_time interval,
    snapshot_increase_size bigint
);


ALTER TABLE statsrepo.snapshot OWNER TO postgres;

--
-- Name: snapshot_snapid_seq; Type: SEQUENCE; Schema: statsrepo; Owner: postgres
--

CREATE SEQUENCE snapshot_snapid_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE statsrepo.snapshot_snapid_seq OWNER TO postgres;

--
-- Name: snapshot_snapid_seq; Type: SEQUENCE OWNED BY; Schema: statsrepo; Owner: postgres
--

ALTER SEQUENCE snapshot_snapid_seq OWNED BY snapshot.snapid;


--
-- Name: snapshot_snapid_seq; Type: SEQUENCE SET; Schema: statsrepo; Owner: postgres
--

SELECT pg_catalog.setval('snapshot_snapid_seq', 2, true);


--
-- Name: statement; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE statement (
    snapid bigint,
    dbid oid,
    userid oid,
    query text,
    calls bigint,
    total_time double precision,
    rows bigint,
    shared_blks_hit bigint,
    shared_blks_read bigint,
    shared_blks_written bigint,
    local_blks_hit bigint,
    local_blks_read bigint,
    local_blks_written bigint,
    temp_blks_read bigint,
    temp_blks_written bigint
);


ALTER TABLE statsrepo.statement OWNER TO postgres;

--
-- Name: table_20110816; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE table_20110816 (
    snapid bigint,
    dbid oid,
    tbl oid,
    nsp oid,
    date date,
    tbs oid,
    name name,
    toastrelid oid,
    toastidxid oid,
    relkind "char",
    relpages integer,
    reltuples real,
    reloptions text[],
    size bigint,
    seq_scan bigint,
    seq_tup_read bigint,
    idx_scan bigint,
    idx_tup_fetch bigint,
    n_tup_ins bigint,
    n_tup_upd bigint,
    n_tup_del bigint,
    n_tup_hot_upd bigint,
    n_live_tup bigint,
    n_dead_tup bigint,
    heap_blks_read bigint,
    heap_blks_hit bigint,
    idx_blks_read bigint,
    idx_blks_hit bigint,
    toast_blks_read bigint,
    toast_blks_hit bigint,
    tidx_blks_read bigint,
    tidx_blks_hit bigint,
    last_vacuum timestamp with time zone,
    last_autovacuum timestamp with time zone,
    last_analyze timestamp with time zone,
    last_autoanalyze timestamp with time zone,
    CONSTRAINT table_20110816_date_check CHECK (((date >= '2011-08-16'::date) AND (date < '2011-08-17'::date)))
)
INHERITS ("table");


ALTER TABLE statsrepo.table_20110816 OWNER TO postgres;

--
-- Name: tables; Type: VIEW; Schema: statsrepo; Owner: postgres
--

CREATE VIEW tables AS
    SELECT t.snapid, d.name AS database, s.name AS schema, t.name AS "table", t.dbid, t.tbl, t.nsp, t.tbs, t.toastrelid, t.toastidxid, t.relkind, t.reloptions, t.size, t.seq_scan, t.seq_tup_read, t.idx_scan, t.idx_tup_fetch, t.n_tup_ins, t.n_tup_upd, t.n_tup_del, t.n_tup_hot_upd, t.n_live_tup, t.n_dead_tup, t.heap_blks_read, t.heap_blks_hit, t.idx_blks_read, t.idx_blks_hit, t.toast_blks_read, t.toast_blks_hit, t.tidx_blks_read, t.tidx_blks_hit, t.last_vacuum, t.last_autovacuum, t.last_analyze, t.last_autoanalyze, t.relpages FROM database d, schema s, "table" t WHERE (((((d.snapid = t.snapid) AND (s.snapid = t.snapid)) AND (s.nsp = t.nsp)) AND (d.dbid = t.dbid)) AND (s.dbid = t.dbid));


ALTER TABLE statsrepo.tables OWNER TO postgres;

--
-- Name: tablespace; Type: TABLE; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE TABLE tablespace (
    snapid bigint NOT NULL,
    tbs oid,
    name name NOT NULL,
    location text,
    device text,
    avail bigint,
    total bigint,
    spcoptions text[]
);


ALTER TABLE statsrepo.tablespace OWNER TO postgres;

--
-- Name: instid; Type: DEFAULT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE instance ALTER COLUMN instid SET DEFAULT nextval('instance_instid_seq'::regclass);


--
-- Name: snapid; Type: DEFAULT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE snapshot ALTER COLUMN snapid SET DEFAULT nextval('snapshot_snapid_seq'::regclass);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY activity (snapid, idle, idle_in_xact, waiting, running, max_xact_client, max_xact_pid, max_xact_start, max_xact_duration, max_xact_query) FROM stdin;
1	0	0	0	0	\N	\N	\N	\N	\N
2	0.0083333333333333297	0.063888888888888898	0	0.81666666666666698	\N	11231	2011-08-16 18:02:53.622174+09	46.564079999999997	autovacuum: ANALYZE public.pgbench_accounts
\.


--
-- Data for Name: autoanalyze; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY autoanalyze (instid, start, database, schema, "table", duration) FROM stdin;
1	2011-08-16 17:36:49.182+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:36:49.226+09	testdb	public	pgbench_history	0.02
1	2011-08-16 17:36:49.263+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:37:49.273+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:37:49.314+09	testdb	public	pgbench_history	0.31
1	2011-08-16 17:37:49.641+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:38:49.343+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 17:38:49.405+09	testdb	public	pgbench_history	0.47
1	2011-08-16 17:38:49.896+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:39:49.319+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 17:39:49.364+09	testdb	public	pgbench_history	0.61000001
1	2011-08-16 17:39:49.994+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:40:49.798+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 17:40:49.885+09	testdb	public	pgbench_history	0.58999997
1	2011-08-16 17:40:50.497+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:41:49.519+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 17:41:49.568+09	testdb	public	pgbench_history	0.81999999
1	2011-08-16 17:41:50.408+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:42:49.502+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 17:42:49.549+09	testdb	public	pgbench_history	0.91000003
1	2011-08-16 17:42:50.485+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:43:50.027+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 17:43:50.215+09	testdb	public	pgbench_history	0.88999999
1	2011-08-16 17:43:51.123+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:44:49.615+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:44:49.647+09	testdb	public	pgbench_history	1.11
1	2011-08-16 17:44:50.779+09	testdb	public	pgbench_tellers	0
1	2011-08-16 17:44:50.795+09	testdb	public	pgbench_accounts	45.990002
1	2011-08-16 17:45:49.613+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 17:45:49.673+09	testdb	public	pgbench_history	1.01
1	2011-08-16 17:45:50.753+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:46:49.799+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 17:46:49.878+09	testdb	public	pgbench_history	1.24
1	2011-08-16 17:46:51.276+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 17:47:49.715+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 17:47:49.816+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:48:49.71+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:48:49.757+09	testdb	public	pgbench_history	1.45
1	2011-08-16 17:48:51.263+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:49:49.777+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:49:49.86+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:50:49.823+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 17:50:49.866+09	testdb	public	pgbench_history	1.74
1	2011-08-16 17:50:51.645+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:51:49.897+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 17:51:49.985+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:52:50.451+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:52:50.486+09	testdb	public	pgbench_history	1.98
1	2011-08-16 17:52:52.507+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:53:50.172+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 17:53:50.353+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:53:50.386+09	testdb	public	pgbench_accounts	46.450001
1	2011-08-16 17:54:50.459+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 17:54:50.683+09	testdb	public	pgbench_history	2.1800001
1	2011-08-16 17:54:53.004+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:55:50.047+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:55:50.249+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 17:56:50.232+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 17:56:50.333+09	testdb	public	pgbench_history	2.2
1	2011-08-16 17:56:52.571+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 17:57:50.225+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 17:57:50.31+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:58:50.228+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 17:58:50.336+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 17:59:50.696+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 17:59:50.743+09	testdb	public	pgbench_history	2.74
1	2011-08-16 17:59:53.523+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 18:00:50.297+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:00:50.394+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:01:50.328+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:01:50.417+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:02:50.527+09	testdb	public	pgbench_branches	0
1	2011-08-16 18:02:50.538+09	testdb	public	pgbench_history	3.01
1	2011-08-16 18:02:53.587+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 18:02:53.625+09	testdb	public	pgbench_accounts	46.57
1	2011-08-16 18:03:50.43+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:03:50.545+09	testdb	public	pgbench_tellers	0
1	2011-08-16 18:04:50.589+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:04:50.772+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:05:51.016+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:05:51.243+09	testdb	public	pgbench_history	3.29
1	2011-08-16 18:05:54.60+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:06:50.554+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:06:50.673+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:07:50.656+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:07:50.741+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:08:50.659+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:08:50.704+09	testdb	public	pgbench_history	3.5999999
1	2011-08-16 18:08:54.369+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:09:50.738+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 18:09:50.965+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:10:50.74+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:10:50.922+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:11:50.799+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 18:11:50.927+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:11:50.999+09	testdb	public	pgbench_accounts	47.139999
1	2011-08-16 18:12:50.798+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:12:50.86+09	testdb	public	pgbench_history	4.0999999
1	2011-08-16 18:12:55.111+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 18:13:50.885+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:13:51.106+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:14:51.06+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 18:14:51.206+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:15:50.963+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:15:51.043+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:16:50.99+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 18:16:51.062+09	testdb	public	pgbench_history	4.3800001
1	2011-08-16 18:16:55.505+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:17:51.055+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:17:51.139+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:18:51.111+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:18:51.193+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:19:51.719+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:19:51.968+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:20:51.33+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:20:51.367+09	testdb	public	pgbench_history	4.8400002
1	2011-08-16 18:20:56.271+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:20:56.331+09	testdb	public	pgbench_accounts	46.740002
1	2011-08-16 18:21:51.184+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:21:51.261+09	testdb	public	pgbench_tellers	0
1	2011-08-16 18:22:51.417+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 18:22:51.649+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:23:51.309+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:23:51.387+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:24:51.338+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:24:51.426+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:25:51.369+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 18:25:51.448+09	testdb	public	pgbench_history	5.27
1	2011-08-16 18:25:56.778+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:26:51.43+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:26:51.536+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:27:51.533+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 18:27:51.699+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:28:51.519+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:28:51.612+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:29:51.572+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 18:29:51.70+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:29:51.759+09	testdb	public	pgbench_accounts	46.669998
1	2011-08-16 18:30:51.973+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:30:52.189+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 18:31:52.131+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:31:52.169+09	testdb	public	pgbench_history	6.0999999
1	2011-08-16 18:31:58.427+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:32:52.008+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 18:32:52.424+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:33:51.79+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:33:51.88+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:34:51.803+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:34:51.903+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:35:51.833+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:35:51.923+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:36:51.845+09	testdb	public	pgbench_branches	0
1	2011-08-16 18:36:51.915+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:37:51.927+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:37:51.994+09	testdb	public	pgbench_history	6.6100001
1	2011-08-16 18:37:58.936+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:38:51.956+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:38:52.06+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:38:52.139+09	testdb	public	pgbench_accounts	47.16
1	2011-08-16 18:39:51.983+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:39:52.05+09	testdb	public	pgbench_tellers	0
1	2011-08-16 18:40:52.484+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 18:40:52.971+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:41:52.556+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:41:52.682+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:42:52.087+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 18:42:52.216+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:43:52.206+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:43:52.285+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:44:52.202+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:44:52.238+09	testdb	public	pgbench_history	7.3800001
1	2011-08-16 18:44:59.682+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:45:53.068+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:45:53.173+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:46:52.362+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:46:52.465+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:47:52.386+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:47:52.505+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 18:47:52.56+09	testdb	public	pgbench_accounts	47.259998
1	2011-08-16 18:48:52.455+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:48:52.511+09	testdb	public	pgbench_tellers	0
1	2011-08-16 18:49:52.545+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:49:52.748+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:50:52.576+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:50:52.655+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:51:54.643+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:51:55.789+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:52:52.964+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:52:53.258+09	testdb	public	pgbench_history	8.29
1	2011-08-16 18:53:02.158+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:53:52.665+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:53:52.742+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:54:52.834+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:54:52.922+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:55:53.677+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 18:55:54.069+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:56:52.752+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:56:52.831+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:56:52.908+09	testdb	public	pgbench_accounts	47.240002
1	2011-08-16 18:57:52.853+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:57:53.061+09	testdb	public	pgbench_tellers	0
1	2011-08-16 18:58:52.859+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 18:58:53.079+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 18:59:53.221+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 18:59:53.299+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:00:53.348+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:00:53.39+09	testdb	public	pgbench_history	8.8999996
1	2011-08-16 19:01:02.364+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:01:53.004+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:01:53.116+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:02:53.019+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 19:02:53.148+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:03:53.628+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 19:03:53.749+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:04:53.108+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:04:53.197+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:05:53.238+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 19:05:53.336+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:05:53.407+09	testdb	public	pgbench_accounts	47.639999
1	2011-08-16 19:06:53.266+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:06:53.443+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 19:07:53.422+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 19:07:53.662+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:08:53.40+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:08:53.487+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:09:53.344+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:09:53.395+09	testdb	public	pgbench_history	9.8400002
1	2011-08-16 19:10:03.567+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:10:53.45+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 19:10:53.604+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:11:53.458+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:11:53.565+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:12:53.529+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:12:53.64+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:13:53.562+09	testdb	public	pgbench_branches	0
1	2011-08-16 19:13:53.66+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:14:53.567+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:14:53.667+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:14:53.747+09	testdb	public	pgbench_accounts	47.43
1	2011-08-16 19:15:53.806+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 19:15:53.99+09	testdb	public	pgbench_tellers	0
1	2011-08-16 19:16:53.734+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:16:53.937+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:17:53.721+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:17:53.81+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:18:53.776+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:18:53.862+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:19:53.84+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:19:53.892+09	testdb	public	pgbench_history	10.85
1	2011-08-16 19:20:04.804+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:20:53.914+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 19:20:54.051+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:21:53.909+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:21:54.01+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:22:53.93+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:22:54.04+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:23:54.008+09	testdb	public	pgbench_branches	0
1	2011-08-16 19:23:54.09+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:23:54.146+09	testdb	public	pgbench_accounts	47.259998
1	2011-08-16 19:24:54.35+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 19:24:54.563+09	testdb	public	pgbench_tellers	0
1	2011-08-16 19:25:54.447+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 19:25:54.686+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:26:54.165+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:26:54.256+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:27:54.137+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:27:54.23+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:28:54.176+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 19:28:54.313+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:29:54.901+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:29:54.992+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:30:54.27+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 19:30:54.361+09	testdb	public	pgbench_history	12.07
1	2011-08-16 19:31:06.60+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:31:54.409+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 19:31:54.568+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:32:54.398+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:32:54.497+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:32:54.579+09	testdb	public	pgbench_accounts	47.599998
1	2011-08-16 19:33:54.456+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:33:54.527+09	testdb	public	pgbench_tellers	0
1	2011-08-16 19:34:54.543+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:34:54.757+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:35:54.516+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:35:54.594+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:36:54.607+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:36:54.691+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:37:55.315+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:37:55.396+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:38:54.68+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:38:54.76+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:39:54.718+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:39:54.80+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:40:54.728+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 19:40:54.858+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:41:54.773+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 19:41:54.913+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:41:54.992+09	testdb	public	pgbench_accounts	47.830002
1	2011-08-16 19:42:54.851+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:42:54.896+09	testdb	public	pgbench_history	13.38
1	2011-08-16 19:43:08.473+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:43:54.977+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:43:55.197+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:44:54.974+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:44:55.056+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:45:56.218+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:45:56.297+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:46:55.099+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:46:55.191+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:47:56.26+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:47:56.338+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:48:55.079+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:48:55.158+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:49:55.136+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 19:49:55.241+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:50:55.832+09	testdb	public	pgbench_branches	0
1	2011-08-16 19:50:55.897+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:50:55.973+09	testdb	public	pgbench_accounts	47.759998
1	2011-08-16 19:51:55.226+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:51:55.301+09	testdb	public	pgbench_tellers	0
1	2011-08-16 19:52:55.405+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:52:55.598+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:53:55.339+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 19:53:55.447+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:54:55.469+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 19:54:55.571+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:55:55.418+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:55:55.467+09	testdb	public	pgbench_history	14.73
1	2011-08-16 19:56:10.258+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:56:55.524+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:56:55.657+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:57:55.796+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:57:55.876+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:58:55.558+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 19:58:55.638+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 19:59:55.856+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 19:59:55.963+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 19:59:56.017+09	testdb	public	pgbench_accounts	47.860001
1	2011-08-16 20:00:55.707+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:00:55.808+09	testdb	public	pgbench_tellers	0
1	2011-08-16 20:01:55.767+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 20:01:56.007+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:02:55.745+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:02:55.833+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:03:55.751+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:03:55.841+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:04:55.822+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:04:55.901+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:05:55.865+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:05:55.945+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:06:55.917+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:06:55.995+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:07:55.928+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:07:56.015+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:08:56.201+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:08:56.292+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:08:56.345+09	testdb	public	pgbench_accounts	47.779999
1	2011-08-16 20:09:56.151+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:09:56.205+09	testdb	public	pgbench_history	16.040001
1	2011-08-16 20:10:12.464+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:10:56.197+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:10:56.435+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:11:56.074+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 20:11:56.208+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:12:56.236+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 20:12:56.371+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:13:56.176+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:13:56.269+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:14:56.287+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:14:56.368+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:15:56.292+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:15:56.476+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:16:56.333+09	testdb	public	pgbench_branches	0
1	2011-08-16 20:16:56.408+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:17:56.382+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 20:17:56.485+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:17:56.578+09	testdb	public	pgbench_accounts	48.080002
1	2011-08-16 20:18:57.127+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 20:18:57.803+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 20:19:56.574+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 20:19:56.843+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:20:56.486+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 20:20:56.626+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:21:56.606+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:21:56.706+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:22:56.661+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:22:56.76+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:23:56.688+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:23:56.797+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:24:56.713+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:24:56.813+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:25:56.861+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 20:25:56.946+09	testdb	public	pgbench_history	17.84
1	2011-08-16 20:26:15.168+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:26:57.105+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 20:26:57.269+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:26:57.341+09	testdb	public	pgbench_accounts	48.580002
1	2011-08-16 20:27:56.966+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:27:57.024+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 20:28:57.019+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 20:28:57.284+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:29:56.904+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:29:56.994+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:30:56.959+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:30:57.049+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:31:57.005+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:31:57.097+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:32:57.068+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:32:57.148+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:33:57.107+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:33:57.198+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:34:57.153+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:34:57.243+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:34:57.319+09	testdb	public	pgbench_accounts	48.139999
1	2011-08-16 20:35:57.201+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:35:57.261+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 20:36:57.312+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:36:57.526+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:37:57.229+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 20:37:57.358+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:38:58+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 20:38:58.431+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:39:58.208+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:39:58.292+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:40:57.404+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 20:40:57.514+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:41:57.484+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:41:57.564+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:42:57.488+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 20:42:57.553+09	testdb	public	pgbench_history	19.700001
1	2011-08-16 20:43:17.414+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 20:43:57.664+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:43:57.815+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:43:57.892+09	testdb	public	pgbench_accounts	48.32
1	2011-08-16 20:44:58.69+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:44:58.837+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 20:45:57.875+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 20:45:58.156+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:46:57.638+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:46:57.72+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:47:57.711+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:47:57.802+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:48:57.781+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:48:57.861+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:49:57.879+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:49:57.965+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:50:57.859+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:50:57.949+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:51:57.961+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:51:58.048+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:52:57.951+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:52:58.044+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:52:58.146+09	testdb	public	pgbench_accounts	48.080002
1	2011-08-16 20:53:59.093+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 20:53:59.33+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 20:54:58.135+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:54:58.35+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 20:55:58.062+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 20:55:58.17+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:56:58.185+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 20:56:58.293+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:57:58.177+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 20:57:58.266+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:58:58.279+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 20:58:58.379+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 20:59:58.232+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 20:59:58.314+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:00:58.304+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 21:00:58.414+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:01:59.066+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 21:01:59.135+09	testdb	public	pgbench_history	21.73
1	2011-08-16 21:02:20.933+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:02:58.556+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:02:58.782+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 21:02:21.012+09	testdb	public	pgbench_accounts	48.709999
1	2011-08-16 21:03:58.40+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 21:03:58.487+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:04:58.66+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 21:04:59.011+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:05:58.582+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:05:58.804+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:06:58.609+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:06:58.691+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:07:58.606+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:07:58.688+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:08:58.652+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:08:58.731+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:09:58.73+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:09:58.809+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:10:59.207+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:10:59.545+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:10:59.754+09	testdb	public	pgbench_accounts	47.880001
1	2011-08-16 21:11:59.514+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 21:11:59.85+09	testdb	public	pgbench_tellers	0
1	2011-08-16 21:12:58.987+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:12:59.199+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:13:58.891+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 21:13:58.999+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:14:58.994+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:14:59.082+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:15:58.958+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:15:59.05+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:16:59.031+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 21:16:59.14+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:17:59.539+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 21:17:59.638+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:18:59.117+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 21:18:59.225+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:19:59.385+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 21:19:59.802+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:20:00.027+09	testdb	public	pgbench_accounts	48.369999
1	2011-08-16 21:20:59.216+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:20:59.319+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 21:21:59.349+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 21:21:59.599+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:22:59.312+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:22:59.355+09	testdb	public	pgbench_history	23.9
1	2011-08-16 21:23:23.32+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 21:23:59.368+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:23:59.512+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:24:59.419+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:24:59.532+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:25:59.457+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:25:59.566+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:26:59.453+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 21:26:59.573+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:27:59.50+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:27:59.611+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:28:59.902+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:29:00.092+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:29:00.39+09	testdb	public	pgbench_accounts	47.919998
1	2011-08-16 21:29:59.953+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 21:30:00.288+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 21:30:59.778+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:30:59.989+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:31:59.684+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 21:31:59.792+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:32:59.80+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:32:59.885+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:33:59.914+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:34:00.003+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:34:59.838+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 21:34:59.946+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:35:59.852+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:35:59.94+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:36:59.928+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:37:00.021+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:38:00.395+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 21:38:00.495+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:38:00.83+09	testdb	public	pgbench_accounts	48.34
1	2011-08-16 21:39:00.37+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:39:00.539+09	testdb	public	pgbench_tellers	0
1	2011-08-16 21:40:00.144+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 21:40:00.416+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:41:00.941+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:41:01.027+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:42:00.18+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:42:00.273+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:43:00.212+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:43:00.296+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:44:00.241+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:44:00.335+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:45:00.284+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:45:00.374+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 21:46:00.391+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:46:00.436+09	testdb	public	pgbench_history	26.25
1	2011-08-16 21:46:27.058+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-16 21:47:01.542+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:47:02.051+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:47:02.202+09	testdb	public	pgbench_accounts	48.59
1	2011-08-16 21:48:00.466+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:48:00.611+09	testdb	public	pgbench_tellers	0
1	2011-08-16 21:49:00.601+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 21:49:00.876+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:50:00.467+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:50:00.557+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:51:00.559+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:51:00.638+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:52:00.611+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:52:00.692+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:53:00.636+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:53:00.725+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:54:00.696+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 21:54:00.831+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:55:00.757+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:55:00.848+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:56:01.091+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:56:01.508+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:56:01.738+09	testdb	public	pgbench_accounts	48.57
1	2011-08-16 21:57:00.808+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 21:57:00.899+09	testdb	public	pgbench_tellers	0
1	2011-08-16 21:58:00.947+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 21:58:01.217+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 21:59:00.896+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 21:59:00.992+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:00:00.977+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:00:01.07+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:01:01.043+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:01:01.127+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:02:01.028+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:02:01.126+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:03:01.082+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:03:01.173+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:04:01.135+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:04:01.232+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:05:01.151+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:05:01.438+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:05:01.653+09	testdb	public	pgbench_accounts	48.450001
1	2011-08-16 22:06:01.194+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:06:01.305+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:07:01.342+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:07:01.601+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:08:01.278+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:08:01.363+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:09:01.337+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:09:01.42+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:10:01.362+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:10:01.449+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:11:01.422+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:11:01.512+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:12:01.482+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:12:01.525+09	testdb	public	pgbench_history	29.190001
1	2011-08-16 22:12:30.786+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:13:01.632+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:13:01.815+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:14:01.889+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:14:02.158+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:14:02.355+09	testdb	public	pgbench_accounts	48.639999
1	2011-08-16 22:15:02.424+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:15:02.62+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:16:01.593+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:16:01.861+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:17:01.636+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 22:17:01.766+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:18:01.724+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:18:01.817+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:19:01.887+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 22:19:02.005+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:20:01.787+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:20:01.873+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:21:01.896+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:21:01.98+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:22:01.898+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 22:22:02.002+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:23:01.902+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:23:01.99+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:23:02.071+09	testdb	public	pgbench_accounts	48.220001
1	2011-08-16 22:24:02.003+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:24:02.127+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:25:01.961+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 22:25:02.217+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:26:02.107+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:26:02.199+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:27:02.133+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:27:02.213+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:28:02.247+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:28:02.337+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:29:02.152+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:29:02.282+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:30:02.268+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:30:02.361+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:31:02.276+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:31:02.356+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:32:02.336+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:32:02.475+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:32:02.569+09	testdb	public	pgbench_accounts	48.700001
1	2011-08-16 22:33:02.399+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:33:02.557+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:34:02.531+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:34:02.793+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:35:02.509+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 22:35:02.63+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:36:02.59+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:36:02.669+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:37:02.552+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 22:37:02.662+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:38:02.63+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:38:02.719+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:39:02.641+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:39:02.735+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:40:02.904+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 22:40:03.024+09	testdb	public	pgbench_history	31.99
1	2011-08-16 22:40:35.273+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:41:03.476+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:41:03.667+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:41:03.74+09	testdb	public	pgbench_accounts	48.77
1	2011-08-16 22:42:02.742+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:42:02.811+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:43:03.164+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:43:03.427+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:44:02.843+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:44:02.937+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:45:02.975+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:45:03.057+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:46:02.911+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:46:02.999+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:47:03.008+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:47:03.097+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:48:03.285+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:48:03.545+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:49:03.05+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:49:03.136+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:50:03.134+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:50:03.232+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:50:03.328+09	testdb	public	pgbench_accounts	48.709999
1	2011-08-16 22:51:03.167+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:51:03.238+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 22:52:03.28+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:52:03.493+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 22:53:03.232+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:53:03.373+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:54:03.634+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:54:03.722+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:55:03.359+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 22:55:03.458+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:56:03.369+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:56:03.465+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:57:03.752+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 22:57:04.132+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:58:03.482+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 22:58:03.617+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:59:03.501+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 22:59:03.582+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 22:59:03.656+09	testdb	public	pgbench_accounts	49.139999
1	2011-08-16 23:00:03.53+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:00:03.588+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 23:01:03.898+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 23:01:04.16+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:02:03.697+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:02:03.79+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:03:03.719+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:03:03.803+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:04:03.702+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:04:03.796+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:05:03.794+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:05:03.874+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:06:04.199+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:06:04.604+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:07:04.145+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:07:04.228+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:08:03.919+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:08:04.011+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:08:04.105+09	testdb	public	pgbench_accounts	48.779999
1	2011-08-16 23:09:03.91+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:09:03.98+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 23:10:04.211+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:10:04.436+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:11:04.084+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:11:04.127+09	testdb	public	pgbench_history	35.330002
1	2011-08-16 23:11:39.528+09	testdb	public	pgbench_tellers	0
1	2011-08-16 23:12:04.086+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 23:12:04.271+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:13:04.557+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 23:13:04.721+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:14:04.105+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 23:14:04.23+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:15:04.168+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:15:04.277+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:16:04.321+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:16:04.435+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:17:04.892+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:17:05.006+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:17:05.078+09	testdb	public	pgbench_accounts	48.77
1	2011-08-16 23:18:04.316+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:18:04.426+09	testdb	public	pgbench_tellers	0
1	2011-08-16 23:19:04.322+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 23:19:04.581+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:20:04.66+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:20:05.085+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:21:04.424+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 23:21:04.552+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:22:04.486+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-16 23:22:04.615+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:23:04.657+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:23:04.737+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:24:04.629+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 23:24:04.771+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:25:04.62+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:25:04.706+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:26:04.69+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:26:04.778+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:26:04.861+09	testdb	public	pgbench_accounts	48.610001
1	2011-08-16 23:27:04.761+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:27:04.932+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 23:28:04.798+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:28:05.211+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:29:04.95+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 23:29:05.083+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:30:04.839+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:30:04.929+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:31:04.888+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 23:31:04.997+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:32:04.999+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-16 23:32:05.109+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:33:05.012+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:33:05.106+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:34:05.06+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 23:34:05.17+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:35:05.062+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:35:05.153+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:35:05.23+09	testdb	public	pgbench_accounts	48.77
1	2011-08-16 23:36:05.488+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:36:05.601+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 23:37:05.123+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 23:37:05.395+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:38:05.29+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:38:05.374+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:39:05.264+09	testdb	public	pgbench_branches	0.07
1	2011-08-16 23:39:05.396+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:40:05.302+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:40:05.389+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:41:05.374+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:41:05.467+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:42:05.418+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:42:05.506+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:43:05.958+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:43:06.05+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:44:05.48+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:44:05.571+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:44:05.663+09	testdb	public	pgbench_accounts	49.080002
1	2011-08-16 23:45:05.475+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:45:05.519+09	testdb	public	pgbench_history	38.259998
1	2011-08-16 23:45:44.028+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:46:05.67+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:46:05.937+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:47:05.722+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 23:47:05.83+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:48:05.597+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:48:05.684+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:49:05.655+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:49:05.744+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:50:05.721+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:50:05.816+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:51:05.744+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:51:05.836+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:52:05.76+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-16 23:52:05.869+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:53:05.85+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:53:05.941+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-16 23:53:06.02+09	testdb	public	pgbench_accounts	48.779999
1	2011-08-16 23:54:06.021+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:54:06.255+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 23:55:06.402+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-16 23:55:06.699+09	testdb	public	pgbench_tellers	0.1
1	2011-08-16 23:56:06.103+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:56:06.219+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-16 23:57:06.159+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:57:06.237+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 23:58:06.065+09	testdb	public	pgbench_branches	0.02
1	2011-08-16 23:58:06.146+09	testdb	public	pgbench_tellers	0.02
1	2011-08-16 23:59:06.124+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-16 23:59:06.216+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:00:06.227+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:00:06.304+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:01:06.435+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:01:06.849+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:02:06.238+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:02:06.325+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:02:06.363+09	testdb	public	pgbench_accounts	49.139999
1	2011-08-17 00:03:06.257+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:03:06.326+09	testdb	public	pgbench_tellers	0
1	2011-08-17 00:04:06.83+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:04:07.25+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:05:06.369+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 00:05:06.497+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:06:06.373+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:06:06.461+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:07:06.461+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 00:07:06.589+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:08:06.537+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 00:08:06.66+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:09:06.513+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:09:06.601+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:10:06.60+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 00:10:06.728+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:11:06.647+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 00:11:06.766+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:11:06.805+09	testdb	public	pgbench_accounts	48.919998
1	2011-08-17 00:12:06.737+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:12:06.935+09	testdb	public	pgbench_tellers	0
1	2011-08-17 00:13:06.652+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 00:13:06.917+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:14:06.809+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:14:06.90+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:15:06.883+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 00:15:07.019+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:16:06.802+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 00:16:06.928+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:17:06.924+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:17:07.009+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:18:07.314+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:18:07.392+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:19:06.956+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:19:07.036+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:20:07.029+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:20:07.116+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:20:07.153+09	testdb	public	pgbench_accounts	49.07
1	2011-08-17 00:21:07.053+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:21:07.229+09	testdb	public	pgbench_tellers	0
1	2011-08-17 00:22:07.40+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:22:07.614+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:23:07.142+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 00:23:07.207+09	testdb	public	pgbench_history	40.889999
1	2011-08-17 00:23:48.159+09	testdb	public	pgbench_tellers	0
1	2011-08-17 00:24:07.199+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:24:07.325+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:25:07.313+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:25:07.404+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:26:07.542+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:26:07.645+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:27:07.729+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:27:07.81+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:28:07.346+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:28:07.437+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:29:07.387+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 00:29:07.493+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:29:07.566+09	testdb	public	pgbench_accounts	49.130001
1	2011-08-17 00:30:08.393+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:30:08.462+09	testdb	public	pgbench_tellers	0
1	2011-08-17 00:31:07.581+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 00:31:07.83+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:32:07.48+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:32:07.567+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:33:07.562+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:33:07.65+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:34:08.049+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:34:08.136+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:35:07.618+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:35:07.713+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:36:07.749+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:36:07.836+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:37:07.73+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:37:07.827+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:38:07.792+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:38:07.881+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 00:38:07.943+09	testdb	public	pgbench_accounts	49.299999
1	2011-08-17 00:39:07.812+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:39:07.888+09	testdb	public	pgbench_tellers	0
1	2011-08-17 00:40:07.932+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:40:08.143+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:41:07.903+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 00:41:08.01+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:42:07.988+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 00:42:08.088+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:43:08.064+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:43:08.16+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:44:08.098+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 00:44:08.211+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:45:08.47+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:45:08.556+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:46:08.15+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 00:46:08.26+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:47:08.276+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 00:47:08.375+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:47:08.418+09	testdb	public	pgbench_accounts	48.810001
1	2011-08-17 00:48:08.29+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:48:08.446+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 00:49:08.40+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 00:49:08.651+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:50:08.80+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:50:08.89+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:51:08.362+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:51:08.451+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:52:08.41+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:52:08.497+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:53:08.56+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:53:08.655+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:54:08.458+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 00:54:08.597+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:55:08.58+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:55:08.659+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:56:08.586+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:56:08.675+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:56:08.753+09	testdb	public	pgbench_accounts	49.02
1	2011-08-17 00:57:08.662+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 00:57:08.835+09	testdb	public	pgbench_tellers	0
1	2011-08-17 00:58:08.805+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 00:58:09.02+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 00:59:08.709+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 00:59:08.816+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:00:08.792+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 01:00:08.903+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:01:09.09+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:01:09.179+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:02:08.876+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 01:02:08.976+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:03:09.01+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:03:09.094+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:04:08.952+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 01:04:09.015+09	testdb	public	pgbench_history	38.68
1	2011-08-17 01:04:47.80+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:05:09.105+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:05:09.286+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:05:09.368+09	testdb	public	pgbench_accounts	48.880001
1	2011-08-17 01:06:09.078+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:06:09.209+09	testdb	public	pgbench_tellers	0
1	2011-08-17 01:07:09.167+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 01:07:09.428+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:08:09.054+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:08:09.144+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:09:09.136+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 01:09:09.244+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:10:09.328+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:10:09.41+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:11:09.211+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:11:09.301+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:12:09.328+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 01:12:09.436+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:13:09.354+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:13:09.444+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:14:09.398+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 01:14:09.505+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:14:09.586+09	testdb	public	pgbench_accounts	49.139999
1	2011-08-17 01:15:09.409+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:15:09.471+09	testdb	public	pgbench_tellers	0
1	2011-08-17 01:16:09.60+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:16:09.815+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:17:09.511+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 01:17:09.64+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:18:09.517+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 01:18:09.644+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:19:09.607+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:19:09.684+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:20:09.71+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:20:09.796+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:21:10.019+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:21:10.112+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:22:09.733+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:22:09.821+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:23:09.779+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:23:09.875+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:23:09.947+09	testdb	public	pgbench_accounts	49.049999
1	2011-08-17 01:24:09.923+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:24:09.995+09	testdb	public	pgbench_tellers	0
1	2011-08-17 01:25:09.953+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 01:25:10.201+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:26:09.872+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:26:09.959+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:27:09.955+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:27:10.043+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:28:10.057+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:28:10.142+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:29:10.493+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:29:10.58+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:30:10.113+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 01:30:10.252+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:31:10.096+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:31:10.184+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:32:10.187+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:32:10.266+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:32:10.33+09	testdb	public	pgbench_accounts	48.990002
1	2011-08-17 01:33:10.208+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:33:10.264+09	testdb	public	pgbench_tellers	0
1	2011-08-17 01:34:10.316+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:34:10.353+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:35:10.238+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 01:35:10.506+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:36:10.351+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:36:10.436+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:37:10.468+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:37:10.549+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:38:10.566+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:38:10.603+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:39:10.466+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:39:10.553+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:40:10.486+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 01:40:10.614+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:41:10.577+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:41:10.66+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:41:10.699+09	testdb	public	pgbench_accounts	48.830002
1	2011-08-17 01:42:10.771+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:42:10.855+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:43:10.762+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 01:43:11.016+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 01:44:10.991+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:44:11.078+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:45:10.724+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:45:10.812+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:46:10.806+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:46:10.892+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:47:10.82+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:47:10.912+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:48:10.857+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:48:10.948+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:49:10.934+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:49:10.983+09	testdb	public	pgbench_history	38.950001
1	2011-08-17 01:49:49.977+09	testdb	public	pgbench_tellers	0
1	2011-08-17 01:50:10.998+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:50:11.163+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:50:11.197+09	testdb	public	pgbench_accounts	48.93
1	2011-08-17 01:51:11.423+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:51:11.649+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:52:11.155+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:52:11.366+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 01:53:11.063+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 01:53:11.17+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:54:11.067+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 01:54:11.196+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:55:11.152+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 01:55:11.231+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:56:11.334+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 01:56:11.431+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:57:11.205+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 01:57:11.30+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:58:11.288+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 01:58:11.395+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:59:11.343+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 01:59:11.467+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 01:59:11.502+09	testdb	public	pgbench_accounts	49.009998
1	2011-08-17 02:00:12.185+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:00:12.318+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:01:11.649+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 02:01:11.922+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:02:11.516+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:02:11.608+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:03:11.497+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:03:11.586+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:04:11.534+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 02:04:11.662+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:05:11.559+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:05:11.658+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:06:11.634+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:06:11.723+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:07:11.675+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:07:11.779+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:08:11.712+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:08:11.803+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:08:11.892+09	testdb	public	pgbench_accounts	49.049999
1	2011-08-17 02:09:12.329+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:09:12.564+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:10:11.871+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:10:12.083+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:11:11.832+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 02:11:11.939+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:12:11.887+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 02:12:11.991+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:13:11.878+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:13:11.97+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:14:12.021+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 02:14:12.125+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:15:12.019+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:15:12.095+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:16:12.07+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 02:16:12.176+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:17:12.123+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:17:12.207+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:17:12.254+09	testdb	public	pgbench_accounts	49.049999
1	2011-08-17 02:18:12.19+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:18:12.302+09	testdb	public	pgbench_tellers	0
1	2011-08-17 02:19:12.298+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 02:19:12.559+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:20:12.215+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:20:12.306+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:21:12.28+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 02:21:12.408+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:22:12.325+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:22:12.408+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:23:12.362+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:23:12.443+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:24:12.395+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:24:12.484+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:25:12.69+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 02:25:12.927+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:26:12.443+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:26:12.536+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:26:12.615+09	testdb	public	pgbench_accounts	49.240002
1	2011-08-17 02:27:12.488+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:27:12.56+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:28:12.54+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:28:12.758+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:29:12.713+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 02:29:12.84+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:30:12.65+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 02:30:12.757+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:31:12.685+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:31:12.774+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:32:12.733+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 02:32:12.849+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:33:13.18+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:33:13.27+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:34:12.829+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 02:34:12.936+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:35:12.875+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 02:35:12.975+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:35:13.019+09	testdb	public	pgbench_accounts	49.560001
1	2011-08-17 02:36:12.86+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:36:12.932+09	testdb	public	pgbench_tellers	0
1	2011-08-17 02:37:13.044+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 02:37:13.306+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:38:13.104+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 02:38:13.237+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:39:12.984+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:39:13.03+09	testdb	public	pgbench_history	40.779999
1	2011-08-17 02:39:53.849+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 02:40:13.185+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:40:13.392+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:41:14.451+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:41:14.689+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:42:13.161+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:42:13.249+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:43:13.284+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:43:13.367+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:44:13.634+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:44:13.725+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:44:13.802+09	testdb	public	pgbench_accounts	49.18
1	2011-08-17 02:45:13.265+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:45:13.334+09	testdb	public	pgbench_tellers	0
1	2011-08-17 02:46:13.31+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:46:13.523+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:47:13.478+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 02:47:13.619+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:48:13.405+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:48:13.488+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:49:14.881+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:49:14.961+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:50:13.572+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:50:13.654+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:51:13.616+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:51:13.707+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:52:13.626+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:52:13.715+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:53:13.632+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 02:53:13.77+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:53:13.845+09	testdb	public	pgbench_accounts	49.09
1	2011-08-17 02:54:13.661+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 02:54:13.728+09	testdb	public	pgbench_tellers	0
1	2011-08-17 02:55:13.688+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 02:55:13.949+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:56:13.766+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 02:56:13.874+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:57:14.383+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:57:14.462+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:58:13.959+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 02:58:14.064+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 02:59:13.906+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 02:59:13.994+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:00:13.948+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 03:00:14.056+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:01:13.994+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:01:14.087+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:02:13.993+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:02:14.084+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:02:14.159+09	testdb	public	pgbench_accounts	48.810001
1	2011-08-17 03:03:14.103+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:03:14.249+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:04:14.645+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:04:15.043+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:05:14.144+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 03:05:14.252+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:06:14.186+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 03:06:14.292+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:07:14.256+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:07:14.348+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:08:14.275+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 03:08:14.385+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:09:14.316+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:09:14.401+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:10:14.333+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:10:14.411+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:11:14.396+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 03:11:14.50+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:11:14.577+09	testdb	public	pgbench_accounts	49.169998
1	2011-08-17 03:12:14.483+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:12:14.663+09	testdb	public	pgbench_tellers	0
1	2011-08-17 03:13:14.571+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 03:13:14.834+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:14:14.49+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 03:14:14.615+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:15:14.592+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:15:14.671+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:16:14.661+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:16:14.747+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:17:14.633+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:17:14.719+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:18:14.70+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:18:14.778+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:19:15.142+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:19:15.645+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:20:14.752+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:20:14.84+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:20:14.881+09	testdb	public	pgbench_accounts	49.330002
1	2011-08-17 03:21:14.811+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:21:14.872+09	testdb	public	pgbench_tellers	0
1	2011-08-17 03:22:14.976+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:22:15.189+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 03:23:14.843+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 03:23:14.969+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:24:14.905+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 03:24:15.037+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:25:15.343+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:25:15.877+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:26:15.015+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:26:15.102+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:27:15.091+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:27:15.181+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:28:15.094+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:28:15.172+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:29:15.23+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:29:15.319+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:29:15.358+09	testdb	public	pgbench_accounts	48.990002
1	2011-08-17 03:30:15.176+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:30:15.248+09	testdb	public	pgbench_tellers	0
1	2011-08-17 03:31:15.337+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 03:31:15.589+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:32:15.287+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:32:15.376+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:33:15.30+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:33:15.39+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:34:15.413+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 03:34:15.468+09	testdb	public	pgbench_history	52.799999
1	2011-08-17 03:35:08.373+09	testdb	public	pgbench_tellers	0
1	2011-08-17 03:35:15.392+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:35:15.437+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:36:15.52+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 03:36:15.648+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:37:15.457+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 03:37:15.562+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:38:15.503+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:38:15.592+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:38:15.636+09	testdb	public	pgbench_accounts	48.98
1	2011-08-17 03:39:15.739+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 03:39:15.96+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 03:40:15.77+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 03:40:16.025+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:41:15.563+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 03:41:15.673+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:42:15.98+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 03:42:16.11+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:43:15.675+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:43:15.757+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:44:15.752+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 03:44:15.882+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:45:15.753+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 03:45:15.886+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:46:15.902+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:46:16.103+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:47:15.942+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 03:47:16.093+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:47:16.174+09	testdb	public	pgbench_accounts	53.349998
1	2011-08-17 03:48:15.955+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:48:16.026+09	testdb	public	pgbench_tellers	0
1	2011-08-17 03:49:16.047+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 03:49:16.308+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:50:16.003+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 03:50:16.123+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:51:16.023+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:51:16.106+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:52:16.085+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:52:16.174+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:53:16.496+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:53:16.576+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:54:16.154+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:54:16.245+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:55:16.659+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 03:55:16.745+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:56:16.211+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:56:16.302+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:56:16.546+09	testdb	public	pgbench_accounts	49.389999
1	2011-08-17 03:57:16.263+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 03:57:16.405+09	testdb	public	pgbench_tellers	0
1	2011-08-17 03:58:17.239+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 03:58:17.513+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 03:59:16.321+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 03:59:16.411+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:00:16.44+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:00:16.541+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:01:16.461+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:01:16.548+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:02:16.483+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 04:02:16.591+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:03:16.807+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:03:17.082+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:04:16.876+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:04:16.955+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:05:16.618+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 04:05:16.729+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:05:16.809+09	testdb	public	pgbench_accounts	49.419998
1	2011-08-17 04:06:16.652+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:06:16.724+09	testdb	public	pgbench_tellers	0
1	2011-08-17 04:07:16.771+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 04:07:17.041+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:08:16.785+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:08:16.865+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:09:16.793+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:09:16.887+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:10:17.061+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:10:17.147+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:11:17.336+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:11:17.425+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:12:16.895+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:12:16.984+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:13:16.97+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:13:17.053+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:14:17.271+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:14:17.363+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:14:17.442+09	testdb	public	pgbench_accounts	49.59
1	2011-08-17 04:15:17.008+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:15:17.128+09	testdb	public	pgbench_tellers	0
1	2011-08-17 04:16:17.238+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:16:17.498+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:17:17.082+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:17:17.162+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:18:17.732+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:18:18.028+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:19:17.698+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:19:17.777+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:20:17.186+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 04:20:17.327+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:21:17.274+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:21:17.382+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:22:17.302+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:22:17.383+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:23:17.374+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:23:17.473+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:23:17.513+09	testdb	public	pgbench_accounts	49.09
1	2011-08-17 04:24:17.416+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:24:17.533+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:25:17.525+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:25:17.754+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:26:17.946+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:26:18.068+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:27:17.506+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:27:17.585+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:28:17.503+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 04:28:17.629+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:29:17.577+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:29:17.70+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:30:17.675+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:30:17.765+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:31:17.71+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:31:17.786+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:32:17.739+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:32:17.832+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:32:17.873+09	testdb	public	pgbench_accounts	49.41
1	2011-08-17 04:33:17.879+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:33:18.085+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:34:18.323+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 04:34:18.818+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 04:35:18.875+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:36:18.105+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:36:18.338+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:35:18.917+09	testdb	public	pgbench_history	77.839996
1	2011-08-17 04:36:36.811+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 04:37:18.202+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:37:18.497+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:38:18.172+09	testdb	public	pgbench_branches	0.11
1	2011-08-17 04:38:18.34+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 04:39:18.087+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 04:39:18.236+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 04:40:18.164+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:40:18.256+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 04:41:18.159+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:41:18.261+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 04:41:18.319+09	testdb	public	pgbench_accounts	49.490002
1	2011-08-17 04:42:18.176+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:42:18.254+09	testdb	public	pgbench_tellers	0
1	2011-08-17 04:43:18.239+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 04:43:18.502+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:44:18.24+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:44:18.352+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:45:18.197+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:45:18.309+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:46:18.281+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:46:18.392+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:47:18.285+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:47:18.439+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:48:18.329+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:48:18.441+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:49:18.493+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:49:18.599+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:50:18.49+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:50:18.595+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:50:18.691+09	testdb	public	pgbench_accounts	49.369999
1	2011-08-17 04:51:18.512+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:51:18.707+09	testdb	public	pgbench_tellers	0
1	2011-08-17 04:52:19.012+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 04:52:19.296+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 04:53:18.703+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:53:18.801+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:54:18.629+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 04:54:18.785+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:55:18.639+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 04:55:18.743+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:56:18.694+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 04:56:18.826+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:57:18.837+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 04:57:18.965+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:58:18.818+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 04:58:18.928+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:59:18.886+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 04:59:19.015+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 04:59:19.09+09	testdb	public	pgbench_accounts	49.23
1	2011-08-17 05:00:18.99+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:00:19.114+09	testdb	public	pgbench_tellers	0
1	2011-08-17 05:01:18.968+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 05:01:19.226+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 05:02:18.949+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:02:19.049+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:03:18.923+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:03:19.035+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:04:19.002+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:04:19.112+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:05:19.029+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:05:19.132+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:06:19.104+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:06:19.21+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:07:19.289+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:07:19.391+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:08:19.217+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:08:19.332+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:08:19.432+09	testdb	public	pgbench_accounts	49.43
1	2011-08-17 05:09:19.196+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:09:19.274+09	testdb	public	pgbench_tellers	0
1	2011-08-17 05:10:19.221+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 05:10:19.478+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:11:19.395+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:11:19.506+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:12:19.958+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:12:20.225+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:13:19.359+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:13:19.463+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:14:19.424+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:14:19.523+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:15:19.473+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:15:19.577+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:16:19.508+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:16:19.615+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:17:19.543+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:17:19.655+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:17:19.748+09	testdb	public	pgbench_accounts	49.52
1	2011-08-17 05:18:19.646+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:18:19.771+09	testdb	public	pgbench_tellers	0
1	2011-08-17 05:19:20.045+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:19:20.276+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 05:20:19.729+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 05:20:19.85+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:21:19.672+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:21:19.773+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:22:19.736+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 05:22:19.866+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:23:19.79+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:23:19.897+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:24:20.399+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:24:20.51+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:25:19.911+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 05:25:20.068+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:26:19.881+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:26:19.986+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:26:20.078+09	testdb	public	pgbench_accounts	49.25
1	2011-08-17 05:27:19.992+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:27:20.187+09	testdb	public	pgbench_tellers	0
1	2011-08-17 05:28:20.113+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 05:28:20.378+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:29:19.979+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:29:20.091+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:30:20.074+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:30:20.179+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:31:20.088+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:31:20.198+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:32:20.15+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:32:20.251+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:33:20.227+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 05:33:20.377+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:34:20.36+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:34:20.47+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:35:20.282+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:35:20.382+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:35:20.475+09	testdb	public	pgbench_accounts	49.450001
1	2011-08-17 05:36:20.253+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:36:20.474+09	testdb	public	pgbench_tellers	0
1	2011-08-17 05:37:20.43+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:37:20.656+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:38:20.374+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:38:20.486+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:39:20.431+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:39:20.547+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:40:20.453+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:40:20.564+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:41:20.464+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:41:20.576+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:42:21.30+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:43:20.719+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 05:43:20.963+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 05:42:21.348+09	testdb	public	pgbench_history	87.629997
1	2011-08-17 05:43:49.151+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 05:44:20.597+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:44:20.881+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:44:20.973+09	testdb	public	pgbench_accounts	50.779999
1	2011-08-17 05:45:20.902+09	testdb	public	pgbench_branches	0.090000004
1	2011-08-17 05:45:21.053+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 05:46:20.999+09	testdb	public	pgbench_branches	0.13
1	2011-08-17 05:46:21.342+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:47:20.691+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:47:20.806+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:48:20.765+09	testdb	public	pgbench_branches	0.13
1	2011-08-17 05:48:20.986+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:49:20.786+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:49:20.887+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:50:21.307+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:50:21.409+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:51:20.935+09	testdb	public	pgbench_branches	0.11
1	2011-08-17 05:51:21.13+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:52:20.907+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:52:21.02+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:53:20.978+09	testdb	public	pgbench_branches	0.11
1	2011-08-17 05:53:21.169+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:53:21.265+09	testdb	public	pgbench_accounts	49.380001
1	2011-08-17 05:54:21.002+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 05:54:21.141+09	testdb	public	pgbench_tellers	0
1	2011-08-17 05:55:21.129+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:55:21.378+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:56:21.109+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:56:21.214+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:57:21.681+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:57:21.793+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:58:21.182+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 05:58:21.296+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 05:59:21.287+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 05:59:21.389+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:00:21.221+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:00:21.339+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:01:21.314+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:01:21.435+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:02:21.302+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:02:21.422+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:02:21.521+09	testdb	public	pgbench_accounts	49.169998
1	2011-08-17 06:03:21.435+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:03:21.681+09	testdb	public	pgbench_tellers	0
1	2011-08-17 06:04:21.714+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 06:04:22.077+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:05:21.557+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:05:21.675+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:06:21.498+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:06:21.612+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:07:21.528+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:07:21.628+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:08:21.56+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:08:21.674+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:09:21.667+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:09:21.772+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:10:21.618+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:10:21.736+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:11:21.703+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:11:21.806+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:11:21.898+09	testdb	public	pgbench_accounts	49.369999
1	2011-08-17 06:12:21.828+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:12:22.05+09	testdb	public	pgbench_tellers	0
1	2011-08-17 06:13:21.78+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:13:22.028+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:14:21.809+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 06:14:21.965+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:15:21.952+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:15:22.05+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:16:21.882+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 06:16:22.013+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:17:21.936+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 06:17:22.061+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:18:21.999+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:18:22.099+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:19:22.051+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 06:19:22.182+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:20:22.013+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:20:22.122+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:20:22.22+09	testdb	public	pgbench_accounts	49.470001
1	2011-08-17 06:21:22.053+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:21:22.142+09	testdb	public	pgbench_tellers	0
1	2011-08-17 06:22:22.556+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 06:22:22.852+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 06:23:22.157+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:23:22.269+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:24:22.20+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:24:22.312+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:25:22.241+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:25:22.346+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:26:22.324+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:26:22.427+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:27:22.383+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:27:22.495+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:28:22.387+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:28:22.501+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:29:22.409+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:29:22.519+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:29:22.613+09	testdb	public	pgbench_accounts	49.59
1	2011-08-17 06:30:22.43+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:30:22.51+09	testdb	public	pgbench_tellers	0
1	2011-08-17 06:31:22.581+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:31:22.816+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:32:22.455+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 06:32:22.604+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:33:22.945+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:33:23.371+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:34:22.596+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 06:34:22.729+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:35:22.652+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 06:35:22.781+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:36:22.715+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:36:22.814+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:37:22.684+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 06:37:22.836+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:38:22.785+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 06:38:22.911+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:38:23.013+09	testdb	public	pgbench_accounts	48.93
1	2011-08-17 06:39:22.911+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:39:23.132+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 06:40:23.394+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 06:40:23.995+09	testdb	public	pgbench_tellers	0.18000001
1	2011-08-17 06:41:22.897+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:41:23.005+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:42:22.912+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 06:42:23.064+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:43:22.957+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:43:23.059+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:44:22.975+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:44:23.08+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:45:23.042+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:45:23.147+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:46:23.066+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:46:23.18+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:47:23.079+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 06:47:23.231+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:47:23.328+09	testdb	public	pgbench_accounts	49.549999
1	2011-08-17 06:48:23.162+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:48:23.332+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 06:49:23.317+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:49:23.552+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:50:23.228+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 06:50:23.359+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:51:23.283+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 06:51:23.435+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:52:23.284+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:52:23.385+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:53:23.376+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 06:53:23.504+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:54:23.453+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:54:23.57+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:55:23.439+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 06:55:23.569+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 06:56:23.546+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 06:57:23.728+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 06:57:24.051+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 06:56:23.609+09	testdb	public	pgbench_history	105.75
1	2011-08-17 06:58:09.564+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 06:58:23.709+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 06:58:23.852+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 06:57:24.083+09	testdb	public	pgbench_accounts	75.239998
1	2011-08-17 06:59:23.961+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 06:59:24.166+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 07:00:23.953+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 07:00:24.452+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 07:01:23.676+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:01:23.794+09	testdb	public	pgbench_tellers	0
1	2011-08-17 07:02:23.698+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:02:23.759+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:03:23.751+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:03:23.819+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:04:23.834+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:04:23.893+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:05:23.818+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:05:23.883+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:06:23.914+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:06:23.985+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:06:24.03+09	testdb	public	pgbench_accounts	49.310001
1	2011-08-17 07:07:24.008+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:07:24.162+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:08:23.934+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 07:08:24.195+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:09:24.15+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:09:24.51+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:10:24.141+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:10:24.223+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:11:24.133+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 07:11:24.243+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:12:24.102+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:12:24.18+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:13:24.159+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 07:13:24.265+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:14:24.248+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 07:14:24.36+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:15:24.219+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:15:24.306+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:15:24.344+09	testdb	public	pgbench_accounts	49.450001
1	2011-08-17 07:16:24.761+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 07:16:25.015+09	testdb	public	pgbench_tellers	0
1	2011-08-17 07:17:24.732+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:17:25.089+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:18:24.335+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 07:18:24.443+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:19:24.748+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 07:19:24.876+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:20:24.392+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:20:24.473+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:21:24.406+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 07:21:24.54+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:22:24.462+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:22:24.543+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:23:24.522+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 07:23:24.63+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:24:25.115+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 07:24:25.655+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:24:25.884+09	testdb	public	pgbench_accounts	49.549999
1	2011-08-17 07:25:24.56+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:25:24.631+09	testdb	public	pgbench_tellers	0
1	2011-08-17 07:26:24.728+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 07:26:24.995+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 07:27:24.696+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 07:27:24.828+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 07:28:24.841+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:28:24.936+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:29:24.769+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:29:24.858+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:30:25.059+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:30:25.146+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:31:24.83+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:31:24.917+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:32:24.909+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:32:25.007+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:33:24.884+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:33:24.973+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:33:25.052+09	testdb	public	pgbench_accounts	49.490002
1	2011-08-17 07:34:24.948+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:34:25.01+09	testdb	public	pgbench_tellers	0
1	2011-08-17 07:35:25.09+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:35:25.126+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 07:36:24.995+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:36:25.215+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 07:37:25.101+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:37:25.187+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:38:25.413+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:38:25.623+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:39:25.145+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:39:25.223+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:40:25.199+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:40:25.286+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:41:25.21+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:41:25.297+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:42:25.275+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 07:42:25.409+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:42:25.448+09	testdb	public	pgbench_accounts	49.330002
1	2011-08-17 07:43:25.292+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:43:25.361+09	testdb	public	pgbench_tellers	0
1	2011-08-17 07:44:25.415+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 07:44:25.677+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:45:25.345+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:45:25.435+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:46:25.337+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:46:25.428+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:47:25.471+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 07:47:25.569+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:48:25.429+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:48:25.515+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:49:25.493+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 07:49:25.603+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:50:25.568+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 07:50:25.703+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:51:25.535+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:51:25.634+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:51:25.71+09	testdb	public	pgbench_accounts	49.380001
1	2011-08-17 07:52:26.197+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 07:52:26.506+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 07:53:26.106+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 07:53:26.316+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:54:25.675+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 07:54:25.783+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:55:25.735+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 07:55:25.842+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:56:25.808+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:56:25.901+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:57:25.795+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 07:57:25.905+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:58:25.827+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 07:58:25.954+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 07:59:25.886+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 07:59:25.976+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:00:25.942+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:00:26.044+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:00:26.125+09	testdb	public	pgbench_accounts	49.73
1	2011-08-17 08:01:27.073+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:01:27.22+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 08:02:26.427+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 08:02:26.802+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:03:26.042+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:03:26.152+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:04:26.057+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:04:26.145+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:05:26.134+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:05:26.223+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:06:26.416+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:06:26.956+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:07:26.169+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:07:26.259+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:08:26.218+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:08:26.305+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:09:26.251+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:09:26.342+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:09:26.42+09	testdb	public	pgbench_accounts	49.27
1	2011-08-17 08:10:26.247+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:10:26.315+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 08:11:26.25+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:11:26.472+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:12:26.452+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 08:12:26.57+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:13:26.366+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:13:26.475+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:14:26.381+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:14:26.461+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:15:26.456+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 08:15:26.564+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:16:26.499+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:16:26.587+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:17:26.491+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 08:17:26.62+09	testdb	public	pgbench_tellers	0.059999999
1	2011-08-17 08:18:26.958+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:19:26.708+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 08:19:26.94+09	testdb	public	pgbench_tellers	0.02
1	2011-08-17 08:20:26.981+09	testdb	public	pgbench_branches	0.1
1	2011-08-17 08:20:27.482+09	testdb	public	pgbench_tellers	0.050000001
1	2011-08-17 08:18:27.19+09	testdb	public	pgbench_history	124.98
1	2011-08-17 08:19:26.976+09	testdb	public	pgbench_accounts	84.169998
1	2011-08-17 08:21:26.645+09	testdb	public	pgbench_branches	0.11
1	2011-08-17 08:21:26.778+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:22:27.081+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:22:27.778+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 08:23:27.491+09	testdb	public	pgbench_branches	0.14
1	2011-08-17 08:23:28.239+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 08:24:26.76+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:24:26.851+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 08:25:26.834+09	testdb	public	pgbench_branches	0.11
1	2011-08-17 08:25:27.005+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 08:26:26.828+09	testdb	public	pgbench_branches	0.12
1	2011-08-17 08:26:27.019+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 08:27:26.903+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:27:26.987+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 08:28:27.002+09	testdb	public	pgbench_branches	0.11
1	2011-08-17 08:28:27.172+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 08:29:26.981+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:29:27.074+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 08:29:27.191+09	testdb	public	pgbench_accounts	49.439999
1	2011-08-17 08:30:27.103+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 08:30:27.40+09	testdb	public	pgbench_tellers	0.039999999
1	2011-08-17 08:31:27.695+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 08:31:28.081+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:32:27.682+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:32:27.816+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:33:27.352+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 08:33:27.504+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:34:27.294+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:34:27.426+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:35:27.211+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:35:27.355+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:36:27.299+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:36:27.441+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:37:27.289+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:37:27.422+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:38:27.319+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 08:38:27.473+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:38:27.613+09	testdb	public	pgbench_accounts	49.630001
1	2011-08-17 08:39:27.473+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:39:27.60+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 08:40:27.513+09	testdb	public	pgbench_branches	0.1
1	2011-08-17 08:40:27.894+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:41:27.427+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:41:27.569+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:42:28.286+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:42:28.418+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:43:27.498+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 08:43:27.651+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:44:27.61+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 08:44:27.753+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:45:27.535+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:45:27.669+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:46:27.618+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 08:46:27.777+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:47:27.687+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:47:27.82+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:47:27.955+09	testdb	public	pgbench_accounts	49.389999
1	2011-08-17 08:48:27.714+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:48:27.954+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 08:49:27.812+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 08:49:28.119+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 08:50:27.795+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:50:27.937+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:51:28.014+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 08:51:28.178+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:52:27.818+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:52:27.923+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 08:53:27.85+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:53:27.984+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:54:27.924+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:54:28.054+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:55:28.127+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:55:28.256+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:56:28.04+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:56:28.166+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 08:56:28.308+09	testdb	public	pgbench_accounts	49.52
1	2011-08-17 08:57:27.996+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 08:57:28.091+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 08:58:28.122+09	testdb	public	pgbench_branches	0.079999998
1	2011-08-17 08:58:28.418+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 08:59:28.142+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 08:59:28.267+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:00:28.302+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:00:28.427+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:01:28.131+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:01:28.265+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:02:28.20+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:02:28.331+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:03:28.577+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:03:28.864+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:04:28.309+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:04:28.421+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:05:28.387+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:05:28.511+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:05:28.648+09	testdb	public	pgbench_accounts	49.59
1	2011-08-17 09:06:28.286+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:06:28.37+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 09:07:28.442+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 09:07:28.744+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:08:28.345+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:08:28.479+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:09:28.783+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:09:28.976+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:10:28.469+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:10:28.591+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:11:28.479+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:11:28.612+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:12:28.536+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:12:28.661+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:13:28.565+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:13:28.699+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:14:28.591+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:14:28.715+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:14:28.855+09	testdb	public	pgbench_accounts	49.84
1	2011-08-17 09:15:28.694+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:15:28.905+09	testdb	public	pgbench_tellers	0.079999998
1	2011-08-17 09:16:28.971+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:16:29.235+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:17:28.875+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 09:17:29.047+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:18:28.789+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:18:28.915+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:19:28.722+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 09:19:28.896+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:20:29.06+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 09:20:29.228+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:21:29.34+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:21:29.47+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:22:28.939+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 09:22:29.082+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:23:28.942+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:23:29.067+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:23:29.20+09	testdb	public	pgbench_accounts	49.919998
1	2011-08-17 09:24:28.907+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:24:29.002+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 09:25:29.124+09	testdb	public	pgbench_branches	0.07
1	2011-08-17 09:25:29.409+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:26:29.048+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:26:29.158+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:27:29.074+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:27:29.199+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:28:29.471+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:28:29.822+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:29:29.128+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:29:29.265+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:30:29.198+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:30:29.32+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:31:29.208+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:31:29.323+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:32:29.258+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:32:29.382+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:32:29.518+09	testdb	public	pgbench_accounts	49.639999
1	2011-08-17 09:33:29.253+09	testdb	public	pgbench_branches	0.039999999
1	2011-08-17 09:33:29.361+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 09:34:29.547+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:34:29.804+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:35:29.344+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 09:35:29.516+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:36:29.955+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:36:30.06+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:37:29.413+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 09:37:29.567+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:38:29.428+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 09:38:29.595+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:39:29.447+09	testdb	public	pgbench_branches	0.02
1	2011-08-17 09:39:29.57+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:40:29.546+09	testdb	public	pgbench_branches	0.050000001
1	2011-08-17 09:40:29.679+09	testdb	public	pgbench_tellers	0.14
1	2011-08-17 09:41:29.571+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:41:29.706+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:41:29.846+09	testdb	public	pgbench_accounts	49.790001
1	2011-08-17 09:42:29.58+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:42:29.697+09	testdb	public	pgbench_tellers	0.1
1	2011-08-17 09:43:29.977+09	testdb	public	pgbench_branches	0.059999999
1	2011-08-17 09:43:30.273+09	testdb	public	pgbench_tellers	0.12
1	2011-08-17 09:44:29.622+09	testdb	public	pgbench_branches	0.029999999
1	2011-08-17 09:44:29.755+09	testdb	public	pgbench_tellers	0.12
\.


--
-- Data for Name: autovacuum; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY autovacuum (instid, start, database, schema, "table", index_scans, page_removed, page_remain, tup_removed, tup_remain, duration) FROM stdin;
1	2011-08-16 17:36:38.158+09	testdb	public	pgbench_branches	0	0	1	67	11	0
1	2011-08-16 17:37:38.256+09	testdb	public	pgbench_branches	0	0	1	11	11	0
1	2011-08-16 17:38:39.329+09	testdb	public	pgbench_branches	0	0	1	123	10	0
1	2011-08-16 17:37:08.892+09	testdb	public	pgbench_tellers	1	0	2	62	101	0
1	2011-08-16 17:39:38.309+09	testdb	public	pgbench_branches	0	0	1	189	11	0
1	2011-08-16 17:38:08.991+09	testdb	public	pgbench_tellers	0	0	2	64	101	0
1	2011-08-16 17:40:39.735+09	testdb	public	pgbench_branches	0	0	1	102	10	0
1	2011-08-16 17:39:10.488+09	testdb	public	pgbench_tellers	0	0	2	92	100	0
1	2011-08-16 17:41:38.502+09	testdb	public	pgbench_branches	0	0	1	171	11	0
1	2011-08-16 17:40:09.405+09	testdb	public	pgbench_tellers	1	0	2	86	101	0
1	2011-08-16 17:42:38.491+09	testdb	public	pgbench_branches	1	0	2	110	11	0
1	2011-08-16 17:41:09.482+09	testdb	public	pgbench_tellers	1	0	2	91	101	0
1	2011-08-16 17:43:38.826+09	testdb	public	pgbench_branches	0	0	2	193	11	0
1	2011-08-16 17:42:11.118+09	testdb	public	pgbench_tellers	0	0	2	123	100	0
1	2011-08-16 17:44:38.59+09	testdb	public	pgbench_branches	0	0	2	189	11	0
1	2011-08-16 17:43:09.775+09	testdb	public	pgbench_tellers	1	0	3	4	101	0
1	2011-08-16 17:45:39.61+09	testdb	public	pgbench_branches	1	0	40	131	10	0.039999999
1	2011-08-16 17:44:10.74+09	testdb	public	pgbench_tellers	1	0	48	131	100	0.039999999
1	2011-08-16 17:46:05.774+09	testdb	public	pgbench_branches	0	0	40	61	44	0.13
1	2011-08-16 17:44:55.268+09	testdb	public	pgbench_tellers	1	0	48	234	116	0.13
1	2011-08-16 17:47:39.711+09	testdb	public	pgbench_branches	1	39	1	34	10	0.02
1	2011-08-16 17:46:03.814+09	testdb	public	pgbench_tellers	0	0	48	293	106	0.039999999
1	2011-08-16 17:47:11.261+09	testdb	public	pgbench_tellers	0	0	48	206	100	0.039999999
1	2011-08-16 17:49:39.761+09	testdb	public	pgbench_branches	0	0	1	104	10	0
1	2011-08-16 17:48:04.852+09	testdb	public	pgbench_tellers	0	0	48	311	105	0.039999999
1	2011-08-16 17:50:39.816+09	testdb	public	pgbench_branches	0	0	1	30	10	0
1	2011-08-16 17:49:08.643+09	testdb	public	pgbench_tellers	1	0	48	178	103	0.02
1	2011-08-16 17:51:38.874+09	testdb	public	pgbench_branches	1	0	2	167	11	0
1	2011-08-16 17:50:05.983+09	testdb	public	pgbench_tellers	0	0	48	446	104	0.039999999
1	2011-08-16 17:52:39.419+09	testdb	public	pgbench_branches	0	0	2	102	11	0
1	2011-08-16 17:51:09.505+09	testdb	public	pgbench_tellers	1	0	48	115	103	0.02
1	2011-08-16 17:53:39.995+09	testdb	public	pgbench_branches	1	0	3	37	10	0.02
1	2011-08-16 17:52:10.346+09	testdb	public	pgbench_tellers	0	0	48	520	100	0.039999999
1	2011-08-16 17:54:39.35+09	testdb	public	pgbench_branches	1	0	42	20	11	0.11
1	2011-08-16 17:53:11.995+09	testdb	public	pgbench_tellers	1	0	53	80	101	0.11
1	2011-08-16 17:53:31.241+09	testdb	public	pgbench_tellers	0	0	53	311	139	0.15000001
1	2011-08-16 17:56:40.228+09	testdb	public	pgbench_branches	1	0	42	6	10	0.13
1	2011-08-16 17:55:12.567+09	testdb	public	pgbench_tellers	1	0	53	501	100	0.02
1	2011-08-16 17:57:39.212+09	testdb	public	pgbench_branches	1	0	42	119	11	0.02
1	2011-08-16 17:56:07.303+09	testdb	public	pgbench_tellers	0	0	53	227	103	0.039999999
1	2011-08-16 17:58:40.219+09	testdb	public	pgbench_branches	0	41	1	173	10	0.039999999
1	2011-08-16 17:57:10.333+09	testdb	public	pgbench_tellers	0	0	53	391	100	0.039999999
1	2011-08-16 17:59:39.681+09	testdb	public	pgbench_branches	0	0	1	95	11	0
1	2011-08-16 17:58:12.521+09	testdb	public	pgbench_tellers	1	0	53	404	101	0.02
1	2011-08-16 18:00:39.275+09	testdb	public	pgbench_branches	1	0	4	64	11	0
1	2011-08-16 17:59:06.391+09	testdb	public	pgbench_tellers	0	0	53	348	104	0.039999999
1	2011-08-16 18:01:39.323+09	testdb	public	pgbench_branches	0	0	4	170	11	0.02
1	2011-08-16 18:00:06.409+09	testdb	public	pgbench_tellers	0	0	53	379	104	0.039999999
1	2011-08-16 18:01:12.585+09	testdb	public	pgbench_tellers	1	0	53	329	101	0.02
1	2011-08-16 18:03:40.429+09	testdb	public	pgbench_branches	1	0	45	197	10	0.059999999
1	2011-08-16 18:02:10.543+09	testdb	public	pgbench_tellers	1	4	49	324	100	0.07
1	2011-08-16 18:04:18.572+09	testdb	public	pgbench_branches	0	0	45	177	32	0.090000004
1	2011-08-16 18:02:35.765+09	testdb	public	pgbench_tellers	0	0	49	287	135	0.13
1	2011-08-16 18:05:39.59+09	testdb	public	pgbench_branches	0	0	45	229	11	0
1	2011-08-16 18:04:11.593+09	testdb	public	pgbench_tellers	1	0	49	319	103	0.039999999
1	2011-08-16 18:06:38.553+09	testdb	public	pgbench_branches	1	0	45	301	12	0.039999999
1	2011-08-16 18:05:10.67+09	testdb	public	pgbench_tellers	0	0	49	476	100	0.059999999
1	2011-08-16 18:07:39.65+09	testdb	public	pgbench_branches	0	0	45	327	11	0.02
1	2011-08-16 18:06:09.73+09	testdb	public	pgbench_tellers	0	0	49	482	101	0.039999999
1	2011-08-16 18:08:40.654+09	testdb	public	pgbench_branches	0	0	45	257	10	0.039999999
1	2011-08-16 18:07:12.362+09	testdb	public	pgbench_tellers	1	0	49	384	102	0.039999999
1	2011-08-16 18:09:39.727+09	testdb	public	pgbench_branches	1	0	45	143	11	0.059999999
1	2011-08-16 18:08:09.956+09	testdb	public	pgbench_tellers	0	0	49	782	101	0.039999999
1	2011-08-16 18:10:39.738+09	testdb	public	pgbench_branches	0	0	45	177	11	0.02
1	2011-08-16 18:09:07.915+09	testdb	public	pgbench_tellers	0	0	49	474	103	0.039999999
1	2011-08-16 18:11:40.791+09	testdb	public	pgbench_branches	0	0	45	263	10	0.039999999
1	2011-08-16 18:10:10.923+09	testdb	public	pgbench_tellers	0	0	49	450	100	0.039999999
1	2011-08-16 18:12:39.788+09	testdb	public	pgbench_branches	1	0	45	57	11	0.02
1	2011-08-16 18:11:15.109+09	testdb	public	pgbench_tellers	1	0	60	1215	100	0.13
1	2011-08-16 18:11:39.101+09	testdb	public	pgbench_tellers	0	0	60	168	132	0.17
1	2011-08-16 18:14:40.04+09	testdb	public	pgbench_branches	1	0	45	41	11	0.13
1	2011-08-16 18:13:01.198+09	testdb	public	pgbench_tellers	0	0	60	360	110	0.039999999
1	2011-08-16 18:15:39.961+09	testdb	public	pgbench_branches	0	0	45	30	11	0.02
1	2011-08-16 18:13:58.039+09	testdb	public	pgbench_tellers	0	0	60	339	113	0.039999999
1	2011-08-16 18:16:40.986+09	testdb	public	pgbench_branches	0	40	5	178	10	0.039999999
1	2011-08-16 18:15:14.50+09	testdb	public	pgbench_tellers	1	0	60	233	101	0.039999999
1	2011-08-16 18:17:40.039+09	testdb	public	pgbench_branches	1	0	5	80	11	0.02
1	2011-08-16 18:16:10.13+09	testdb	public	pgbench_tellers	0	0	60	493	101	0.039999999
1	2011-08-16 18:18:41.108+09	testdb	public	pgbench_branches	0	1	4	85	10	0.029999999
1	2011-08-16 18:17:11.187+09	testdb	public	pgbench_tellers	0	0	60	411	100	0.039999999
1	2011-08-16 18:19:41.624+09	testdb	public	pgbench_branches	0	0	4	156	10	0
1	2011-08-16 18:18:11.841+09	testdb	public	pgbench_tellers	0	0	60	385	100	0.039999999
1	2011-08-16 18:20:40.319+09	testdb	public	pgbench_branches	0	0	4	60	11	0
1	2011-08-16 18:19:15.267+09	testdb	public	pgbench_tellers	1	0	60	315	101	0.039999999
1	2011-08-16 18:21:41.176+09	testdb	public	pgbench_branches	1	0	45	96	10	0.02
1	2011-08-16 18:20:11.259+09	testdb	public	pgbench_tellers	1	0	60	220	100	0.02
1	2011-08-16 18:22:05.398+09	testdb	public	pgbench_branches	0	0	45	122	46	0.15000001
1	2011-08-16 18:20:42.643+09	testdb	public	pgbench_tellers	0	0	60	459	129	0.15000001
1	2011-08-16 18:23:40.292+09	testdb	public	pgbench_branches	0	0	45	63	11	0
1	2011-08-16 18:21:59.383+09	testdb	public	pgbench_tellers	0	0	60	479	112	0.039999999
1	2011-08-16 18:24:41.336+09	testdb	public	pgbench_branches	0	0	45	61	10	0.039999999
1	2011-08-16 18:23:11.422+09	testdb	public	pgbench_tellers	0	0	60	403	100	0.039999999
1	2011-08-16 18:24:16.774+09	testdb	public	pgbench_tellers	1	0	60	1720	100	0.039999999
1	2011-08-16 18:26:40.413+09	testdb	public	pgbench_branches	1	0	45	153	11	0.02
1	2011-08-16 18:25:10.532+09	testdb	public	pgbench_tellers	0	0	60	580	101	0.059999999
1	2011-08-16 18:27:36.532+09	testdb	public	pgbench_branches	0	0	45	111	15	0.039999999
1	2011-08-16 18:26:09.697+09	testdb	public	pgbench_tellers	0	0	60	613	102	0.059999999
1	2011-08-16 18:28:40.511+09	testdb	public	pgbench_branches	0	0	45	89	11	0
1	2011-08-16 18:27:09.607+09	testdb	public	pgbench_tellers	0	0	60	563	102	0.039999999
1	2011-08-16 18:29:41.568+09	testdb	public	pgbench_branches	0	39	6	98	10	0.039999999
1	2011-08-16 18:28:11.697+09	testdb	public	pgbench_tellers	0	0	60	536	100	0.059999999
1	2011-08-16 18:30:40.963+09	testdb	public	pgbench_branches	1	0	43	61	11	0.090000004
1	2011-08-16 18:29:11.184+09	testdb	public	pgbench_tellers	1	0	60	214	101	0.15000001
1	2011-08-16 18:31:41.091+09	testdb	public	pgbench_branches	0	0	43	94	11	0.090000004
1	2011-08-16 18:30:14.418+09	testdb	public	pgbench_tellers	1	0	60	245	104	0.13
1	2011-08-16 18:32:40.759+09	testdb	public	pgbench_branches	1	0	43	171	11	0.059999999
1	2011-08-16 18:31:11.291+09	testdb	public	pgbench_tellers	0	0	60	629	101	0.059999999
1	2011-08-16 18:33:41.785+09	testdb	public	pgbench_branches	0	0	43	97	10	0.02
1	2011-08-16 18:32:10.876+09	testdb	public	pgbench_tellers	0	0	60	658	101	0.039999999
1	2011-08-16 18:34:41.793+09	testdb	public	pgbench_branches	0	37	6	60	10	0.039999999
1	2011-08-16 18:33:11.898+09	testdb	public	pgbench_tellers	0	0	60	719	100	0.039999999
1	2011-08-16 18:35:41.813+09	testdb	public	pgbench_branches	0	0	6	101	10	0
1	2011-08-16 18:34:10.919+09	testdb	public	pgbench_tellers	0	0	60	666	101	0.039999999
1	2011-08-16 18:35:10.91+09	testdb	public	pgbench_tellers	0	0	60	593	101	0.039999999
1	2011-08-16 18:37:41.926+09	testdb	public	pgbench_branches	0	0	6	159	10	0
1	2011-08-16 18:36:17.786+09	testdb	public	pgbench_tellers	1	0	60	553	101	0.039999999
1	2011-08-16 18:38:40.938+09	testdb	public	pgbench_branches	1	0	6	46	11	0
1	2011-08-16 18:37:11.051+09	testdb	public	pgbench_tellers	0	0	60	568	101	0.039999999
1	2011-08-16 18:39:41.978+09	testdb	public	pgbench_branches	1	0	39	40	10	0.02
1	2011-08-16 18:38:12.048+09	testdb	public	pgbench_tellers	1	0	60	404	100	0.02
1	2011-08-16 18:40:18.118+09	testdb	public	pgbench_branches	0	0	39	30	34	0.11
1	2011-08-16 18:38:17.968+09	testdb	public	pgbench_tellers	0	0	60	546	155	0.15000001
1	2011-08-16 18:39:57.677+09	testdb	public	pgbench_tellers	0	0	60	440	115	0.039999999
1	2011-08-16 18:41:12.212+09	testdb	public	pgbench_tellers	0	0	60	487	100	0.039999999
1	2011-08-16 18:43:41.189+09	testdb	public	pgbench_branches	0	0	39	80	11	0
1	2011-08-16 18:42:03.282+09	testdb	public	pgbench_tellers	0	0	60	526	109	0.039999999
1	2011-08-16 18:44:41.186+09	testdb	public	pgbench_branches	0	0	39	121	11	0
1	2011-08-16 18:43:16.679+09	testdb	public	pgbench_tellers	1	0	60	546	103	0.039999999
1	2011-08-16 18:45:43.049+09	testdb	public	pgbench_branches	1	0	39	141	10	0.059999999
1	2011-08-16 18:44:08.167+09	testdb	public	pgbench_tellers	0	0	60	622	105	0.059999999
1	2011-08-16 18:46:41.357+09	testdb	public	pgbench_branches	0	0	39	86	11	0.02
1	2011-08-16 18:45:08.463+09	testdb	public	pgbench_tellers	0	0	60	651	104	0.059999999
1	2011-08-16 18:47:42.383+09	testdb	public	pgbench_branches	0	33	6	92	10	0.039999999
1	2011-08-16 18:46:12.502+09	testdb	public	pgbench_tellers	0	0	60	527	100	0.059999999
1	2011-08-16 18:48:41.444+09	testdb	public	pgbench_branches	1	0	43	318	11	0.02
1	2011-08-16 18:47:11.51+09	testdb	public	pgbench_tellers	1	0	60	456	101	0.02
1	2011-08-16 18:49:16.533+09	testdb	public	pgbench_branches	0	0	43	83	36	0.090000004
1	2011-08-16 18:47:30.742+09	testdb	public	pgbench_tellers	0	0	60	319	142	0.15000001
1	2011-08-16 18:50:28.56+09	testdb	public	pgbench_branches	0	0	43	327	24	0.039999999
1	2011-08-16 18:49:01.65+09	testdb	public	pgbench_tellers	0	0	60	430	111	0.039999999
1	2011-08-16 18:51:43.538+09	testdb	public	pgbench_branches	0	0	43	296	11	0
1	2011-08-16 18:50:14.785+09	testdb	public	pgbench_tellers	0	0	60	344	101	0.039999999
1	2011-08-16 18:52:42.706+09	testdb	public	pgbench_branches	0	0	43	204	10	0.039999999
1	2011-08-16 18:51:21.035+09	testdb	public	pgbench_tellers	0	0	60	358	101	0.039999999
1	2011-08-16 18:53:24.646+09	testdb	public	pgbench_branches	0	0	43	310	28	0.039999999
1	2011-08-16 18:51:55.738+09	testdb	public	pgbench_tellers	0	0	60	480	117	0.039999999
1	2011-08-16 18:54:41.825+09	testdb	public	pgbench_branches	0	0	43	149	11	0
1	2011-08-16 18:52:54.919+09	testdb	public	pgbench_tellers	0	0	60	316	118	0.039999999
1	2011-08-16 18:55:42.471+09	testdb	public	pgbench_branches	0	0	43	217	11	0
1	2011-08-16 18:54:12.965+09	testdb	public	pgbench_tellers	0	0	60	306	101	0.039999999
1	2011-08-16 18:56:41.737+09	testdb	public	pgbench_branches	0	0	43	137	11	0
1	2011-08-16 18:54:54.827+09	testdb	public	pgbench_tellers	0	0	60	292	118	0.039999999
1	2011-08-16 18:57:42.843+09	testdb	public	pgbench_branches	1	4	39	114	10	0.079999998
1	2011-08-16 18:56:13.059+09	testdb	public	pgbench_tellers	1	0	60	331	100	0.15000001
1	2011-08-16 18:56:39.072+09	testdb	public	pgbench_tellers	0	0	60	374	134	0.15000001
1	2011-08-16 18:59:14.206+09	testdb	public	pgbench_branches	0	0	39	92	39	0.090000004
1	2011-08-16 18:58:04.295+09	testdb	public	pgbench_tellers	0	0	60	397	109	0.039999999
1	2011-08-16 19:00:42.289+09	testdb	public	pgbench_branches	0	0	39	152	11	0.039999999
1	2011-08-16 18:59:21.359+09	testdb	public	pgbench_tellers	1	0	60	521	101	0.039999999
1	2011-08-16 19:01:42.991+09	testdb	public	pgbench_branches	1	0	39	162	10	0.02
1	2011-08-16 19:00:09.11+09	testdb	public	pgbench_tellers	0	0	60	382	104	0.059999999
1	2011-08-16 19:01:13.144+09	testdb	public	pgbench_tellers	0	0	60	446	100	0.039999999
1	2011-08-16 19:03:40.615+09	testdb	public	pgbench_branches	0	0	39	0	13	0.059999999
1	2011-08-16 19:02:12.741+09	testdb	public	pgbench_tellers	0	0	60	537	101	0.039999999
1	2011-08-16 19:03:13.187+09	testdb	public	pgbench_tellers	0	0	60	515	100	0.039999999
1	2011-08-16 19:05:43.237+09	testdb	public	pgbench_branches	0	32	7	157	10	0.059999999
1	2011-08-16 19:04:13.331+09	testdb	public	pgbench_tellers	0	0	60	416	100	0.039999999
1	2011-08-16 19:06:43.252+09	testdb	public	pgbench_branches	1	0	39	13	10	0.059999999
1	2011-08-16 19:05:13.44+09	testdb	public	pgbench_tellers	1	0	60	346	100	0.13
1	2011-08-16 19:07:03.412+09	testdb	public	pgbench_branches	0	0	39	32	50	0.13
1	2011-08-16 19:06:13.657+09	testdb	public	pgbench_tellers	0	0	60	405	100	0.15000001
1	2011-08-16 19:08:42.377+09	testdb	public	pgbench_branches	0	0	39	191	11	0
1	2011-08-16 19:07:01.478+09	testdb	public	pgbench_tellers	0	0	60	468	112	0.039999999
1	2011-08-16 19:09:43.342+09	testdb	public	pgbench_branches	0	0	39	29	10	0.039999999
1	2011-08-16 19:08:22.414+09	testdb	public	pgbench_tellers	1	0	60	860	101	0.039999999
1	2011-08-16 19:10:43.445+09	testdb	public	pgbench_branches	1	29	10	142	10	0.07
1	2011-08-16 19:09:07.596+09	testdb	public	pgbench_tellers	0	0	60	404	106	0.079999998
1	2011-08-16 19:11:35.445+09	testdb	public	pgbench_branches	0	0	10	49	18	0.02
1	2011-08-16 19:10:12.557+09	testdb	public	pgbench_tellers	0	0	60	623	101	0.059999999
1	2011-08-16 19:12:43.527+09	testdb	public	pgbench_branches	0	0	10	138	10	0.02
1	2011-08-16 19:11:13.635+09	testdb	public	pgbench_tellers	0	0	60	721	100	0.059999999
1	2011-08-16 19:12:12.653+09	testdb	public	pgbench_tellers	0	0	60	566	101	0.059999999
1	2011-08-16 19:14:43.554+09	testdb	public	pgbench_branches	0	0	10	72	10	0
1	2011-08-16 19:13:12.662+09	testdb	public	pgbench_tellers	0	0	60	491	101	0.059999999
1	2011-08-16 19:15:42.792+09	testdb	public	pgbench_branches	1	0	43	189	11	0.079999998
1	2011-08-16 19:14:12.989+09	testdb	public	pgbench_tellers	1	0	60	377	101	0.12
1	2011-08-16 19:16:15.715+09	testdb	public	pgbench_branches	0	0	43	112	38	0.090000004
1	2011-08-16 19:14:34.929+09	testdb	public	pgbench_tellers	0	0	60	427	139	0.15000001
1	2011-08-16 19:17:43.719+09	testdb	public	pgbench_branches	0	0	43	76	10	0.039999999
1	2011-08-16 19:16:13.806+09	testdb	public	pgbench_tellers	0	0	60	234	100	0.039999999
1	2011-08-16 19:18:36.774+09	testdb	public	pgbench_branches	0	0	43	143	17	0.039999999
1	2011-08-16 19:17:03.856+09	testdb	public	pgbench_tellers	0	0	60	393	110	0.039999999
1	2011-08-16 19:19:43.832+09	testdb	public	pgbench_branches	0	0	43	141	10	0
1	2011-08-16 19:18:24.799+09	testdb	public	pgbench_tellers	1	0	60	2839	100	0.039999999
1	2011-08-16 19:20:43.905+09	testdb	public	pgbench_branches	1	32	11	52	10	0.090000004
1	2011-08-16 19:19:08.049+09	testdb	public	pgbench_tellers	0	0	60	454	106	0.079999998
1	2011-08-16 19:21:34.887+09	testdb	public	pgbench_branches	0	0	11	167	19	0.02
1	2011-08-16 19:20:13.008+09	testdb	public	pgbench_tellers	0	0	60	547	101	0.059999999
1	2011-08-16 19:22:43.927+09	testdb	public	pgbench_branches	0	0	11	69	10	0.02
1	2011-08-16 19:21:14.036+09	testdb	public	pgbench_tellers	0	0	60	482	100	0.059999999
1	2011-08-16 19:22:11.088+09	testdb	public	pgbench_tellers	0	0	60	468	103	0.059999999
1	2011-08-16 19:24:44.337+09	testdb	public	pgbench_branches	1	0	42	102	10	0.090000004
1	2011-08-16 19:23:14.561+09	testdb	public	pgbench_tellers	1	0	60	367	100	0.15000001
1	2011-08-16 19:25:44.442+09	testdb	public	pgbench_branches	0	0	42	62	10	0.13
1	2011-08-16 19:24:14.682+09	testdb	public	pgbench_tellers	0	0	60	570	100	0.15000001
1	2011-08-16 19:26:39.163+09	testdb	public	pgbench_branches	0	0	42	134	15	0.039999999
1	2011-08-16 19:25:09.248+09	testdb	public	pgbench_tellers	0	0	60	401	105	0.039999999
1	2011-08-16 19:27:44.127+09	testdb	public	pgbench_branches	0	0	42	1	10	0
1	2011-08-16 19:26:03.222+09	testdb	public	pgbench_tellers	0	0	60	529	111	0.039999999
1	2011-08-16 19:27:03.307+09	testdb	public	pgbench_tellers	0	0	60	547	111	0.039999999
1	2011-08-16 19:29:43.892+09	testdb	public	pgbench_branches	0	0	42	26	11	0
1	2011-08-16 19:28:02.988+09	testdb	public	pgbench_tellers	0	0	60	634	112	0.039999999
1	2011-08-16 19:29:26.562+09	testdb	public	pgbench_tellers	1	0	60	3023	100	0.059999999
1	2011-08-16 19:31:43.398+09	testdb	public	pgbench_branches	1	0	42	24	11	0.079999998
1	2011-08-16 19:30:08.56+09	testdb	public	pgbench_tellers	0	0	60	636	106	0.079999998
1	2011-08-16 19:31:14.493+09	testdb	public	pgbench_tellers	0	0	60	711	100	0.059999999
1	2011-08-16 19:33:43.441+09	testdb	public	pgbench_branches	1	0	45	164	11	0.02
1	2011-08-16 19:32:14.525+09	testdb	public	pgbench_tellers	1	0	60	409	100	0.02
1	2011-08-16 19:34:18.534+09	testdb	public	pgbench_branches	0	0	45	125	36	0.11
1	2011-08-16 19:32:37.752+09	testdb	public	pgbench_tellers	0	0	60	482	137	0.17
1	2011-08-16 19:35:44.511+09	testdb	public	pgbench_branches	0	0	45	28	10	0.039999999
1	2011-08-16 19:34:14.59+09	testdb	public	pgbench_tellers	0	0	60	563	100	0.039999999
1	2011-08-16 19:35:10.687+09	testdb	public	pgbench_tellers	0	0	60	582	104	0.039999999
1	2011-08-16 19:37:45.299+09	testdb	public	pgbench_branches	0	0	45	51	10	0
1	2011-08-16 19:36:08.392+09	testdb	public	pgbench_tellers	0	0	60	560	107	0.039999999
1	2011-08-16 19:38:27.664+09	testdb	public	pgbench_branches	0	0	45	120	27	0.039999999
1	2011-08-16 19:37:07.756+09	testdb	public	pgbench_tellers	0	0	60	445	107	0.039999999
1	2011-08-16 19:39:36.70+09	testdb	public	pgbench_branches	0	0	45	61	18	0.02
1	2011-08-16 19:38:03.796+09	testdb	public	pgbench_tellers	0	0	60	625	111	0.039999999
1	2011-08-16 19:39:14.854+09	testdb	public	pgbench_tellers	0	0	60	496	100	0.039999999
1	2011-08-16 19:40:06.906+09	testdb	public	pgbench_tellers	0	0	60	626	108	0.039999999
1	2011-08-16 19:42:43.847+09	testdb	public	pgbench_branches	1	0	45	156	11	0
1	2011-08-16 19:41:16.47+09	testdb	public	pgbench_tellers	1	0	60	128	112	0.17
1	2011-08-16 19:43:44.97+09	testdb	public	pgbench_branches	1	32	13	52	10	0.13
1	2011-08-16 19:42:15.193+09	testdb	public	pgbench_tellers	0	0	60	483	100	0.17
1	2011-08-16 19:44:32.956+09	testdb	public	pgbench_branches	0	0	13	93	22	0.039999999
1	2011-08-16 19:43:05.049+09	testdb	public	pgbench_tellers	0	0	60	385	110	0.039999999
1	2011-08-16 19:45:45.209+09	testdb	public	pgbench_branches	0	0	13	107	11	0
1	2011-08-16 19:44:05.293+09	testdb	public	pgbench_tellers	0	0	60	617	111	0.039999999
1	2011-08-16 19:46:44.085+09	testdb	public	pgbench_branches	0	0	13	62	11	0
1	2011-08-16 19:45:05.186+09	testdb	public	pgbench_tellers	0	0	60	484	110	0.039999999
1	2011-08-16 19:47:45.247+09	testdb	public	pgbench_branches	0	0	13	146	11	0
1	2011-08-16 19:45:59.334+09	testdb	public	pgbench_tellers	0	0	60	553	117	0.039999999
1	2011-08-16 19:47:15.153+09	testdb	public	pgbench_tellers	0	0	60	423	100	0.039999999
1	2011-08-16 19:49:44.134+09	testdb	public	pgbench_branches	0	0	13	59	11	0
1	2011-08-16 19:48:03.232+09	testdb	public	pgbench_tellers	0	0	60	509	112	0.039999999
1	2011-08-16 19:49:00.893+09	testdb	public	pgbench_tellers	0	0	60	514	115	0.039999999
1	2011-08-16 19:51:44.214+09	testdb	public	pgbench_branches	1	0	46	35	11	0.02
1	2011-08-16 19:50:15.299+09	testdb	public	pgbench_tellers	1	3	57	440	100	0.029999999
1	2011-08-16 19:52:37.389+09	testdb	public	pgbench_branches	0	0	46	0	18	0.11
1	2011-08-16 19:50:32.594+09	testdb	public	pgbench_tellers	0	0	57	372	143	0.15000001
1	2011-08-16 19:53:45.336+09	testdb	public	pgbench_branches	0	0	46	183	10	0.039999999
1	2011-08-16 19:52:15.443+09	testdb	public	pgbench_tellers	0	0	57	382	100	0.039999999
1	2011-08-16 19:54:33.448+09	testdb	public	pgbench_branches	0	0	46	50	22	0.039999999
1	2011-08-16 19:53:14.565+09	testdb	public	pgbench_tellers	0	0	57	373	101	0.039999999
1	2011-08-16 19:55:45.404+09	testdb	public	pgbench_branches	0	0	46	180	10	0
1	2011-08-16 19:54:29.254+09	testdb	public	pgbench_tellers	1	0	57	475	101	0.039999999
1	2011-08-16 19:56:45.519+09	testdb	public	pgbench_branches	1	31	15	171	10	0.079999998
1	2011-08-16 19:55:15.653+09	testdb	public	pgbench_tellers	0	0	57	461	100	0.079999998
1	2011-08-16 19:57:44.788+09	testdb	public	pgbench_branches	0	0	15	141	11	0.039999999
1	2011-08-16 19:56:05.871+09	testdb	public	pgbench_tellers	0	0	57	697	110	0.039999999
1	2011-08-16 19:58:44.542+09	testdb	public	pgbench_branches	0	0	15	156	11	0
1	2011-08-16 19:57:12.633+09	testdb	public	pgbench_tellers	0	0	57	639	103	0.039999999
1	2011-08-16 19:59:39.84+09	testdb	public	pgbench_branches	0	0	15	7	16	0.02
1	2011-08-16 19:58:10.961+09	testdb	public	pgbench_tellers	0	0	57	645	105	0.059999999
1	2011-08-16 20:00:45.695+09	testdb	public	pgbench_branches	1	0	43	139	10	0.039999999
1	2011-08-16 19:59:14.806+09	testdb	public	pgbench_tellers	1	0	57	434	101	0.059999999
1	2011-08-16 20:01:45.758+09	testdb	public	pgbench_branches	0	0	43	133	10	0.13
1	2011-08-16 20:00:16.003+09	testdb	public	pgbench_tellers	0	0	57	622	100	0.15000001
1	2011-08-16 20:02:39.743+09	testdb	public	pgbench_branches	0	0	43	80	16	0.039999999
1	2011-08-16 20:01:08.827+09	testdb	public	pgbench_tellers	0	0	57	428	107	0.039999999
1	2011-08-16 20:02:12.835+09	testdb	public	pgbench_tellers	0	0	57	526	103	0.039999999
1	2011-08-16 20:04:36.805+09	testdb	public	pgbench_branches	0	0	43	69	19	0.039999999
1	2011-08-16 20:03:10.898+09	testdb	public	pgbench_tellers	0	0	57	588	105	0.039999999
1	2011-08-16 20:05:44.844+09	testdb	public	pgbench_branches	0	0	43	127	11	0
1	2011-08-16 20:04:05.942+09	testdb	public	pgbench_tellers	0	0	57	542	110	0.039999999
1	2011-08-16 20:06:45.911+09	testdb	public	pgbench_branches	0	0	43	167	10	0.039999999
1	2011-08-16 20:05:15.992+09	testdb	public	pgbench_tellers	0	0	57	553	100	0.039999999
1	2011-08-16 20:07:44.919+09	testdb	public	pgbench_branches	0	0	43	9	11	0
1	2011-08-16 20:06:04.012+09	testdb	public	pgbench_tellers	0	0	57	559	112	0.039999999
1	2011-08-16 20:08:46.19+09	testdb	public	pgbench_branches	0	0	43	116	10	0
1	2011-08-16 20:07:07.288+09	testdb	public	pgbench_tellers	0	0	57	340	109	0.039999999
1	2011-08-16 20:09:46.129+09	testdb	public	pgbench_branches	1	0	45	72	10	0.11
1	2011-08-16 20:08:32.459+09	testdb	public	pgbench_tellers	1	0	67	3003	100	0.2
1	2011-08-16 20:10:45.183+09	testdb	public	pgbench_branches	1	0	45	20	11	0.11
1	2011-08-16 20:08:19.427+09	testdb	public	pgbench_tellers	0	0	67	536	157	0.19
1	2011-08-16 20:10:16.199+09	testdb	public	pgbench_tellers	0	0	67	396	100	0.039999999
1	2011-08-16 20:12:35.226+09	testdb	public	pgbench_branches	0	0	45	3	21	0.079999998
1	2011-08-16 20:11:02.362+09	testdb	public	pgbench_tellers	0	0	67	616	114	0.039999999
1	2011-08-16 20:13:45.169+09	testdb	public	pgbench_branches	0	0	45	47	11	0
1	2011-08-16 20:12:05.26+09	testdb	public	pgbench_tellers	0	0	67	554	111	0.039999999
1	2011-08-16 20:14:46.279+09	testdb	public	pgbench_branches	0	32	13	102	10	0.059999999
1	2011-08-16 20:13:16.362+09	testdb	public	pgbench_tellers	0	0	67	595	100	0.039999999
1	2011-08-16 20:15:45.289+09	testdb	public	pgbench_branches	0	0	13	106	11	0.02
1	2011-08-16 20:14:04.464+09	testdb	public	pgbench_tellers	0	0	67	544	112	0.039999999
1	2011-08-16 20:15:06.398+09	testdb	public	pgbench_tellers	0	0	67	447	110	0.039999999
1	2011-08-16 20:17:45.374+09	testdb	public	pgbench_branches	0	0	13	177	11	0
1	2011-08-16 20:16:06.477+09	testdb	public	pgbench_tellers	0	0	67	462	110	0.039999999
1	2011-08-16 20:18:46.068+09	testdb	public	pgbench_branches	1	0	43	70	11	0.090000004
1	2011-08-16 20:17:16.80+09	testdb	public	pgbench_tellers	1	0	67	451	101	0.37
1	2011-08-16 20:19:46.57+09	testdb	public	pgbench_branches	0	0	43	12	10	0.13
1	2011-08-16 20:18:16.839+09	testdb	public	pgbench_tellers	0	0	67	726	100	0.17
1	2011-08-16 20:19:04.623+09	testdb	public	pgbench_tellers	0	0	67	564	112	0.059999999
1	2011-08-16 20:21:45.593+09	testdb	public	pgbench_branches	0	0	43	162	11	0
1	2011-08-16 20:20:06.703+09	testdb	public	pgbench_tellers	0	0	67	735	110	0.059999999
1	2011-08-16 20:22:36.645+09	testdb	public	pgbench_branches	0	0	43	107	20	0.039999999
1	2011-08-16 20:21:05.757+09	testdb	public	pgbench_tellers	0	0	67	756	111	0.059999999
1	2011-08-16 20:23:46.679+09	testdb	public	pgbench_branches	0	0	43	139	10	0
1	2011-08-16 20:22:05.794+09	testdb	public	pgbench_tellers	0	0	67	559	111	0.059999999
1	2011-08-16 20:24:46.702+09	testdb	public	pgbench_branches	0	0	43	161	10	0.039999999
1	2011-08-16 20:23:16.809+09	testdb	public	pgbench_tellers	0	0	67	745	100	0.059999999
1	2011-08-16 20:24:35.054+09	testdb	public	pgbench_tellers	1	0	67	4638	100	0.079999998
1	2011-08-16 20:26:46.098+09	testdb	public	pgbench_branches	1	0	43	47	11	0.039999999
1	2011-08-16 20:24:50.264+09	testdb	public	pgbench_tellers	0	0	67	581	127	0.1
1	2011-08-16 20:27:45.942+09	testdb	public	pgbench_branches	1	0	44	60	11	0.02
1	2011-08-16 20:26:16.022+09	testdb	public	pgbench_tellers	1	0	67	369	101	0.02
1	2011-08-16 20:27:51.987+09	testdb	public	pgbench_branches	0	0	44	38	65	0.13
1	2011-08-16 20:26:33.28+09	testdb	public	pgbench_tellers	0	0	67	327	144	0.17
1	2011-08-16 20:29:46.902+09	testdb	public	pgbench_branches	0	0	44	170	10	0.039999999
1	2011-08-16 20:28:16.989+09	testdb	public	pgbench_tellers	0	0	67	554	100	0.039999999
1	2011-08-16 20:30:40.956+09	testdb	public	pgbench_branches	0	0	44	127	16	0.039999999
1	2011-08-16 20:29:06.042+09	testdb	public	pgbench_tellers	0	0	67	511	111	0.039999999
1	2011-08-16 20:31:46.995+09	testdb	public	pgbench_branches	0	0	44	130	10	0
1	2011-08-16 20:30:07.09+09	testdb	public	pgbench_tellers	0	0	67	516	110	0.039999999
1	2011-08-16 20:32:47.057+09	testdb	public	pgbench_branches	0	0	44	106	10	0.039999999
1	2011-08-16 20:31:17.144+09	testdb	public	pgbench_tellers	0	0	67	431	100	0.039999999
1	2011-08-16 20:33:41.105+09	testdb	public	pgbench_branches	0	0	44	163	16	0.039999999
1	2011-08-16 20:32:08.19+09	testdb	public	pgbench_tellers	0	0	67	386	109	0.039999999
1	2011-08-16 20:33:11.237+09	testdb	public	pgbench_tellers	0	0	67	382	106	0.039999999
1	2011-08-16 20:35:47.193+09	testdb	public	pgbench_branches	1	0	48	22	10	0.02
1	2011-08-16 20:34:16.257+09	testdb	public	pgbench_tellers	1	0	67	299	101	0.02
1	2011-08-16 20:36:13.297+09	testdb	public	pgbench_branches	0	0	48	78	44	0.11
1	2011-08-16 20:34:32.52+09	testdb	public	pgbench_tellers	0	0	67	347	145	0.17
1	2011-08-16 20:36:17.354+09	testdb	public	pgbench_tellers	0	0	67	355	100	0.039999999
1	2011-08-16 20:38:46.835+09	testdb	public	pgbench_branches	0	0	48	32	11	0.039999999
1	2011-08-16 20:37:17.271+09	testdb	public	pgbench_tellers	0	0	67	371	101	0.039999999
1	2011-08-16 20:39:47.191+09	testdb	public	pgbench_branches	0	0	48	130	11	0
1	2011-08-16 20:38:07.287+09	testdb	public	pgbench_tellers	0	0	67	296	111	0.039999999
1	2011-08-16 20:40:33.397+09	testdb	public	pgbench_branches	0	0	48	94	24	0.039999999
1	2011-08-16 20:39:07.508+09	testdb	public	pgbench_tellers	0	0	67	330	110	0.039999999
1	2011-08-16 20:41:46.465+09	testdb	public	pgbench_branches	0	0	48	14	11	0
1	2011-08-16 20:40:06.56+09	testdb	public	pgbench_tellers	0	0	67	278	111	0.039999999
1	2011-08-16 20:42:47.484+09	testdb	public	pgbench_branches	0	0	48	137	10	0.039999999
1	2011-08-16 20:41:36.412+09	testdb	public	pgbench_tellers	1	0	67	244	101	0.039999999
1	2011-08-16 20:43:47.658+09	testdb	public	pgbench_branches	1	0	48	194	10	0.079999998
1	2011-08-16 20:41:59.806+09	testdb	public	pgbench_tellers	0	0	67	433	118	0.1
1	2011-08-16 20:44:47.678+09	testdb	public	pgbench_branches	1	0	48	172	11	0.059999999
1	2011-08-16 20:43:17.832+09	testdb	public	pgbench_tellers	1	0	67	421	101	0.11
1	2011-08-16 20:45:46.874+09	testdb	public	pgbench_branches	0	5	43	58	11	0.20999999
1	2011-08-16 20:44:18.152+09	testdb	public	pgbench_tellers	0	0	67	379	100	0.17
1	2011-08-16 20:46:46.622+09	testdb	public	pgbench_branches	0	0	43	36	11	0
1	2011-08-16 20:45:12.713+09	testdb	public	pgbench_tellers	0	0	67	247	105	0.039999999
1	2011-08-16 20:47:47.709+09	testdb	public	pgbench_branches	0	0	43	133	10	0.039999999
1	2011-08-16 20:46:17.797+09	testdb	public	pgbench_tellers	0	0	67	239	100	0.039999999
1	2011-08-16 20:48:38.763+09	testdb	public	pgbench_branches	0	0	43	17	19	0.039999999
1	2011-08-16 20:47:05.855+09	testdb	public	pgbench_tellers	0	0	67	337	112	0.039999999
1	2011-08-16 20:49:46.863+09	testdb	public	pgbench_branches	0	0	43	27	11	0
1	2011-08-16 20:48:13.955+09	testdb	public	pgbench_tellers	0	0	67	367	104	0.039999999
1	2011-08-16 20:50:47.856+09	testdb	public	pgbench_branches	0	0	43	173	10	0.039999999
1	2011-08-16 20:49:17.944+09	testdb	public	pgbench_tellers	0	0	67	307	100	0.039999999
1	2011-08-16 20:51:40.958+09	testdb	public	pgbench_branches	0	0	43	176	17	0.039999999
1	2011-08-16 20:50:10.039+09	testdb	public	pgbench_tellers	0	0	67	317	108	0.039999999
1	2011-08-16 20:52:47.948+09	testdb	public	pgbench_branches	0	0	43	125	10	0
1	2011-08-16 20:51:07.035+09	testdb	public	pgbench_tellers	0	0	67	355	111	0.039999999
1	2011-08-16 20:53:48.024+09	testdb	public	pgbench_branches	1	0	47	110	11	0.11
1	2011-08-16 20:52:18.328+09	testdb	public	pgbench_tellers	1	0	67	249	101	0.18000001
1	2011-08-16 20:54:15.123+09	testdb	public	pgbench_branches	0	0	47	144	43	0.11
1	2011-08-16 20:52:50.346+09	testdb	public	pgbench_tellers	0	0	67	404	128	0.17
1	2011-08-16 20:55:48.059+09	testdb	public	pgbench_branches	0	0	47	85	10	0.039999999
1	2011-08-16 20:54:18.166+09	testdb	public	pgbench_tellers	0	0	67	389	100	0.039999999
1	2011-08-16 20:56:39.182+09	testdb	public	pgbench_branches	0	0	47	153	19	0.039999999
1	2011-08-16 20:55:09.289+09	testdb	public	pgbench_tellers	0	0	67	511	109	0.039999999
1	2011-08-16 20:57:48.168+09	testdb	public	pgbench_branches	0	0	47	102	10	0
1	2011-08-16 20:56:06.262+09	testdb	public	pgbench_tellers	0	0	67	329	112	0.039999999
1	2011-08-16 20:58:36.261+09	testdb	public	pgbench_branches	0	0	47	174	22	0.039999999
1	2011-08-16 20:57:07.375+09	testdb	public	pgbench_tellers	0	0	67	530	111	0.039999999
1	2011-08-16 20:58:09.308+09	testdb	public	pgbench_tellers	0	0	67	345	109	0.039999999
1	2011-08-16 21:00:48.301+09	testdb	public	pgbench_branches	0	0	47	132	10	0.039999999
1	2011-08-16 20:59:18.41+09	testdb	public	pgbench_tellers	0	0	67	518	100	0.039999999
1	2011-08-16 21:01:44.062+09	testdb	public	pgbench_branches	0	0	47	17	15	0.039999999
1	2011-08-16 21:00:40.927+09	testdb	public	pgbench_tellers	1	0	67	273	100	0.039999999
1	2011-08-16 18:55:00.541+09	testdb	public	pgbench_branches	1	0	50	0	7678	0.18000001
1	2011-08-16 18:52:01.779+09	testdb	public	pgbench_tellers	0	0	67	0	7857	0.18000001
1	2011-08-16 21:04:47.644+09	testdb	public	pgbench_branches	1	0	51	156	11	0.19
1	2011-08-16 21:03:08.005+09	testdb	public	pgbench_tellers	1	0	67	324	111	0.25999999
1	2011-08-16 21:05:38.573+09	testdb	public	pgbench_branches	0	42	9	204	20	0.090000004
1	2011-08-16 21:04:05.80+09	testdb	public	pgbench_tellers	0	0	67	352	113	0.17
1	2011-08-16 21:06:42.59+09	testdb	public	pgbench_branches	0	0	9	316	16	0.02
1	2011-08-16 21:05:13.683+09	testdb	public	pgbench_tellers	0	0	67	474	105	0.039999999
1	2011-08-16 21:07:48.59+09	testdb	public	pgbench_branches	0	0	9	298	10	0
1	2011-08-16 21:06:08.68+09	testdb	public	pgbench_tellers	0	0	67	386	110	0.039999999
1	2011-08-16 21:08:48.647+09	testdb	public	pgbench_branches	0	0	9	88	10	0.02
1	2011-08-16 21:07:18.726+09	testdb	public	pgbench_tellers	0	0	67	503	100	0.039999999
1	2011-08-16 21:09:48.712+09	testdb	public	pgbench_branches	0	0	9	242	10	0
1	2011-08-16 21:08:10.805+09	testdb	public	pgbench_tellers	0	0	67	554	108	0.039999999
1	2011-08-16 21:10:48.181+09	testdb	public	pgbench_branches	0	0	9	319	11	0
1	2011-08-16 21:09:18.49+09	testdb	public	pgbench_tellers	0	0	67	357	101	0.039999999
1	2011-08-16 21:11:49.465+09	testdb	public	pgbench_branches	1	0	47	343	10	0.15000001
1	2011-08-16 21:10:19.827+09	testdb	public	pgbench_tellers	1	0	67	299	100	0.18000001
1	2011-08-16 21:12:17.977+09	testdb	public	pgbench_branches	0	0	47	187	41	0.11
1	2011-08-16 21:10:45.194+09	testdb	public	pgbench_tellers	0	0	67	346	134	0.17
1	2011-08-16 21:13:48.888+09	testdb	public	pgbench_branches	0	0	47	271	10	0.039999999
1	2011-08-16 21:12:18.995+09	testdb	public	pgbench_tellers	0	0	67	441	100	0.039999999
1	2011-08-16 21:14:37.978+09	testdb	public	pgbench_branches	0	0	47	202	21	0.039999999
1	2011-08-16 21:13:10.078+09	testdb	public	pgbench_tellers	0	0	67	402	109	0.039999999
1	2011-08-16 21:15:47.944+09	testdb	public	pgbench_branches	0	0	47	284	11	0
1	2011-08-16 21:14:11.042+09	testdb	public	pgbench_tellers	0	0	67	476	108	0.039999999
1	2011-08-16 21:16:49.028+09	testdb	public	pgbench_branches	0	0	47	394	10	0.039999999
1	2011-08-16 21:15:19.136+09	testdb	public	pgbench_tellers	0	0	67	483	100	0.039999999
1	2011-08-16 21:17:43.528+09	testdb	public	pgbench_branches	0	0	47	109	16	0.039999999
1	2011-08-16 21:16:08.633+09	testdb	public	pgbench_tellers	0	0	67	476	111	0.039999999
1	2011-08-16 21:18:49.113+09	testdb	public	pgbench_branches	0	0	47	265	10	0.039999999
1	2011-08-16 21:17:09.22+09	testdb	public	pgbench_tellers	0	0	67	343	110	0.039999999
1	2011-08-16 21:19:48.225+09	testdb	public	pgbench_branches	0	0	47	168	11	0.039999999
1	2011-08-16 21:18:18.639+09	testdb	public	pgbench_tellers	0	0	67	481	101	0.039999999
1	2011-08-16 21:20:48.20+09	testdb	public	pgbench_branches	1	0	47	81	11	0.039999999
1	2011-08-16 21:19:18.316+09	testdb	public	pgbench_tellers	1	0	67	400	101	0.059999999
1	2011-08-16 21:21:49.339+09	testdb	public	pgbench_branches	0	5	42	174	10	0.15000001
1	2011-08-16 21:20:19.595+09	testdb	public	pgbench_tellers	0	0	67	569	100	0.17
1	2011-08-16 21:22:44.311+09	testdb	public	pgbench_branches	0	0	42	182	15	0.039999999
1	2011-08-16 21:21:42.315+09	testdb	public	pgbench_tellers	1	0	67	487	101	0.039999999
1	2011-08-16 21:23:48.362+09	testdb	public	pgbench_branches	1	20	22	335	11	0.07
1	2011-08-16 21:22:00.507+09	testdb	public	pgbench_tellers	0	0	67	714	119	0.1
1	2011-08-16 21:24:28.403+09	testdb	public	pgbench_branches	0	0	22	205	31	0.059999999
1	2011-08-16 21:23:13.525+09	testdb	public	pgbench_tellers	0	0	67	779	106	0.059999999
1	2011-08-16 21:25:48.446+09	testdb	public	pgbench_branches	0	0	22	112	11	0
1	2011-08-16 21:24:10.562+09	testdb	public	pgbench_tellers	0	0	67	717	109	0.059999999
1	2011-08-16 21:26:49.449+09	testdb	public	pgbench_branches	0	0	22	292	10	0.02
1	2011-08-16 21:25:19.568+09	testdb	public	pgbench_tellers	0	0	67	751	100	0.059999999
1	2011-08-16 21:27:48.484+09	testdb	public	pgbench_branches	0	0	22	216	11	0
1	2011-08-16 21:26:12.605+09	testdb	public	pgbench_tellers	0	0	67	688	107	0.059999999
1	2011-08-16 21:28:48.859+09	testdb	public	pgbench_branches	0	0	22	122	11	0
1	2011-08-16 21:27:17.087+09	testdb	public	pgbench_tellers	0	0	67	813	103	0.059999999
1	2011-08-16 21:29:48.939+09	testdb	public	pgbench_branches	1	0	47	197	11	0.079999998
1	2011-08-16 21:28:20.238+09	testdb	public	pgbench_tellers	1	0	67	541	100	0.13
1	2011-08-16 21:30:24.767+09	testdb	public	pgbench_branches	0	0	47	114	35	0.11
1	2011-08-16 21:28:32.985+09	testdb	public	pgbench_tellers	0	0	67	476	147	0.17
1	2011-08-16 21:31:49.681+09	testdb	public	pgbench_branches	0	0	47	210	10	0.039999999
1	2011-08-16 21:30:19.788+09	testdb	public	pgbench_tellers	0	0	67	565	100	0.039999999
1	2011-08-16 21:32:41.785+09	testdb	public	pgbench_branches	0	0	47	220	18	0.039999999
1	2011-08-16 21:31:06.876+09	testdb	public	pgbench_tellers	0	0	67	547	113	0.039999999
1	2011-08-16 21:33:48.903+09	testdb	public	pgbench_branches	0	0	47	149	11	0
1	2011-08-16 21:32:07.999+09	testdb	public	pgbench_tellers	0	0	67	373	112	0.039999999
1	2011-08-16 21:34:49.835+09	testdb	public	pgbench_branches	0	0	47	204	10	0.039999999
1	2011-08-16 21:33:19.942+09	testdb	public	pgbench_tellers	0	0	67	634	100	0.039999999
1	2011-08-16 21:35:49.843+09	testdb	public	pgbench_branches	0	0	47	193	10	0
1	2011-08-16 21:34:09.936+09	testdb	public	pgbench_tellers	0	0	67	542	110	0.039999999
1	2011-08-16 21:36:48.924+09	testdb	public	pgbench_branches	0	0	47	235	11	0
1	2011-08-16 21:35:12.017+09	testdb	public	pgbench_tellers	0	0	67	641	108	0.039999999
1	2011-08-16 21:37:43.376+09	testdb	public	pgbench_branches	0	0	47	217	17	0.039999999
1	2011-08-16 21:36:14.491+09	testdb	public	pgbench_tellers	0	0	67	535	106	0.039999999
1	2011-08-16 21:38:49.365+09	testdb	public	pgbench_branches	1	2	45	137	11	0.07
1	2011-08-16 21:37:20.513+09	testdb	public	pgbench_tellers	1	0	67	431	100	0.11
1	2011-08-16 21:39:50.137+09	testdb	public	pgbench_branches	0	0	45	247	10	0.13
1	2011-08-16 21:38:20.412+09	testdb	public	pgbench_tellers	0	0	67	435	100	0.17
1	2011-08-16 21:40:38.929+09	testdb	public	pgbench_branches	0	0	45	141	22	0.039999999
1	2011-08-16 21:39:12.018+09	testdb	public	pgbench_tellers	0	0	67	516	109	0.039999999
1	2011-08-16 21:41:49.167+09	testdb	public	pgbench_branches	0	0	45	181	11	0
1	2011-08-16 21:40:14.265+09	testdb	public	pgbench_tellers	0	0	67	439	106	0.039999999
1	2011-08-16 21:42:41.196+09	testdb	public	pgbench_branches	0	0	45	270	19	0.039999999
1	2011-08-16 21:41:11.287+09	testdb	public	pgbench_tellers	0	0	67	401	109	0.039999999
1	2011-08-16 21:43:49.232+09	testdb	public	pgbench_branches	0	0	45	189	11	0
1	2011-08-16 21:42:14.326+09	testdb	public	pgbench_tellers	0	0	67	383	106	0.039999999
1	2011-08-16 21:44:50.282+09	testdb	public	pgbench_branches	0	0	45	66	10	0.039999999
1	2011-08-16 21:43:20.369+09	testdb	public	pgbench_tellers	0	0	67	470	100	0.039999999
1	2011-08-16 21:45:37.381+09	testdb	public	pgbench_branches	0	0	45	51	23	0.039999999
1	2011-08-16 21:44:45.908+09	testdb	public	pgbench_tellers	1	0	67	838	101	0.039999999
1	2011-08-16 21:46:50.406+09	testdb	public	pgbench_branches	1	0	45	182	11	0.059999999
1	2011-08-16 21:45:20.885+09	testdb	public	pgbench_tellers	0	0	67	515	101	0.12
1	2011-08-16 21:47:50.456+09	testdb	public	pgbench_branches	1	0	45	105	10	0.079999998
1	2011-08-16 21:46:20.609+09	testdb	public	pgbench_tellers	1	0	67	431	100	0.11
1	2011-08-16 21:48:09.599+09	testdb	public	pgbench_branches	0	0	45	49	51	0.13
1	2011-08-16 21:46:43.869+09	testdb	public	pgbench_tellers	0	0	67	383	137	0.17
1	2011-08-16 21:48:10.548+09	testdb	public	pgbench_tellers	0	0	67	485	110	0.039999999
1	2011-08-16 21:50:34.544+09	testdb	public	pgbench_branches	0	0	45	57	26	0.039999999
1	2011-08-16 21:49:09.634+09	testdb	public	pgbench_tellers	0	0	67	551	111	0.039999999
1	2011-08-16 21:51:49.589+09	testdb	public	pgbench_branches	0	0	45	79	11	0
1	2011-08-16 21:50:13.687+09	testdb	public	pgbench_tellers	0	0	67	372	107	0.039999999
1	2011-08-16 21:52:50.633+09	testdb	public	pgbench_branches	0	0	45	124	10	0.039999999
1	2011-08-16 21:51:20.721+09	testdb	public	pgbench_tellers	0	0	67	572	100	0.039999999
1	2011-08-16 21:52:13.818+09	testdb	public	pgbench_tellers	0	0	67	564	107	0.039999999
1	2011-08-16 21:54:49.749+09	testdb	public	pgbench_branches	0	0	45	139	11	0
1	2011-08-16 21:53:09.844+09	testdb	public	pgbench_tellers	0	0	67	460	111	0.039999999
1	2011-08-16 21:55:49.926+09	testdb	public	pgbench_branches	0	0	45	137	11	0.039999999
1	2011-08-16 21:54:20.365+09	testdb	public	pgbench_tellers	0	0	67	591	101	0.039999999
1	2011-08-16 21:56:49.794+09	testdb	public	pgbench_branches	1	0	45	16	11	0
1	2011-08-16 21:55:19.897+09	testdb	public	pgbench_tellers	1	0	67	517	101	0.039999999
1	2011-08-16 21:57:50.938+09	testdb	public	pgbench_branches	0	2	43	116	10	0.13
1	2011-08-16 21:56:21.213+09	testdb	public	pgbench_tellers	0	0	67	273	100	0.17
1	2011-08-16 21:58:44.894+09	testdb	public	pgbench_branches	0	0	43	129	16	0.039999999
1	2011-08-16 21:57:14.981+09	testdb	public	pgbench_tellers	0	0	67	413	106	0.039999999
1	2011-08-16 21:59:50.966+09	testdb	public	pgbench_branches	0	0	43	185	10	0
1	2011-08-16 21:58:10.063+09	testdb	public	pgbench_tellers	0	0	67	429	111	0.039999999
1	2011-08-16 22:00:39.026+09	testdb	public	pgbench_branches	0	0	43	4	22	0.039999999
1	2011-08-16 21:59:13.117+09	testdb	public	pgbench_tellers	0	0	67	374	108	0.039999999
1	2011-08-16 22:01:50.018+09	testdb	public	pgbench_branches	0	0	43	142	11	0
1	2011-08-16 22:00:14.117+09	testdb	public	pgbench_tellers	0	0	67	482	107	0.039999999
1	2011-08-16 22:02:51.08+09	testdb	public	pgbench_branches	0	0	43	176	10	0.039999999
1	2011-08-16 22:01:21.167+09	testdb	public	pgbench_tellers	0	0	67	310	100	0.039999999
1	2011-08-16 22:03:45.132+09	testdb	public	pgbench_branches	0	0	43	150	16	0.039999999
1	2011-08-16 22:02:15.217+09	testdb	public	pgbench_tellers	0	0	67	559	106	0.039999999
1	2011-08-16 22:04:50.134+09	testdb	public	pgbench_branches	0	0	43	81	11	0
1	2011-08-16 22:03:16.229+09	testdb	public	pgbench_tellers	0	0	67	393	105	0.039999999
1	2011-08-16 22:05:51.192+09	testdb	public	pgbench_branches	1	0	44	172	10	0.039999999
1	2011-08-16 22:04:21.303+09	testdb	public	pgbench_tellers	1	0	67	490	100	0.059999999
1	2011-08-16 22:06:13.323+09	testdb	public	pgbench_branches	0	0	44	117	48	0.13
1	2011-08-16 22:04:44.597+09	testdb	public	pgbench_tellers	0	0	67	477	137	0.17
1	2011-08-16 22:06:10.359+09	testdb	public	pgbench_tellers	0	0	67	561	111	0.039999999
1	2011-08-16 22:08:41.318+09	testdb	public	pgbench_branches	0	0	44	89	20	0.039999999
1	2011-08-16 22:07:14.415+09	testdb	public	pgbench_tellers	0	0	67	548	107	0.039999999
1	2011-08-16 22:09:50.342+09	testdb	public	pgbench_branches	0	0	44	78	11	0
1	2011-08-16 22:08:14.44+09	testdb	public	pgbench_tellers	0	0	67	500	107	0.039999999
1	2011-08-16 22:10:51.42+09	testdb	public	pgbench_branches	0	0	44	89	10	0.039999999
1	2011-08-16 22:09:21.508+09	testdb	public	pgbench_tellers	0	0	67	426	100	0.039999999
1	2011-08-16 22:11:46.48+09	testdb	public	pgbench_branches	0	0	44	32	15	0.039999999
1	2011-08-16 22:10:49.782+09	testdb	public	pgbench_tellers	1	0	67	603	101	0.039999999
1	2011-08-16 22:12:51.621+09	testdb	public	pgbench_branches	1	17	27	116	10	0.07
1	2011-08-16 22:11:07.802+09	testdb	public	pgbench_tellers	0	0	67	588	114	0.12
1	2011-08-16 22:13:50.856+09	testdb	public	pgbench_branches	0	0	27	122	11	0.079999998
1	2011-08-16 22:12:21.105+09	testdb	public	pgbench_tellers	0	0	67	659	101	0.059999999
1	2011-08-16 22:14:52.408+09	testdb	public	pgbench_branches	1	0	47	14	10	0.079999998
1	2011-08-16 22:13:21.618+09	testdb	public	pgbench_tellers	1	0	67	284	101	0.15000001
1	2011-08-16 22:14:21.851+09	testdb	public	pgbench_tellers	0	0	67	341	100	0.17
1	2011-08-16 22:15:15.757+09	testdb	public	pgbench_tellers	0	0	67	277	106	0.039999999
1	2011-08-16 22:16:15.808+09	testdb	public	pgbench_tellers	0	0	67	203	106	0.039999999
1	2011-08-16 22:18:51.876+09	testdb	public	pgbench_branches	0	0	47	173	10	0.15000001
1	2011-08-16 22:17:22+09	testdb	public	pgbench_tellers	0	0	67	285	100	0.039999999
1	2011-08-16 22:19:50.771+09	testdb	public	pgbench_branches	0	0	47	147	11	0
1	2011-08-16 22:18:16.868+09	testdb	public	pgbench_tellers	0	0	67	322	105	0.039999999
1	2011-08-16 22:20:50.88+09	testdb	public	pgbench_branches	0	0	47	184	11	0
1	2011-08-16 22:19:11.972+09	testdb	public	pgbench_tellers	0	0	67	355	110	0.039999999
1	2011-08-16 22:21:44.895+09	testdb	public	pgbench_branches	0	0	47	44	17	0.039999999
1	2011-08-16 22:20:13.998+09	testdb	public	pgbench_tellers	0	0	67	306	108	0.039999999
1	2011-08-16 22:22:50.895+09	testdb	public	pgbench_branches	0	0	47	79	11	0
1	2011-08-16 22:21:13.986+09	testdb	public	pgbench_tellers	0	0	67	172	108	0.039999999
1	2011-08-16 22:23:51.994+09	testdb	public	pgbench_branches	1	4	43	183	10	0.079999998
1	2011-08-16 22:22:22.124+09	testdb	public	pgbench_tellers	1	0	67	336	100	0.079999998
1	2011-08-16 22:22:42.213+09	testdb	public	pgbench_tellers	0	0	67	509	140	0.17
1	2011-08-16 22:25:25.092+09	testdb	public	pgbench_branches	0	0	43	116	37	0.090000004
1	2011-08-16 22:24:10.191+09	testdb	public	pgbench_tellers	0	0	67	537	112	0.039999999
1	2011-08-16 22:26:36.113+09	testdb	public	pgbench_branches	0	0	43	74	26	0.039999999
1	2011-08-16 22:25:13.207+09	testdb	public	pgbench_tellers	0	0	67	530	109	0.039999999
1	2011-08-16 22:27:52.242+09	testdb	public	pgbench_branches	0	0	43	91	10	0
1	2011-08-16 22:26:12.332+09	testdb	public	pgbench_tellers	0	0	67	471	110	0.039999999
1	2011-08-16 22:27:22.277+09	testdb	public	pgbench_tellers	0	0	67	472	100	0.039999999
1	2011-08-16 22:29:45.267+09	testdb	public	pgbench_branches	0	0	43	148	17	0.039999999
1	2011-08-16 22:28:14.352+09	testdb	public	pgbench_tellers	0	0	67	422	108	0.039999999
1	2011-08-16 22:30:51.257+09	testdb	public	pgbench_branches	0	0	43	40	11	0
1	2011-08-16 22:29:12.35+09	testdb	public	pgbench_tellers	0	0	67	536	110	0.039999999
1	2011-08-16 22:30:07.467+09	testdb	public	pgbench_tellers	0	0	67	478	115	0.039999999
1	2011-08-16 22:32:51.39+09	testdb	public	pgbench_branches	1	0	46	178	11	0.059999999
1	2011-08-16 22:31:21.551+09	testdb	public	pgbench_tellers	1	0	67	428	101	0.11
1	2011-08-16 22:33:52.529+09	testdb	public	pgbench_branches	0	0	46	22	10	0.15000001
1	2011-08-16 22:32:22.788+09	testdb	public	pgbench_tellers	0	0	67	448	100	0.17
1	2011-08-16 22:34:42.509+09	testdb	public	pgbench_branches	0	0	46	0	20	0.039999999
1	2011-08-16 22:33:15.626+09	testdb	public	pgbench_tellers	0	0	67	507	107	0.039999999
1	2011-08-16 22:35:51.575+09	testdb	public	pgbench_branches	0	0	46	109	11	0
1	2011-08-16 22:34:14.664+09	testdb	public	pgbench_tellers	0	0	67	291	108	0.039999999
1	2011-08-16 22:36:52.549+09	testdb	public	pgbench_branches	0	0	46	181	10	0.039999999
1	2011-08-16 22:35:22.657+09	testdb	public	pgbench_tellers	0	0	67	448	100	0.039999999
1	2011-08-16 22:37:44.628+09	testdb	public	pgbench_branches	0	0	46	29	18	0.039999999
1	2011-08-16 22:36:12.714+09	testdb	public	pgbench_tellers	0	0	67	408	110	0.039999999
1	2011-08-16 22:38:52.627+09	testdb	public	pgbench_branches	0	0	46	12	10	0
1	2011-08-16 22:37:15.728+09	testdb	public	pgbench_tellers	0	0	67	393	107	0.039999999
1	2011-08-16 22:38:54.27+09	testdb	public	pgbench_tellers	1	0	67	289	101	0.039999999
1	2011-08-16 22:40:52.466+09	testdb	public	pgbench_branches	1	0	46	185	11	0.059999999
1	2011-08-16 22:39:03.663+09	testdb	public	pgbench_tellers	0	0	67	363	120	0.15000001
1	2011-08-16 22:41:52.739+09	testdb	public	pgbench_branches	1	3	43	8	10	0.02
1	2011-08-16 22:40:22.808+09	testdb	public	pgbench_tellers	1	0	67	318	100	0.02
1	2011-08-16 22:42:17.153+09	testdb	public	pgbench_branches	0	0	43	79	46	0.13
1	2011-08-16 22:41:06.422+09	testdb	public	pgbench_tellers	0	0	67	276	117	0.17
1	2011-08-16 22:43:52.834+09	testdb	public	pgbench_branches	0	0	43	77	10	0
1	2011-08-16 22:42:11.928+09	testdb	public	pgbench_tellers	0	0	67	234	111	0.039999999
1	2011-08-16 22:44:43.955+09	testdb	public	pgbench_branches	0	0	43	8	19	0.039999999
1	2011-08-16 22:43:14.052+09	testdb	public	pgbench_tellers	0	0	67	309	109	0.039999999
1	2011-08-16 22:44:12.992+09	testdb	public	pgbench_tellers	0	0	67	325	110	0.039999999
1	2011-08-16 22:46:53.005+09	testdb	public	pgbench_branches	0	0	43	55	10	0.039999999
1	2011-08-16 22:45:23.092+09	testdb	public	pgbench_tellers	0	0	67	195	100	0.039999999
1	2011-08-16 22:47:52.123+09	testdb	public	pgbench_branches	0	0	43	128	11	0.039999999
1	2011-08-16 22:46:22.539+09	testdb	public	pgbench_tellers	0	0	67	196	101	0.039999999
1	2011-08-16 22:47:13.131+09	testdb	public	pgbench_tellers	0	0	67	309	110	0.039999999
1	2011-08-16 22:49:53.132+09	testdb	public	pgbench_branches	0	0	43	6	10	0.039999999
1	2011-08-16 22:48:23.219+09	testdb	public	pgbench_tellers	0	0	67	363	100	0.039999999
1	2011-08-16 22:50:52.149+09	testdb	public	pgbench_branches	1	0	46	124	11	0
1	2011-08-16 22:49:23.236+09	testdb	public	pgbench_tellers	1	0	67	265	100	0.02
1	2011-08-16 22:51:28.27+09	testdb	public	pgbench_branches	0	0	46	91	35	0.11
1	2011-08-16 22:49:39.488+09	testdb	public	pgbench_tellers	0	0	67	359	144	0.17
1	2011-08-16 22:51:18.368+09	testdb	public	pgbench_tellers	0	0	67	313	105	0.039999999
1	2011-08-16 22:53:53.625+09	testdb	public	pgbench_branches	0	0	46	120	10	0
1	2011-08-16 22:52:12.718+09	testdb	public	pgbench_tellers	0	0	67	370	111	0.039999999
1	2011-08-16 22:54:53.348+09	testdb	public	pgbench_branches	0	0	46	98	10	0.039999999
1	2011-08-16 22:53:23.454+09	testdb	public	pgbench_tellers	0	0	67	295	100	0.039999999
1	2011-08-16 22:55:52.358+09	testdb	public	pgbench_branches	0	0	46	140	11	0
1	2011-08-16 22:54:17.456+09	testdb	public	pgbench_tellers	0	0	67	377	106	0.039999999
1	2011-08-16 22:55:23.031+09	testdb	public	pgbench_tellers	0	0	67	329	101	0.039999999
1	2011-08-16 22:56:15.612+09	testdb	public	pgbench_tellers	0	0	67	305	108	0.039999999
1	2011-08-16 22:58:52.481+09	testdb	public	pgbench_branches	0	0	46	47	11	0
1	2011-08-16 22:57:12.575+09	testdb	public	pgbench_tellers	0	0	67	364	111	0.039999999
1	2011-08-16 22:59:53.522+09	testdb	public	pgbench_branches	1	2	44	111	10	0.02
1	2011-08-16 22:58:23.586+09	testdb	public	pgbench_tellers	1	0	67	393	100	0.02
1	2011-08-16 22:58:45.155+09	testdb	public	pgbench_tellers	0	0	67	497	139	0.17
1	2011-08-16 23:01:30.677+09	testdb	public	pgbench_branches	0	0	44	80	33	0.079999998
1	2011-08-16 23:00:18.782+09	testdb	public	pgbench_tellers	0	0	67	474	105	0.039999999
1	2011-08-16 23:02:39.701+09	testdb	public	pgbench_branches	0	0	44	143	24	0.039999999
1	2011-08-16 23:01:11.798+09	testdb	public	pgbench_tellers	0	0	67	431	112	0.039999999
1	2011-08-16 23:03:53.692+09	testdb	public	pgbench_branches	0	0	44	78	10	0
1	2011-08-16 23:02:14.788+09	testdb	public	pgbench_tellers	0	0	67	332	109	0.039999999
1	2011-08-16 23:04:53.784+09	testdb	public	pgbench_branches	0	0	44	91	10	0.039999999
1	2011-08-16 23:03:23.868+09	testdb	public	pgbench_tellers	0	0	67	426	100	0.039999999
1	2011-08-16 23:05:53.015+09	testdb	public	pgbench_branches	0	0	44	87	11	0.039999999
1	2011-08-16 23:04:23.448+09	testdb	public	pgbench_tellers	0	0	67	585	101	0.039999999
1	2011-08-16 23:06:53.131+09	testdb	public	pgbench_branches	0	0	44	113	11	0
1	2011-08-16 23:05:13.22+09	testdb	public	pgbench_tellers	0	0	67	415	111	0.039999999
1	2011-08-16 23:07:53.917+09	testdb	public	pgbench_branches	0	0	44	123	10	0.039999999
1	2011-08-16 23:06:24.006+09	testdb	public	pgbench_tellers	0	0	67	513	100	0.039999999
1	2011-08-16 23:08:52.89+09	testdb	public	pgbench_branches	1	0	45	220	11	0
1	2011-08-16 23:07:22.975+09	testdb	public	pgbench_tellers	1	0	67	379	101	0.02
1	2011-08-16 23:09:31.202+09	testdb	public	pgbench_branches	0	0	45	286	33	0.090000004
1	2011-08-16 23:07:46.431+09	testdb	public	pgbench_tellers	0	0	67	484	138	0.17
1	2011-08-16 23:10:42.072+09	testdb	public	pgbench_branches	0	0	45	310	22	0.039999999
1	2011-08-16 23:09:58.523+09	testdb	public	pgbench_tellers	1	0	67	575	101	0.039999999
1	2011-08-16 23:11:53.075+09	testdb	public	pgbench_branches	1	0	45	173	11	0.059999999
1	2011-08-16 23:10:06.267+09	testdb	public	pgbench_tellers	0	0	67	398	118	0.12
1	2011-08-16 23:12:54.551+09	testdb	public	pgbench_branches	0	15	30	116	10	0.14
1	2011-08-16 23:11:24.715+09	testdb	public	pgbench_tellers	0	0	67	927	100	0.059999999
1	2011-08-16 23:12:16.226+09	testdb	public	pgbench_tellers	0	0	67	923	108	0.059999999
1	2011-08-16 23:14:53.157+09	testdb	public	pgbench_branches	0	0	30	73	11	0
1	2011-08-16 23:13:18.273+09	testdb	public	pgbench_tellers	0	0	67	925	106	0.059999999
1	2011-08-16 23:15:43.305+09	testdb	public	pgbench_branches	0	0	30	79	21	0.039999999
1	2011-08-16 23:14:18.428+09	testdb	public	pgbench_tellers	0	0	67	1203	106	0.059999999
1	2011-08-16 23:16:54.881+09	testdb	public	pgbench_branches	0	0	30	181	10	0
1	2011-08-16 23:15:13.002+09	testdb	public	pgbench_tellers	0	0	67	984	112	0.059999999
1	2011-08-16 23:17:54.314+09	testdb	public	pgbench_branches	1	0	45	113	10	0.039999999
1	2011-08-16 23:16:24.424+09	testdb	public	pgbench_tellers	1	0	67	440	100	0.059999999
1	2011-08-16 23:16:43.577+09	testdb	public	pgbench_tellers	0	0	67	436	141	0.17
1	2011-08-16 23:18:23.925+09	testdb	public	pgbench_tellers	0	0	67	526	101	0.039999999
1	2011-08-16 23:19:24.548+09	testdb	public	pgbench_tellers	0	0	67	549	100	0.039999999
1	2011-08-16 23:20:16.611+09	testdb	public	pgbench_tellers	0	0	67	652	108	0.039999999
1	2011-08-16 23:22:47.647+09	testdb	public	pgbench_branches	0	0	45	0	17	0.11
1	2011-08-16 23:21:13.733+09	testdb	public	pgbench_tellers	0	0	67	471	111	0.039999999
1	2011-08-16 23:22:12.763+09	testdb	public	pgbench_tellers	0	0	67	522	112	0.039999999
1	2011-08-16 23:24:53.603+09	testdb	public	pgbench_branches	0	0	45	160	11	0
1	2011-08-16 23:23:12.697+09	testdb	public	pgbench_tellers	0	0	67	530	112	0.039999999
1	2011-08-16 23:25:54.687+09	testdb	public	pgbench_branches	0	0	45	60	10	0.039999999
1	2011-08-16 23:24:24.774+09	testdb	public	pgbench_tellers	0	0	67	558	100	0.039999999
1	2011-08-16 23:26:54.755+09	testdb	public	pgbench_branches	1	0	47	68	10	0.079999998
1	2011-08-16 23:25:24.93+09	testdb	public	pgbench_tellers	1	0	67	358	100	0.13
1	2011-08-16 23:25:43.195+09	testdb	public	pgbench_tellers	0	0	67	638	142	0.17
1	2011-08-16 23:28:14.939+09	testdb	public	pgbench_branches	0	0	47	34	50	0.15000001
1	2011-08-16 23:27:16.075+09	testdb	public	pgbench_tellers	0	0	67	699	109	0.039999999
1	2011-08-16 23:28:22.921+09	testdb	public	pgbench_tellers	0	0	67	601	102	0.039999999
1	2011-08-16 23:30:54.885+09	testdb	public	pgbench_branches	0	0	47	166	10	0.039999999
1	2011-08-16 23:29:24.992+09	testdb	public	pgbench_tellers	0	0	67	616	100	0.039999999
1	2011-08-16 23:31:48.996+09	testdb	public	pgbench_branches	0	0	47	128	16	0.039999999
1	2011-08-16 23:30:17.101+09	testdb	public	pgbench_tellers	0	0	67	583	108	0.039999999
1	2011-08-16 23:32:55.009+09	testdb	public	pgbench_branches	0	0	47	1	10	0
1	2011-08-16 23:31:15.096+09	testdb	public	pgbench_tellers	0	0	67	638	110	0.039999999
1	2011-08-16 23:33:49.059+09	testdb	public	pgbench_branches	0	0	47	8	16	0.039999999
1	2011-08-16 23:32:25.165+09	testdb	public	pgbench_tellers	0	0	67	598	100	0.039999999
1	2011-08-16 23:34:54.053+09	testdb	public	pgbench_branches	0	0	47	173	11	0
1	2011-08-16 23:33:14.149+09	testdb	public	pgbench_tellers	0	0	67	648	111	0.039999999
1	2011-08-16 23:35:54.473+09	testdb	public	pgbench_branches	1	0	47	18	11	0.039999999
1	2011-08-16 23:34:25.598+09	testdb	public	pgbench_tellers	1	0	67	441	100	0.059999999
1	2011-08-16 23:34:39.389+09	testdb	public	pgbench_tellers	0	0	67	481	146	0.17
1	2011-08-16 23:37:31.28+09	testdb	public	pgbench_branches	0	0	47	94	34	0.11
1	2011-08-16 23:36:13.369+09	testdb	public	pgbench_tellers	0	0	67	474	112	0.039999999
1	2011-08-16 23:38:55.257+09	testdb	public	pgbench_branches	0	3	44	117	10	0.039999999
1	2011-08-16 23:37:25.391+09	testdb	public	pgbench_tellers	0	0	67	335	100	0.039999999
1	2011-08-16 23:39:52.299+09	testdb	public	pgbench_branches	0	0	44	0	13	0.039999999
1	2011-08-16 23:38:16.384+09	testdb	public	pgbench_tellers	0	0	67	554	109	0.039999999
1	2011-08-16 23:40:55.364+09	testdb	public	pgbench_branches	0	0	44	22	10	0
1	2011-08-16 23:39:15.46+09	testdb	public	pgbench_tellers	0	0	67	604	110	0.039999999
1	2011-08-16 23:41:42.401+09	testdb	public	pgbench_branches	0	0	44	7	23	0.039999999
1	2011-08-16 23:40:14.498+09	testdb	public	pgbench_tellers	0	0	67	557	111	0.039999999
1	2011-08-16 23:42:54.791+09	testdb	public	pgbench_branches	0	0	44	64	11	0
1	2011-08-16 23:41:13.033+09	testdb	public	pgbench_tellers	0	0	67	498	113	0.039999999
1	2011-08-16 23:43:55.477+09	testdb	public	pgbench_branches	0	0	44	158	10	0.039999999
1	2011-08-16 23:42:25.566+09	testdb	public	pgbench_tellers	0	0	67	470	100	0.039999999
1	2011-08-16 23:44:54.461+09	testdb	public	pgbench_branches	1	0	46	108	11	0
1	2011-08-16 23:43:53.016+09	testdb	public	pgbench_tellers	1	0	97	2	111	0.20999999
1	2011-08-16 23:45:55.654+09	testdb	public	pgbench_branches	1	0	46	11	10	0.039999999
1	2011-08-16 23:43:21.925+09	testdb	public	pgbench_tellers	0	0	97	260	164	0.22
1	2011-08-16 23:46:26.716+09	testdb	public	pgbench_branches	0	10	36	14	39	0.13
1	2011-08-16 23:45:13.826+09	testdb	public	pgbench_tellers	0	0	97	362	112	0.039999999
1	2011-08-16 23:46:13.68+09	testdb	public	pgbench_tellers	0	0	97	259	112	0.039999999
1	2011-08-16 23:48:55.653+09	testdb	public	pgbench_branches	0	0	36	100	10	0.039999999
1	2011-08-16 23:47:25.74+09	testdb	public	pgbench_tellers	0	0	97	380	100	0.039999999
1	2011-08-16 23:49:49.719+09	testdb	public	pgbench_branches	0	0	36	33	16	0.039999999
1	2011-08-16 23:48:15.807+09	testdb	public	pgbench_tellers	0	0	97	292	110	0.039999999
1	2011-08-16 23:50:55.736+09	testdb	public	pgbench_branches	0	0	36	69	10	0
1	2011-08-16 23:49:19.829+09	testdb	public	pgbench_tellers	0	0	97	276	106	0.039999999
1	2011-08-16 23:50:25.865+09	testdb	public	pgbench_tellers	0	0	97	256	100	0.039999999
1	2011-08-16 23:52:50.847+09	testdb	public	pgbench_branches	0	0	36	67	15	0.039999999
1	2011-08-16 23:51:13.933+09	testdb	public	pgbench_tellers	0	0	97	292	112	0.039999999
1	2011-08-16 23:53:56.003+09	testdb	public	pgbench_branches	1	0	45	102	10	0.11
1	2011-08-16 23:52:25.252+09	testdb	public	pgbench_tellers	1	0	97	188	101	0.19
1	2011-08-16 23:54:17.389+09	testdb	public	pgbench_branches	0	0	45	95	49	0.13
1	2011-08-16 23:52:51.694+09	testdb	public	pgbench_tellers	0	0	97	308	135	0.19
1	2011-08-16 23:55:56.10+09	testdb	public	pgbench_branches	0	0	45	270	10	0
1	2011-08-16 23:54:14.209+09	testdb	public	pgbench_tellers	0	45	52	125	112	0.059999999
1	2011-08-16 23:56:56.148+09	testdb	public	pgbench_branches	0	0	45	166	10	0.039999999
1	2011-08-16 23:55:26.235+09	testdb	public	pgbench_tellers	0	0	52	315	100	0.039999999
1	2011-08-16 23:57:49.054+09	testdb	public	pgbench_branches	0	0	45	170	17	0.039999999
1	2011-08-16 23:56:19.14+09	testdb	public	pgbench_tellers	0	0	52	297	107	0.039999999
1	2011-08-16 23:58:55.113+09	testdb	public	pgbench_branches	0	0	45	77	11	0
1	2011-08-16 23:57:13.209+09	testdb	public	pgbench_tellers	0	0	52	317	113	0.039999999
1	2011-08-16 23:59:42.213+09	testdb	public	pgbench_branches	0	0	45	279	24	0.039999999
1	2011-08-16 23:58:18.301+09	testdb	public	pgbench_tellers	0	0	52	230	108	0.039999999
1	2011-08-17 00:00:55.235+09	testdb	public	pgbench_branches	0	0	45	265	11	0
1	2011-08-16 23:59:25.698+09	testdb	public	pgbench_tellers	0	0	52	290	101	0.039999999
1	2011-08-17 00:01:56.236+09	testdb	public	pgbench_branches	0	0	45	141	10	0.039999999
1	2011-08-17 00:00:26.323+09	testdb	public	pgbench_tellers	0	0	52	304	100	0.039999999
1	2011-08-17 00:02:55.244+09	testdb	public	pgbench_branches	1	0	46	188	11	0
1	2011-08-17 00:01:25.325+09	testdb	public	pgbench_tellers	1	0	57	169	101	0.02
1	2011-08-17 00:03:32.768+09	testdb	public	pgbench_branches	0	0	46	180	34	0.11
1	2011-08-17 00:01:28.247+09	testdb	public	pgbench_tellers	0	0	57	310	159	0.17
1	2011-08-17 00:04:41.354+09	testdb	public	pgbench_branches	0	0	46	143	25	0.039999999
1	2011-08-17 00:03:16.495+09	testdb	public	pgbench_tellers	0	0	57	281	110	0.039999999
1	2011-08-17 00:05:55.363+09	testdb	public	pgbench_branches	0	0	46	351	11	0
1	2011-08-17 00:04:09.459+09	testdb	public	pgbench_tellers	0	0	57	375	117	0.039999999
1	2011-08-17 00:06:56.455+09	testdb	public	pgbench_branches	0	0	46	108	10	0.039999999
1	2011-08-17 00:05:26.587+09	testdb	public	pgbench_tellers	0	0	57	345	100	0.039999999
1	2011-08-17 00:07:44.523+09	testdb	public	pgbench_branches	0	0	46	164	22	0.039999999
1	2011-08-17 00:06:18.654+09	testdb	public	pgbench_tellers	0	0	57	291	108	0.039999999
1	2011-08-17 00:08:55.502+09	testdb	public	pgbench_branches	0	0	46	218	11	0
1	2011-08-17 00:07:17.598+09	testdb	public	pgbench_tellers	0	0	57	250	109	0.039999999
1	2011-08-17 00:09:56.594+09	testdb	public	pgbench_branches	0	0	46	251	10	0.039999999
1	2011-08-17 00:08:26.726+09	testdb	public	pgbench_tellers	0	0	57	264	100	0.039999999
1	2011-08-17 00:10:43.636+09	testdb	public	pgbench_branches	0	0	46	311	23	0.039999999
1	2011-08-17 00:09:15.764+09	testdb	public	pgbench_tellers	0	0	57	175	111	0.039999999
1	2011-08-17 00:11:56.73+09	testdb	public	pgbench_branches	1	2	44	69	10	0.12
1	2011-08-17 00:10:25.927+09	testdb	public	pgbench_tellers	1	0	57	436	101	0.15000001
1	2011-08-17 00:10:56.913+09	testdb	public	pgbench_tellers	0	0	57	328	130	0.17
1	2011-08-17 00:12:16.897+09	testdb	public	pgbench_tellers	0	3	54	317	110	0.039999999
1	2011-08-17 00:14:56.874+09	testdb	public	pgbench_branches	0	0	44	78	10	0.13
1	2011-08-17 00:13:27.017+09	testdb	public	pgbench_tellers	0	0	54	395	100	0.039999999
1	2011-08-17 00:14:16.926+09	testdb	public	pgbench_tellers	0	0	54	373	110	0.039999999
1	2011-08-17 00:16:56.905+09	testdb	public	pgbench_branches	0	0	44	192	10	0
1	2011-08-17 00:15:16.003+09	testdb	public	pgbench_tellers	0	0	54	342	111	0.039999999
1	2011-08-17 00:17:45.298+09	testdb	public	pgbench_branches	0	0	44	87	22	0.039999999
1	2011-08-17 00:16:18.39+09	testdb	public	pgbench_tellers	0	0	54	459	109	0.039999999
1	2011-08-17 00:18:55.939+09	testdb	public	pgbench_branches	0	0	44	165	11	0
1	2011-08-17 00:17:17.034+09	testdb	public	pgbench_tellers	0	0	54	388	110	0.039999999
1	2011-08-17 00:19:57.027+09	testdb	public	pgbench_branches	0	0	44	133	10	0.039999999
1	2011-08-17 00:18:27.114+09	testdb	public	pgbench_tellers	0	0	54	517	100	0.039999999
1	2011-08-17 00:20:56.041+09	testdb	public	pgbench_branches	1	0	47	105	11	0.039999999
1	2011-08-17 00:19:26.183+09	testdb	public	pgbench_tellers	1	0	59	192	101	0.079999998
1	2011-08-17 00:21:23.391+09	testdb	public	pgbench_branches	0	0	47	120	44	0.11
1	2011-08-17 00:19:50.61+09	testdb	public	pgbench_tellers	0	0	59	287	137	0.17
1	2011-08-17 00:22:42.134+09	testdb	public	pgbench_branches	0	0	47	144	25	0.039999999
1	2011-08-17 00:22:08.158+09	testdb	public	pgbench_tellers	1	3	56	7473	100	0.039999999
1	2011-08-17 00:23:56.185+09	testdb	public	pgbench_branches	1	0	47	103	11	0.059999999
1	2011-08-17 00:22:11.317+09	testdb	public	pgbench_tellers	0	0	56	313	116	0.079999998
1	2011-08-17 00:24:57.303+09	testdb	public	pgbench_branches	0	14	33	86	10	0.13
1	2011-08-17 00:23:20.396+09	testdb	public	pgbench_tellers	0	0	56	499	107	0.039999999
1	2011-08-17 00:25:48.539+09	testdb	public	pgbench_branches	0	0	33	61	19	0.039999999
1	2011-08-17 00:24:10.643+09	testdb	public	pgbench_tellers	0	0	56	365	117	0.059999999
1	2011-08-17 00:26:56.68+09	testdb	public	pgbench_branches	0	0	33	183	11	0
1	2011-08-17 00:25:17.804+09	testdb	public	pgbench_tellers	0	0	56	402	110	0.039999999
1	2011-08-17 00:27:57.344+09	testdb	public	pgbench_branches	0	0	33	42	10	0.039999999
1	2011-08-17 00:26:27.431+09	testdb	public	pgbench_tellers	0	0	56	573	100	0.039999999
1	2011-08-17 00:27:17.487+09	testdb	public	pgbench_tellers	0	0	56	407	110	0.039999999
1	2011-08-17 00:29:57.379+09	testdb	public	pgbench_branches	1	0	43	175	11	0
1	2011-08-17 00:28:28.459+09	testdb	public	pgbench_tellers	1	0	56	241	100	0.02
1	2011-08-17 00:30:19.575+09	testdb	public	pgbench_branches	0	0	43	131	48	0.13
1	2011-08-17 00:29:07.826+09	testdb	public	pgbench_tellers	0	0	56	534	120	0.15000001
1	2011-08-17 00:31:56.472+09	testdb	public	pgbench_branches	0	0	43	59	11	0
1	2011-08-17 00:30:17.564+09	testdb	public	pgbench_tellers	0	0	56	478	110	0.039999999
1	2011-08-17 00:32:57.56+09	testdb	public	pgbench_branches	0	0	43	156	10	0.039999999
1	2011-08-17 00:31:27.647+09	testdb	public	pgbench_tellers	0	0	56	444	100	0.039999999
1	2011-08-17 00:33:54.046+09	testdb	public	pgbench_branches	0	0	43	41	14	0.039999999
1	2011-08-17 00:32:24.131+09	testdb	public	pgbench_tellers	0	0	56	529	104	0.039999999
1	2011-08-17 00:34:57.609+09	testdb	public	pgbench_branches	0	0	43	141	10	0
1	2011-08-17 00:33:18.71+09	testdb	public	pgbench_tellers	0	0	56	444	109	0.039999999
1	2011-08-17 00:35:46.732+09	testdb	public	pgbench_branches	0	0	43	164	21	0.039999999
1	2011-08-17 00:34:21.828+09	testdb	public	pgbench_tellers	0	0	56	507	106	0.039999999
1	2011-08-17 00:36:56.723+09	testdb	public	pgbench_branches	0	0	43	107	11	0
1	2011-08-17 00:35:21.816+09	testdb	public	pgbench_tellers	0	0	56	412	106	0.039999999
1	2011-08-17 00:37:57.789+09	testdb	public	pgbench_branches	0	0	43	99	10	0.039999999
1	2011-08-17 00:36:27.877+09	testdb	public	pgbench_tellers	0	0	56	506	100	0.039999999
1	2011-08-17 00:38:56.797+09	testdb	public	pgbench_branches	1	0	49	146	11	0.02
1	2011-08-17 00:37:27.88+09	testdb	public	pgbench_tellers	1	0	61	209	100	0.02
1	2011-08-17 00:39:24.921+09	testdb	public	pgbench_branches	0	0	49	48	43	0.11
1	2011-08-17 00:37:50.139+09	testdb	public	pgbench_tellers	0	0	61	233	138	0.17
1	2011-08-17 00:40:57.899+09	testdb	public	pgbench_branches	0	0	49	369	10	0.039999999
1	2011-08-17 00:39:28.007+09	testdb	public	pgbench_tellers	0	0	61	262	100	0.039999999
1	2011-08-17 00:41:47.977+09	testdb	public	pgbench_branches	0	0	49	266	20	0.039999999
1	2011-08-17 00:40:20.083+09	testdb	public	pgbench_tellers	0	0	61	275	108	0.039999999
1	2011-08-17 00:42:57.048+09	testdb	public	pgbench_branches	0	0	49	234	11	0
1	2011-08-17 00:41:18.158+09	testdb	public	pgbench_tellers	0	0	61	178	110	0.039999999
1	2011-08-17 00:43:45.086+09	testdb	public	pgbench_branches	0	0	49	215	23	0.039999999
1	2011-08-17 00:42:17.203+09	testdb	public	pgbench_tellers	0	0	61	290	111	0.039999999
1	2011-08-17 00:44:58.454+09	testdb	public	pgbench_branches	0	0	49	51	10	0
1	2011-08-17 00:43:18.554+09	testdb	public	pgbench_tellers	0	0	61	284	110	0.039999999
1	2011-08-17 00:45:58.148+09	testdb	public	pgbench_branches	0	0	49	196	10	0.039999999
1	2011-08-17 00:44:28.255+09	testdb	public	pgbench_tellers	0	0	61	380	100	0.039999999
1	2011-08-17 00:46:46.265+09	testdb	public	pgbench_branches	0	0	49	244	22	0.039999999
1	2011-08-17 00:45:15.371+09	testdb	public	pgbench_tellers	0	0	61	378	113	0.039999999
1	2011-08-17 00:47:58.284+09	testdb	public	pgbench_branches	1	6	43	2	10	0.07
1	2011-08-17 00:46:27.444+09	testdb	public	pgbench_tellers	1	3	58	336	101	0.1
1	2011-08-17 00:48:42.389+09	testdb	public	pgbench_branches	0	0	43	0	26	0.13
1	2011-08-17 00:46:50.647+09	testdb	public	pgbench_tellers	0	0	58	548	138	0.15000001
1	2011-08-17 00:49:57.678+09	testdb	public	pgbench_branches	0	0	43	73	11	0
1	2011-08-17 00:48:20.884+09	testdb	public	pgbench_tellers	0	0	58	612	108	0.039999999
1	2011-08-17 00:50:58.36+09	testdb	public	pgbench_branches	0	0	43	58	10	0.039999999
1	2011-08-17 00:49:28.447+09	testdb	public	pgbench_tellers	0	0	58	633	100	0.039999999
1	2011-08-17 00:51:52.407+09	testdb	public	pgbench_branches	0	0	43	9	16	0.039999999
1	2011-08-17 00:50:22.492+09	testdb	public	pgbench_tellers	0	0	58	428	106	0.039999999
1	2011-08-17 00:52:58.557+09	testdb	public	pgbench_branches	0	0	43	90	10	0
1	2011-08-17 00:51:15.651+09	testdb	public	pgbench_tellers	0	0	58	488	113	0.039999999
1	2011-08-17 00:52:17.588+09	testdb	public	pgbench_tellers	0	0	58	662	111	0.039999999
1	2011-08-17 00:54:57.553+09	testdb	public	pgbench_branches	0	0	43	1	11	0
1	2011-08-17 00:53:16.653+09	testdb	public	pgbench_tellers	0	0	58	574	112	0.039999999
1	2011-08-17 00:55:58.584+09	testdb	public	pgbench_branches	0	0	43	82	10	0.039999999
1	2011-08-17 00:54:28.671+09	testdb	public	pgbench_tellers	0	0	58	580	100	0.039999999
1	2011-08-17 00:56:57.647+09	testdb	public	pgbench_branches	1	0	49	69	11	0.059999999
1	2011-08-17 00:55:27.834+09	testdb	public	pgbench_tellers	1	0	62	189	101	0.13
1	2011-08-17 00:57:49.791+09	testdb	public	pgbench_branches	0	0	49	0	19	0.11
1	2011-08-17 00:55:42.013+09	testdb	public	pgbench_tellers	0	0	62	289	147	0.17
1	2011-08-17 00:58:58.706+09	testdb	public	pgbench_branches	0	0	49	182	10	0.039999999
1	2011-08-17 00:57:28.814+09	testdb	public	pgbench_tellers	0	0	62	165	100	0.039999999
1	2011-08-17 00:59:51.788+09	testdb	public	pgbench_branches	0	0	49	104	17	0.039999999
1	2011-08-17 00:58:11.90+09	testdb	public	pgbench_tellers	0	0	62	246	117	0.039999999
1	2011-08-17 00:59:19.173+09	testdb	public	pgbench_tellers	0	0	62	196	110	0.039999999
1	2011-08-17 01:01:45.859+09	testdb	public	pgbench_branches	0	0	49	1	23	0.039999999
1	2011-08-17 01:00:20.971+09	testdb	public	pgbench_tellers	0	0	62	366	108	0.039999999
1	2011-08-17 01:02:57.991+09	testdb	public	pgbench_branches	0	0	49	6	11	0
1	2011-08-17 01:01:19.087+09	testdb	public	pgbench_tellers	0	0	62	224	110	0.039999999
1	2011-08-17 01:03:58.949+09	testdb	public	pgbench_branches	0	0	49	134	10	0.039999999
1	2011-08-17 01:03:07.788+09	testdb	public	pgbench_tellers	1	3	59	8391	100	0.07
1	2011-08-17 01:04:59.097+09	testdb	public	pgbench_branches	1	12	37	39	10	0.090000004
1	2011-08-17 01:02:46.28+09	testdb	public	pgbench_tellers	0	0	59	238	143	0.13
1	2011-08-17 01:05:58.061+09	testdb	public	pgbench_branches	1	0	47	110	11	0.059999999
1	2011-08-17 01:04:29.207+09	testdb	public	pgbench_tellers	1	0	59	275	100	0.090000004
1	2011-08-17 01:06:16.156+09	testdb	public	pgbench_branches	0	0	47	81	53	0.15000001
1	2011-08-17 01:04:57.424+09	testdb	public	pgbench_tellers	0	0	59	197	132	0.17
1	2011-08-17 01:07:58.046+09	testdb	public	pgbench_branches	0	0	47	67	11	0
1	2011-08-17 01:06:20.139+09	testdb	public	pgbench_tellers	0	0	59	218	109	0.039999999
1	2011-08-17 01:08:59.133+09	testdb	public	pgbench_branches	0	0	47	123	10	0.039999999
1	2011-08-17 01:07:29.24+09	testdb	public	pgbench_tellers	0	0	59	214	100	0.039999999
1	2011-08-17 01:09:48.306+09	testdb	public	pgbench_branches	0	0	47	202	21	0.039999999
1	2011-08-17 01:08:18.406+09	testdb	public	pgbench_tellers	0	0	59	216	111	0.039999999
1	2011-08-17 01:10:59.201+09	testdb	public	pgbench_branches	0	0	47	70	10	0
1	2011-08-17 01:09:20.297+09	testdb	public	pgbench_tellers	0	0	59	238	109	0.039999999
1	2011-08-17 01:11:46.318+09	testdb	public	pgbench_branches	0	0	47	255	23	0.039999999
1	2011-08-17 01:10:29.432+09	testdb	public	pgbench_tellers	0	0	59	242	100	0.039999999
1	2011-08-17 01:12:58.343+09	testdb	public	pgbench_branches	0	0	47	231	11	0
1	2011-08-17 01:11:19.44+09	testdb	public	pgbench_tellers	0	0	59	115	110	0.039999999
1	2011-08-17 01:13:59.395+09	testdb	public	pgbench_branches	0	0	47	200	10	0.039999999
1	2011-08-17 01:12:21.501+09	testdb	public	pgbench_tellers	0	0	59	181	108	0.039999999
1	2011-08-17 01:14:58.393+09	testdb	public	pgbench_branches	1	0	47	115	11	0.02
1	2011-08-17 01:13:28.465+09	testdb	public	pgbench_tellers	1	0	59	348	101	0.02
1	2011-08-17 01:15:33.584+09	testdb	public	pgbench_branches	0	0	47	142	36	0.11
1	2011-08-17 01:13:40.81+09	testdb	public	pgbench_tellers	0	0	59	302	149	0.17
1	2011-08-17 01:16:59.505+09	testdb	public	pgbench_branches	0	2	45	62	10	0.039999999
1	2011-08-17 01:15:29.636+09	testdb	public	pgbench_tellers	0	0	59	322	100	0.039999999
1	2011-08-17 01:16:19.639+09	testdb	public	pgbench_tellers	0	0	59	310	110	0.039999999
1	2011-08-17 01:18:59.59+09	testdb	public	pgbench_branches	0	0	45	49	10	0
1	2011-08-17 01:17:17.68+09	testdb	public	pgbench_tellers	0	0	59	468	112	0.039999999
1	2011-08-17 01:19:51.708+09	testdb	public	pgbench_branches	0	0	45	97	18	0.039999999
1	2011-08-17 01:18:21.789+09	testdb	public	pgbench_tellers	0	0	59	274	108	0.039999999
1	2011-08-17 01:20:58.946+09	testdb	public	pgbench_branches	0	0	45	160	11	0
1	2011-08-17 01:19:20.105+09	testdb	public	pgbench_tellers	0	0	59	327	110	0.039999999
1	2011-08-17 01:21:59.731+09	testdb	public	pgbench_branches	0	0	45	119	10	0.039999999
1	2011-08-17 01:20:29.817+09	testdb	public	pgbench_tellers	0	0	59	261	100	0.039999999
1	2011-08-17 01:22:54.777+09	testdb	public	pgbench_branches	0	0	45	116	15	0.039999999
1	2011-08-17 01:21:21.871+09	testdb	public	pgbench_tellers	0	0	59	424	108	0.039999999
1	2011-08-17 01:23:59.918+09	testdb	public	pgbench_branches	1	2	43	180	10	0.0099999998
1	2011-08-17 01:22:28.99+09	testdb	public	pgbench_tellers	1	6	53	149	101	0.02
1	2011-08-17 01:24:21.941+09	testdb	public	pgbench_branches	0	0	43	76	48	0.13
1	2011-08-17 01:22:51.197+09	testdb	public	pgbench_tellers	0	0	53	353	139	0.15000001
1	2011-08-17 01:25:58.864+09	testdb	public	pgbench_branches	0	0	43	49	11	0
1	2011-08-17 01:24:21.956+09	testdb	public	pgbench_tellers	0	0	53	369	108	0.039999999
1	2011-08-17 01:26:59.953+09	testdb	public	pgbench_branches	0	0	43	171	10	0.039999999
1	2011-08-17 01:25:30.04+09	testdb	public	pgbench_tellers	0	0	53	333	100	0.039999999
1	2011-08-17 01:27:55.055+09	testdb	public	pgbench_branches	0	0	43	0	15	0.039999999
1	2011-08-17 01:26:18.139+09	testdb	public	pgbench_tellers	0	0	53	351	112	0.039999999
1	2011-08-17 01:28:59.457+09	testdb	public	pgbench_branches	0	0	43	25	11	0
1	2011-08-17 01:27:12.577+09	testdb	public	pgbench_tellers	0	0	53	404	118	0.039999999
1	2011-08-17 01:28:18.246+09	testdb	public	pgbench_tellers	0	0	53	247	112	0.039999999
1	2011-08-17 01:31:00.087+09	testdb	public	pgbench_branches	0	0	43	77	10	0
1	2011-08-17 01:29:18.181+09	testdb	public	pgbench_tellers	0	0	53	290	112	0.039999999
1	2011-08-17 01:32:00.176+09	testdb	public	pgbench_branches	0	0	43	157	10	0.039999999
1	2011-08-17 01:30:30.262+09	testdb	public	pgbench_tellers	0	0	53	395	100	0.039999999
1	2011-08-17 01:32:59.201+09	testdb	public	pgbench_branches	1	0	45	61	11	0.02
1	2011-08-17 01:31:30.263+09	testdb	public	pgbench_tellers	1	0	56	103	100	0.02
1	2011-08-17 01:33:33.312+09	testdb	public	pgbench_branches	0	0	45	26	37	0.11
1	2011-08-17 01:33:30.495+09	testdb	public	pgbench_tellers	0	0	56	59	100	0.17
1	2011-08-17 01:35:59.327+09	testdb	public	pgbench_branches	0	0	45	108	11	0
1	2011-08-17 01:34:25.428+09	testdb	public	pgbench_tellers	0	0	56	199	105	0.039999999
1	2011-08-17 01:36:59.449+09	testdb	public	pgbench_branches	0	0	45	17	11	0
1	2011-08-17 01:35:24.548+09	testdb	public	pgbench_tellers	0	0	56	36	106	0.039999999
1	2011-08-17 01:37:42.549+09	testdb	public	pgbench_branches	0	0	45	156	28	0.039999999
1	2011-08-17 01:38:59.436+09	testdb	public	pgbench_branches	0	0	45	9	11	0
1	2011-08-17 01:37:24.552+09	testdb	public	pgbench_tellers	0	0	56	171	106	0.039999999
1	2011-08-17 01:38:30.611+09	testdb	public	pgbench_tellers	0	0	56	99	100	0.039999999
1	2011-08-17 01:40:54.574+09	testdb	public	pgbench_branches	0	0	45	34	16	0.039999999
1	2011-08-17 01:39:25.658+09	testdb	public	pgbench_tellers	0	0	56	165	105	0.039999999
1	2011-08-17 01:41:59.761+09	testdb	public	pgbench_branches	1	0	45	149	11	0.039999999
1	2011-08-17 01:40:29.851+09	testdb	public	pgbench_tellers	1	0	56	104	101	0.039999999
1	2011-08-17 01:42:20.744+09	testdb	public	pgbench_branches	0	0	45	129	50	0.15000001
1	2011-08-17 01:40:46.012+09	testdb	public	pgbench_tellers	0	0	56	261	145	0.17
1	2011-08-17 01:43:59.838+09	testdb	public	pgbench_branches	0	0	45	92	11	0
1	2011-08-17 01:42:18.074+09	testdb	public	pgbench_tellers	0	0	56	181	113	0.039999999
1	2011-08-17 01:45:00.72+09	testdb	public	pgbench_branches	0	0	45	118	10	0.039999999
1	2011-08-17 01:43:30.808+09	testdb	public	pgbench_tellers	0	0	56	278	100	0.039999999
1	2011-08-17 01:45:53.803+09	testdb	public	pgbench_branches	0	0	45	26	17	0.039999999
1	2011-08-17 01:44:24.889+09	testdb	public	pgbench_tellers	0	0	56	160	106	0.039999999
1	2011-08-17 01:47:00.812+09	testdb	public	pgbench_branches	0	0	45	192	10	0
1	2011-08-17 01:45:15.904+09	testdb	public	pgbench_tellers	0	0	56	246	115	0.039999999
1	2011-08-17 01:48:00.856+09	testdb	public	pgbench_branches	0	0	45	168	10	0.039999999
1	2011-08-17 01:46:30.944+09	testdb	public	pgbench_tellers	0	0	56	278	100	0.039999999
1	2011-08-17 01:48:57.932+09	testdb	public	pgbench_branches	0	0	45	146	13	0.039999999
1	2011-08-17 01:48:09.975+09	testdb	public	pgbench_tellers	1	4	52	909	100	0.02
1	2011-08-17 01:50:00.985+09	testdb	public	pgbench_branches	1	0	45	149	10	0.079999998
1	2011-08-17 01:48:06.157+09	testdb	public	pgbench_tellers	0	0	52	253	125	0.11
1	2011-08-17 01:51:00.277+09	testdb	public	pgbench_branches	1	0	49	156	11	0.22
1	2011-08-17 01:49:30.647+09	testdb	public	pgbench_tellers	1	0	62	152	101	0.18000001
1	2011-08-17 01:51:27.142+09	testdb	public	pgbench_branches	0	0	49	48	44	0.11
1	2011-08-17 01:49:48.362+09	testdb	public	pgbench_tellers	0	0	62	315	143	0.17
1	2011-08-17 01:53:01.06+09	testdb	public	pgbench_branches	0	0	49	165	10	0.039999999
1	2011-08-17 01:51:31.168+09	testdb	public	pgbench_tellers	0	0	62	312	100	0.039999999
1	2011-08-17 01:52:25.188+09	testdb	public	pgbench_tellers	0	0	62	354	106	0.039999999
1	2011-08-17 01:55:00.133+09	testdb	public	pgbench_branches	0	0	49	132	11	0
1	2011-08-17 01:53:19.227+09	testdb	public	pgbench_tellers	0	0	62	337	112	0.039999999
1	2011-08-17 01:55:50.313+09	testdb	public	pgbench_branches	0	0	49	167	21	0.039999999
1	2011-08-17 01:54:19.429+09	testdb	public	pgbench_tellers	0	0	62	399	112	0.039999999
1	2011-08-17 01:57:00.198+09	testdb	public	pgbench_branches	0	0	49	174	11	0
1	2011-08-17 01:55:23.292+09	testdb	public	pgbench_tellers	0	0	62	430	108	0.039999999
1	2011-08-17 01:58:01.284+09	testdb	public	pgbench_branches	0	0	49	149	10	0.039999999
1	2011-08-17 01:56:31.391+09	testdb	public	pgbench_tellers	0	0	62	297	100	0.039999999
1	2011-08-17 01:57:25.464+09	testdb	public	pgbench_tellers	0	0	62	400	106	0.039999999
1	2011-08-17 02:00:02.183+09	testdb	public	pgbench_branches	1	4	45	57	10	0.050000001
1	2011-08-17 01:58:31.301+09	testdb	public	pgbench_tellers	1	0	62	414	101	0.07
1	2011-08-17 01:58:55.916+09	testdb	public	pgbench_tellers	0	3	59	379	136	0.17
1	2011-08-17 02:01:39.496+09	testdb	public	pgbench_branches	0	0	45	258	32	0.079999998
1	2011-08-17 02:00:21.60+09	testdb	public	pgbench_tellers	0	0	59	278	110	0.039999999
1	2011-08-17 02:03:01.488+09	testdb	public	pgbench_branches	0	0	45	220	10	0.039999999
1	2011-08-17 02:01:31.582+09	testdb	public	pgbench_tellers	0	0	59	425	100	0.039999999
1	2011-08-17 02:02:25.655+09	testdb	public	pgbench_tellers	0	0	59	577	106	0.039999999
1	2011-08-17 02:05:00.548+09	testdb	public	pgbench_branches	0	0	45	104	11	0
1	2011-08-17 02:03:19.644+09	testdb	public	pgbench_tellers	0	0	59	526	112	0.039999999
1	2011-08-17 02:06:01.632+09	testdb	public	pgbench_branches	0	0	45	284	10	0.039999999
1	2011-08-17 02:04:31.719+09	testdb	public	pgbench_tellers	0	0	59	557	100	0.039999999
1	2011-08-17 02:07:01.668+09	testdb	public	pgbench_branches	0	0	45	199	10	0
1	2011-08-17 02:05:27.774+09	testdb	public	pgbench_tellers	0	0	59	412	104	0.039999999
1	2011-08-17 02:08:00.701+09	testdb	public	pgbench_branches	0	0	45	132	11	0
1	2011-08-17 02:06:26.798+09	testdb	public	pgbench_tellers	0	0	59	449	105	0.039999999
1	2011-08-17 02:09:01.253+09	testdb	public	pgbench_branches	1	0	50	65	11	0.1
1	2011-08-17 02:07:32.552+09	testdb	public	pgbench_tellers	1	0	62	210	100	0.18000001
1	2011-08-17 02:09:31.853+09	testdb	public	pgbench_branches	0	0	50	129	40	0.11
1	2011-08-17 02:07:57.08+09	testdb	public	pgbench_tellers	0	0	62	356	135	0.17
1	2011-08-17 02:11:01.828+09	testdb	public	pgbench_branches	0	0	50	129	10	0.039999999
1	2011-08-17 02:09:31.936+09	testdb	public	pgbench_tellers	0	0	62	415	100	0.039999999
1	2011-08-17 02:11:53.882+09	testdb	public	pgbench_branches	0	0	50	88	18	0.039999999
1	2011-08-17 02:10:26.988+09	testdb	public	pgbench_tellers	0	0	62	196	105	0.039999999
1	2011-08-17 02:13:01.869+09	testdb	public	pgbench_branches	0	0	50	144	10	0
1	2011-08-17 02:11:21.964+09	testdb	public	pgbench_tellers	0	0	62	417	110	0.039999999
1	2011-08-17 02:13:50.003+09	testdb	public	pgbench_branches	0	0	50	28	22	0.039999999
1	2011-08-17 02:12:24.119+09	testdb	public	pgbench_tellers	0	0	62	311	108	0.039999999
1	2011-08-17 02:15:00.993+09	testdb	public	pgbench_branches	0	0	50	39	11	0
1	2011-08-17 02:13:21.093+09	testdb	public	pgbench_tellers	0	0	62	377	111	0.039999999
1	2011-08-17 02:16:02.067+09	testdb	public	pgbench_branches	0	0	50	90	10	0.039999999
1	2011-08-17 02:14:32.174+09	testdb	public	pgbench_tellers	0	0	62	151	100	0.039999999
1	2011-08-17 02:15:19.205+09	testdb	public	pgbench_tellers	0	0	62	305	113	0.039999999
1	2011-08-17 02:18:01.173+09	testdb	public	pgbench_branches	1	0	50	142	11	0.02
1	2011-08-17 02:16:31.301+09	testdb	public	pgbench_tellers	1	3	59	306	101	0.059999999
1	2011-08-17 02:18:29.287+09	testdb	public	pgbench_branches	0	0	50	144	43	0.15000001
1	2011-08-17 02:17:32.554+09	testdb	public	pgbench_tellers	0	0	59	267	100	0.17
1	2011-08-17 02:20:01.199+09	testdb	public	pgbench_branches	0	0	50	185	11	0
1	2011-08-17 02:18:16.302+09	testdb	public	pgbench_tellers	0	0	59	499	116	0.039999999
1	2011-08-17 02:21:02.271+09	testdb	public	pgbench_branches	0	5	45	174	10	0.039999999
1	2011-08-17 02:19:32.405+09	testdb	public	pgbench_tellers	0	0	59	465	100	0.039999999
1	2011-08-17 02:21:51.309+09	testdb	public	pgbench_branches	0	0	45	20	21	0.039999999
1	2011-08-17 02:20:23.40+09	testdb	public	pgbench_tellers	0	0	59	494	109	0.039999999
1	2011-08-17 02:23:01.344+09	testdb	public	pgbench_branches	0	0	45	24	11	0
1	2011-08-17 02:21:21.439+09	testdb	public	pgbench_tellers	0	0	59	598	111	0.039999999
1	2011-08-17 02:24:02.392+09	testdb	public	pgbench_branches	0	0	45	57	10	0.039999999
1	2011-08-17 02:22:32.48+09	testdb	public	pgbench_tellers	0	0	59	448	100	0.039999999
1	2011-08-17 02:23:31.923+09	testdb	public	pgbench_tellers	0	0	59	521	101	0.039999999
1	2011-08-17 02:26:02.425+09	testdb	public	pgbench_branches	0	0	45	39	10	0
1	2011-08-17 02:24:24.529+09	testdb	public	pgbench_tellers	0	0	59	445	108	0.039999999
1	2011-08-17 02:27:02.478+09	testdb	public	pgbench_branches	1	0	49	98	10	0.02
1	2011-08-17 02:25:31.557+09	testdb	public	pgbench_tellers	1	0	61	155	101	0.02
1	2011-08-17 02:25:43.754+09	testdb	public	pgbench_tellers	0	0	61	297	149	0.17
1	2011-08-17 02:29:02.707+09	testdb	public	pgbench_branches	0	0	49	157	10	0.15000001
1	2011-08-17 02:27:32.838+09	testdb	public	pgbench_tellers	0	0	61	438	100	0.039999999
1	2011-08-17 02:29:56.646+09	testdb	public	pgbench_branches	0	0	49	159	16	0.039999999
1	2011-08-17 02:28:21.754+09	testdb	public	pgbench_tellers	0	0	61	431	111	0.039999999
1	2011-08-17 02:31:02.682+09	testdb	public	pgbench_branches	0	0	49	65	10	0
1	2011-08-17 02:29:21.769+09	testdb	public	pgbench_tellers	0	0	61	215	111	0.039999999
1	2011-08-17 02:30:26.847+09	testdb	public	pgbench_tellers	0	0	61	281	106	0.039999999
1	2011-08-17 02:33:03.17+09	testdb	public	pgbench_branches	0	0	49	25	10	0
1	2011-08-17 02:31:25.264+09	testdb	public	pgbench_tellers	0	0	61	301	108	0.039999999
1	2011-08-17 02:34:02.827+09	testdb	public	pgbench_branches	0	0	49	119	10	0.039999999
1	2011-08-17 02:32:32.933+09	testdb	public	pgbench_tellers	0	0	61	341	100	0.039999999
1	2011-08-17 02:34:58.869+09	testdb	public	pgbench_branches	0	0	49	58	14	0.039999999
1	2011-08-17 02:33:23.969+09	testdb	public	pgbench_tellers	0	0	61	275	109	0.039999999
1	2011-08-17 02:36:01.848+09	testdb	public	pgbench_branches	1	0	49	120	11	0
1	2011-08-17 02:34:31.926+09	testdb	public	pgbench_tellers	1	0	61	331	101	0.02
1	2011-08-17 02:37:03.04+09	testdb	public	pgbench_branches	0	5	44	179	10	0.15000001
1	2011-08-17 02:35:33.302+09	testdb	public	pgbench_tellers	0	0	61	484	100	0.17
1	2011-08-17 02:36:23.227+09	testdb	public	pgbench_tellers	0	0	61	395	110	0.039999999
1	2011-08-17 02:39:02.975+09	testdb	public	pgbench_branches	0	0	44	72	10	0
1	2011-08-17 02:38:12.847+09	testdb	public	pgbench_tellers	1	0	61	618	101	0.02
1	2011-08-17 02:40:02.177+09	testdb	public	pgbench_branches	1	3	41	232	11	0.12
1	2011-08-17 02:37:54.372+09	testdb	public	pgbench_tellers	0	0	61	227	139	0.15000001
1	2011-08-17 02:40:56.322+09	testdb	public	pgbench_branches	0	0	41	229	18	0.98000002
1	2011-08-17 02:39:22.685+09	testdb	public	pgbench_tellers	0	0	61	388	112	0.039999999
1	2011-08-17 02:42:03.158+09	testdb	public	pgbench_branches	0	0	41	204	10	0.039999999
1	2011-08-17 02:40:33.245+09	testdb	public	pgbench_tellers	0	0	61	373	100	0.039999999
1	2011-08-17 02:42:54.273+09	testdb	public	pgbench_branches	0	0	41	149	19	0.039999999
1	2011-08-17 02:41:28.359+09	testdb	public	pgbench_tellers	0	0	61	267	105	0.039999999
1	2011-08-17 02:44:03.618+09	testdb	public	pgbench_branches	0	0	41	255	10	0
1	2011-08-17 02:42:25.721+09	testdb	public	pgbench_tellers	0	0	61	531	108	0.039999999
1	2011-08-17 02:45:03.261+09	testdb	public	pgbench_branches	1	0	45	143	10	0.02
1	2011-08-17 02:43:33.333+09	testdb	public	pgbench_tellers	1	0	61	361	100	0.02
1	2011-08-17 02:43:54.519+09	testdb	public	pgbench_tellers	0	0	61	480	139	0.17
1	2011-08-17 02:47:03.473+09	testdb	public	pgbench_branches	0	0	45	129	10	0.13
1	2011-08-17 02:45:33.615+09	testdb	public	pgbench_tellers	0	0	61	511	100	0.039999999
1	2011-08-17 02:48:03.388+09	testdb	public	pgbench_branches	0	0	45	170	10	0
1	2011-08-17 02:46:20.479+09	testdb	public	pgbench_tellers	0	0	61	541	113	0.039999999
1	2011-08-17 02:49:04.673+09	testdb	public	pgbench_branches	0	0	45	9	10	0
1	2011-08-17 02:47:15.957+09	testdb	public	pgbench_tellers	0	0	61	504	119	0.039999999
1	2011-08-17 02:50:03.562+09	testdb	public	pgbench_branches	0	0	45	190	10	0.039999999
1	2011-08-17 02:48:33.65+09	testdb	public	pgbench_tellers	0	0	61	439	100	0.039999999
1	2011-08-17 02:50:57.613+09	testdb	public	pgbench_branches	0	0	45	113	16	0.039999999
1	2011-08-17 02:49:23.699+09	testdb	public	pgbench_tellers	0	0	61	366	110	0.039999999
1	2011-08-17 02:52:03.624+09	testdb	public	pgbench_branches	0	0	45	143	10	0.039999999
1	2011-08-17 02:50:30.711+09	testdb	public	pgbench_tellers	0	0	61	574	103	0.039999999
1	2011-08-17 02:51:20.763+09	testdb	public	pgbench_tellers	0	0	61	418	113	0.039999999
1	2011-08-17 02:54:02.645+09	testdb	public	pgbench_branches	1	0	46	63	11	0
1	2011-08-17 02:52:33.727+09	testdb	public	pgbench_tellers	1	0	61	425	100	0.02
1	2011-08-17 02:53:33.945+09	testdb	public	pgbench_tellers	0	0	61	595	100	0.17
1	2011-08-17 02:54:21.868+09	testdb	public	pgbench_tellers	0	0	61	491	112	0.039999999
1	2011-08-17 02:56:39.369+09	testdb	public	pgbench_branches	0	0	46	0	35	0.11
1	2011-08-17 02:55:23.458+09	testdb	public	pgbench_tellers	0	0	61	498	111	0.039999999
1	2011-08-17 02:57:49.94+09	testdb	public	pgbench_branches	0	0	46	46	24	0.039999999
1	2011-08-17 02:56:27.056+09	testdb	public	pgbench_tellers	0	0	61	521	107	0.039999999
1	2011-08-17 02:57:22.99+09	testdb	public	pgbench_tellers	0	0	61	552	111	0.039999999
1	2011-08-17 03:00:03.945+09	testdb	public	pgbench_branches	0	0	46	159	10	0.039999999
1	2011-08-17 02:58:34.052+09	testdb	public	pgbench_tellers	0	0	61	496	100	0.039999999
1	2011-08-17 03:00:56.992+09	testdb	public	pgbench_branches	0	0	46	125	17	0.039999999
1	2011-08-17 02:59:26.082+09	testdb	public	pgbench_tellers	0	0	61	661	108	0.039999999
1	2011-08-17 03:02:02.98+09	testdb	public	pgbench_branches	0	0	46	162	11	0
1	2011-08-17 03:00:21.08+09	testdb	public	pgbench_tellers	0	0	61	489	113	0.039999999
1	2011-08-17 03:03:03.089+09	testdb	public	pgbench_branches	1	0	48	191	11	0.079999998
1	2011-08-17 03:01:34.247+09	testdb	public	pgbench_tellers	1	0	61	330	100	0.11
1	2011-08-17 03:04:02.346+09	testdb	public	pgbench_branches	0	0	48	47	12	0.11
1	2011-08-17 03:02:11.039+09	testdb	public	pgbench_tellers	0	0	61	278	124	0.17
1	2011-08-17 03:05:04.14+09	testdb	public	pgbench_branches	0	0	48	57	10	0.039999999
1	2011-08-17 03:03:34.248+09	testdb	public	pgbench_tellers	0	0	61	343	100	0.039999999
1	2011-08-17 03:05:56.183+09	testdb	public	pgbench_branches	0	0	48	163	18	0.039999999
1	2011-08-17 03:04:30.286+09	testdb	public	pgbench_tellers	0	0	61	185	104	0.039999999
1	2011-08-17 03:07:04.253+09	testdb	public	pgbench_branches	0	0	48	145	10	0
1	2011-08-17 03:05:22.34+09	testdb	public	pgbench_tellers	0	0	61	262	112	0.039999999
1	2011-08-17 03:08:04.273+09	testdb	public	pgbench_branches	0	0	48	119	10	0.039999999
1	2011-08-17 03:06:34.381+09	testdb	public	pgbench_tellers	0	0	61	404	100	0.039999999
1	2011-08-17 03:07:23.396+09	testdb	public	pgbench_tellers	0	0	61	268	111	0.039999999
1	2011-08-17 03:10:03.307+09	testdb	public	pgbench_branches	0	0	48	114	11	0
1	2011-08-17 03:08:21.406+09	testdb	public	pgbench_tellers	0	0	61	405	113	0.039999999
1	2011-08-17 03:10:59.394+09	testdb	public	pgbench_branches	0	0	48	187	15	0.039999999
1	2011-08-17 03:09:24.495+09	testdb	public	pgbench_tellers	0	0	61	150	110	0.039999999
1	2011-08-17 03:12:03.476+09	testdb	public	pgbench_branches	1	0	48	64	11	0.059999999
1	2011-08-17 03:10:34.66+09	testdb	public	pgbench_tellers	1	0	61	154	100	0.13
1	2011-08-17 03:13:04.567+09	testdb	public	pgbench_branches	0	3	45	170	10	0.15000001
1	2011-08-17 03:11:34.829+09	testdb	public	pgbench_tellers	0	8	53	372	100	0.17
1	2011-08-17 03:12:30.614+09	testdb	public	pgbench_tellers	0	0	53	335	104	0.039999999
1	2011-08-17 03:15:04.573+09	testdb	public	pgbench_branches	0	0	45	183	10	0
1	2011-08-17 03:13:28.67+09	testdb	public	pgbench_tellers	0	0	53	316	106	0.039999999
1	2011-08-17 03:15:55.641+09	testdb	public	pgbench_branches	0	0	45	137	19	0.039999999
1	2011-08-17 03:14:24.742+09	testdb	public	pgbench_tellers	0	0	53	170	110	0.039999999
1	2011-08-17 03:17:04.625+09	testdb	public	pgbench_branches	0	0	45	87	10	0
1	2011-08-17 03:15:28.718+09	testdb	public	pgbench_tellers	0	0	53	327	106	0.039999999
1	2011-08-17 03:18:04.69+09	testdb	public	pgbench_branches	0	0	45	103	10	0.039999999
1	2011-08-17 03:16:34.776+09	testdb	public	pgbench_tellers	0	0	53	309	100	0.039999999
1	2011-08-17 03:18:57.139+09	testdb	public	pgbench_branches	0	0	45	132	18	0.039999999
1	2011-08-17 03:17:34.603+09	testdb	public	pgbench_tellers	0	0	53	409	101	0.039999999
1	2011-08-17 03:20:04.741+09	testdb	public	pgbench_branches	0	0	45	60	10	0
1	2011-08-17 03:18:23.835+09	testdb	public	pgbench_tellers	0	0	53	320	111	0.039999999
1	2011-08-17 03:21:03.793+09	testdb	public	pgbench_branches	1	0	45	125	11	0.02
1	2011-08-17 03:19:33.866+09	testdb	public	pgbench_tellers	1	0	56	251	101	0.02
1	2011-08-17 03:21:33.963+09	testdb	public	pgbench_branches	0	0	45	79	41	0.11
1	2011-08-17 03:20:10.184+09	testdb	public	pgbench_tellers	0	0	56	129	125	0.17
1	2011-08-17 03:21:34.966+09	testdb	public	pgbench_tellers	0	0	56	94	100	0.039999999
1	2011-08-17 03:22:24.03+09	testdb	public	pgbench_tellers	0	0	56	207	111	0.039999999
1	2011-08-17 03:25:04.139+09	testdb	public	pgbench_branches	0	0	45	82	11	0
1	2011-08-17 03:23:34.596+09	testdb	public	pgbench_tellers	0	0	56	81	101	0.039999999
1	2011-08-17 03:26:05.012+09	testdb	public	pgbench_branches	0	0	45	171	10	0.039999999
1	2011-08-17 03:24:35.10+09	testdb	public	pgbench_tellers	0	0	56	133	100	0.039999999
1	2011-08-17 03:27:00.09+09	testdb	public	pgbench_branches	0	0	45	45	15	0.039999999
1	2011-08-17 03:25:26.175+09	testdb	public	pgbench_tellers	0	0	56	182	109	0.039999999
1	2011-08-17 03:28:04.074+09	testdb	public	pgbench_branches	0	0	45	30	11	0
1	2011-08-17 03:26:28.171+09	testdb	public	pgbench_tellers	0	0	56	112	107	0.039999999
1	2011-08-17 03:28:54.222+09	testdb	public	pgbench_branches	0	0	45	7	21	0.039999999
1	2011-08-17 03:27:26.317+09	testdb	public	pgbench_tellers	0	0	56	252	109	0.039999999
1	2011-08-17 03:30:05.165+09	testdb	public	pgbench_branches	1	0	46	16	10	0
1	2011-08-17 03:28:34.242+09	testdb	public	pgbench_tellers	1	0	57	116	101	0.02
1	2011-08-17 03:31:05.33+09	testdb	public	pgbench_branches	0	0	46	98	10	0.15000001
1	2011-08-17 03:29:35.585+09	testdb	public	pgbench_tellers	0	0	57	165	100	0.17
1	2011-08-17 03:30:25.371+09	testdb	public	pgbench_tellers	0	0	57	178	110	0.039999999
1	2011-08-17 03:33:05.293+09	testdb	public	pgbench_branches	0	0	46	68	10	0
1	2011-08-17 03:31:26.385+09	testdb	public	pgbench_tellers	0	0	57	111	109	0.039999999
1	2011-08-17 03:33:55.391+09	testdb	public	pgbench_branches	0	0	46	7	20	0.039999999
1	2011-08-17 03:33:28.371+09	testdb	public	pgbench_tellers	1	0	60	10745	100	0.090000004
1	2011-08-17 03:35:04.381+09	testdb	public	pgbench_branches	1	0	48	67	11	0
1	2011-08-17 03:33:34.435+09	testdb	public	pgbench_tellers	0	0	60	133	101	0
1	2011-08-17 03:36:05.511+09	testdb	public	pgbench_branches	0	0	48	90	10	0.15000001
1	2011-08-17 03:34:35.645+09	testdb	public	pgbench_tellers	0	0	60	310	100	0.039999999
1	2011-08-17 03:37:00.454+09	testdb	public	pgbench_branches	0	0	48	70	15	0.039999999
1	2011-08-17 03:35:25.556+09	testdb	public	pgbench_tellers	0	0	60	291	110	0.039999999
1	2011-08-17 03:38:05.494+09	testdb	public	pgbench_branches	0	0	48	160	10	0
1	2011-08-17 03:36:24.587+09	testdb	public	pgbench_tellers	0	0	60	160	111	0.039999999
1	2011-08-17 03:39:05.737+09	testdb	public	pgbench_branches	1	0	48	14	10	0.11
1	2011-08-17 03:37:35.952+09	testdb	public	pgbench_tellers	1	0	60	337	100	0.16
1	2011-08-17 03:39:23.757+09	testdb	public	pgbench_branches	0	0	48	71	52	0.15000001
1	2011-08-17 03:38:05.021+09	testdb	public	pgbench_tellers	0	0	60	368	131	0.17
1	2011-08-17 03:39:22.669+09	testdb	public	pgbench_tellers	0	0	60	438	113	0.039999999
1	2011-08-17 03:41:51.967+09	testdb	public	pgbench_branches	0	0	48	129	24	0.039999999
1	2011-08-17 03:40:25.106+09	testdb	public	pgbench_tellers	0	0	60	370	111	0.039999999
1	2011-08-17 03:43:04.652+09	testdb	public	pgbench_branches	0	0	48	44	11	0
1	2011-08-17 03:41:29.753+09	testdb	public	pgbench_tellers	0	0	60	361	106	0.039999999
1	2011-08-17 03:44:05.746+09	testdb	public	pgbench_branches	0	0	48	186	10	0.039999999
1	2011-08-17 03:42:35.878+09	testdb	public	pgbench_tellers	0	0	60	483	100	0.039999999
1	2011-08-17 03:43:28.877+09	testdb	public	pgbench_tellers	0	0	60	371	107	0.039999999
1	2011-08-17 03:46:04.888+09	testdb	public	pgbench_branches	0	0	48	81	11	0
1	2011-08-17 03:44:21.099+09	testdb	public	pgbench_tellers	0	0	60	399	115	0.15000001
1	2011-08-17 03:46:50.931+09	testdb	public	pgbench_branches	0	0	48	93	25	0.039999999
1	2011-08-17 03:45:27.066+09	testdb	public	pgbench_tellers	0	0	60	412	109	0.039999999
1	2011-08-17 03:48:04.943+09	testdb	public	pgbench_branches	1	0	48	188	11	0
1	2011-08-17 03:46:35.021+09	testdb	public	pgbench_tellers	1	0	60	354	101	0.02
1	2011-08-17 03:49:06.042+09	testdb	public	pgbench_branches	0	3	45	51	10	0.15000001
1	2011-08-17 03:47:36.304+09	testdb	public	pgbench_tellers	0	0	60	449	100	0.17
1	2011-08-17 03:48:21.118+09	testdb	public	pgbench_tellers	0	0	60	374	115	0.039999999
1	2011-08-17 03:51:06.002+09	testdb	public	pgbench_branches	0	0	45	190	10	0
1	2011-08-17 03:49:18.102+09	testdb	public	pgbench_tellers	0	0	60	512	118	0.039999999
1	2011-08-17 03:51:56.068+09	testdb	public	pgbench_branches	0	0	45	52	20	0.039999999
1	2011-08-17 03:50:25.159+09	testdb	public	pgbench_tellers	0	0	60	443	111	0.039999999
1	2011-08-17 03:53:05.471+09	testdb	public	pgbench_branches	0	0	45	165	11	0
1	2011-08-17 03:51:28.571+09	testdb	public	pgbench_tellers	0	0	60	491	108	0.039999999
1	2011-08-17 03:54:06.152+09	testdb	public	pgbench_branches	0	0	45	41	10	0.039999999
1	2011-08-17 03:52:36.24+09	testdb	public	pgbench_tellers	0	0	60	442	100	0.039999999
1	2011-08-17 03:54:57.658+09	testdb	public	pgbench_branches	0	0	45	42	19	0.039999999
1	2011-08-17 03:53:20.74+09	testdb	public	pgbench_tellers	0	0	60	486	116	0.039999999
1	2011-08-17 03:56:06.201+09	testdb	public	pgbench_branches	0	0	45	91	10	0
1	2011-08-17 03:54:24.295+09	testdb	public	pgbench_tellers	0	0	60	373	112	0.039999999
1	2011-08-17 03:57:06.259+09	testdb	public	pgbench_branches	1	0	46	55	10	0.039999999
1	2011-08-17 03:55:36.403+09	testdb	public	pgbench_tellers	1	0	60	375	100	0.079999998
1	2011-08-17 03:57:28.228+09	testdb	public	pgbench_branches	0	0	46	0	49	0.13
1	2011-08-17 03:55:58.507+09	testdb	public	pgbench_tellers	0	0	60	341	139	0.17
1	2011-08-17 03:59:05.308+09	testdb	public	pgbench_branches	0	0	46	139	11	0
1	2011-08-17 03:57:29.407+09	testdb	public	pgbench_tellers	0	0	60	268	107	0.039999999
1	2011-08-17 03:59:58.422+09	testdb	public	pgbench_branches	0	0	46	134	18	0.039999999
1	2011-08-17 03:58:30.534+09	testdb	public	pgbench_tellers	0	0	60	253	106	0.039999999
1	2011-08-17 03:59:28.542+09	testdb	public	pgbench_tellers	0	0	60	346	108	0.039999999
1	2011-08-17 04:02:06.48+09	testdb	public	pgbench_branches	0	0	46	134	10	0.039999999
1	2011-08-17 04:00:36.587+09	testdb	public	pgbench_tellers	0	0	60	324	100	0.039999999
1	2011-08-17 04:01:36.078+09	testdb	public	pgbench_tellers	0	0	60	260	101	0.039999999
1	2011-08-17 04:04:05.859+09	testdb	public	pgbench_branches	0	0	46	122	11	0
1	2011-08-17 04:02:26.951+09	testdb	public	pgbench_tellers	0	0	60	206	110	0.039999999
1	2011-08-17 04:04:55.609+09	testdb	public	pgbench_branches	0	0	46	8	21	0.039999999
1	2011-08-17 04:03:28.722+09	testdb	public	pgbench_tellers	0	0	60	255	108	0.039999999
1	2011-08-17 04:06:05.64+09	testdb	public	pgbench_branches	1	0	46	35	11	0
1	2011-08-17 04:04:35.719+09	testdb	public	pgbench_tellers	1	0	60	350	101	0.02
1	2011-08-17 04:07:06.764+09	testdb	public	pgbench_branches	0	4	42	68	10	0.13
1	2011-08-17 04:05:37.037+09	testdb	public	pgbench_tellers	0	0	60	448	100	0.17
1	2011-08-17 04:08:01.782+09	testdb	public	pgbench_branches	0	0	42	49	15	0.039999999
1	2011-08-17 04:06:26.861+09	testdb	public	pgbench_tellers	0	0	60	341	110	0.039999999
1	2011-08-17 04:09:06.785+09	testdb	public	pgbench_branches	0	0	42	36	10	0
1	2011-08-17 04:07:26.88+09	testdb	public	pgbench_tellers	0	0	60	305	110	0.039999999
1	2011-08-17 04:10:05.052+09	testdb	public	pgbench_branches	0	0	42	72	12	0.039999999
1	2011-08-17 04:08:37.138+09	testdb	public	pgbench_tellers	0	0	60	335	100	0.039999999
1	2011-08-17 04:11:06.329+09	testdb	public	pgbench_branches	0	0	42	89	11	0
1	2011-08-17 04:09:30.421+09	testdb	public	pgbench_tellers	0	0	60	303	107	0.039999999
1	2011-08-17 04:12:06.892+09	testdb	public	pgbench_branches	0	0	42	145	10	0.039999999
1	2011-08-17 04:10:36.98+09	testdb	public	pgbench_tellers	0	0	60	406	100	0.039999999
1	2011-08-17 04:12:55.952+09	testdb	public	pgbench_branches	0	0	42	93	21	0.039999999
1	2011-08-17 04:11:27.049+09	testdb	public	pgbench_tellers	0	0	60	250	110	0.039999999
1	2011-08-17 04:14:06.264+09	testdb	public	pgbench_branches	0	0	42	128	11	0
1	2011-08-17 04:12:22.359+09	testdb	public	pgbench_tellers	0	0	60	386	115	0.039999999
1	2011-08-17 04:15:07.005+09	testdb	public	pgbench_branches	1	0	47	87	10	0.039999999
1	2011-08-17 04:13:37.127+09	testdb	public	pgbench_tellers	1	0	60	464	100	0.059999999
1	2011-08-17 04:15:31.226+09	testdb	public	pgbench_branches	0	0	47	48	46	0.15000001
1	2011-08-17 04:13:51.486+09	testdb	public	pgbench_tellers	0	0	60	414	146	0.17
1	2011-08-17 04:15:26.16+09	testdb	public	pgbench_tellers	0	0	60	504	111	0.039999999
1	2011-08-17 04:18:06.639+09	testdb	public	pgbench_branches	0	0	47	32	11	0.039999999
1	2011-08-17 04:16:36.026+09	testdb	public	pgbench_tellers	0	0	60	491	102	0.039999999
1	2011-08-17 04:19:06.669+09	testdb	public	pgbench_branches	0	0	47	81	11	0
1	2011-08-17 04:17:26.772+09	testdb	public	pgbench_tellers	0	0	60	425	111	0.039999999
1	2011-08-17 04:18:37.312+09	testdb	public	pgbench_tellers	0	0	60	370	100	0.039999999
1	2011-08-17 04:21:02.271+09	testdb	public	pgbench_branches	0	0	47	80	15	0.039999999
1	2011-08-17 04:19:26.377+09	testdb	public	pgbench_tellers	0	0	60	367	111	0.039999999
1	2011-08-17 04:22:06.282+09	testdb	public	pgbench_branches	0	0	47	164	11	0
1	2011-08-17 04:20:28.38+09	testdb	public	pgbench_tellers	0	0	60	437	109	0.039999999
1	2011-08-17 04:22:55.357+09	testdb	public	pgbench_branches	0	0	47	52	22	0.039999999
1	2011-08-17 04:21:26.468+09	testdb	public	pgbench_tellers	0	0	60	510	111	0.039999999
1	2011-08-17 04:24:06.407+09	testdb	public	pgbench_branches	1	2	45	92	11	0.050000001
1	2011-08-17 04:22:36.531+09	testdb	public	pgbench_tellers	1	5	55	424	101	0.07
1	2011-08-17 04:25:07.515+09	testdb	public	pgbench_branches	0	0	45	48	10	0.15000001
1	2011-08-17 04:23:37.751+09	testdb	public	pgbench_tellers	0	0	55	515	100	0.15000001
1	2011-08-17 04:24:23.066+09	testdb	public	pgbench_tellers	0	0	55	413	115	0.039999999
1	2011-08-17 04:27:07.489+09	testdb	public	pgbench_branches	0	0	45	45	10	0
1	2011-08-17 04:25:23.58+09	testdb	public	pgbench_tellers	0	0	55	373	114	0.039999999
1	2011-08-17 04:26:37.627+09	testdb	public	pgbench_tellers	0	0	55	127	100	0.039999999
1	2011-08-17 04:27:31.698+09	testdb	public	pgbench_tellers	0	0	55	355	106	0.039999999
1	2011-08-17 04:30:07.662+09	testdb	public	pgbench_branches	0	0	45	121	10	0
1	2011-08-17 04:28:29.763+09	testdb	public	pgbench_tellers	0	0	55	471	108	0.039999999
1	2011-08-17 04:30:54.686+09	testdb	public	pgbench_branches	0	0	45	120	23	0.039999999
1	2011-08-17 04:29:26.784+09	testdb	public	pgbench_tellers	0	0	55	420	111	0.039999999
1	2011-08-17 04:32:06.728+09	testdb	public	pgbench_branches	0	0	45	118	11	0
1	2011-08-17 04:30:32.825+09	testdb	public	pgbench_tellers	0	0	55	500	105	0.039999999
1	2011-08-17 04:33:07.853+09	testdb	public	pgbench_branches	1	0	46	337	10	0.11
1	2011-08-17 04:31:38.081+09	testdb	public	pgbench_tellers	1	0	57	246	100	0.16
1	2011-08-17 04:34:06.033+09	testdb	public	pgbench_branches	0	0	46	343	12	0.13
1	2011-08-17 04:32:35.813+09	testdb	public	pgbench_tellers	0	0	57	302	103	0.17
1	2011-08-17 04:35:07.86+09	testdb	public	pgbench_branches	0	0	46	222	11	0
1	2011-08-17 01:36:15.089+09	testdb	public	pgbench_branches	0	0	48	0	10803	0.13
1	2011-08-17 01:33:50.334+09	testdb	public	pgbench_tellers	0	0	61	0	10948	0.15000001
1	2011-08-17 04:34:55.803+09	testdb	public	pgbench_tellers	1	0	78	3144	101	0.029999999
1	2011-08-17 04:31:21.188+09	testdb	pg_catalog	pg_statistic	1	0	36	84	357	0.30000001
1	2011-08-17 04:34:32.493+09	testdb	public	pgbench_tellers	0	0	78	289	166	0.23999999
1	2011-08-17 04:38:08.169+09	testdb	public	pgbench_branches	1	0	63	42	10	0.25999999
1	2011-08-17 04:36:38.336+09	testdb	public	pgbench_tellers	0	0	78	520	100	0.039999999
1	2011-08-17 04:37:22.233+09	testdb	public	pgbench_tellers	0	0	78	522	116	0.039999999
1	2011-08-17 04:39:27.131+09	testdb	public	pgbench_branches	0	0	63	115	51	0.13
1	2011-08-17 04:38:28.249+09	testdb	public	pgbench_tellers	0	0	78	576	110	0.039999999
1	2011-08-17 04:40:58.136+09	testdb	public	pgbench_branches	0	0	63	12	20	0.039999999
1	2011-08-17 04:39:29.255+09	testdb	public	pgbench_tellers	0	0	78	467	109	0.039999999
1	2011-08-17 04:42:08.174+09	testdb	public	pgbench_branches	1	21	42	105	10	0.029999999
1	2011-08-17 04:40:36.253+09	testdb	public	pgbench_tellers	1	0	78	489	102	0.039999999
1	2011-08-17 04:43:08.233+09	testdb	public	pgbench_branches	0	0	42	152	10	0.13
1	2011-08-17 04:41:38.495+09	testdb	public	pgbench_tellers	0	0	78	507	100	0.17
1	2011-08-17 04:44:02.237+09	testdb	public	pgbench_branches	0	0	42	41	16	0.039999999
1	2011-08-17 04:42:29.345+09	testdb	public	pgbench_tellers	0	0	78	603	109	0.059999999
1	2011-08-17 04:43:32.302+09	testdb	public	pgbench_tellers	0	0	78	620	106	0.059999999
1	2011-08-17 04:46:08.279+09	testdb	public	pgbench_branches	0	0	42	186	10	0.039999999
1	2011-08-17 04:44:38.387+09	testdb	public	pgbench_tellers	0	0	78	620	100	0.059999999
1	2011-08-17 04:45:29.431+09	testdb	public	pgbench_tellers	0	0	78	600	109	0.059999999
1	2011-08-17 04:48:08.322+09	testdb	public	pgbench_branches	0	0	42	156	10	0
1	2011-08-17 04:46:26.433+09	testdb	public	pgbench_tellers	0	0	78	608	112	0.059999999
1	2011-08-17 04:48:53.474+09	testdb	public	pgbench_branches	0	0	42	119	25	0.039999999
1	2011-08-17 04:47:29.588+09	testdb	public	pgbench_tellers	0	0	78	611	109	0.059999999
1	2011-08-17 04:50:07.47+09	testdb	public	pgbench_branches	0	0	42	117	11	0
1	2011-08-17 04:48:29.589+09	testdb	public	pgbench_tellers	0	0	78	502	109	0.059999999
1	2011-08-17 04:51:08.505+09	testdb	public	pgbench_branches	1	0	47	58	10	0.079999998
1	2011-08-17 04:49:38.705+09	testdb	public	pgbench_tellers	1	0	78	692	100	0.15000001
1	2011-08-17 04:49:37.287+09	testdb	public	pgbench_tellers	0	0	78	562	162	0.19
1	2011-08-17 04:52:33.693+09	testdb	public	pgbench_branches	0	0	47	69	45	0.11
1	2011-08-17 04:51:24.798+09	testdb	public	pgbench_tellers	0	0	78	563	114	0.059999999
1	2011-08-17 04:52:30.782+09	testdb	public	pgbench_tellers	0	0	78	598	108	0.059999999
1	2011-08-17 04:53:32.74+09	testdb	public	pgbench_tellers	0	0	78	704	106	0.059999999
1	2011-08-17 04:56:08.691+09	testdb	public	pgbench_branches	0	0	47	44	10	0.039999999
1	2011-08-17 04:54:38.819+09	testdb	public	pgbench_tellers	0	0	78	634	100	0.059999999
1	2011-08-17 04:57:02.833+09	testdb	public	pgbench_branches	0	0	47	110	16	0.039999999
1	2011-08-17 04:55:31.961+09	testdb	public	pgbench_tellers	0	0	78	614	107	0.059999999
1	2011-08-17 04:58:08.802+09	testdb	public	pgbench_branches	0	0	47	117	10	0
1	2011-08-17 04:56:31.924+09	testdb	public	pgbench_tellers	0	0	78	459	107	0.059999999
1	2011-08-17 04:59:05.884+09	testdb	public	pgbench_branches	0	0	47	4	13	0.039999999
1	2011-08-17 04:57:39.01+09	testdb	public	pgbench_tellers	0	0	78	632	100	0.059999999
1	2011-08-17 05:00:08.987+09	testdb	public	pgbench_branches	1	2	45	172	10	0.050000001
1	2011-08-17 04:58:39.112+09	testdb	public	pgbench_tellers	1	0	78	572	100	0.090000004
1	2011-08-17 05:01:08.965+09	testdb	public	pgbench_branches	0	0	45	168	10	0.13
1	2011-08-17 04:59:07.221+09	testdb	public	pgbench_tellers	0	0	78	587	132	0.19
1	2011-08-17 05:01:55.929+09	testdb	public	pgbench_branches	0	0	45	165	23	0.039999999
1	2011-08-17 05:00:27.044+09	testdb	public	pgbench_tellers	0	0	78	658	112	0.059999999
1	2011-08-17 05:03:07.919+09	testdb	public	pgbench_branches	0	0	45	102	11	0
1	2011-08-17 05:01:28.029+09	testdb	public	pgbench_tellers	0	0	78	721	111	0.059999999
1	2011-08-17 05:04:09+09	testdb	public	pgbench_branches	0	0	45	124	10	0.039999999
1	2011-08-17 05:02:39.107+09	testdb	public	pgbench_tellers	0	0	78	667	100	0.059999999
1	2011-08-17 05:05:08.006+09	testdb	public	pgbench_branches	0	0	45	81	11	0
1	2011-08-17 05:03:28.127+09	testdb	public	pgbench_tellers	0	0	78	652	111	0.059999999
1	2011-08-17 05:06:08.089+09	testdb	public	pgbench_branches	0	0	45	134	11	0
1	2011-08-17 05:04:32.204+09	testdb	public	pgbench_tellers	0	0	78	760	107	0.059999999
1	2011-08-17 05:06:58.272+09	testdb	public	pgbench_branches	0	0	45	25	21	0.039999999
1	2011-08-17 05:05:28.386+09	testdb	public	pgbench_tellers	0	0	78	608	111	0.059999999
1	2011-08-17 05:06:33.324+09	testdb	public	pgbench_tellers	0	0	78	585	106	0.059999999
1	2011-08-17 05:09:09.186+09	testdb	public	pgbench_branches	1	3	42	2	10	0.02
1	2011-08-17 05:07:39.273+09	testdb	public	pgbench_tellers	1	0	78	628	100	0.039999999
1	2011-08-17 05:08:01.473+09	testdb	public	pgbench_tellers	0	0	78	842	138	0.17
1	2011-08-17 05:10:44.387+09	testdb	public	pgbench_branches	0	0	42	105	35	0.090000004
1	2011-08-17 05:09:27.501+09	testdb	public	pgbench_tellers	0	0	78	833	112	0.059999999
1	2011-08-17 05:12:09.875+09	testdb	public	pgbench_branches	0	0	42	82	10	0.039999999
1	2011-08-17 05:10:40.196+09	testdb	public	pgbench_tellers	0	0	78	660	100	0.059999999
1	2011-08-17 05:11:28.456+09	testdb	public	pgbench_tellers	0	0	78	930	111	0.059999999
1	2011-08-17 05:14:09.413+09	testdb	public	pgbench_branches	0	0	42	190	10	0.039999999
1	2011-08-17 05:12:39.518+09	testdb	public	pgbench_tellers	0	0	78	852	100	0.059999999
1	2011-08-17 05:14:56.457+09	testdb	public	pgbench_branches	0	0	42	1	23	0.039999999
1	2011-08-17 05:13:28.572+09	testdb	public	pgbench_tellers	0	0	78	859	111	0.059999999
1	2011-08-17 05:14:28.61+09	testdb	public	pgbench_tellers	0	0	78	857	111	0.059999999
1	2011-08-17 05:17:09.541+09	testdb	public	pgbench_branches	0	0	42	71	10	0.039999999
1	2011-08-17 05:15:39.65+09	testdb	public	pgbench_tellers	0	0	78	804	100	0.059999999
1	2011-08-17 05:18:08.63+09	testdb	public	pgbench_branches	1	0	46	100	11	0.039999999
1	2011-08-17 05:16:37.768+09	testdb	public	pgbench_tellers	1	0	78	578	102	0.079999998
1	2011-08-17 05:18:43.037+09	testdb	public	pgbench_branches	0	0	46	52	37	0.11
1	2011-08-17 05:17:01.272+09	testdb	public	pgbench_tellers	0	0	78	857	139	0.19
1	2011-08-17 05:19:58.707+09	testdb	public	pgbench_branches	0	0	46	6	21	0.039999999
1	2011-08-17 05:18:28.844+09	testdb	public	pgbench_tellers	0	0	78	911	111	0.059999999
1	2011-08-17 05:21:08.654+09	testdb	public	pgbench_branches	0	0	46	121	11	0
1	2011-08-17 05:19:29.767+09	testdb	public	pgbench_tellers	0	0	78	688	110	0.059999999
1	2011-08-17 05:22:09.733+09	testdb	public	pgbench_branches	0	0	46	62	10	0.039999999
1	2011-08-17 05:20:39.861+09	testdb	public	pgbench_tellers	0	0	78	650	100	0.059999999
1	2011-08-17 05:23:00.787+09	testdb	public	pgbench_branches	0	0	46	133	19	0.039999999
1	2011-08-17 05:21:25.891+09	testdb	public	pgbench_tellers	0	0	78	819	114	0.059999999
1	2011-08-17 05:24:10.396+09	testdb	public	pgbench_branches	0	0	46	167	10	0
1	2011-08-17 05:22:27.504+09	testdb	public	pgbench_tellers	0	0	78	768	113	0.059999999
1	2011-08-17 05:23:33.063+09	testdb	public	pgbench_tellers	0	0	78	641	107	0.059999999
1	2011-08-17 05:26:09.864+09	testdb	public	pgbench_branches	0	0	46	166	10	0
1	2011-08-17 05:24:28.98+09	testdb	public	pgbench_tellers	0	0	78	798	111	0.059999999
1	2011-08-17 05:27:09.985+09	testdb	public	pgbench_branches	1	2	44	182	10	0.1
1	2011-08-17 05:25:40.185+09	testdb	public	pgbench_tellers	1	0	78	641	100	0.15000001
1	2011-08-17 05:27:30.099+09	testdb	public	pgbench_branches	0	0	44	5	50	0.13
1	2011-08-17 05:25:58.369+09	testdb	public	pgbench_tellers	0	0	78	739	142	0.17
1	2011-08-17 05:29:08.971+09	testdb	public	pgbench_branches	0	0	44	27	11	0
1	2011-08-17 05:27:34.086+09	testdb	public	pgbench_tellers	0	0	78	763	106	0.059999999
1	2011-08-17 05:29:56.061+09	testdb	public	pgbench_branches	0	0	44	23	24	0.039999999
1	2011-08-17 05:28:28.173+09	testdb	public	pgbench_tellers	0	0	78	796	112	0.059999999
1	2011-08-17 05:31:10.084+09	testdb	public	pgbench_branches	0	0	44	23	10	0
1	2011-08-17 05:29:29.193+09	testdb	public	pgbench_tellers	0	0	78	768	111	0.059999999
1	2011-08-17 05:32:10.14+09	testdb	public	pgbench_branches	0	0	44	99	10	0.039999999
1	2011-08-17 05:30:40.246+09	testdb	public	pgbench_tellers	0	0	78	688	100	0.059999999
1	2011-08-17 05:31:34.371+09	testdb	public	pgbench_tellers	0	0	78	758	106	0.059999999
1	2011-08-17 05:34:10.351+09	testdb	public	pgbench_branches	0	0	44	17	10	0
1	2011-08-17 05:32:27.465+09	testdb	public	pgbench_tellers	0	0	78	622	113	0.059999999
1	2011-08-17 05:35:10.272+09	testdb	public	pgbench_branches	0	0	44	82	10	0.039999999
1	2011-08-17 05:33:40.377+09	testdb	public	pgbench_tellers	0	0	78	688	100	0.059999999
1	2011-08-17 05:36:10.246+09	testdb	public	pgbench_branches	1	0	44	14	10	0
1	2011-08-17 05:34:39.472+09	testdb	public	pgbench_tellers	1	0	78	545	101	0.039999999
1	2011-08-17 05:36:38.413+09	testdb	public	pgbench_branches	0	0	44	49	42	0.090000004
1	2011-08-17 05:34:59.647+09	testdb	public	pgbench_tellers	0	0	78	655	141	0.17
1	2011-08-17 05:37:56.365+09	testdb	public	pgbench_branches	0	0	44	67	24	0.039999999
1	2011-08-17 05:36:30.479+09	testdb	public	pgbench_tellers	0	0	78	698	110	0.059999999
1	2011-08-17 05:39:09.422+09	testdb	public	pgbench_branches	0	0	44	40	11	0
1	2011-08-17 05:37:29.54+09	testdb	public	pgbench_tellers	0	0	78	721	111	0.059999999
1	2011-08-17 05:40:10.45+09	testdb	public	pgbench_branches	0	0	44	109	10	0.039999999
1	2011-08-17 05:38:40.559+09	testdb	public	pgbench_tellers	0	0	78	629	100	0.059999999
1	2011-08-17 05:41:09.455+09	testdb	public	pgbench_branches	0	0	44	132	11	0
1	2011-08-17 05:39:30.57+09	testdb	public	pgbench_tellers	0	0	78	669	110	0.059999999
1	2011-08-17 05:42:10.282+09	testdb	public	pgbench_branches	0	0	44	19	11	0
1	2011-08-17 02:51:59.705+09	testdb	public	pgbench_branches	0	0	46	0	10281	0.13
1	2011-08-17 02:49:40.961+09	testdb	public	pgbench_tellers	0	0	78	0	10420	0.18000001
1	2011-08-17 05:42:09.149+09	testdb	public	pgbench_tellers	1	0	80	14431	100	0.15000001
1	2011-08-17 05:41:26.872+09	testdb	public	pgbench_tellers	0	0	80	79	174	0.23999999
1	2011-08-17 05:45:10.901+09	testdb	public	pgbench_branches	1	0	110	124	10	0.30000001
1	2011-08-17 05:43:41.05+09	testdb	public	pgbench_tellers	1	0	80	299	100	0.039999999
1	2011-08-17 05:44:36.988+09	testdb	public	pgbench_branches	0	0	110	0	104	0.34999999
1	2011-08-17 05:44:02.336+09	testdb	public	pgbench_tellers	0	0	80	313	139	0.19
1	2011-08-17 05:47:09.679+09	testdb	public	pgbench_branches	0	0	110	1	11	0
1	2011-08-17 05:45:29.801+09	testdb	public	pgbench_tellers	0	0	80	311	111	0.059999999
1	2011-08-17 05:46:31.98+09	testdb	public	pgbench_tellers	0	0	80	363	109	0.059999999
1	2011-08-17 05:49:09.769+09	testdb	public	pgbench_branches	0	0	110	155	11	0
1	2011-08-17 05:47:30.881+09	testdb	public	pgbench_tellers	0	0	80	393	110	0.059999999
1	2011-08-17 05:50:10.256+09	testdb	public	pgbench_branches	0	0	110	68	11	0
1	2011-08-17 05:48:27.404+09	testdb	public	pgbench_tellers	0	0	80	317	114	0.059999999
1	2011-08-17 05:51:00.925+09	testdb	public	pgbench_branches	0	0	110	60	20	0.039999999
1	2011-08-17 05:49:28.125+09	testdb	public	pgbench_tellers	0	0	80	351	113	0.059999999
1	2011-08-17 05:52:09.894+09	testdb	public	pgbench_branches	0	0	110	96	11	0
1	2011-08-17 05:50:32.015+09	testdb	public	pgbench_tellers	0	0	80	407	109	0.059999999
1	2011-08-17 05:53:10.972+09	testdb	public	pgbench_branches	0	0	110	175	10	0.039999999
1	2011-08-17 05:51:41.164+09	testdb	public	pgbench_tellers	0	0	80	318	100	0.059999999
1	2011-08-17 05:54:10.001+09	testdb	public	pgbench_branches	1	64	46	26	11	0.050000001
1	2011-08-17 05:52:40.139+09	testdb	public	pgbench_tellers	1	0	80	362	101	0.039999999
1	2011-08-17 05:54:44.119+09	testdb	public	pgbench_branches	0	0	46	147	37	0.11
1	2011-08-17 05:52:57.37+09	testdb	public	pgbench_tellers	0	0	80	352	144	0.19
1	2011-08-17 05:55:59.097+09	testdb	public	pgbench_branches	0	0	46	226	22	0.039999999
1	2011-08-17 05:54:30.207+09	testdb	public	pgbench_tellers	0	0	80	373	111	0.059999999
1	2011-08-17 05:57:10.529+09	testdb	public	pgbench_branches	0	0	46	235	11	0
1	2011-08-17 05:55:27.788+09	testdb	public	pgbench_tellers	0	0	80	328	114	0.059999999
1	2011-08-17 05:58:11.18+09	testdb	public	pgbench_branches	0	0	46	193	10	0.039999999
1	2011-08-17 05:56:41.29+09	testdb	public	pgbench_tellers	0	0	80	437	100	0.059999999
1	2011-08-17 05:58:59.275+09	testdb	public	pgbench_branches	0	0	46	276	22	0.039999999
1	2011-08-17 05:57:33.383+09	testdb	public	pgbench_tellers	0	0	80	307	108	0.059999999
1	2011-08-17 06:00:10.217+09	testdb	public	pgbench_branches	0	0	46	216	11	0
1	2011-08-17 05:58:35.331+09	testdb	public	pgbench_tellers	0	0	80	378	106	0.059999999
1	2011-08-17 06:01:00.301+09	testdb	public	pgbench_branches	0	0	46	287	21	0.039999999
1	2011-08-17 05:59:30.429+09	testdb	public	pgbench_tellers	0	0	80	440	111	0.059999999
1	2011-08-17 06:02:11.294+09	testdb	public	pgbench_branches	0	0	46	169	10	0
1	2011-08-17 06:00:34.415+09	testdb	public	pgbench_tellers	0	0	80	415	107	0.059999999
1	2011-08-17 06:03:11.426+09	testdb	public	pgbench_branches	1	2	44	114	10	0.11
1	2011-08-17 06:01:41.679+09	testdb	public	pgbench_tellers	1	0	80	315	100	0.2
1	2011-08-17 06:01:54.032+09	testdb	public	pgbench_tellers	0	0	80	485	148	0.19
1	2011-08-17 06:04:46.54+09	testdb	public	pgbench_branches	0	0	44	191	35	0.090000004
1	2011-08-17 06:03:32.664+09	testdb	public	pgbench_tellers	0	0	80	553	109	0.059999999
1	2011-08-17 06:06:11.47+09	testdb	public	pgbench_branches	0	0	44	217	10	0.039999999
1	2011-08-17 06:04:41.607+09	testdb	public	pgbench_tellers	0	0	80	398	100	0.059999999
1	2011-08-17 06:07:01.517+09	testdb	public	pgbench_branches	0	0	44	323	20	0.039999999
1	2011-08-17 06:05:28.623+09	testdb	public	pgbench_tellers	0	0	80	344	113	0.059999999
1	2011-08-17 06:08:11.542+09	testdb	public	pgbench_branches	0	0	44	111	10	0
1	2011-08-17 06:06:29.669+09	testdb	public	pgbench_tellers	0	0	80	461	112	0.059999999
1	2011-08-17 06:09:06.651+09	testdb	public	pgbench_branches	0	0	44	25	15	0.039999999
1	2011-08-17 06:07:29.767+09	testdb	public	pgbench_tellers	0	0	80	232	112	0.059999999
1	2011-08-17 06:10:11.61+09	testdb	public	pgbench_branches	0	0	44	160	10	0
1	2011-08-17 06:08:31.73+09	testdb	public	pgbench_tellers	0	0	80	406	110	0.059999999
1	2011-08-17 06:11:11.693+09	testdb	public	pgbench_branches	0	0	44	142	10	0.039999999
1	2011-08-17 06:09:41.801+09	testdb	public	pgbench_tellers	0	0	80	523	100	0.059999999
1	2011-08-17 06:12:11.818+09	testdb	public	pgbench_branches	1	0	49	130	10	0.079999998
1	2011-08-17 06:10:41.048+09	testdb	public	pgbench_tellers	1	0	80	279	101	0.17
1	2011-08-17 06:10:57.021+09	testdb	public	pgbench_tellers	0	0	80	476	145	0.19
1	2011-08-17 06:12:28.96+09	testdb	public	pgbench_tellers	0	0	80	434	113	0.059999999
1	2011-08-17 06:14:34.93+09	testdb	public	pgbench_branches	0	0	49	59	47	0.11
1	2011-08-17 06:13:32.046+09	testdb	public	pgbench_tellers	0	0	80	402	110	0.059999999
1	2011-08-17 06:16:11.878+09	testdb	public	pgbench_branches	0	0	49	95	10	0.039999999
1	2011-08-17 06:14:42.008+09	testdb	public	pgbench_tellers	0	0	80	493	100	0.059999999
1	2011-08-17 06:17:02.932+09	testdb	public	pgbench_branches	0	0	49	136	19	0.039999999
1	2011-08-17 06:15:37.057+09	testdb	public	pgbench_tellers	0	0	80	466	105	0.059999999
1	2011-08-17 06:18:10.981+09	testdb	public	pgbench_branches	0	0	49	9	11	0
1	2011-08-17 06:16:32.095+09	testdb	public	pgbench_tellers	0	0	80	474	110	0.059999999
1	2011-08-17 06:19:01.038+09	testdb	public	pgbench_branches	0	0	49	146	21	0.039999999
1	2011-08-17 06:17:42.177+09	testdb	public	pgbench_tellers	0	0	80	416	100	0.059999999
1	2011-08-17 06:18:32.118+09	testdb	public	pgbench_tellers	0	0	80	397	110	0.059999999
1	2011-08-17 06:21:12.05+09	testdb	public	pgbench_branches	1	6	43	41	10	0.02
1	2011-08-17 06:19:42.14+09	testdb	public	pgbench_tellers	1	0	80	494	100	0.039999999
1	2011-08-17 06:22:06.548+09	testdb	public	pgbench_branches	0	0	43	169	16	0.13
1	2011-08-17 06:20:11.844+09	testdb	public	pgbench_tellers	0	0	80	543	131	0.19
1	2011-08-17 06:23:11.14+09	testdb	public	pgbench_branches	0	0	43	299	11	0
1	2011-08-17 06:21:30.264+09	testdb	public	pgbench_tellers	0	0	80	670	112	0.059999999
1	2011-08-17 06:24:12.198+09	testdb	public	pgbench_branches	0	0	43	154	10	0.039999999
1	2011-08-17 06:22:42.306+09	testdb	public	pgbench_tellers	0	0	80	453	100	0.059999999
1	2011-08-17 06:25:12.224+09	testdb	public	pgbench_branches	0	0	43	224	10	0
1	2011-08-17 06:23:36.34+09	testdb	public	pgbench_tellers	0	0	80	645	106	0.059999999
1	2011-08-17 06:26:12.307+09	testdb	public	pgbench_branches	0	0	43	168	10	0
1	2011-08-17 06:24:37.42+09	testdb	public	pgbench_tellers	0	0	80	546	105	0.059999999
1	2011-08-17 06:27:01.374+09	testdb	public	pgbench_branches	0	0	43	211	21	0.039999999
1	2011-08-17 06:25:32.487+09	testdb	public	pgbench_tellers	0	0	80	590	110	0.059999999
1	2011-08-17 06:28:11.378+09	testdb	public	pgbench_branches	0	0	43	228	11	0
1	2011-08-17 06:26:33.493+09	testdb	public	pgbench_tellers	0	0	80	618	109	0.059999999
1	2011-08-17 06:29:12.405+09	testdb	public	pgbench_branches	0	0	43	163	10	0.039999999
1	2011-08-17 06:27:42.513+09	testdb	public	pgbench_tellers	0	0	80	466	100	0.059999999
1	2011-08-17 06:30:12.426+09	testdb	public	pgbench_branches	1	0	48	49	10	0.02
1	2011-08-17 06:28:42.508+09	testdb	public	pgbench_tellers	1	0	80	342	100	0.039999999
1	2011-08-17 06:30:36.569+09	testdb	public	pgbench_branches	0	0	48	117	46	0.11
1	2011-08-17 06:29:12.809+09	testdb	public	pgbench_tellers	0	0	80	230	130	0.19
1	2011-08-17 06:30:30.60+09	testdb	public	pgbench_tellers	0	0	80	563	112	0.059999999
1	2011-08-17 06:33:11.721+09	testdb	public	pgbench_branches	0	0	48	48	11	0
1	2011-08-17 06:31:42.223+09	testdb	public	pgbench_tellers	0	0	80	468	101	0.059999999
1	2011-08-17 06:34:12.592+09	testdb	public	pgbench_branches	0	0	48	99	10	0.039999999
1	2011-08-17 06:32:42.722+09	testdb	public	pgbench_tellers	0	0	80	547	100	0.059999999
1	2011-08-17 06:35:00.643+09	testdb	public	pgbench_branches	0	0	48	13	22	0.039999999
1	2011-08-17 06:33:31.777+09	testdb	public	pgbench_tellers	0	0	80	491	111	0.059999999
1	2011-08-17 06:36:11.692+09	testdb	public	pgbench_branches	0	0	48	93	11	0
1	2011-08-17 06:34:32.81+09	testdb	public	pgbench_tellers	0	0	80	258	110	0.059999999
1	2011-08-17 06:35:42.831+09	testdb	public	pgbench_tellers	0	0	80	566	100	0.059999999
1	2011-08-17 06:38:08.781+09	testdb	public	pgbench_branches	0	0	48	137	14	0.039999999
1	2011-08-17 06:36:30.906+09	testdb	public	pgbench_tellers	0	0	80	415	112	0.059999999
1	2011-08-17 06:39:12.897+09	testdb	public	pgbench_branches	1	0	48	65	10	0.11
1	2011-08-17 06:37:42.123+09	testdb	public	pgbench_tellers	1	0	80	441	101	0.18000001
1	2011-08-17 06:39:40.334+09	testdb	public	pgbench_branches	0	0	48	128	43	0.15000001
1	2011-08-17 06:37:53.935+09	testdb	public	pgbench_tellers	0	0	80	523	150	0.19
1	2011-08-17 06:39:35.999+09	testdb	public	pgbench_tellers	0	0	80	517	107	0.059999999
1	2011-08-17 06:42:12.905+09	testdb	public	pgbench_branches	0	3	45	1	10	0.039999999
1	2011-08-17 06:40:43.059+09	testdb	public	pgbench_tellers	0	0	80	687	100	0.059999999
1	2011-08-17 06:43:04.956+09	testdb	public	pgbench_branches	0	0	45	154	18	0.039999999
1	2011-08-17 06:41:33.053+09	testdb	public	pgbench_tellers	0	0	80	617	110	0.059999999
1	2011-08-17 06:44:11.945+09	testdb	public	pgbench_branches	0	0	45	109	11	0
1	2011-08-17 06:42:33.074+09	testdb	public	pgbench_tellers	0	0	80	491	110	0.059999999
1	2011-08-17 06:45:03.026+09	testdb	public	pgbench_branches	0	0	45	165	20	0.039999999
1	2011-08-17 06:43:36.142+09	testdb	public	pgbench_tellers	0	0	80	537	107	0.059999999
1	2011-08-17 06:46:12.056+09	testdb	public	pgbench_branches	0	0	45	64	11	0
1	2011-08-17 06:44:36.172+09	testdb	public	pgbench_tellers	0	0	80	493	107	0.059999999
1	2011-08-17 06:45:43.226+09	testdb	public	pgbench_tellers	0	0	80	534	100	0.059999999
1	2011-08-17 06:48:12.144+09	testdb	public	pgbench_branches	1	0	49	118	11	0.039999999
1	2011-08-17 06:46:42.33+09	testdb	public	pgbench_tellers	1	0	80	313	101	0.13
1	2011-08-17 06:48:43.302+09	testdb	public	pgbench_branches	0	0	49	0	40	0.11
1	2011-08-17 06:46:52.545+09	testdb	public	pgbench_tellers	0	0	80	322	151	0.19
1	2011-08-17 06:50:13.225+09	testdb	public	pgbench_branches	0	0	49	126	10	0.039999999
1	2011-08-17 06:48:43.354+09	testdb	public	pgbench_tellers	0	0	80	316	100	0.059999999
1	2011-08-17 06:49:37.43+09	testdb	public	pgbench_tellers	0	0	80	400	106	0.059999999
1	2011-08-17 06:52:12.265+09	testdb	public	pgbench_branches	0	0	49	26	11	0
1	2011-08-17 06:50:36.381+09	testdb	public	pgbench_tellers	0	0	80	356	107	0.059999999
1	2011-08-17 06:53:06.372+09	testdb	public	pgbench_branches	0	0	49	5	17	0.039999999
1	2011-08-17 06:51:33.499+09	testdb	public	pgbench_tellers	0	0	80	206	110	0.059999999
1	2011-08-17 06:52:37.565+09	testdb	public	pgbench_tellers	0	0	80	227	106	0.059999999
1	2011-08-17 06:55:13.435+09	testdb	public	pgbench_branches	0	0	49	106	10	0.039999999
1	2011-08-17 06:53:43.564+09	testdb	public	pgbench_tellers	0	0	80	352	100	0.059999999
1	2011-08-17 06:56:05.542+09	testdb	public	pgbench_branches	0	0	49	181	18	0.039999999
1	2011-08-17 04:19:10.714+09	testdb	public	pgbench_branches	0	0	49	0	9493	0.16
1	2011-08-17 04:16:38.049+09	testdb	public	pgbench_tellers	0	0	80	0	9646	0.27000001
1	2011-08-17 04:37:26.561+09	testdb	public	pgbench_tellers	1	0	99	722	8443	0.18000001
1	2011-08-17 03:55:34.694+09	testdb	public	pgbench_branches	1	0	91	0	10969	0.13
1	2011-08-17 03:53:18.846+09	testdb	public	pgbench_tellers	0	0	99	0	11105	0.039999999
1	2011-08-17 07:00:13.95+09	testdb	public	pgbench_branches	1	80	11	122	10	0.36000001
1	2011-08-17 06:58:44.448+09	testdb	public	pgbench_tellers	1	71	28	441	100	0.40000001
1	2011-08-17 07:01:07.654+09	testdb	public	pgbench_branches	0	0	11	161	16	0.02
1	2011-08-17 06:59:22.793+09	testdb	public	pgbench_tellers	0	0	28	362	121	0.079999998
1	2011-08-17 07:02:12.679+09	testdb	public	pgbench_branches	0	0	11	32	11	0
1	2011-08-17 07:00:37.753+09	testdb	public	pgbench_tellers	0	0	28	350	106	0.02
1	2011-08-17 07:03:05.742+09	testdb	public	pgbench_branches	0	0	11	173	18	0.02
1	2011-08-17 07:01:38.816+09	testdb	public	pgbench_tellers	0	0	28	217	105	0.02
1	2011-08-17 07:04:12.814+09	testdb	public	pgbench_branches	0	0	11	163	11	0
1	2011-08-17 07:02:38.891+09	testdb	public	pgbench_tellers	0	0	28	269	105	0.02
1	2011-08-17 07:05:13.815+09	testdb	public	pgbench_branches	0	0	11	63	10	0.02
1	2011-08-17 07:03:43.881+09	testdb	public	pgbench_tellers	0	0	28	301	100	0.02
1	2011-08-17 07:06:13.90+09	testdb	public	pgbench_branches	0	0	11	32	10	0
1	2011-08-17 07:04:35.983+09	testdb	public	pgbench_tellers	0	0	28	452	108	0.02
1	2011-08-17 07:07:12.996+09	testdb	public	pgbench_branches	1	0	47	93	11	0.059999999
1	2011-08-17 07:05:44.16+09	testdb	public	pgbench_tellers	1	0	58	271	100	0.1
1	2011-08-17 07:06:44.191+09	testdb	public	pgbench_tellers	0	0	58	140	100	0.17
1	2011-08-17 07:07:43.409+09	testdb	public	pgbench_tellers	0	0	58	286	101	0.039999999
1	2011-08-17 07:10:14.131+09	testdb	public	pgbench_branches	0	0	47	51	10	0.15000001
1	2011-08-17 07:08:33.221+09	testdb	public	pgbench_tellers	0	0	58	292	111	0.039999999
1	2011-08-17 07:11:05.124+09	testdb	public	pgbench_branches	0	0	47	49	19	0.039999999
1	2011-08-17 07:09:34.241+09	testdb	public	pgbench_tellers	0	0	58	325	110	0.039999999
1	2011-08-17 07:12:13.082+09	testdb	public	pgbench_branches	0	0	47	33	11	0
1	2011-08-17 07:10:35.176+09	testdb	public	pgbench_tellers	0	0	58	346	109	0.039999999
1	2011-08-17 07:13:14.156+09	testdb	public	pgbench_branches	0	0	47	118	10	0.039999999
1	2011-08-17 07:11:44.263+09	testdb	public	pgbench_tellers	0	0	58	290	100	0.039999999
1	2011-08-17 07:14:04.244+09	testdb	public	pgbench_branches	0	0	47	157	20	0.039999999
1	2011-08-17 07:12:34.354+09	testdb	public	pgbench_tellers	0	0	58	273	110	0.039999999
1	2011-08-17 07:15:13.211+09	testdb	public	pgbench_branches	0	0	47	76	11	0
1	2011-08-17 07:13:41.304+09	testdb	public	pgbench_tellers	0	0	58	251	103	0.039999999
1	2011-08-17 07:16:14.675+09	testdb	public	pgbench_branches	1	0	49	109	10	0.11
1	2011-08-17 07:14:44.013+09	testdb	public	pgbench_tellers	1	0	61	298	101	0.2
1	2011-08-17 07:16:42.668+09	testdb	public	pgbench_branches	0	0	49	130	42	0.11
1	2011-08-17 07:15:22.038+09	testdb	public	pgbench_tellers	0	0	61	513	123	0.17
1	2011-08-17 07:18:14.331+09	testdb	public	pgbench_branches	0	0	49	181	10	0.039999999
1	2011-08-17 07:16:44.439+09	testdb	public	pgbench_tellers	0	0	61	438	100	0.039999999
1	2011-08-17 07:17:35.869+09	testdb	public	pgbench_tellers	0	0	61	543	109	0.039999999
1	2011-08-17 07:20:14.376+09	testdb	public	pgbench_branches	0	0	49	137	10	0
1	2011-08-17 07:18:35.466+09	testdb	public	pgbench_tellers	0	0	61	378	109	0.039999999
1	2011-08-17 07:19:31.536+09	testdb	public	pgbench_tellers	0	0	61	445	113	0.039999999
1	2011-08-17 07:22:14.441+09	testdb	public	pgbench_branches	0	0	49	171	10	0
1	2011-08-17 07:20:34.539+09	testdb	public	pgbench_tellers	0	0	61	416	110	0.039999999
1	2011-08-17 07:23:14.521+09	testdb	public	pgbench_branches	0	0	49	144	10	0.039999999
1	2011-08-17 07:21:44.626+09	testdb	public	pgbench_tellers	0	0	61	440	100	0.039999999
1	2011-08-17 07:24:13.956+09	testdb	public	pgbench_branches	0	0	49	2	11	0.039999999
1	2011-08-17 07:22:44.40+09	testdb	public	pgbench_tellers	0	0	61	492	101	0.039999999
1	2011-08-17 07:25:14.553+09	testdb	public	pgbench_branches	1	6	43	95	10	0.0099999998
1	2011-08-17 07:23:43.626+09	testdb	public	pgbench_tellers	1	0	61	413	101	0.02
1	2011-08-17 07:26:14.719+09	testdb	public	pgbench_branches	0	0	43	123	10	0.13
1	2011-08-17 07:24:44.985+09	testdb	public	pgbench_tellers	0	6	55	507	100	0.17
1	2011-08-17 07:25:37.821+09	testdb	public	pgbench_tellers	0	0	55	482	107	0.039999999
1	2011-08-17 07:28:13.833+09	testdb	public	pgbench_branches	0	0	43	128	11	0
1	2011-08-17 07:26:34.927+09	testdb	public	pgbench_tellers	0	0	55	428	110	0.039999999
1	2011-08-17 07:29:07.766+09	testdb	public	pgbench_branches	0	0	43	115	17	0.039999999
1	2011-08-17 07:27:34.854+09	testdb	public	pgbench_tellers	0	0	55	483	110	0.039999999
1	2011-08-17 07:30:14.016+09	testdb	public	pgbench_branches	0	0	43	49	11	0
1	2011-08-17 07:28:27.142+09	testdb	public	pgbench_tellers	0	0	55	410	118	0.039999999
1	2011-08-17 07:31:14.827+09	testdb	public	pgbench_branches	0	0	43	158	10	0.039999999
1	2011-08-17 07:29:44.914+09	testdb	public	pgbench_tellers	0	0	55	573	100	0.039999999
1	2011-08-17 07:32:09.907+09	testdb	public	pgbench_branches	0	0	43	162	15	0.039999999
1	2011-08-17 07:30:33.992+09	testdb	public	pgbench_tellers	0	0	55	467	111	0.039999999
1	2011-08-17 07:33:14.876+09	testdb	public	pgbench_branches	0	0	43	170	10	0
1	2011-08-17 07:31:33.969+09	testdb	public	pgbench_tellers	0	0	55	413	111	0.039999999
1	2011-08-17 07:34:13.932+09	testdb	public	pgbench_branches	1	0	45	25	11	0.02
1	2011-08-17 07:32:44.006+09	testdb	public	pgbench_tellers	1	0	56	248	101	0.02
1	2011-08-17 07:34:47.079+09	testdb	public	pgbench_branches	0	0	45	29	38	0.11
1	2011-08-17 07:36:14.993+09	testdb	public	pgbench_branches	0	0	45	107	10	0.039999999
1	2011-08-17 07:34:45.212+09	testdb	public	pgbench_tellers	0	0	56	268	100	0.17
1	2011-08-17 07:37:09.099+09	testdb	public	pgbench_branches	0	0	45	86	16	0.039999999
1	2011-08-17 07:35:33.184+09	testdb	public	pgbench_tellers	0	0	56	288	112	0.039999999
1	2011-08-17 07:36:44.619+09	testdb	public	pgbench_tellers	0	0	56	232	101	0.039999999
1	2011-08-17 07:39:05.129+09	testdb	public	pgbench_branches	0	0	45	130	20	0.039999999
1	2011-08-17 07:37:45.221+09	testdb	public	pgbench_tellers	0	0	56	147	100	0.039999999
1	2011-08-17 07:40:08.196+09	testdb	public	pgbench_branches	0	0	45	18	17	0.039999999
1	2011-08-17 07:38:36.282+09	testdb	public	pgbench_tellers	0	0	56	154	109	0.039999999
1	2011-08-17 07:41:15.208+09	testdb	public	pgbench_branches	0	0	45	146	10	0.039999999
1	2011-08-17 07:39:40.294+09	testdb	public	pgbench_tellers	0	0	56	226	105	0.039999999
1	2011-08-17 07:40:35.406+09	testdb	public	pgbench_tellers	0	0	56	250	110	0.039999999
1	2011-08-17 07:43:14.274+09	testdb	public	pgbench_branches	1	0	46	56	11	0
1	2011-08-17 07:41:44.359+09	testdb	public	pgbench_tellers	1	0	58	214	101	0.02
1	2011-08-17 07:44:15.412+09	testdb	public	pgbench_branches	0	0	46	173	10	0.15000001
1	2011-08-17 07:42:45.673+09	testdb	public	pgbench_tellers	0	0	58	441	100	0.17
1	2011-08-17 07:45:14.331+09	testdb	public	pgbench_branches	0	0	46	33	11	0
1	2011-08-17 07:43:41.431+09	testdb	public	pgbench_tellers	0	0	58	263	104	0.039999999
1	2011-08-17 07:44:35.421+09	testdb	public	pgbench_tellers	0	0	58	304	110	0.039999999
1	2011-08-17 07:47:05.451+09	testdb	public	pgbench_branches	0	0	46	112	20	0.039999999
1	2011-08-17 07:45:34.565+09	testdb	public	pgbench_tellers	0	0	58	303	111	0.039999999
1	2011-08-17 07:48:14.414+09	testdb	public	pgbench_branches	0	0	46	31	11	0
1	2011-08-17 07:46:34.507+09	testdb	public	pgbench_tellers	0	0	58	316	111	0.039999999
1	2011-08-17 07:49:15.49+09	testdb	public	pgbench_branches	0	0	46	132	10	0.039999999
1	2011-08-17 07:47:45.599+09	testdb	public	pgbench_tellers	0	0	58	380	100	0.039999999
1	2011-08-17 07:48:40.696+09	testdb	public	pgbench_tellers	0	0	58	355	105	0.039999999
1	2011-08-17 07:51:14.528+09	testdb	public	pgbench_branches	0	0	46	187	11	0
1	2011-08-17 07:49:34.622+09	testdb	public	pgbench_tellers	0	0	58	343	111	0.039999999
1	2011-08-17 07:52:15.099+09	testdb	public	pgbench_branches	1	0	48	108	11	0.33000001
1	2011-08-17 07:50:46.501+09	testdb	public	pgbench_tellers	1	0	59	135	100	0.18000001
1	2011-08-17 07:52:45.045+09	testdb	public	pgbench_branches	0	0	48	253	41	0.11
1	2011-08-17 07:51:22.312+09	testdb	public	pgbench_tellers	0	0	59	355	124	0.17
1	2011-08-17 07:54:15.672+09	testdb	public	pgbench_branches	0	0	48	159	10	0.039999999
1	2011-08-17 07:52:45.779+09	testdb	public	pgbench_tellers	0	0	59	349	100	0.039999999
1	2011-08-17 07:55:01.722+09	testdb	public	pgbench_branches	0	0	48	325	24	0.039999999
1	2011-08-17 07:53:36.83+09	testdb	public	pgbench_tellers	0	0	59	353	109	0.039999999
1	2011-08-17 07:56:14.786+09	testdb	public	pgbench_branches	0	0	48	44	11	0
1	2011-08-17 07:54:37.893+09	testdb	public	pgbench_tellers	0	0	59	381	108	0.039999999
1	2011-08-17 07:57:15.792+09	testdb	public	pgbench_branches	0	0	48	108	10	0.039999999
1	2011-08-17 07:55:45.90+09	testdb	public	pgbench_tellers	0	0	59	399	100	0.039999999
1	2011-08-17 07:56:35.949+09	testdb	public	pgbench_tellers	0	0	59	385	110	0.039999999
1	2011-08-17 07:59:14.874+09	testdb	public	pgbench_branches	0	0	48	257	11	0
1	2011-08-17 07:57:35.971+09	testdb	public	pgbench_tellers	0	0	59	316	110	0.039999999
1	2011-08-17 08:00:05.933+09	testdb	public	pgbench_branches	0	0	48	260	20	0.039999999
1	2011-08-17 07:58:37.04+09	testdb	public	pgbench_tellers	0	0	59	404	109	0.039999999
1	2011-08-17 08:01:17.053+09	testdb	public	pgbench_branches	1	0	48	30	10	0.059999999
1	2011-08-17 07:59:46.216+09	testdb	public	pgbench_tellers	1	0	59	250	101	0.11
1	2011-08-17 08:02:16.422+09	testdb	public	pgbench_branches	0	4	44	138	10	0.25999999
1	2011-08-17 08:00:46.759+09	testdb	public	pgbench_tellers	0	0	59	315	100	0.17
1	2011-08-17 08:03:09.04+09	testdb	public	pgbench_branches	0	0	44	16	17	0.039999999
1	2011-08-17 08:01:34.126+09	testdb	public	pgbench_tellers	0	0	59	376	112	0.039999999
1	2011-08-17 08:02:38.141+09	testdb	public	pgbench_tellers	0	0	59	467	108	0.039999999
1	2011-08-17 08:05:08.132+09	testdb	public	pgbench_branches	0	0	44	65	18	0.039999999
1	2011-08-17 08:03:34.214+09	testdb	public	pgbench_tellers	0	0	59	327	112	0.039999999
1	2011-08-17 08:04:45.799+09	testdb	public	pgbench_tellers	0	0	59	391	101	0.039999999
1	2011-08-17 08:07:16.167+09	testdb	public	pgbench_branches	0	0	44	171	10	0.039999999
1	2011-08-17 08:05:46.254+09	testdb	public	pgbench_tellers	0	0	59	261	100	0.039999999
1	2011-08-17 08:08:09.216+09	testdb	public	pgbench_branches	0	0	44	39	17	0.039999999
1	2011-08-17 08:06:36.301+09	testdb	public	pgbench_tellers	0	0	59	472	110	0.039999999
1	2011-08-17 08:09:16.241+09	testdb	public	pgbench_branches	0	0	44	41	10	0
1	2011-08-17 08:07:34.335+09	testdb	public	pgbench_tellers	0	0	59	401	112	0.039999999
1	2011-08-17 08:10:16.235+09	testdb	public	pgbench_branches	1	0	47	110	10	0.02
1	2011-08-17 08:08:45.313+09	testdb	public	pgbench_tellers	1	0	59	225	101	0.02
1	2011-08-17 08:09:01.468+09	testdb	public	pgbench_tellers	0	0	59	166	145	0.17
1	2011-08-17 08:12:16.441+09	testdb	public	pgbench_branches	0	0	47	109	10	0.15000001
1	2011-08-17 08:10:46.565+09	testdb	public	pgbench_tellers	0	0	59	357	100	0.039999999
1	2011-08-17 08:13:11.363+09	testdb	public	pgbench_branches	0	0	47	25	15	0.039999999
1	2011-08-17 08:11:35.467+09	testdb	public	pgbench_tellers	0	0	59	306	111	0.039999999
1	2011-08-17 08:14:15.363+09	testdb	public	pgbench_branches	0	0	47	73	11	0
1	2011-08-17 08:12:35.457+09	testdb	public	pgbench_tellers	0	0	59	335	111	0.039999999
1	2011-08-17 08:15:06.447+09	testdb	public	pgbench_branches	0	0	47	17	20	0.039999999
1	2011-08-17 08:13:46.56+09	testdb	public	pgbench_tellers	0	0	59	316	100	0.039999999
1	2011-08-17 08:16:16.491+09	testdb	public	pgbench_branches	0	0	47	45	10	0
1	2011-08-17 08:14:37.583+09	testdb	public	pgbench_tellers	0	0	59	282	109	0.039999999
1	2011-08-17 08:15:46.616+09	testdb	public	pgbench_tellers	0	0	59	301	100	0.039999999
1	2011-08-17 08:18:15.792+09	testdb	public	pgbench_branches	0	0	47	97	11	0.039999999
1	2011-08-17 05:36:23.685+09	testdb	public	pgbench_branches	0	0	47	0	9783	0.11
1	2011-08-17 05:34:06.934+09	testdb	public	pgbench_tellers	0	0	59	0	9920	0.15000001
1	2011-08-17 02:40:45.977+09	testdb	public	pgbench_branches	0	0	91	0	20381	0.33000001
1	2011-08-17 02:39:16.479+09	testdb	public	pgbench_tellers	0	0	112	0	20471	0.38
1	2011-08-17 08:22:17.08+09	testdb	public	pgbench_branches	1	0	109	166	10	0.40000001
1	2011-08-17 08:20:22.769+09	testdb	public	pgbench_tellers	1	0	134	253	125	0.63
1	2011-08-17 08:21:47.408+09	testdb	public	pgbench_branches	0	0	109	94	100	0.33000001
1	2011-08-17 08:19:55.231+09	testdb	public	pgbench_tellers	0	0	134	179	213	0.46000001
1	2011-08-17 08:24:16.751+09	testdb	public	pgbench_branches	0	0	109	120	10	0
1	2011-08-17 08:22:35.844+09	testdb	public	pgbench_tellers	0	0	134	249	111	0.039999999
1	2011-08-17 08:25:16.83+09	testdb	public	pgbench_branches	0	0	109	62	10	0.039999999
1	2011-08-17 08:23:46.999+09	testdb	public	pgbench_tellers	0	0	134	251	100	0.039999999
1	2011-08-17 08:24:37.009+09	testdb	public	pgbench_tellers	0	0	134	217	110	0.039999999
1	2011-08-17 08:27:15.882+09	testdb	public	pgbench_branches	0	0	109	17	11	0
1	2011-08-17 08:25:36.981+09	testdb	public	pgbench_tellers	0	0	134	189	110	0.039999999
1	2011-08-17 08:28:05.989+09	testdb	public	pgbench_branches	0	0	109	162	21	0.039999999
1	2011-08-17 08:26:41.167+09	testdb	public	pgbench_tellers	0	0	134	187	106	0.039999999
1	2011-08-17 08:27:36.064+09	testdb	public	pgbench_tellers	0	0	134	250	111	0.039999999
1	2011-08-17 08:30:17.101+09	testdb	public	pgbench_branches	1	61	48	155	10	0.13
1	2011-08-17 08:28:47.397+09	testdb	public	pgbench_tellers	1	0	134	466	100	0.2
1	2011-08-17 08:31:05.682+09	testdb	public	pgbench_branches	0	0	48	41	22	0.15000001
1	2011-08-17 08:29:07.988+09	testdb	public	pgbench_tellers	0	0	134	420	140	0.22
1	2011-08-17 08:32:16.672+09	testdb	public	pgbench_branches	0	0	48	184	11	0
1	2011-08-17 08:30:39.809+09	testdb	public	pgbench_tellers	0	0	134	456	108	0.079999998
1	2011-08-17 08:33:06.339+09	testdb	public	pgbench_branches	0	0	48	162	21	0.039999999
1	2011-08-17 08:31:35.497+09	testdb	public	pgbench_tellers	0	0	134	663	112	0.079999998
1	2011-08-17 08:34:17.285+09	testdb	public	pgbench_branches	0	0	48	331	10	0
1	2011-08-17 08:32:38.419+09	testdb	public	pgbench_tellers	0	0	134	467	109	0.079999998
1	2011-08-17 08:35:17.20+09	testdb	public	pgbench_branches	0	0	48	210	10	0.039999999
1	2011-08-17 08:33:47.347+09	testdb	public	pgbench_tellers	0	0	134	405	100	0.079999998
1	2011-08-17 08:36:11.283+09	testdb	public	pgbench_branches	0	0	48	83	16	0.039999999
1	2011-08-17 08:34:38.435+09	testdb	public	pgbench_tellers	0	0	134	489	109	0.079999998
1	2011-08-17 08:37:16.282+09	testdb	public	pgbench_branches	0	0	48	150	11	0
1	2011-08-17 08:35:38.416+09	testdb	public	pgbench_tellers	0	0	134	549	109	0.079999998
1	2011-08-17 08:38:17.316+09	testdb	public	pgbench_branches	0	0	48	96	10	0.039999999
1	2011-08-17 08:36:47.465+09	testdb	public	pgbench_tellers	0	0	134	492	100	0.079999998
1	2011-08-17 08:39:17.455+09	testdb	public	pgbench_branches	1	0	59	225	10	0.039999999
1	2011-08-17 08:37:46.595+09	testdb	public	pgbench_tellers	1	0	134	340	101	0.079999998
1	2011-08-17 08:40:17.506+09	testdb	public	pgbench_branches	0	0	59	187	10	0.17
1	2011-08-17 08:38:46.888+09	testdb	public	pgbench_tellers	0	0	134	454	101	0.25999999
1	2011-08-17 08:41:09.414+09	testdb	public	pgbench_branches	0	0	59	254	18	0.039999999
1	2011-08-17 08:39:37.563+09	testdb	public	pgbench_tellers	0	0	134	431	110	0.079999998
1	2011-08-17 08:42:17.119+09	testdb	public	pgbench_branches	0	0	59	132	11	0
1	2011-08-17 08:40:43.412+09	testdb	public	pgbench_tellers	0	0	134	394	105	0.079999998
1	2011-08-17 08:43:17.495+09	testdb	public	pgbench_branches	0	0	59	270	10	0.039999999
1	2011-08-17 08:41:47.644+09	testdb	public	pgbench_tellers	0	0	134	482	100	0.079999998
1	2011-08-17 08:44:07.597+09	testdb	public	pgbench_branches	0	0	59	263	20	0.039999999
1	2011-08-17 08:42:37.746+09	testdb	public	pgbench_tellers	0	0	134	340	110	0.079999998
1	2011-08-17 08:45:17.526+09	testdb	public	pgbench_branches	0	0	59	324	10	0
1	2011-08-17 08:43:42.662+09	testdb	public	pgbench_tellers	0	0	134	231	105	0.079999998
1	2011-08-17 08:46:04.603+09	testdb	public	pgbench_branches	0	0	59	203	23	0.039999999
1	2011-08-17 08:44:36.77+09	testdb	public	pgbench_tellers	0	0	134	329	111	0.079999998
1	2011-08-17 08:47:16.675+09	testdb	public	pgbench_branches	0	0	59	58	11	0
1	2011-08-17 08:45:37.814+09	testdb	public	pgbench_tellers	0	0	134	365	110	0.079999998
1	2011-08-17 08:48:17.703+09	testdb	public	pgbench_branches	1	14	45	10	10	0.090000004
1	2011-08-17 08:46:47.948+09	testdb	public	pgbench_tellers	1	0	134	423	100	0.19
1	2011-08-17 08:46:57.108+09	testdb	public	pgbench_tellers	0	0	134	319	151	0.20999999
1	2011-08-17 08:48:38.931+09	testdb	public	pgbench_tellers	0	0	134	212	109	0.079999998
1	2011-08-17 08:50:43.998+09	testdb	public	pgbench_branches	0	0	45	127	44	0.15000001
1	2011-08-17 08:49:37.172+09	testdb	public	pgbench_tellers	0	0	134	248	111	0.079999998
1	2011-08-17 08:52:16.796+09	testdb	public	pgbench_branches	0	0	45	100	11	0
1	2011-08-17 08:50:41.914+09	testdb	public	pgbench_tellers	0	0	134	355	106	0.059999999
1	2011-08-17 08:53:17.848+09	testdb	public	pgbench_branches	0	0	45	121	10	0.039999999
1	2011-08-17 08:51:47.977+09	testdb	public	pgbench_tellers	0	0	134	224	100	0.079999998
1	2011-08-17 08:54:11.922+09	testdb	public	pgbench_branches	0	0	45	72	16	0.039999999
1	2011-08-17 08:52:42.047+09	testdb	public	pgbench_tellers	0	0	134	258	106	0.079999998
1	2011-08-17 08:53:38.249+09	testdb	public	pgbench_tellers	0	0	134	305	110	0.079999998
1	2011-08-17 08:56:07.02+09	testdb	public	pgbench_branches	0	0	45	138	21	0.039999999
1	2011-08-17 08:54:48.158+09	testdb	public	pgbench_tellers	0	0	134	216	100	0.079999998
1	2011-08-17 08:57:16.986+09	testdb	public	pgbench_branches	1	0	45	170	11	0
1	2011-08-17 08:55:48.084+09	testdb	public	pgbench_tellers	1	0	134	294	100	0.039999999
1	2011-08-17 08:58:18.11+09	testdb	public	pgbench_branches	0	2	43	68	10	0.13
1	2011-08-17 08:56:09.41+09	testdb	public	pgbench_tellers	0	0	134	373	139	0.19
1	2011-08-17 08:59:09.125+09	testdb	public	pgbench_branches	0	0	43	1	19	0.039999999
1	2011-08-17 08:57:37.26+09	testdb	public	pgbench_tellers	0	0	134	588	111	0.079999998
1	2011-08-17 09:00:17.284+09	testdb	public	pgbench_branches	0	0	43	25	11	0
1	2011-08-17 08:58:36.421+09	testdb	public	pgbench_tellers	0	0	134	445	112	0.079999998
1	2011-08-17 09:01:18.128+09	testdb	public	pgbench_branches	0	0	43	71	10	0.039999999
1	2011-08-17 08:59:48.258+09	testdb	public	pgbench_tellers	0	0	134	370	100	0.079999998
1	2011-08-17 09:02:17.198+09	testdb	public	pgbench_branches	0	0	43	119	11	0.02
1	2011-08-17 09:00:36.325+09	testdb	public	pgbench_tellers	0	0	134	477	112	0.079999998
1	2011-08-17 09:01:46.858+09	testdb	public	pgbench_tellers	0	0	134	506	102	0.079999998
1	2011-08-17 09:04:02.288+09	testdb	public	pgbench_branches	0	0	43	7	26	0.039999999
1	2011-08-17 09:02:42.409+09	testdb	public	pgbench_tellers	0	0	134	433	106	0.059999999
1	2011-08-17 09:05:17.366+09	testdb	public	pgbench_branches	0	0	43	95	11	0
1	2011-08-17 09:03:34.505+09	testdb	public	pgbench_tellers	0	0	134	513	114	0.079999998
1	2011-08-17 09:06:18.278+09	testdb	public	pgbench_branches	1	0	44	16	10	0.02
1	2011-08-17 09:04:48.363+09	testdb	public	pgbench_tellers	1	0	134	426	100	0.039999999
1	2011-08-17 09:06:43.427+09	testdb	public	pgbench_branches	0	0	44	3	45	0.13
1	2011-08-17 09:05:11.719+09	testdb	public	pgbench_tellers	0	0	134	436	137	0.19
1	2011-08-17 09:08:17.335+09	testdb	public	pgbench_branches	0	0	44	92	11	0
1	2011-08-17 09:06:37.472+09	testdb	public	pgbench_tellers	0	0	134	438	111	0.079999998
1	2011-08-17 09:09:17.622+09	testdb	public	pgbench_branches	0	0	44	93	11	0.039999999
1	2011-08-17 09:07:30.969+09	testdb	public	pgbench_tellers	0	0	134	495	118	0.079999998
1	2011-08-17 09:10:17.45+09	testdb	public	pgbench_branches	0	0	44	112	11	0
1	2011-08-17 09:08:37.584+09	testdb	public	pgbench_tellers	0	0	134	448	111	0.079999998
1	2011-08-17 09:11:18.476+09	testdb	public	pgbench_branches	0	0	44	60	10	0.039999999
1	2011-08-17 09:09:48.605+09	testdb	public	pgbench_tellers	0	0	134	495	100	0.079999998
1	2011-08-17 09:12:07.514+09	testdb	public	pgbench_branches	0	0	44	162	21	0.039999999
1	2011-08-17 09:10:36.655+09	testdb	public	pgbench_tellers	0	0	134	189	112	0.079999998
1	2011-08-17 09:13:18.551+09	testdb	public	pgbench_branches	0	0	44	69	10	0
1	2011-08-17 09:11:37.693+09	testdb	public	pgbench_tellers	0	0	134	407	111	0.079999998
1	2011-08-17 09:14:18.58+09	testdb	public	pgbench_branches	0	0	44	12	10	0.039999999
1	2011-08-17 09:12:48.707+09	testdb	public	pgbench_tellers	0	0	134	475	100	0.079999998
1	2011-08-17 09:15:17.68+09	testdb	public	pgbench_branches	1	0	47	71	11	0.059999999
1	2011-08-17 09:13:48.90+09	testdb	public	pgbench_tellers	1	0	134	352	100	0.17
1	2011-08-17 09:14:14.229+09	testdb	public	pgbench_tellers	0	0	134	450	135	0.20999999
1	2011-08-17 09:16:27.864+09	testdb	public	pgbench_branches	0	0	47	103	61	0.15000001
1	2011-08-17 09:15:37.041+09	testdb	public	pgbench_tellers	0	0	134	703	112	0.079999998
1	2011-08-17 09:18:17.775+09	testdb	public	pgbench_branches	0	0	47	21	11	0
1	2011-08-17 09:16:38.909+09	testdb	public	pgbench_tellers	0	0	134	527	110	0.079999998
1	2011-08-17 09:17:48.889+09	testdb	public	pgbench_tellers	0	0	134	487	100	0.079999998
1	2011-08-17 09:18:35.222+09	testdb	public	pgbench_tellers	0	0	134	583	114	0.079999998
1	2011-08-17 09:21:18.331+09	testdb	public	pgbench_branches	0	0	47	181	11	0
1	2011-08-17 09:19:32.463+09	testdb	public	pgbench_tellers	0	0	134	557	117	0.079999998
1	2011-08-17 09:22:09.92+09	testdb	public	pgbench_branches	0	0	47	31	19	0.039999999
1	2011-08-17 09:20:39.075+09	testdb	public	pgbench_tellers	0	0	134	598	110	0.079999998
1	2011-08-17 09:23:17.923+09	testdb	public	pgbench_branches	0	0	47	80	11	0
1	2011-08-17 09:21:38.06+09	testdb	public	pgbench_tellers	0	0	134	608	111	0.079999998
1	2011-08-17 09:24:18.906+09	testdb	public	pgbench_branches	1	4	43	100	10	0.02
1	2011-08-17 09:22:48.994+09	testdb	public	pgbench_tellers	1	0	134	454	100	0.039999999
1	2011-08-17 09:24:40.109+09	testdb	public	pgbench_branches	0	0	43	0	49	0.13
1	2011-08-17 09:23:04.401+09	testdb	public	pgbench_tellers	0	0	134	386	145	0.19
1	2011-08-17 09:26:18.028+09	testdb	public	pgbench_branches	0	0	43	82	11	0
1	2011-08-17 09:24:42.147+09	testdb	public	pgbench_tellers	0	0	134	383	107	0.059999999
1	2011-08-17 09:27:05.053+09	testdb	public	pgbench_branches	0	0	43	13	24	0.039999999
1	2011-08-17 09:25:38.193+09	testdb	public	pgbench_tellers	0	0	134	362	111	0.079999998
1	2011-08-17 09:28:18.312+09	testdb	public	pgbench_branches	0	0	43	164	11	0.039999999
1	2011-08-17 09:26:48.762+09	testdb	public	pgbench_tellers	0	0	134	567	101	0.079999998
1	2011-08-17 09:29:19.126+09	testdb	public	pgbench_branches	0	0	43	109	10	0.039999999
1	2011-08-17 09:27:49.257+09	testdb	public	pgbench_tellers	0	0	134	351	100	0.079999998
1	2011-08-17 09:30:07.181+09	testdb	public	pgbench_branches	0	0	43	146	22	0.039999999
1	2011-08-17 09:28:37.314+09	testdb	public	pgbench_tellers	0	0	134	520	112	0.079999998
1	2011-08-17 09:31:19.198+09	testdb	public	pgbench_branches	0	0	43	1	10	0
1	2011-08-17 09:29:44.314+09	testdb	public	pgbench_tellers	0	0	134	411	105	0.059999999
1	2011-08-17 09:32:19.249+09	testdb	public	pgbench_branches	0	0	43	99	10	0.039999999
1	2011-08-17 09:30:49.374+09	testdb	public	pgbench_tellers	0	0	134	508	100	0.079999998
1	2011-08-17 09:33:18.244+09	testdb	public	pgbench_branches	1	0	48	18	11	0
1	2011-08-17 09:31:48.352+09	testdb	public	pgbench_tellers	1	0	134	309	101	0.039999999
1	2011-08-17 09:33:51.535+09	testdb	public	pgbench_branches	0	0	48	0	38	0.11
1	2011-08-17 09:31:58.797+09	testdb	public	pgbench_tellers	0	0	134	278	151	0.20999999
1	2011-08-17 09:33:38.509+09	testdb	public	pgbench_tellers	0	0	134	459	111	0.079999998
1	2011-08-17 09:36:18.899+09	testdb	public	pgbench_branches	0	0	48	69	11	0
1	2011-08-17 09:34:41.051+09	testdb	public	pgbench_tellers	0	0	134	366	109	0.059999999
1	2011-08-17 09:37:19.409+09	testdb	public	pgbench_branches	0	0	48	146	10	0.039999999
1	2011-08-17 09:35:49.559+09	testdb	public	pgbench_tellers	0	0	134	384	100	0.079999998
1	2011-08-17 09:36:42.589+09	testdb	public	pgbench_tellers	0	0	134	351	107	0.079999998
1	2011-08-17 09:39:19.431+09	testdb	public	pgbench_branches	0	0	48	26	10	0
1	2011-08-17 09:37:38.564+09	testdb	public	pgbench_tellers	0	0	134	306	111	0.079999998
1	2011-08-17 09:40:10.537+09	testdb	public	pgbench_branches	0	0	48	89	19	0.039999999
1	2011-08-17 09:38:43.671+09	testdb	public	pgbench_tellers	0	0	134	170	106	0.059999999
1	2011-08-17 09:41:18.559+09	testdb	public	pgbench_branches	0	0	48	80	11	0
1	2011-08-17 09:39:39.70+09	testdb	public	pgbench_tellers	0	0	134	232	110	0.079999998
1	2011-08-17 09:42:19.573+09	testdb	public	pgbench_branches	1	0	48	110	10	0.039999999
1	2011-08-17 09:40:49.691+09	testdb	public	pgbench_tellers	1	0	134	304	100	0.059999999
1	2011-08-17 09:42:28.965+09	testdb	public	pgbench_branches	0	0	48	135	61	0.15000001
1	2011-08-17 09:41:02.267+09	testdb	public	pgbench_tellers	0	0	134	466	148	0.20999999
1	2011-08-17 09:44:18.613+09	testdb	public	pgbench_branches	0	0	48	2	11	0
1	2011-08-17 09:42:36.749+09	testdb	public	pgbench_tellers	0	0	134	423	113	0.079999998
\.


--
-- Data for Name: checkpoint; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY checkpoint (instid, start, flags, num_buffers, xlog_added, xlog_removed, xlog_recycled, write_duration, sync_duration, total_duration) FROM stdin;
1	2011-08-16 17:36:47.899+09	xlog	3215	0	0	0	9.2910004	2.467	12.125
1	2011-08-16 17:37:12.767+09	xlog	2551	0	0	3	5.46	1.914	7.5749998
1	2011-08-16 17:37:38.135+09	xlog	2427	0	0	3	7.2690001	0.74299997	8.1280003
1	2011-08-16 17:38:04.43+09	xlog	2136	0	0	3	5.6550002	2.8180001	8.5039997
1	2011-08-16 17:38:29.496+09	xlog	1958	0	0	3	5.6539998	2.5450001	8.2189999
1	2011-08-16 17:38:57.987+09	xlog	1820	0	0	3	5.6550002	2.2639999	7.9380002
1	2011-08-16 17:39:24.805+09	xlog	1668	0	0	3	9.2749996	2.063	11.358
1	2011-08-16 17:39:53.43+09	xlog	1575	0	0	3	8.8669996	2.293	11.176
1	2011-08-16 17:40:26.933+09	xlog	1436	0	0	3	5.8520002	1.824	7.6950002
1	2011-08-16 17:40:57.177+09	xlog	1426	0	0	3	9.0620003	1.825	10.905
1	2011-08-16 17:41:31.117+09	xlog	1297	0	0	3	5.645	2.1140001	7.7750001
1	2011-08-16 17:42:03.169+09	xlog	1326	0	0	3	9.4680004	1.934	11.418
1	2011-08-16 17:42:38.90+09	xlog	1292	0	0	3	6.0489998	1.974	8.0389996
1	2011-08-16 17:43:09.055+09	xlog	1278	0	0	3	8.467	2.1129999	10.594
1	2011-08-16 17:43:42.321+09	xlog	1284	0	0	3	5.645	2.2320001	7.8959999
1	2011-08-16 17:44:13.365+09	xlog	1255	0	0	3	8.6730003	2.1059999	10.796
1	2011-08-16 17:44:47.315+09	xlog	1247	0	0	3	6.4489999	2.349	8.8199997
1	2011-08-16 17:45:17.309+09	xlog	1769	0	0	3	8.6660004	2.039	10.724
1	2011-08-16 17:45:45.334+09	xlog	1550	0	0	3	8.6719999	2.233	10.92
1	2011-08-16 17:46:19.178+09	xlog	1262	0	0	3	5.6420002	2.0840001	7.7420001
1	2011-08-16 17:46:49.763+09	xlog	1227	0	0	3	8.6599998	2.168	10.843
1	2011-08-16 17:47:23.825+09	xlog	1253	0	0	3	5.8460002	2.3269999	8.1949997
1	2011-08-16 17:47:54.532+09	xlog	1301	0	0	3	9.0679998	2.1800001	11.272
1	2011-08-16 17:48:28.581+09	xlog	1302	0	0	3	6.2490001	2.4820001	8.7550001
1	2011-08-16 17:48:59.455+09	xlog	1277	0	0	3	8.658	2.322	10.995
1	2011-08-16 17:49:33.034+09	xlog	1275	0	0	3	5.8460002	2.2520001	8.1230001
1	2011-08-16 17:50:03.115+09	xlog	1301	0	0	3	8.8620005	2.4849999	11.362
1	2011-08-16 17:50:33.443+09	xlog	1265	0	0	3	8.257	2.3210001	10.597
1	2011-08-16 17:51:07.222+09	xlog	1257	0	0	3	5.6669998	2.49	8.1759996
1	2011-08-16 17:51:36.167+09	xlog	1307	0	0	3	8.6599998	2.395	11.073
1	2011-08-16 17:52:09.913+09	xlog	1287	0	0	3	5.8470001	3.125	8.9980001
1	2011-08-16 17:52:38.881+09	xlog	1250	0	0	3	8.6610003	2.8759999	11.567
1	2011-08-16 17:53:08.828+09	xlog	1289	0	0	3	8.8620005	2.5050001	11.388
1	2011-08-16 17:53:42.275+09	xlog	1268	0	0	3	5.645	2.4300001	8.0909996
1	2011-08-16 17:54:11.485+09	xlog	1752	0	0	3	8.868	2.0450001	10.931
1	2011-08-16 17:54:39.869+09	xlog	1863	0	0	3	9.2700005	2.0710001	11.358
1	2011-08-16 17:55:13.707+09	xlog	1370	0	0	3	6.0440001	2.3299999	8.3909998
1	2011-08-16 17:55:43.044+09	xlog	1330	0	0	3	9.0649996	2.1429999	11.224
1	2011-08-16 17:56:16.14+09	xlog	1187	0	0	3	5.4439998	2.2780001	7.737
1	2011-08-16 17:56:46.745+09	xlog	1259	0	0	3	8.4639997	2.0680001	10.548
1	2011-08-16 17:57:17.32+09	xlog	1246	0	0	3	8.6619997	2.3210001	11.024
1	2011-08-16 17:57:51.774+09	xlog	1203	0	0	3	8.4580002	2.4489999	10.933
1	2011-08-16 17:58:22.547+09	xlog	1255	0	0	3	9.0609999	2.368	11.451
1	2011-08-16 17:58:55.916+09	xlog	1278	0	0	3	5.8439999	2.4779999	8.3369999
1	2011-08-16 17:59:24.681+09	xlog	1230	0	0	3	8.665	2.3559999	11.036
1	2011-08-16 17:59:58.496+09	xlog	1272	0	0	3	6.0560002	2.4230001	8.5030003
1	2011-08-16 18:00:29.341+09	xlog	1271	0	0	3	8.4589996	2.5369999	11.01
1	2011-08-16 18:01:02.505+09	xlog	1270	0	0	3	5.8499999	2.3640001	8.2290001
1	2011-08-16 18:01:32.644+09	xlog	1265	0	0	3	8.6599998	3.677	12.353
1	2011-08-16 18:02:01.953+09	xlog	1270	0	0	3	7.8569999	4.4790001	12.352
1	2011-08-16 18:02:35.472+09	xlog	1288	0	0	3	5.855	2.5669999	8.4379997
1	2011-08-16 18:03:04.399+09	xlog	1497	0	0	3	8.2609997	2.7909999	11.066
1	2011-08-16 18:03:33.448+09	xlog	1997	0	0	3	9.4729996	1.927	11.419
1	2011-08-16 18:04:06.141+09	xlog	1294	0	0	3	5.8520002	2.7019999	8.5719995
1	2011-08-16 18:04:36.302+09	xlog	1294	0	0	3	9.2609997	2.3800001	11.66
1	2011-08-16 18:05:10.102+09	xlog	1200	0	0	3	6.053	2.78	8.8520002
1	2011-08-16 18:05:40.475+09	xlog	1232	0	0	3	8.868	1.925	10.814
1	2011-08-16 18:06:11.401+09	xlog	1306	0	0	3	8.8610001	3.9189999	12.795
1	2011-08-16 18:06:45.16+09	xlog	1228	0	0	3	8.6599998	2.5190001	11.194
1	2011-08-16 18:07:15.899+09	xlog	1211	0	0	3	8.4580002	3.4000001	11.875
1	2011-08-16 18:07:48.441+09	xlog	1278	0	0	3	5.8470001	2.5190001	8.3809996
1	2011-08-16 18:08:17.274+09	xlog	1306	0	0	3	8.9910002	3.651	12.668
1	2011-08-16 18:08:46.989+09	xlog	1265	0	0	3	9.0600004	2.3710001	11.448
1	2011-08-16 18:09:20.899+09	xlog	1227	0	0	3	5.652	2.612	8.2810001
1	2011-08-16 18:09:49.197+09	xlog	1236	0	0	3	8.6630001	3.2720001	11.95
1	2011-08-16 18:10:17.757+09	xlog	1241	0	0	3	8.2600002	2.368	10.643
1	2011-08-16 18:10:50.666+09	xlog	1249	0	0	3	4.243	3.977	8.2440004
1	2011-08-16 18:11:20.925+09	xlog	1181	0	0	3	8.6639996	2.918	11.613
1	2011-08-16 18:11:54.461+09	xlog	1316	0	0	3	6.0479999	2.822	8.8940001
1	2011-08-16 18:12:22.676+09	xlog	1816	0	0	3	5.9219999	4.6440001	10.582
1	2011-08-16 18:12:49.268+09	xlog	1536	0	0	3	5.8499999	2.4089999	8.2840004
1	2011-08-16 18:13:17.645+09	xlog	1324	0	0	3	8.6730003	2.618	11.31
1	2011-08-16 18:13:51.223+09	xlog	1193	0	0	3	5.448	2.4449999	7.9120002
1	2011-08-16 18:14:22.439+09	xlog	1237	0	0	3	9.0629997	2.471	11.551
1	2011-08-16 18:14:56.404+09	xlog	1290	0	0	3	5.8429999	2.674	8.5380001
1	2011-08-16 18:15:27.732+09	xlog	1344	0	0	3	9.2620001	2.9349999	12.217
1	2011-08-16 18:16:02.013+09	xlog	1278	0	0	3	5.8470001	2.8929999	8.7559996
1	2011-08-16 18:16:32.146+09	xlog	1314	0	0	3	8.257	3.4400001	11.72
1	2011-08-16 18:17:05.819+09	xlog	1309	0	0	3	5.8850002	3.2079999	9.1090002
1	2011-08-16 18:17:34.67+09	xlog	1316	0	0	3	5.6469998	2.743	8.4209995
1	2011-08-16 18:18:02.609+09	xlog	1389	0	0	3	8.8669996	2.497	11.382
1	2011-08-16 18:18:32.954+09	xlog	1376	0	0	3	8.8649998	2.46	11.339
1	2011-08-16 18:19:05.918+09	xlog	1335	0	0	3	5.4439998	2.869	8.3380003
1	2011-08-16 18:19:31.858+09	xlog	1353	0	0	3	5.4499998	2.6040001	8.0690002
1	2011-08-16 18:20:00.05+09	xlog	1359	0	0	3	8.2749996	2.0639999	10.36
1	2011-08-16 18:20:30.251+09	xlog	1330	0	0	3	7.8590002	1.646	10.602
1	2011-08-16 18:21:04.527+09	xlog	1506	0	0	3	9.2650003	1.8200001	11.101
1	2011-08-16 18:21:34.154+09	xlog	1908	0	0	3	8.8710003	1.749	10.636
1	2011-08-16 18:22:05.474+09	xlog	1404	0	0	3	5.448	1.729	7.1929998
1	2011-08-16 18:22:35.927+09	xlog	1388	0	0	3	8.8710003	0.366	9.3009996
1	2011-08-16 18:23:03.622+09	xlog	1407	0	0	3	8.8640003	2.3970001	11.306
1	2011-08-16 18:23:30.70+09	xlog	1325	0	0	3	8.4910002	5.0380001	13.544
1	2011-08-16 18:24:02.808+09	xlog	1323	0	0	3	5.645	2.6300001	8.29
1	2011-08-16 18:24:33.216+09	xlog	1404	0	0	3	9.059	3.188	12.266
1	2011-08-16 18:25:02.55+09	xlog	1383	0	0	3	8.46	2.7079999	11.193
1	2011-08-16 18:25:35.493+09	xlog	1370	0	0	3	5.8460002	2.6289999	8.493
1	2011-08-16 18:26:04.725+09	xlog	1403	0	0	3	8.8660002	3.3729999	12.26
1	2011-08-16 18:26:34.272+09	xlog	1374	0	0	3	8.4610004	2.6029999	11.081
1	2011-08-16 18:27:07.267+09	xlog	1402	0	0	3	5.6459999	2.756	8.4189997
1	2011-08-16 18:27:36.061+09	xlog	1438	0	0	3	8.8660002	3.006	11.888
1	2011-08-16 18:28:05.547+09	xlog	1422	0	0	3	8.8640003	2.5829999	11.466
1	2011-08-16 18:28:38.72+09	xlog	1431	0	0	3	5.6490002	2.477	8.1429996
1	2011-08-16 18:29:07.276+09	xlog	1434	0	0	3	9.066	2.6300001	11.711
1	2011-08-16 18:29:41.48+09	xlog	1343	0	0	3	6.0500002	2.1819999	8.2469997
1	2011-08-16 18:30:11.107+09	xlog	1686	0	0	3	8.8629999	1.7869999	10.673
1	2011-08-16 18:30:40.021+09	xlog	1852	0	0	3	9.0699997	3.404	12.5
1	2011-08-16 18:31:12.531+09	xlog	1348	0	0	3	5.6539998	2.6819999	8.3549995
1	2011-08-16 18:31:42.702+09	xlog	1352	0	0	3	8.6610003	4.052	12.734
1	2011-08-16 18:32:11.751+09	xlog	1371	0	0	3	8.4680004	2.675	11.167
1	2011-08-16 18:32:45.278+09	xlog	1467	0	0	3	6.2529998	2.4549999	8.7250004
1	2011-08-16 18:33:13.848+09	xlog	1404	0	0	3	8.6619997	2.5650001	11.249
1	2011-08-16 18:33:44.512+09	xlog	1371	0	0	3	8.8599997	2.6670001	11.55
1	2011-08-16 18:34:16.767+09	xlog	1355	0	0	3	5.8520002	2.434	8.3030005
1	2011-08-16 18:34:45.432+09	xlog	1424	0	0	3	9.0600004	3.296	12.371
1	2011-08-16 18:35:15.041+09	xlog	1372	0	0	3	9.0649996	2.75	11.832
1	2011-08-16 18:35:48.932+09	xlog	1370	0	0	3	5.8449998	2.5580001	8.4259996
1	2011-08-16 18:36:17.107+09	xlog	1305	0	0	3	8.4639997	2.457	10.939
1	2011-08-16 18:36:50.339+09	xlog	1313	0	0	3	5.6469998	2.3989999	8.0719995
1	2011-08-16 18:37:20.019+09	xlog	1245	0	0	3	5.2470002	2.5	7.7649999
1	2011-08-16 18:37:48.874+09	xlog	1338	0	0	3	8.6599998	2.405	11.082
1	2011-08-16 18:38:22.921+09	xlog	1290	0	0	3	6.0500002	2.375	8.4469995
1	2011-08-16 18:38:54.156+09	xlog	1404	0	0	3	8.8640003	2.3010001	11.181
1	2011-08-16 18:39:26.557+09	xlog	1840	0	0	3	6.2519999	2.339	8.6120005
1	2011-08-16 18:39:56.005+09	xlog	1414	0	0	3	5.8520002	5.3330002	11.199
1	2011-08-16 18:40:26.449+09	xlog	1233	0	0	3	8.2620001	2.1400001	10.417
1	2011-08-16 18:41:00.276+09	xlog	1282	0	0	3	5.855	1.939	7.809
1	2011-08-16 18:41:30.806+09	xlog	1328	0	0	3	8.6610003	2.0190001	10.699
1	2011-08-16 18:42:04.968+09	xlog	1320	0	0	3	6.2490001	2.171	8.4359999
1	2011-08-16 18:42:35.775+09	xlog	1329	0	0	3	8.8620005	2.1819999	11.06
1	2011-08-16 18:43:10.32+09	xlog	1305	0	0	3	5.8429999	1.985	7.8429999
1	2011-08-16 18:43:40.258+09	xlog	1299	0	0	3	8.6619997	1.971	10.651
1	2011-08-16 18:44:13.756+09	xlog	1278	0	0	3	5.8449998	2.4419999	8.302
1	2011-08-16 18:44:44.682+09	xlog	1365	0	0	3	9.0609999	2.4909999	11.569
1	2011-08-16 18:45:19.004+09	xlog	1335	0	0	3	5.645	2.3640001	8.0340004
1	2011-08-16 18:45:49.961+09	xlog	1303	0	0	3	8.6619997	2.385	11.061
1	2011-08-16 18:46:23.313+09	xlog	1146	0	0	3	5.2459998	2.526	7.796
1	2011-08-16 18:46:53.877+09	xlog	1261	0	0	3	8.6590004	2.914	11.599
1	2011-08-16 18:47:23.829+09	xlog	1269	0	0	3	9.0640001	2.7060001	11.789
1	2011-08-16 18:47:58.637+09	xlog	1381	0	0	3	9.0649996	0.34299999	9.4230003
1	2011-08-16 18:48:26.294+09	xlog	1900	0	0	3	9.6719999	1.552	11.24
1	2011-08-16 18:48:55.572+09	xlog	1456	0	0	3	8.8660002	3.2839999	12.17
1	2011-08-16 18:49:28.875+09	xlog	1304	0	0	3	6.0450001	2.4790001	8.5450001
1	2011-08-16 18:49:57.448+09	xlog	1277	0	0	3	8.6639996	2.533	11.213
1	2011-08-16 18:50:31.192+09	xlog	1253	0	0	3	5.6599998	2.4159999	8.0930004
1	2011-08-16 18:51:02.186+09	xlog	1327	0	0	3	9.0609999	2.4260001	11.502
1	2011-08-16 18:51:36.942+09	xlog	1305	0	0	3	6.0450001	14.503	20.563999
1	2011-08-16 18:52:08.50+09	xlog	1214	0	0	3	7.4559999	12.726	20.271
1	2011-08-16 18:52:44.895+09	xlog	1341	0	0	3	5.2399998	13.175	18.433001
1	2011-08-16 18:53:21.478+09	xlog	1202	0	0	3	4.6370001	12.974	17.648001
1	2011-08-16 18:53:59.678+09	xlog	1209	0	0	3	7.4899998	13.383	20.888
1	2011-08-16 18:54:32.615+09	xlog	1243	0	0	3	7.2519999	9.526	16.829
1	2011-08-16 18:55:07.83+09	xlog	1247	0	0	3	5.04	16.128	21.187
1	2011-08-16 18:55:40.269+09	xlog	1133	0	0	3	6.6500001	7.1469998	13.842
1	2011-08-16 18:56:14.007+09	xlog	1322	0	0	3	4.8449998	8.1529999	13.036
1	2011-08-16 18:56:45.143+09	xlog	1274	0	0	3	7.8569999	4.073	11.998
1	2011-08-16 18:57:18.807+09	xlog	1711	0	0	3	5.8499999	3.9549999	9.8219995
1	2011-08-16 18:57:45.852+09	xlog	1672	0	0	3	9.0740004	1.959	11.052
1	2011-08-16 18:58:16.673+09	xlog	1249	0	0	3	8.7539997	1.924	10.698
1	2011-08-16 18:58:50.442+09	xlog	1280	0	0	3	6.0479999	1.756	7.822
1	2011-08-16 18:59:20.082+09	xlog	1222	0	0	3	9.0699997	2.052	11.137
1	2011-08-16 18:59:53.825+09	xlog	1225	0	0	3	5.8449998	2.8789999	8.7399998
1	2011-08-16 19:00:24.936+09	xlog	1228	0	0	3	8.8669996	1.811	10.703
1	2011-08-16 19:00:58.539+09	xlog	1296	0	0	3	5.8470001	1.594	7.4629998
1	2011-08-16 19:01:28.853+09	xlog	1305	0	0	3	8.8640003	1.813	10.696
1	2011-08-16 19:02:02.80+09	xlog	1216	0	0	3	5.7620001	1.652	7.4429998
1	2011-08-16 19:02:34.52+09	xlog	1269	0	0	3	8.4689999	1.872	10.36
1	2011-08-16 19:03:08.37+09	xlog	1261	0	0	3	5.4439998	1.5420001	7.5040002
1	2011-08-16 19:03:39.19+09	xlog	1291	0	0	3	8.6549997	1.457	10.183
1	2011-08-16 19:04:08.263+09	xlog	1271	0	0	3	8.6599998	1.304	9.9820004
1	2011-08-16 19:04:40.865+09	xlog	1316	0	0	3	7.0910001	1.128	8.2340002
1	2011-08-16 19:05:10.803+09	xlog	1303	0	0	3	9.0830002	0.935	10.054
1	2011-08-16 19:05:39.888+09	xlog	1268	0	0	3	8.6569996	4.414	13.086
1	2011-08-16 19:06:12.337+09	xlog	1547	0	0	3	4.842	5.921	10.78
1	2011-08-16 19:06:45.005+09	xlog	1630	0	0	3	9.0690002	2.059	11.147
1	2011-08-16 19:07:18.281+09	xlog	1229	0	0	3	5.8449998	2.188	8.0550003
1	2011-08-16 19:07:49.117+09	xlog	1288	0	0	3	8.8629999	2.082	10.96
1	2011-08-16 19:08:18.775+09	xlog	1222	0	0	3	8.46	2.1760001	10.653
1	2011-08-16 19:08:52.446+09	xlog	1257	0	0	3	5.8429999	2.5439999	8.4060001
1	2011-08-16 19:09:21.805+09	xlog	1183	0	0	3	8.2589998	1.944	10.219
1	2011-08-16 19:09:55.59+09	xlog	1335	0	0	3	6.2470002	2.352	8.6199999
1	2011-08-16 19:10:26.064+09	xlog	1358	0	0	3	9.0620003	2.4130001	11.495
1	2011-08-16 19:10:59.884+09	xlog	1255	0	0	3	5.645	2.2119999	7.8720002
1	2011-08-16 19:11:30.739+09	xlog	1343	0	0	3	9.059	2.1059999	11.189
1	2011-08-16 19:12:04.464+09	xlog	1202	0	0	3	5.4450002	2.4070001	7.868
1	2011-08-16 19:12:34.716+09	xlog	1274	0	0	3	8.8669996	2.4000001	11.293
1	2011-08-16 19:13:05.565+09	xlog	1276	0	0	3	9.0620003	2.3169999	11.398
1	2011-08-16 19:13:39.796+09	xlog	1276	0	0	3	8.8620005	2.4059999	11.288
1	2011-08-16 19:14:10.847+09	xlog	1268	0	0	3	9.2679996	2.4809999	11.767
1	2011-08-16 19:14:45.484+09	xlog	1274	0	0	3	8.6669998	2.8529999	11.537
1	2011-08-16 19:15:15.612+09	xlog	1552	0	0	3	10.673	1.4069999	12.096
1	2011-08-16 19:15:48.82+09	xlog	1676	0	0	3	6.4520001	2.329	8.8050003
1	2011-08-16 19:16:17.664+09	xlog	1345	0	0	3	9.0609999	2.362	11.441
1	2011-08-16 19:16:51.567+09	xlog	1215	0	0	3	5.849	2.2650001	8.1379995
1	2011-08-16 19:17:22.464+09	xlog	1198	0	0	3	8.2620001	3.174	11.457
1	2011-08-16 19:17:55.836+09	xlog	1197	0	0	3	5.6469998	2.9389999	8.6009998
1	2011-08-16 19:18:26.973+09	xlog	1304	0	0	3	9.1079998	2.312	11.442
1	2011-08-16 19:18:56.571+09	xlog	1230	0	0	3	8.6560001	2.569	11.241
1	2011-08-16 19:19:30.619+09	xlog	1280	0	0	3	5.8449998	2.665	8.5310001
1	2011-08-16 19:19:59.135+09	xlog	1306	0	0	3	8.6599998	3.4230001	12.101
1	2011-08-16 19:20:32.149+09	xlog	1209	0	0	3	5.6440001	2.7909999	8.4510002
1	2011-08-16 19:21:02.903+09	xlog	1251	0	0	3	8.6639996	3.3280001	12.007
1	2011-08-16 19:21:32.574+09	xlog	1253	0	0	3	8.4630003	2.5380001	11.017
1	2011-08-16 19:22:07.232+09	xlog	1304	0	0	3	9.2670002	1.551	10.841
1	2011-08-16 19:22:36.268+09	xlog	1275	0	0	3	9.0679998	2.4809999	11.566
1	2011-08-16 19:23:10.211+09	xlog	1278	0	0	3	5.849	2.4560001	8.3299999
1	2011-08-16 19:23:40.226+09	xlog	1334	0	0	3	9.0620003	2.483	11.566
1	2011-08-16 19:24:14.761+09	xlog	1541	0	0	3	5.849	1.886	7.7529998
1	2011-08-16 19:24:43.433+09	xlog	1671	0	0	3	9.0699997	0.42500001	9.5170002
1	2011-08-16 19:25:11.584+09	xlog	1293	0	0	3	8.8599997	2.5539999	11.438
1	2011-08-16 19:25:45.527+09	xlog	1271	0	0	3	5.8449998	3.04	8.901
1	2011-08-16 19:26:15.018+09	xlog	1284	0	0	3	8.6660004	2.608	11.293
1	2011-08-16 19:26:49.319+09	xlog	1250	0	0	3	6.1329999	2.951	9.1059999
1	2011-08-16 19:27:19.062+09	xlog	1253	0	0	3	5.8460002	2.5769999	8.4370003
1	2011-08-16 19:27:47.606+09	xlog	1310	0	0	3	8.8649998	2.4649999	11.346
1	2011-08-16 19:28:21.531+09	xlog	1136	0	0	3	5.4429998	2.4400001	7.9349999
1	2011-08-16 19:28:51.768+09	xlog	1264	0	0	3	8.6610003	2.4349999	11.111
1	2011-08-16 19:29:25.329+09	xlog	1156	0	0	3	5.4460001	2.589	8.052
1	2011-08-16 19:29:56.07+09	xlog	1232	0	0	3	8.8599997	3.8410001	12.723
1	2011-08-16 19:30:25.49+09	xlog	1207	0	0	3	8.6569996	2.385	11.062
1	2011-08-16 19:30:59.345+09	xlog	1357	0	0	3	6.2470002	2.5780001	8.8439999
1	2011-08-16 19:31:28.111+09	xlog	1321	0	0	3	9.0609999	3.911	12.999
1	2011-08-16 19:32:01.591+09	xlog	1216	0	0	3	5.6420002	2.53	8.1899996
1	2011-08-16 19:32:32.421+09	xlog	1255	0	0	3	8.8599997	3.6659999	12.542
1	2011-08-16 19:33:02.464+09	xlog	1370	0	0	3	8.4580002	2.2939999	10.767
1	2011-08-16 19:33:34.778+09	xlog	1777	0	0	3	6.2360001	1.92	8.1709995
1	2011-08-16 19:34:04.139+09	xlog	1383	0	0	3	9.0670004	3.0120001	12.104
1	2011-08-16 19:34:37.581+09	xlog	1217	0	0	3	5.645	2.6099999	8.2749996
1	2011-08-16 19:35:08.412+09	xlog	1298	0	0	3	8.8590002	2.493	11.37
1	2011-08-16 19:35:39.019+09	xlog	1261	0	0	3	8.6590004	2.4849999	11.173
1	2011-08-16 19:36:13.376+09	xlog	1240	0	0	3	8.8610001	2.4760001	11.356
1	2011-08-16 19:36:43.225+09	xlog	1229	0	0	3	8.665	2.3599999	11.041
1	2011-08-16 19:37:17.126+09	xlog	1295	0	0	3	6.4510002	2.5450001	9.0190001
1	2011-08-16 19:37:46.736+09	xlog	1242	0	0	3	9.0600004	3.927	13.002
1	2011-08-16 19:38:19.799+09	xlog	1225	0	0	3	5.6529999	2.4560001	8.1239996
1	2011-08-16 19:38:50.337+09	xlog	1301	0	0	3	8.6619997	3.849	12.533
1	2011-08-16 19:39:20.223+09	xlog	1186	0	0	3	8.4580002	2.477	10.953
1	2011-08-16 19:39:52.92+09	xlog	1229	0	0	3	5.8449998	2.45	8.3120003
1	2011-08-16 19:40:22.015+09	xlog	1244	0	0	3	8.6660004	2.8469999	11.538
1	2011-08-16 19:40:55.735+09	xlog	1140	0	0	3	5.6459999	2.904	8.5640001
1	2011-08-16 19:41:27.251+09	xlog	1236	0	0	3	9.6639996	1.526	11.205
1	2011-08-16 19:42:00.244+09	xlog	1264	0	0	3	6.447	2.484	8.9519997
1	2011-08-16 19:42:31.959+09	xlog	1703	0	0	3	9.4709997	1.2869999	10.78
1	2011-08-16 19:43:01.554+09	xlog	1442	0	0	3	9.2659998	4.0240002	13.309
1	2011-08-16 19:43:34.468+09	xlog	1296	0	0	3	6.0469999	2.4860001	8.5629997
1	2011-08-16 19:44:03.502+09	xlog	1250	0	0	3	8.46	2.546	11.042
1	2011-08-16 19:44:37.326+09	xlog	1245	0	0	3	5.4450002	2.3859999	7.8569999
1	2011-08-16 19:45:07.572+09	xlog	1312	0	0	3	8.8640003	2.5139999	11.397
1	2011-08-16 19:45:38.285+09	xlog	1297	0	0	3	8.6569996	2.3010001	10.996
1	2011-08-16 19:46:12.084+09	xlog	1243	0	0	3	8.8610001	4.6240001	13.51
1	2011-08-16 19:46:42.709+09	xlog	1262	0	0	3	8.658	2.448	11.123
1	2011-08-16 19:47:16.27+09	xlog	1253	0	0	3	5.6490002	2.5209999	8.1879997
1	2011-08-16 19:47:44.928+09	xlog	1289	0	0	3	8.8640003	2.431	11.318
1	2011-08-16 19:48:19.503+09	xlog	1253	0	0	3	5.8449998	2.3570001	8.2259998
1	2011-08-16 19:48:50.467+09	xlog	1281	0	0	3	9.0629997	2.77	11.848
1	2011-08-16 19:49:24.462+09	xlog	1180	0	0	3	5.8439999	2.4289999	8.2950001
1	2011-08-16 19:49:55.101+09	xlog	1257	0	0	3	9.2600002	2.073	11.357
1	2011-08-16 19:50:24.371+09	xlog	1236	0	0	3	8.2600002	2.3770001	10.665
1	2011-08-16 19:50:58.465+09	xlog	1284	0	0	3	8.8610001	2.3889999	11.269
1	2011-08-16 19:51:27.28+09	xlog	1630	0	0	3	9.0769997	1.4630001	10.567
1	2011-08-16 19:51:59.209+09	xlog	1349	0	0	3	5.4450002	3.2509999	8.7130003
1	2011-08-16 19:52:29.282+09	xlog	1191	0	0	3	5.6479998	2.319	7.987
1	2011-08-16 19:52:58.009+09	xlog	1252	0	0	3	8.6630001	3.733	12.411
1	2011-08-16 19:53:30.863+09	xlog	1117	0	0	3	5.6440001	2.5280001	8.1929998
1	2011-08-16 19:54:02.244+09	xlog	1285	0	0	3	9.0620003	3.335	12.423
1	2011-08-16 19:54:35.16+09	xlog	1200	0	0	3	5.6479998	2.5650001	8.2349997
1	2011-08-16 19:55:06.193+09	xlog	1213	0	0	3	8.4580002	3.757	12.231
1	2011-08-16 19:55:35.648+09	xlog	1208	0	0	3	8.4589996	2.4979999	10.972
1	2011-08-16 19:56:09.227+09	xlog	1431	0	0	3	6.4520001	2.6949999	9.1619997
1	2011-08-16 19:56:38.749+09	xlog	1291	0	0	3	9.0710001	4.2969999	13.383
1	2011-08-16 19:57:12.165+09	xlog	1227	0	0	3	5.6500001	2.405	8.0740004
1	2011-08-16 19:57:43.091+09	xlog	1291	0	0	3	8.8579998	4.2360001	13.122
1	2011-08-16 19:58:13.241+09	xlog	1207	0	0	3	8.46	2.6400001	11.115
1	2011-08-16 19:58:47.214+09	xlog	1237	0	0	3	9.0640001	3.7609999	12.843
1	2011-08-16 19:59:17.001+09	xlog	1281	0	0	3	8.8599997	2.4749999	11.355
1	2011-08-16 19:59:50.781+09	xlog	1295	0	0	3	6.0469999	2.3150001	8.3800001
1	2011-08-16 20:00:20.066+09	xlog	1567	0	0	3	9.2639999	1.844	11.128
1	2011-08-16 20:00:53.032+09	xlog	1504	0	0	3	6.48	2.6129999	9.1070004
1	2011-08-16 20:01:22.752+09	xlog	1215	0	0	3	5.4450002	2.6429999	8.1040001
1	2011-08-16 20:01:51.685+09	xlog	1272	0	0	3	8.8629999	2.5580001	11.436
1	2011-08-16 20:02:26.542+09	xlog	1195	0	0	3	5.6430001	2.454	8.1160002
1	2011-08-16 20:02:56.86+09	xlog	1214	0	0	3	8.8649998	3.0079999	11.888
1	2011-08-16 20:03:31.185+09	xlog	1269	0	0	3	6.447	2.5510001	9.0179996
1	2011-08-16 20:04:01.131+09	xlog	1310	0	0	3	9.6719999	2.5409999	12.227
1	2011-08-16 20:04:34.55+09	xlog	1155	0	0	3	5.6500001	2.4560001	8.1300001
1	2011-08-16 20:05:05.585+09	xlog	1238	0	0	3	8.8719997	2.9289999	11.824
1	2011-08-16 20:05:35.396+09	xlog	1263	0	0	3	8.6569996	2.5039999	11.188
1	2011-08-16 20:06:08.977+09	xlog	1257	0	0	3	6.046	2.6359999	8.7030001
1	2011-08-16 20:06:38.638+09	xlog	1187	0	0	3	8.6680002	2.45	11.138
1	2011-08-16 20:07:12.559+09	xlog	1296	0	0	3	6.526	1.897	8.4420004
1	2011-08-16 20:07:41.749+09	xlog	1307	0	0	3	9.0609999	2.5079999	11.588
1	2011-08-16 20:08:15.43+09	xlog	1159	0	0	3	5.243	2.447	7.704
1	2011-08-16 20:08:46.049+09	xlog	1212	0	0	3	8.46	1.654	10.142
1	2011-08-16 20:09:15.536+09	xlog	1384	0	0	3	10.272	1.391	11.682
1	2011-08-16 20:09:49.714+09	xlog	1617	0	0	3	6.454	2.1819999	8.651
1	2011-08-16 20:10:18.92+09	xlog	1336	0	0	3	8.8590002	2.645	11.521
1	2011-08-16 20:10:52.942+09	xlog	1164	0	0	3	5.645	2.954	8.6169996
1	2011-08-16 20:11:23.461+09	xlog	1231	0	0	3	8.6630001	2.464	11.147
1	2011-08-16 20:11:57.133+09	xlog	1141	0	0	3	5.8559999	2.273	8.1520004
1	2011-08-16 20:12:27.059+09	xlog	1167	0	0	3	8.8620005	2.553	11.435
1	2011-08-16 20:12:57.917+09	xlog	1256	0	0	3	9.316	2.302	11.634
1	2011-08-16 20:13:31.033+09	xlog	1244	0	0	3	6.046	2.5350001	8.5979996
1	2011-08-16 20:14:00.083+09	xlog	1237	0	0	3	8.6560001	3.5380001	12.211
1	2011-08-16 20:14:34.371+09	xlog	1234	0	0	3	5.8509998	2.7969999	8.6669998
1	2011-08-16 20:15:05.519+09	xlog	1272	0	0	3	9.2629995	2.4389999	11.721
1	2011-08-16 20:15:38.278+09	xlog	1229	0	0	3	5.848	2.5309999	8.3950005
1	2011-08-16 20:16:09.147+09	xlog	1300	0	0	3	9.0640001	2.6619999	11.745
1	2011-08-16 20:16:39.152+09	xlog	1327	0	0	3	8.6660004	2.5039999	11.188
1	2011-08-16 20:17:13.136+09	xlog	1273	0	0	3	5.8449998	2.493	8.3610001
1	2011-08-16 20:17:41.853+09	xlog	1269	0	0	3	8.8629999	3.6719999	12.557
1	2011-08-16 20:18:15.475+09	xlog	1398	0	0	3	6.4549999	1.795	8.2650003
1	2011-08-16 20:18:45.991+09	xlog	1620	0	0	3	9.4659996	3.2620001	12.744
1	2011-08-16 20:19:19.245+09	xlog	1241	0	0	3	5.6469998	2.4809999	8.1440001
1	2011-08-16 20:19:50.294+09	xlog	1281	0	0	3	9.2639999	2.2160001	11.5
1	2011-08-16 20:20:19.526+09	xlog	1200	0	0	3	8.46	2.3770001	10.852
1	2011-08-16 20:20:53.059+09	xlog	1280	0	0	3	5.8449998	2.46	8.3210001
1	2011-08-16 20:21:23+09	xlog	1263	0	0	3	8.8649998	2.4319999	11.319
1	2011-08-16 20:21:56.557+09	xlog	1190	0	0	3	5.8429999	2.3759999	8.2550001
1	2011-08-16 20:22:27.428+09	xlog	1174	0	0	3	8.6540003	3.1659999	11.838
1	2011-08-16 20:23:01+09	xlog	1219	0	0	3	6.0489998	2.9749999	9.0389996
1	2011-08-16 20:23:31.908+09	xlog	1275	0	0	3	9.2600002	2.421	11.7
1	2011-08-16 20:24:05.784+09	xlog	1203	0	0	3	6.2490001	2.0079999	8.2779999
1	2011-08-16 20:24:35.80+09	xlog	1227	0	0	3	5.6459999	2.566	8.2270002
1	2011-08-16 20:25:04.337+09	xlog	1284	0	0	3	8.8640003	3.648	12.533
1	2011-08-16 20:25:38.369+09	xlog	1231	0	0	3	5.6430001	2.5699999	8.2320004
1	2011-08-16 20:26:07.585+09	xlog	1349	0	0	3	4.848	4.6599998	9.533
1	2011-08-16 20:26:31.563+09	xlog	1297	0	0	3	5.4419999	6.5809999	12.038
1	2011-08-16 20:27:01.687+09	xlog	1316	0	0	3	8.658	3.2119999	11.884
1	2011-08-16 20:27:37.323+09	xlog	1598	0	0	3	4.2389998	4.303	8.6049995
1	2011-08-16 20:28:04.665+09	xlog	1334	0	0	3	5.0419998	4.9549999	10.011
1	2011-08-16 20:28:29.86+09	xlog	1248	0	0	3	4.6810002	7.8460002	12.543
1	2011-08-16 20:28:54.824+09	xlog	1177	0	0	3	4.4400001	6.1269999	10.582
1	2011-08-16 20:29:22.688+09	xlog	1296	0	0	3	4.4439998	5.132	9.592
1	2011-08-16 20:29:49.596+09	xlog	1256	0	0	3	9.0649996	1.34	10.508
1	2011-08-16 20:30:20.216+09	xlog	1221	0	0	3	9.2679996	1.041	10.324
1	2011-08-16 20:30:54.234+09	xlog	1204	0	0	3	9.2639999	1.312	10.642
1	2011-08-16 20:31:25.612+09	xlog	1203	0	0	3	8.6619997	1.3839999	10.062
1	2011-08-16 20:31:59.664+09	xlog	1200	0	0	3	9.2690001	1.3099999	10.67
1	2011-08-16 20:32:30.179+09	xlog	1231	0	0	3	8.8610001	1.272	10.157
1	2011-08-16 20:33:03.439+09	xlog	1256	0	0	3	9.6660004	1.082	10.819
1	2011-08-16 20:33:33.894+09	xlog	1201	0	0	3	8.2600002	1.209	9.4849997
1	2011-08-16 20:34:06.983+09	xlog	1231	0	0	3	7.0780001	0.829	7.928
1	2011-08-16 20:34:37.171+09	xlog	1299	0	0	3	9.2609997	0.472	9.7559996
1	2011-08-16 20:35:06.636+09	xlog	1327	0	0	3	8.6660004	3.6340001	12.323
1	2011-08-16 20:35:39.874+09	xlog	1630	0	0	3	9.5089998	1.3710001	10.901
1	2011-08-16 20:36:09.799+09	xlog	1306	0	0	3	9.6639996	1.08	10.761
1	2011-08-16 20:36:42.724+09	xlog	1175	0	0	3	5.8400002	2.8380001	8.6940002
1	2011-08-16 20:37:14.114+09	xlog	1246	0	0	3	8.8590002	2.4949999	11.369
1	2011-08-16 20:37:48.512+09	xlog	1210	0	0	3	7.0510001	0.54000002	7.6069999
1	2011-08-16 20:38:18.667+09	xlog	1283	0	0	3	9.6820002	1.441	11.142
1	2011-08-16 20:38:51.38+09	xlog	1162	0	0	3	5.6430001	2.487	8.1459999
1	2011-08-16 20:39:22.559+09	xlog	1252	0	0	3	9.0640001	2.437	11.522
1	2011-08-16 20:39:56.909+09	xlog	1137	0	0	3	5.8410001	2.973	8.8380003
1	2011-08-16 20:40:28.283+09	xlog	1150	0	0	3	8.6590004	2.325	11
1	2011-08-16 20:41:02.834+09	xlog	1223	0	0	3	7.0640001	0.46900001	7.5560002
1	2011-08-16 20:41:32.912+09	xlog	1302	0	0	3	9.6669998	1.025	10.711
1	2011-08-16 20:42:03.085+09	xlog	1225	0	0	3	8.8590002	3.1930001	12.077
1	2011-08-16 20:42:36.877+09	xlog	1234	0	0	3	8.8610001	2.5969999	11.475
1	2011-08-16 20:43:07.942+09	xlog	1324	0	0	3	9.6610003	1.827	11.504
1	2011-08-16 20:43:41.237+09	xlog	1310	0	0	3	6.0469999	2.579	8.6429996
1	2011-08-16 20:44:10.83+09	xlog	1305	0	0	3	9.6689997	2.1689999	11.859
1	2011-08-16 20:44:45.284+09	xlog	1496	0	0	3	10.675	0.149	10.858
1	2011-08-16 20:45:15.528+09	xlog	1296	0	0	3	8.6590004	2.51	11.193
1	2011-08-16 20:45:49.497+09	xlog	1183	0	0	3	6.0489998	2.408	8.4799995
1	2011-08-16 20:46:21.06+09	xlog	1208	0	0	3	9.066	3.2809999	12.372
1	2011-08-16 20:46:54.87+09	xlog	1161	0	0	3	5.6440001	2.322	7.9840002
1	2011-08-16 20:47:25.768+09	xlog	1219	0	0	3	8.665	2.3970001	11.08
1	2011-08-16 20:47:59.264+09	xlog	1192	0	0	3	5.6420002	2.448	8.1090002
1	2011-08-16 20:48:29.987+09	xlog	1261	0	0	3	9.059	3.483	12.561
1	2011-08-16 20:49:03.032+09	xlog	1215	0	0	3	6.0479999	2.579	8.6470003
1	2011-08-16 20:49:33.871+09	xlog	1231	0	0	3	9.2659998	2.9760001	12.262
1	2011-08-16 20:50:04.303+09	xlog	1212	0	0	3	8.6590004	2.2720001	10.948
1	2011-08-16 20:50:38.119+09	xlog	1173	0	0	3	5.244	2.464	7.7259998
1	2011-08-16 20:51:07.137+09	xlog	1225	0	0	3	8.6560001	2.4860001	11.161
1	2011-08-16 20:51:40.991+09	xlog	1245	0	0	3	6.0419998	2.405	8.4720001
1	2011-08-16 20:52:12.051+09	xlog	1224	0	0	3	8.8620005	3.562	12.439
1	2011-08-16 20:52:45.633+09	xlog	1180	0	0	3	5.8509998	2.372	8.2370005
1	2011-08-16 20:53:16.908+09	xlog	1414	0	0	3	9.0649996	1.868	10.956
1	2011-08-16 20:53:51.022+09	xlog	1528	0	0	3	6.5279999	1.545	8.0970001
1	2011-08-16 20:54:21.103+09	xlog	1316	0	0	3	9.8629999	1.623	11.501
1	2011-08-16 20:54:51.314+09	xlog	1191	0	0	3	8.8649998	2.911	11.798
1	2011-08-16 20:55:26.53+09	xlog	1152	0	0	3	8.2670002	2.5	10.785
1	2011-08-16 20:56:00.987+09	xlog	1196	0	0	3	6.8839998	0.80299997	7.7090001
1	2011-08-16 20:56:32.049+09	xlog	1197	0	0	3	9.0620003	0.69300002	9.7709999
1	2011-08-16 20:57:01.441+09	xlog	1183	0	0	3	8.46	4.0279999	12.505
1	2011-08-16 20:57:34.309+09	xlog	1163	0	0	3	5.6430001	2.49	8.1490002
1	2011-08-16 20:58:03.715+09	xlog	1254	0	0	3	8.8590002	3.1989999	12.084
1	2011-08-16 20:58:37.382+09	xlog	1219	0	0	3	6.0469999	2.5220001	8.5930004
1	2011-08-16 20:59:08.368+09	xlog	1255	0	0	3	9.0699997	2.7260001	11.813
1	2011-08-16 20:59:41.043+09	xlog	1175	0	0	3	5.4499998	2.3540001	7.823
1	2011-08-16 21:00:11.805+09	xlog	1301	0	0	3	9.6660004	2.855	12.538
1	2011-08-16 21:00:42.449+09	xlog	1220	0	0	3	8.4589996	2.3929999	10.876
1	2011-08-16 21:01:16.187+09	xlog	1260	0	0	3	5.8449998	2.6670001	8.5279999
1	2011-08-16 21:01:45.389+09	xlog	1239	0	0	3	8.6590004	2.3670001	11.047
1	2011-08-16 21:02:20.114+09	xlog	1366	0	0	3	10.489	0.287	10.794
1	2011-08-16 21:02:51.146+09	xlog	1470	0	0	3	9.6820002	1.595	11.294
1	2011-08-16 21:03:25.119+09	xlog	1334	0	0	3	6.0669999	1.86	7.9429998
1	2011-08-16 21:03:54.236+09	xlog	1223	0	0	3	8.6560001	2.4760001	11.147
1	2011-08-16 21:04:27.915+09	xlog	1152	0	0	3	5.4720001	3.3399999	8.8360004
1	2011-08-16 21:04:57.729+09	xlog	1146	0	0	3	5.243	2.4159999	7.6830001
1	2011-08-16 21:05:26.98+09	xlog	1127	0	0	3	8.2589998	3.2880001	11.561
1	2011-08-16 21:06:01.045+09	xlog	1266	0	0	3	6.0440001	2.5610001	8.6239996
1	2011-08-16 21:06:31.637+09	xlog	1159	0	0	3	9.6639996	1.544	11.233
1	2011-08-16 21:07:04.647+09	xlog	1238	0	0	3	6.053	2.3989999	8.4659996
1	2011-08-16 21:07:36.266+09	xlog	1285	0	0	3	9.6759996	1.2029999	10.9
1	2011-08-16 21:08:09.05+09	xlog	1201	0	0	3	5.4460001	2.681	8.1479998
1	2011-08-16 21:08:39.89+09	xlog	1262	0	0	3	8.6560001	2.4119999	11.084
1	2011-08-16 21:09:13.678+09	xlog	1232	0	0	3	5.6459999	2.415	8.0830002
1	2011-08-16 21:09:44.763+09	xlog	1278	0	0	3	9.0710001	2.4319999	11.526
1	2011-08-16 21:10:19.089+09	xlog	1217	0	0	3	5.8449998	2.776	8.6459999
1	2011-08-16 21:10:49.58+09	xlog	1226	0	0	3	8.8649998	3.165	12.046
1	2011-08-16 21:11:20.046+09	xlog	1342	0	0	3	10.276	0.257	10.557
1	2011-08-16 21:11:52.923+09	xlog	1488	0	0	3	6.079	1.485	7.5910001
1	2011-08-16 21:12:22.633+09	xlog	1251	0	0	3	8.8620005	3.0250001	11.905
1	2011-08-16 21:12:55.608+09	xlog	1134	0	0	3	5.8520002	2.4000001	8.2770004
1	2011-08-16 21:13:26.798+09	xlog	1171	0	0	3	8.8599997	2.711	11.588
1	2011-08-16 21:13:59.849+09	xlog	1153	0	0	3	5.4489999	2.487	7.9520001
1	2011-08-16 21:14:31.266+09	xlog	1220	0	0	3	9.0579996	2.345	11.43
1	2011-08-16 21:15:05.628+09	xlog	1176	0	0	3	5.849	3.1040001	8.9680004
1	2011-08-16 21:15:36.458+09	xlog	1247	0	0	3	9.0629997	2.381	11.461
1	2011-08-16 21:16:10.603+09	xlog	1211	0	0	3	6.4829998	1.77	8.2690001
1	2011-08-16 21:16:40.824+09	xlog	1290	0	0	3	8.8599997	2.2320001	11.108
1	2011-08-16 21:17:11.476+09	xlog	1285	0	0	3	9.2700005	2.145	11.444
1	2011-08-16 21:17:44.342+09	xlog	1234	0	0	3	5.6399999	2.451	8.1090002
1	2011-08-16 21:18:14.471+09	xlog	1174	0	0	3	8.4650002	2.4660001	10.946
1	2011-08-16 21:18:49.254+09	xlog	1282	0	0	3	6.2420001	2.323	8.5819998
1	2011-08-16 21:19:18.469+09	xlog	1313	0	0	3	9.0679998	2.8829999	11.969
1	2011-08-16 21:19:52.36+09	xlog	1165	0	0	3	5.6409998	2.628	8.2860003
1	2011-08-16 21:20:23.761+09	xlog	1394	0	0	3	9.0629997	1.818	10.898
1	2011-08-16 21:20:57.579+09	xlog	1364	0	0	3	5.8520002	2.7839999	8.6599998
1	2011-08-16 21:21:26.834+09	xlog	1131	0	0	3	5.0469999	2.609	7.6729999
1	2011-08-16 21:21:55.81+09	xlog	1192	0	0	3	8.2659998	3.405	11.693
1	2011-08-16 21:22:29.682+09	xlog	1154	0	0	3	5.6459999	2.576	8.2379999
1	2011-08-16 21:23:00.628+09	xlog	1212	0	0	3	9.2629995	1.938	11.218
1	2011-08-16 21:23:33.506+09	xlog	1257	0	0	3	5.848	3.2490001	9.1160002
1	2011-08-16 21:24:04.68+09	xlog	1303	0	0	3	8.8629999	2.5	11.389
1	2011-08-16 21:24:38.42+09	xlog	1201	0	0	3	5.6440001	2.5739999	8.2370005
1	2011-08-16 21:25:09.26+09	xlog	1245	0	0	3	9.059	2.9790001	12.06
1	2011-08-16 21:25:39.145+09	xlog	1214	0	0	3	8.6610003	2.596	11.272
1	2011-08-16 21:26:13.737+09	xlog	1256	0	0	3	9.2629995	1.966	11.248
1	2011-08-16 21:26:43.123+09	xlog	1216	0	0	3	8.6630001	2.5039999	11.182
1	2011-08-16 21:27:17.179+09	xlog	1256	0	0	3	5.6479998	2.845	8.5150003
1	2011-08-16 21:27:46.636+09	xlog	1187	0	0	3	8.6560001	2.6570001	11.329
1	2011-08-16 21:28:20.78+09	xlog	1205	0	0	3	5.8449998	2.556	8.4329996
1	2011-08-16 21:28:52.214+09	xlog	1289	0	0	3	9.4799995	1.829	11.324
1	2011-08-16 21:29:25.332+09	xlog	1366	0	0	3	7.2589998	0.32800001	7.6139998
1	2011-08-16 21:29:55.43+09	xlog	1426	0	0	3	9.0649996	0.33899999	9.4200001
1	2011-08-16 21:30:24.823+09	xlog	1166	0	0	3	8.8640003	2.448	11.326
1	2011-08-16 21:30:59.41+09	xlog	1160	0	0	3	9.2729998	0.47499999	9.7679996
1	2011-08-16 21:31:29.932+09	xlog	1073	0	0	3	9.0600004	1.3710001	10.455
1	2011-08-16 21:32:03.168+09	xlog	1265	0	0	3	6.046	2.4849999	8.552
1	2011-08-16 21:32:32.906+09	xlog	1208	0	0	3	9.0649996	2.931	12.02
1	2011-08-16 21:33:06.144+09	xlog	1176	0	0	3	5.8470001	2.6099999	8.474
1	2011-08-16 21:33:38.111+09	xlog	1229	0	0	3	8.6719999	2.3929999	11.081
1	2011-08-16 21:34:12.037+09	xlog	1234	0	0	3	5.849	2.727	8.5930004
1	2011-08-16 21:34:42.907+09	xlog	1319	0	0	3	9.2589998	2.549	11.829
1	2011-08-16 21:35:16.948+09	xlog	1167	0	0	3	6.0580001	2.119	8.1949997
1	2011-08-16 21:35:46.229+09	xlog	1192	0	0	3	7.4549999	2.573	10.051
1	2011-08-16 21:36:16.475+09	xlog	1163	0	0	3	8.2700005	3.155	11.444
1	2011-08-16 21:36:50.05+09	xlog	1230	0	0	3	5.6479998	2.5539999	8.2279997
1	2011-08-16 21:37:19.765+09	xlog	1229	0	0	3	8.4639997	2.529	11.009
1	2011-08-16 21:37:53.679+09	xlog	1256	0	0	3	6.849	1.497	8.3699999
1	2011-08-16 21:38:23.632+09	xlog	1406	0	0	3	9.2620001	0.745	10.027
1	2011-08-16 21:38:53.286+09	xlog	1466	0	0	3	10.894	0.271	11.183
1	2011-08-16 21:39:27.002+09	xlog	1208	0	0	3	9.3339996	0.12899999	9.4820004
1	2011-08-16 21:39:56.485+09	xlog	1166	0	0	3	8.4619999	3.043	11.523
1	2011-08-16 21:40:28.836+09	xlog	1065	0	0	3	5.2449999	2.5309999	7.7930002
1	2011-08-16 21:40:59.889+09	xlog	1232	0	0	3	9.2639999	2.3729999	11.658
1	2011-08-16 21:41:29.60+09	xlog	1180	0	0	3	8.4610004	2.6289999	11.115
1	2011-08-16 21:42:03.852+09	xlog	1205	0	0	3	8.8710003	1.913	10.801
1	2011-08-16 21:42:33.235+09	xlog	1224	0	0	3	9.2600002	2.563	11.844
1	2011-08-16 21:43:07.893+09	xlog	1187	0	0	3	5.842	2.7639999	8.6260004
1	2011-08-16 21:43:36.675+09	xlog	1266	0	0	3	9.0600004	2.523	11.6
1	2011-08-16 21:44:10.918+09	xlog	1193	0	0	3	6.0479999	2.8710001	8.9329996
1	2011-08-16 21:44:41.288+09	xlog	1232	0	0	3	8.6599998	2.224	10.907
1	2011-08-16 21:45:15.291+09	xlog	1186	0	0	3	6.053	2.9059999	8.9779997
1	2011-08-16 21:45:44.991+09	xlog	1210	0	0	3	8.665	4.0609999	12.745
1	2011-08-16 21:46:15.35+09	xlog	1281	0	0	3	9.2639999	2.6289999	11.909
1	2011-08-16 21:46:51.058+09	xlog	1234	0	0	3	8.6590004	2.4649999	11.142
1	2011-08-16 21:47:25.662+09	xlog	1344	0	0	3	6.4530001	1.73	8.198
1	2011-08-16 21:47:56.867+09	xlog	1402	0	0	3	9.1009998	0.99000001	10.106
1	2011-08-16 21:48:29.563+09	xlog	1108	0	0	3	5.4439998	2.5550001	8.0349998
1	2011-08-16 21:49:00.548+09	xlog	1165	0	0	3	9.2860003	0.76599997	10.074
1	2011-08-16 21:49:30.442+09	xlog	1171	0	0	3	9.0649996	0.96799999	10.05
1	2011-08-16 21:50:03.182+09	xlog	1228	0	0	3	5.8439999	2.5929999	8.4530001
1	2011-08-16 21:50:32.924+09	xlog	1239	0	0	3	8.8610001	2.526	11.403
1	2011-08-16 21:51:06.841+09	xlog	1248	0	0	3	6.448	2.2379999	8.7060003
1	2011-08-16 21:51:37.021+09	xlog	1233	0	0	3	9.0649996	2.1889999	11.269
1	2011-08-16 21:52:11.01+09	xlog	1132	0	0	3	5.2659998	3.865	9.1560001
1	2011-08-16 21:52:41.232+09	xlog	1207	0	0	3	7.6560001	2.4809999	10.155
1	2011-08-16 21:53:11.215+09	xlog	1211	0	0	3	8.6619997	3.789	12.47
1	2011-08-16 21:53:44.329+09	xlog	1256	0	0	3	5.8429999	2.51	8.3710003
1	2011-08-16 21:54:14.593+09	xlog	1276	0	0	3	8.665	2.559	11.239
1	2011-08-16 21:54:48.59+09	xlog	1174	0	0	3	5.6430001	2.47	8.1330004
1	2011-08-16 21:55:19.666+09	xlog	1205	0	0	3	8.658	3.0840001	11.769
1	2011-08-16 21:55:53.414+09	xlog	1216	0	0	3	6.052	2.5090001	8.5760002
1	2011-08-16 21:56:25.368+09	xlog	1327	0	0	3	9.467	1.817	11.304
1	2011-08-16 21:56:59.946+09	xlog	1440	0	0	3	6.6589999	0.68599999	7.3610001
1	2011-08-16 21:57:29.482+09	xlog	1166	0	0	3	8.6669998	2.7360001	11.42
1	2011-08-16 21:57:59.015+09	xlog	1173	0	0	3	8.2580004	2.467	10.74
1	2011-08-16 21:58:32.826+09	xlog	1223	0	0	3	8.8620005	2.766	11.645
1	2011-08-16 21:59:02.175+09	xlog	1137	0	0	3	8.4610004	2.4519999	10.93
1	2011-08-16 21:59:35.913+09	xlog	1255	0	0	3	6.0500002	2.4330001	8.5080004
1	2011-08-16 22:00:05.85+09	xlog	1229	0	0	3	8.8640003	2.392	11.27
1	2011-08-16 22:00:39.785+09	xlog	1192	0	0	3	5.8509998	2.224	8.0909996
1	2011-08-16 22:01:10.638+09	xlog	1237	0	0	3	8.8590002	3.8199999	12.696
1	2011-08-16 22:01:43.965+09	xlog	1126	0	0	3	6.0539999	2.414	8.4820004
1	2011-08-16 22:02:15.959+09	xlog	1195	0	0	3	8.8620005	2.4820001	11.359
1	2011-08-16 22:02:45.357+09	xlog	1187	0	0	3	8.467	2.527	11.01
1	2011-08-16 22:03:19.57+09	xlog	1258	0	0	3	9.0600004	2.2460001	11.326
1	2011-08-16 22:03:49.118+09	xlog	1189	0	0	3	8.8620005	2.51	11.397
1	2011-08-16 22:04:23.36+09	xlog	1273	0	0	3	6.0479999	2.4219999	8.4940004
1	2011-08-16 22:04:52.311+09	xlog	1257	0	0	3	8.8710003	2.382	11.274
1	2011-08-16 22:05:26.985+09	xlog	1332	0	0	3	6.244	1.88	8.1429996
1	2011-08-16 22:05:58.053+09	xlog	1423	0	0	3	9.665	1.072	10.76
1	2011-08-16 22:06:32.538+09	xlog	1074	0	0	3	6.0450001	2.45	8.5179996
1	2011-08-16 22:07:03.111+09	xlog	1137	0	0	3	8.4610004	0.95899999	9.4420004
1	2011-08-16 22:07:35.988+09	xlog	1206	0	0	3	6.6589999	0.71499997	7.3979998
1	2011-08-16 22:08:05.829+09	xlog	1222	0	0	3	8.8599997	0.121	8.9960003
1	2011-08-16 22:08:34.224+09	xlog	1143	0	0	3	8.4589996	3.1129999	11.589
1	2011-08-16 22:09:08.343+09	xlog	1179	0	0	3	5.8530002	2.6159999	8.4890003
1	2011-08-16 22:09:38.858+09	xlog	1210	0	0	3	9.2639999	1.882	11.171
1	2011-08-16 22:10:11.791+09	xlog	1098	0	0	3	5.244	2.4489999	7.71
1	2011-08-16 22:10:42.13+09	xlog	1218	0	0	3	8.6639996	2.839	11.524
1	2011-08-16 22:11:12.684+09	xlog	1252	0	0	3	8.8620005	2.6559999	11.538
1	2011-08-16 22:11:46.436+09	xlog	1185	0	0	3	5.6479998	2.602	8.2749996
1	2011-08-16 22:12:15.226+09	xlog	1293	0	0	3	9.0640001	2.6259999	11.706
1	2011-08-16 22:12:50.153+09	xlog	1303	0	0	3	6.4520001	1.801	8.2700005
1	2011-08-16 22:13:19.664+09	xlog	1221	0	0	3	8.6599998	2.2149999	10.89
1	2011-08-16 22:13:53.783+09	xlog	1234	0	0	3	6.2550001	2.402	8.6750002
1	2011-08-16 22:14:23.917+09	xlog	1341	0	0	3	9.0970001	0.48199999	9.6070004
1	2011-08-16 22:14:53.26+09	xlog	1469	0	0	3	10.88	0.27399999	11.175
1	2011-08-16 22:15:27.108+09	xlog	1225	0	0	3	6.0560002	1.608	7.6820002
1	2011-08-16 22:15:56.37+09	xlog	1196	0	0	3	8.4589996	2.4649999	10.944
1	2011-08-16 22:16:30.077+09	xlog	1101	0	0	3	5.652	2.9630001	8.6339998
1	2011-08-16 22:17:00.466+09	xlog	1188	0	0	3	8.6610003	2.431	11.111
1	2011-08-16 22:17:35.161+09	xlog	1166	0	0	3	7.0689998	1.317	8.408
1	2011-08-16 22:18:05.243+09	xlog	1265	0	0	3	8.8620005	2.161	11.04
1	2011-08-16 22:18:38.959+09	xlog	1118	0	0	3	5.2639999	3.273	8.5570002
1	2011-08-16 22:19:08.847+09	xlog	1214	0	0	3	6.447	2.302	8.7670002
1	2011-08-16 22:19:37.143+09	xlog	1236	0	0	3	8.8579998	2.575	11.448
1	2011-08-16 22:20:11.25+09	xlog	1151	0	0	3	6.447	2.8510001	9.3199997
1	2011-08-16 22:20:41.478+09	xlog	1213	0	0	3	8.6599998	3.651	12.334
1	2011-08-16 22:21:11.739+09	xlog	1207	0	0	3	9.0579996	2.3629999	11.438
1	2011-08-16 22:21:45.994+09	xlog	1205	0	0	3	8.8579998	2.7709999	11.651
1	2011-08-16 22:22:15.948+09	xlog	1157	0	0	3	8.6610003	2.398	11.082
1	2011-08-16 22:22:51.78+09	xlog	1195	0	0	3	9.2650003	0.56800002	9.8549995
1	2011-08-16 22:23:26.206+09	xlog	1320	0	0	3	6.4520001	1.728	8.2069998
1	2011-08-16 22:23:57.206+09	xlog	1385	0	0	3	9.2620001	0.81	10.098
1	2011-08-16 22:24:26.673+09	xlog	1172	0	0	3	8.2559996	2.3399999	10.62
1	2011-08-16 22:25:00.82+09	xlog	1127	0	0	3	8.882	0.242	9.1450005
1	2011-08-16 22:25:29.682+09	xlog	1121	0	0	3	8.665	2.349	11.032
1	2011-08-16 22:26:03.835+09	xlog	1230	0	0	3	6.2480001	2.4460001	8.71
1	2011-08-16 22:26:33.83+09	xlog	1203	0	0	3	9.2620001	2.0190001	11.296
1	2011-08-16 22:27:07.377+09	xlog	1238	0	0	3	6.4489999	2.714	9.1870003
1	2011-08-16 22:27:38.68+09	xlog	1273	0	0	3	9.2650003	2.533	11.816
1	2011-08-16 22:28:13.635+09	xlog	1183	0	0	3	6.697	0.72399998	7.4439998
1	2011-08-16 22:28:44.232+09	xlog	1258	0	0	3	9.6630001	1.1670001	10.847
1	2011-08-16 22:29:16.821+09	xlog	1170	0	0	3	5.6479998	2.7639999	8.4329996
1	2011-08-16 22:29:48.024+09	xlog	1219	0	0	3	8.8620005	1.961	10.843
1	2011-08-16 22:30:17.542+09	xlog	1213	0	0	3	8.6599998	2.895	11.57
1	2011-08-16 22:30:51.572+09	xlog	1204	0	0	3	5.6469998	2.2880001	7.954
1	2011-08-16 22:31:20.353+09	xlog	1221	0	0	3	8.658	3.8110001	12.487
1	2011-08-16 22:31:52.714+09	xlog	1128	0	0	3	5.2449999	2.3940001	7.6609998
1	2011-08-16 22:32:24.091+09	xlog	1346	0	0	3	9.2690001	1.671	10.958
1	2011-08-16 22:32:58.078+09	xlog	1417	0	0	3	6.2550001	2.674	8.9510002
1	2011-08-16 22:33:27.657+09	xlog	1201	0	0	3	5.4450002	2.5150001	7.9790001
1	2011-08-16 22:33:57.221+09	xlog	1221	0	0	3	8.658	2.5469999	11.223
1	2011-08-16 22:34:31.42+09	xlog	1171	0	0	3	5.842	2.411	8.276
1	2011-08-16 22:35:01.974+09	xlog	1187	0	0	3	8.8629999	3.1619999	12.039
1	2011-08-16 22:35:36.695+09	xlog	1237	0	0	3	6.6459999	2.6659999	9.3290005
1	2011-08-16 22:36:07.24+09	xlog	1164	0	0	3	8.8599997	2.483	11.358
1	2011-08-16 22:36:41.72+09	xlog	1214	0	0	3	6.2509999	1.8099999	8.0799999
1	2011-08-16 22:37:12.489+09	xlog	1187	0	0	3	8.8599997	2.2420001	11.129
1	2011-08-16 22:37:45.235+09	xlog	1162	0	0	3	5.6420002	2.552	8.2150002
1	2011-08-16 22:38:16.56+09	xlog	1259	0	0	3	9.0609999	2.424	11.505
1	2011-08-16 22:38:50.189+09	xlog	1160	0	0	3	5.6469998	2.5439999	8.2080002
1	2011-08-16 22:39:20.945+09	xlog	1201	0	0	3	8.8620005	2.5190001	11.407
1	2011-08-16 22:39:54.843+09	xlog	1143	0	0	3	5.6490002	2.4849999	8.1780005
1	2011-08-16 22:40:26.323+09	xlog	1334	0	0	3	9.8660002	2.7679999	12.649
1	2011-08-16 22:40:59.785+09	xlog	1192	0	0	3	5.8499999	2.299	8.1689997
1	2011-08-16 22:41:31.837+09	xlog	1314	0	0	3	8.8599997	1.694	10.572
1	2011-08-16 22:42:06.162+09	xlog	1313	0	0	3	7.4569998	0.62599999	8.2119999
1	2011-08-16 22:42:36.937+09	xlog	1191	0	0	3	9.8649998	1.1799999	11.061
1	2011-08-16 22:43:10.912+09	xlog	1183	0	0	3	6.4530001	1.301	7.8340001
1	2011-08-16 22:43:41.33+09	xlog	1298	0	0	3	9.2790003	0.78600001	10.092
1	2011-08-16 22:44:10.927+09	xlog	1193	0	0	3	9.3120003	1.6109999	10.945
1	2011-08-16 22:44:44.395+09	xlog	1185	0	0	3	5.8439999	2.5109999	8.3710003
1	2011-08-16 22:45:14.119+09	xlog	1103	0	0	3	8.2600002	3.8540001	12.137
1	2011-08-16 22:45:47.744+09	xlog	1177	0	0	3	5.8470001	2.4230001	8.2860003
1	2011-08-16 22:46:18.725+09	xlog	1238	0	0	3	9.0930004	2.4649999	11.573
1	2011-08-16 22:46:52.166+09	xlog	1183	0	0	3	5.8460002	2.4360001	8.3030005
1	2011-08-16 22:47:22.73+09	xlog	1267	0	0	3	9.2609997	2.342	11.624
1	2011-08-16 22:47:52.623+09	xlog	1177	0	0	3	8.4700003	2.418	10.904
1	2011-08-16 22:48:27.407+09	xlog	1244	0	0	3	9.4619999	1.615	11.095
1	2011-08-16 22:48:57.673+09	xlog	1194	0	0	3	8.4580002	2.7950001	11.268
1	2011-08-16 22:49:31.655+09	xlog	1150	0	0	3	8.4589996	2.036	10.513
1	2011-08-16 22:50:02.553+09	xlog	1177	0	0	3	9.2670002	1.362	10.649
1	2011-08-16 22:50:36.449+09	xlog	1330	0	0	3	9.4659996	0.35699999	9.8389997
1	2011-08-16 22:51:06.002+09	xlog	1309	0	0	3	8.8669996	3.017	11.902
1	2011-08-16 22:51:39.624+09	xlog	1182	0	0	3	5.8470001	2.48	8.3459997
1	2011-08-16 22:52:09.867+09	xlog	1224	0	0	3	8.8599997	3.0969999	11.972
1	2011-08-16 22:52:43.012+09	xlog	1119	0	0	3	5.4460001	2.4679999	7.9330001
1	2011-08-16 22:53:14.165+09	xlog	1208	0	0	3	8.8610001	2.608	11.493
1	2011-08-16 22:53:41.717+09	xlog	1169	0	0	3	7.256	2.7650001	10.036
1	2011-08-16 22:54:13.562+09	xlog	1140	0	0	3	5.6430001	2.24	7.9000001
1	2011-08-16 22:54:44.804+09	xlog	1167	0	0	3	8.46	2.2839999	10.76
1	2011-08-16 22:55:18.646+09	xlog	1176	0	0	3	5.8460002	2.365	8.2279997
1	2011-08-16 22:55:49.757+09	xlog	1247	0	0	3	8.8610001	3.6800001	12.559
1	2011-08-16 22:56:23.609+09	xlog	1151	0	0	3	5.6459999	2.3380001	8.0050001
1	2011-08-16 22:56:54.543+09	xlog	1198	0	0	3	8.8620005	1.923	10.806
1	2011-08-16 22:57:24.958+09	xlog	1198	0	0	3	8.6590004	3.0309999	11.704
1	2011-08-16 22:57:59.126+09	xlog	1211	0	0	3	9.0629997	2.5209999	11.599
1	2011-08-16 22:58:29.243+09	xlog	1039	0	0	3	8.0559998	2.382	10.461
1	2011-08-16 22:59:04.287+09	xlog	1198	0	0	3	9.2629995	0.20100001	9.4849997
1	2011-08-16 22:59:34.005+09	xlog	1268	0	0	3	9.0620003	1.544	10.648
1	2011-08-16 23:00:08.198+09	xlog	1291	0	0	3	9.868	0.198	10.087
1	2011-08-16 23:00:38.518+09	xlog	1092	0	0	3	8.2589998	2.132	10.418
1	2011-08-16 23:01:13.262+09	xlog	1259	0	0	3	10.084	0.68199998	10.787
1	2011-08-16 23:01:43.805+09	xlog	1143	0	0	3	9.2620001	0.87099999	10.15
1	2011-08-16 23:02:16.906+09	xlog	1245	0	0	3	6.25	2.7590001	9.0240002
1	2011-08-16 23:02:46.612+09	xlog	1305	0	0	3	8.8590002	2.4230001	11.301
1	2011-08-16 23:03:20.111+09	xlog	1143	0	0	3	5.4510002	3.997	9.4639997
1	2011-08-16 23:03:51.069+09	xlog	1220	0	0	3	8.6590004	2.2679999	10.942
1	2011-08-16 23:04:21.596+09	xlog	1174	0	0	3	8.4639997	3.2679999	11.749
1	2011-08-16 23:04:54.679+09	xlog	1165	0	0	3	5.6479998	2.4030001	8.066
1	2011-08-16 23:05:23.809+09	xlog	1222	0	0	3	8.6590004	2.372	11.047
1	2011-08-16 23:05:57.764+09	xlog	1202	0	0	3	5.8410001	2.2249999	8.0889997
1	2011-08-16 23:06:28.365+09	xlog	1270	0	0	3	8.8590002	2.6370001	11.52
1	2011-08-16 23:07:02.896+09	xlog	1110	0	0	3	5.4450002	2.8150001	8.2749996
1	2011-08-16 23:07:34.204+09	xlog	1111	0	0	3	8.2589998	2.135	10.41
1	2011-08-16 23:08:08.984+09	xlog	1275	0	0	3	7.2979999	0.65200001	7.9710002
1	2011-08-16 23:08:40.485+09	xlog	1404	0	0	3	9.467	1.298	10.782
1	2011-08-16 23:09:14.423+09	xlog	1274	0	0	3	6.2519999	2.1659999	8.4350004
1	2011-08-16 23:09:44.647+09	xlog	1206	0	0	3	8.8579998	2.8340001	11.707
1	2011-08-16 23:10:17.707+09	xlog	1200	0	0	3	5.8449998	2.3800001	8.2419996
1	2011-08-16 23:10:48.81+09	xlog	1215	0	0	3	8.4589996	2.3659999	10.848
1	2011-08-16 23:11:23.252+09	xlog	1243	0	0	3	6.2449999	2.677	8.941
1	2011-08-16 23:11:55.215+09	xlog	1293	0	0	3	9.2629995	2.438	11.72
1	2011-08-16 23:12:29.476+09	xlog	1276	0	0	3	6.2449999	2.4230001	8.6829996
1	2011-08-16 23:12:58.692+09	xlog	1287	0	0	3	9.2620001	0.77899998	10.064
1	2011-08-16 23:13:31.667+09	xlog	1072	0	0	3	5.888	1.272	7.1760001
1	2011-08-16 23:14:01.917+09	xlog	1172	0	0	3	9.0629997	2.3269999	11.405
1	2011-08-16 23:14:36.952+09	xlog	1090	0	0	3	6.7160001	0.69	7.4229999
1	2011-08-16 23:15:07.844+09	xlog	1216	0	0	3	9.2919998	0.25999999	9.5699997
1	2011-08-16 23:15:36.688+09	xlog	1187	0	0	3	9.0629997	2.9760001	12.059
1	2011-08-16 23:16:10.134+09	xlog	1250	0	0	3	6.0440001	2.4070001	8.4860001
1	2011-08-16 23:16:40.12+09	xlog	1285	0	0	3	8.8620005	2.3789999	11.264
1	2011-08-16 23:17:14.977+09	xlog	1242	0	0	3	6.0469999	2.066	8.1300001
1	2011-08-16 23:17:46.391+09	xlog	1383	0	0	3	8.8690004	1.668	10.563
1	2011-08-16 23:18:20.352+09	xlog	1298	0	0	3	6.691	1.4170001	8.1230001
1	2011-08-16 23:18:50.138+09	xlog	1280	0	0	3	9.0600004	2.0369999	11.118
1	2011-08-16 23:19:24.002+09	xlog	1152	0	0	3	5.862	3.007	8.8830004
1	2011-08-16 23:19:54.635+09	xlog	1220	0	0	3	8.658	2.575	11.251
1	2011-08-16 23:20:29.049+09	xlog	1166	0	0	3	6.244	1.6390001	7.9050002
1	2011-08-16 23:20:59.019+09	xlog	1248	0	0	3	8.8610001	2.2809999	11.166
1	2011-08-16 23:21:29.695+09	xlog	1126	0	0	3	8.4569998	2.8280001	11.303
1	2011-08-16 23:22:02.528+09	xlog	1214	0	0	3	6.0440001	2.5320001	8.599
1	2011-08-16 23:22:32.169+09	xlog	1190	0	0	3	8.6599998	3.437	12.112
1	2011-08-16 23:23:05.493+09	xlog	1155	0	0	3	6.448	2.3610001	8.8299999
1	2011-08-16 23:23:37.619+09	xlog	1148	0	0	3	8.6639996	2.3970001	11.078
1	2011-08-16 23:24:12.111+09	xlog	1167	0	0	3	5.8439999	2.8150001	8.6820002
1	2011-08-16 23:24:42.663+09	xlog	1231	0	0	3	8.6599998	2.289	10.967
1	2011-08-16 23:25:16.871+09	xlog	1241	0	0	3	6.8670001	1.1720001	8.0550003
1	2011-08-16 23:25:47.173+09	xlog	1263	0	0	3	8.8610001	2.4779999	11.353
1	2011-08-16 23:26:21.856+09	xlog	1279	0	0	3	7.277	0.76200002	8.0679998
1	2011-08-16 23:26:53.365+09	xlog	1334	0	0	3	8.8699999	1.753	10.642
1	2011-08-16 23:27:26.909+09	xlog	1267	0	0	3	6.684	1.182	7.8850002
1	2011-08-16 23:27:56.977+09	xlog	1235	0	0	3	9.0719995	2.0250001	11.12
1	2011-08-16 23:28:30.771+09	xlog	1193	0	0	3	6.4619999	2.0639999	8.5489998
1	2011-08-16 23:29:01.253+09	xlog	1233	0	0	3	8.8599997	2.293	11.171
1	2011-08-16 23:29:35.617+09	xlog	1057	0	0	3	6.256	1.6210001	7.9039998
1	2011-08-16 23:30:05.924+09	xlog	1143	0	0	3	8.6610003	2.392	11.073
1	2011-08-16 23:30:40.219+09	xlog	1096	0	0	3	6.882	0.74400002	7.6440001
1	2011-08-16 23:31:11.399+09	xlog	1219	0	0	3	9.2620001	0.31600001	9.6040001
1	2011-08-16 23:31:41.528+09	xlog	1236	0	0	3	8.8570004	3.046	11.921
1	2011-08-16 23:32:14.315+09	xlog	1219	0	0	3	5.652	2.2360001	7.9060001
1	2011-08-16 23:32:44.306+09	xlog	1187	0	0	3	8.4580002	3.6389999	12.115
1	2011-08-16 23:33:17.532+09	xlog	1170	0	0	3	5.6469998	2.48	8.1420002
1	2011-08-16 23:33:48.65+09	xlog	1240	0	0	3	9.2600002	2.3199999	11.598
1	2011-08-16 23:34:21.924+09	xlog	1134	0	0	3	5.6479998	2.4779999	8.1409998
1	2011-08-16 23:34:53.511+09	xlog	1185	0	0	3	8.4650002	2.4820001	10.962
1	2011-08-16 23:35:28.189+09	xlog	1288	0	0	3	6.2490001	1.577	7.8509998
1	2011-08-16 23:35:59.863+09	xlog	1369	0	0	3	9.4720001	1.2869999	10.781
1	2011-08-16 23:36:33.469+09	xlog	1154	0	0	3	5.4450002	2.256	7.7350001
1	2011-08-16 23:37:04.26+09	xlog	1168	0	0	3	8.8599997	0.99000001	9.8660002
1	2011-08-16 23:37:37.572+09	xlog	1146	0	0	3	7.0679998	1.048	8.1350002
1	2011-08-16 23:38:08.171+09	xlog	1245	0	0	3	9.2770004	0.69800001	9.9989996
1	2011-08-16 23:38:37.825+09	xlog	1163	0	0	3	9.3149996	1.7130001	11.044
1	2011-08-16 23:39:11.11+09	xlog	1200	0	0	3	6.0489998	2.3770001	8.4429998
1	2011-08-16 23:39:40.261+09	xlog	1180	0	0	3	8.8610001	3.5969999	12.508
1	2011-08-16 23:40:14.595+09	xlog	1172	0	0	3	5.652	2.4430001	8.1120005
1	2011-08-16 23:40:45.918+09	xlog	1094	0	0	3	8.2600002	2.5510001	10.834
1	2011-08-16 23:41:19.587+09	xlog	1191	0	0	3	6.448	2.447	8.9119997
1	2011-08-16 23:41:50.593+09	xlog	1214	0	0	3	9.4630003	1.166	10.645
1	2011-08-16 23:42:23.791+09	xlog	1140	0	0	3	5.645	2.688	8.3529997
1	2011-08-16 23:42:55.49+09	xlog	1190	0	0	3	9.4639997	1.428	10.92
1	2011-08-16 23:43:28.813+09	xlog	1163	0	0	3	5.848	2.533	8.3979998
1	2011-08-16 23:43:59.817+09	xlog	1281	0	0	3	9.6669998	0.99699998	10.682
1	2011-08-16 23:44:34.003+09	xlog	1240	0	0	3	6.0489998	1.851	7.9569998
1	2011-08-16 23:45:05.606+09	xlog	1293	0	0	3	8.8629999	0.89399999	9.7910004
1	2011-08-16 23:45:39.502+09	xlog	1309	0	0	3	11.673	0.60000002	12.299
1	2011-08-16 23:46:12.842+09	xlog	1269	0	0	3	9.2629995	1.5650001	10.909
1	2011-08-16 23:46:47.486+09	xlog	1140	0	0	3	8.6590004	1.466	10.141
1	2011-08-16 23:47:21.962+09	xlog	1211	0	0	3	6.25	1.554	7.822
1	2011-08-16 23:47:54.673+09	xlog	1212	0	0	3	8.8610001	1.591	10.473
1	2011-08-16 23:48:29.122+09	xlog	1219	0	0	3	6.0489998	1.612	7.6789999
1	2011-08-16 23:49:01.232+09	xlog	1199	0	0	3	8.6639996	1.786	10.468
1	2011-08-16 23:49:35.486+09	xlog	1192	0	0	3	5.8439999	1.683	7.5419998
1	2011-08-16 23:50:06.65+09	xlog	1115	0	0	3	8.2639999	1.597	9.8789997
1	2011-08-16 23:50:40.023+09	xlog	1284	0	0	3	6.6479998	1.571	8.2329998
1	2011-08-16 23:51:10.819+09	xlog	1168	0	0	3	8.6680002	2.043	10.735
1	2011-08-16 23:51:44.447+09	xlog	1203	0	0	3	6.2480001	1.563	7.8429999
1	2011-08-16 23:52:16.182+09	xlog	1168	0	0	3	8.4610004	1.679	10.164
1	2011-08-16 23:52:49.445+09	xlog	1200	0	0	3	5.8429999	1.642	7.5029998
1	2011-08-16 23:53:21.403+09	xlog	1250	0	0	3	8.8739996	1.715	10.617
1	2011-08-16 23:53:55.602+09	xlog	1408	0	0	3	6.257	1.837	8.1110001
1	2011-08-16 23:54:27.156+09	xlog	1192	0	0	3	8.4589996	1.7029999	10.184
1	2011-08-16 23:55:01.218+09	xlog	1245	0	0	3	6.4510002	1.723	8.1949997
1	2011-08-16 23:55:32.598+09	xlog	1183	0	0	3	8.6590004	1.798	10.473
1	2011-08-16 23:56:06.073+09	xlog	1162	0	0	3	5.8460002	1.615	7.4840002
1	2011-08-16 23:56:37.394+09	xlog	1076	0	0	3	8.4619999	1.806	10.289
1	2011-08-16 23:57:10.984+09	xlog	1233	0	0	3	6.0450001	1.66	7.7449999
1	2011-08-16 23:57:41.595+09	xlog	1151	0	0	3	8.658	1.577	10.252
1	2011-08-16 23:58:14.913+09	xlog	1178	0	0	3	5.8499999	1.546	7.415
1	2011-08-16 23:58:46.453+09	xlog	1199	0	0	3	9.0690002	1.6849999	10.773
1	2011-08-16 23:59:21.262+09	xlog	1260	0	0	3	6.2449999	1.765	8.0279999
1	2011-08-16 23:59:52.854+09	xlog	1124	0	0	3	8.6569996	1.829	10.503
1	2011-08-17 00:00:26.852+09	xlog	1178	0	0	3	5.4439998	1.735	7.198
1	2011-08-17 00:00:57.418+09	xlog	1156	0	0	3	8.4610004	1.806	10.291
1	2011-08-17 00:01:31.169+09	xlog	1244	0	0	3	5.8449998	1.6	7.4619999
1	2011-08-17 00:02:02.391+09	xlog	1215	0	0	3	8.6599998	1.663	10.344
1	2011-08-17 00:02:37.263+09	xlog	1237	0	0	3	9.2580004	1.938	11.219
1	2011-08-17 00:03:12.589+09	xlog	1314	0	0	3	5.8509998	2.207	8.0749998
1	2011-08-17 00:03:43.907+09	xlog	1258	0	0	3	9.2670002	1.975	11.259
1	2011-08-17 00:04:18.383+09	xlog	1176	0	0	3	5.8520002	2.1159999	7.9889998
1	2011-08-17 00:04:50.068+09	xlog	1269	0	0	3	8.6590004	1.974	10.657
1	2011-08-17 00:05:23.722+09	xlog	1176	0	0	3	5.6469998	2.0550001	7.7179999
1	2011-08-17 00:05:54.781+09	xlog	1245	0	0	3	9.059	2.2119999	11.294
1	2011-08-17 00:06:28.91+09	xlog	1139	0	0	3	5.8460002	2.224	8.085
1	2011-08-17 00:07:00.325+09	xlog	1206	0	0	3	8.8570004	1.952	10.826
1	2011-08-17 00:07:34.053+09	xlog	1141	0	0	3	5.6430001	2.1949999	7.8559999
1	2011-08-17 00:08:05.98+09	xlog	1181	0	0	3	8.8699999	2.2509999	11.136
1	2011-08-17 00:08:40.314+09	xlog	1236	0	0	3	6.2459998	2.4130001	8.6759996
1	2011-08-17 00:09:10.534+09	xlog	1175	0	0	3	9.059	2.5510001	11.624
1	2011-08-17 00:09:44.96+09	xlog	1202	0	0	3	6.2470002	2.3740001	8.6350002
1	2011-08-17 00:10:15.351+09	xlog	1215	0	0	3	8.6569996	2.3710001	11.044
1	2011-08-17 00:10:49.219+09	xlog	1159	0	0	3	5.8460002	2.283	8.1520004
1	2011-08-17 00:11:20.424+09	xlog	1281	0	0	3	9.4630003	2.1470001	11.628
1	2011-08-17 00:11:56.091+09	xlog	1408	0	0	3	7.0539999	1.983	9.0559998
1	2011-08-17 00:12:26.759+09	xlog	1189	0	0	3	8.46	2.2869999	10.766
1	2011-08-17 00:13:02.018+09	xlog	1254	0	0	3	6.6469998	2.418	9.0810003
1	2011-08-17 00:13:31.033+09	xlog	1224	0	0	3	8.8559999	2.589	11.461
1	2011-08-17 00:14:05.176+09	xlog	1162	0	0	3	5.8449998	2.497	8.3610001
1	2011-08-17 00:14:36.888+09	xlog	1153	0	0	3	9.2589998	0.69400001	9.9709997
1	2011-08-17 00:15:10.351+09	xlog	1209	0	0	3	6.0469999	3.0090001	9.0799999
1	2011-08-17 00:15:40.094+09	xlog	1265	0	0	3	9.2580004	2.4419999	11.724
1	2011-08-17 00:16:14.918+09	xlog	1208	0	0	3	6.263	2.221	8.4989996
1	2011-08-17 00:16:45.24+09	xlog	1242	0	0	3	8.8599997	2.26	11.138
1	2011-08-17 00:17:18.952+09	xlog	1132	0	0	3	5.954	2.5369999	8.5100002
1	2011-08-17 00:17:48.638+09	xlog	1184	0	0	3	5.651	2.4719999	8.1400003
1	2011-08-17 00:18:17.61+09	xlog	1212	0	0	3	8.8570004	2.369	11.252
1	2011-08-17 00:18:52.241+09	xlog	1194	0	0	3	6.0479999	2.273	8.3369999
1	2011-08-17 00:19:22.539+09	xlog	1257	0	0	3	8.8590002	2.717	11.597
1	2011-08-17 00:19:56.878+09	xlog	1177	0	0	3	6.257	2.5039999	8.783
1	2011-08-17 00:20:29.061+09	xlog	1260	0	0	3	9.2620001	1.9579999	11.233
1	2011-08-17 00:21:04.215+09	xlog	1376	0	0	3	9.7150002	0.52600002	10.256
1	2011-08-17 00:21:34.42+09	xlog	1099	0	0	3	7.855	2.4260001	10.304
1	2011-08-17 00:22:08.457+09	xlog	1198	0	0	3	7.4569998	0.69300002	8.1789999
1	2011-08-17 00:22:38.021+09	xlog	1140	0	0	3	9.0570002	1.891	10.965
1	2011-08-17 00:23:10.76+09	xlog	1068	0	0	3	5.4419999	2.9130001	8.3710003
1	2011-08-17 00:23:45.143+09	xlog	1322	0	0	3	9.9200001	1.1	11.042
1	2011-08-17 00:24:19.542+09	xlog	1241	0	0	3	9.066	2.48	11.57
1	2011-08-17 00:24:50.991+09	xlog	1220	0	0	3	8.8780003	1.373	10.268
1	2011-08-17 00:25:24.69+09	xlog	1230	0	0	3	10.064	0.991	11.074
1	2011-08-17 00:25:59.602+09	xlog	1124	0	0	3	6.651	1.1799999	7.8979998
1	2011-08-17 00:26:30.707+09	xlog	1210	0	0	3	9.6929998	0.86900002	10.586
1	2011-08-17 00:27:00.739+09	xlog	1189	0	0	3	9.54	0.542	10.097
1	2011-08-17 00:27:33.965+09	xlog	1248	0	0	3	6.046	2.892	8.9560003
1	2011-08-17 00:28:03.115+09	xlog	1201	0	0	3	8.8590002	2.552	11.432
1	2011-08-17 00:28:37.20+09	xlog	1161	0	0	3	6.0430002	2.812	8.8710003
1	2011-08-17 00:29:07.207+09	xlog	1180	0	0	3	8.8610001	2.122	11.004
1	2011-08-17 00:29:42.258+09	xlog	1269	0	0	3	6.4499998	1.635	8.1009998
1	2011-08-17 00:30:14.653+09	xlog	1333	0	0	3	9.0629997	1.1720001	10.25
1	2011-08-17 00:30:48.619+09	xlog	1206	0	0	3	7.053	0.94	8.007
1	2011-08-17 00:31:18.878+09	xlog	1170	0	0	3	8.6669998	0.86000001	9.5459995
1	2011-08-17 00:31:51.407+09	xlog	1162	0	0	3	5.868	3.0910001	8.974
1	2011-08-17 00:32:21.685+09	xlog	1263	0	0	3	9.0600004	2.5320001	11.615
1	2011-08-17 00:32:56.492+09	xlog	1135	0	0	3	6.302	1.59	7.9190001
1	2011-08-17 00:33:26.653+09	xlog	1201	0	0	3	8.6630001	2.1800001	10.864
1	2011-08-17 00:33:57.395+09	xlog	1196	0	0	3	9.0760002	2.642	11.742
1	2011-08-17 00:34:30.625+09	xlog	1198	0	0	3	6.0479999	2.3729999	8.4350004
1	2011-08-17 00:34:59.978+09	xlog	1198	0	0	3	8.8629999	2.4389999	11.317
1	2011-08-17 00:35:34.168+09	xlog	1224	0	0	3	5.849	2.3940001	8.2700005
1	2011-08-17 00:36:04.735+09	xlog	1195	0	0	3	8.658	2.427	11.109
1	2011-08-17 00:36:38.926+09	xlog	1123	0	0	3	6.0419998	2.3199999	8.3780003
1	2011-08-17 00:37:09.911+09	xlog	1196	0	0	3	8.8579998	2.5539999	11.43
1	2011-08-17 00:37:43.781+09	xlog	1171	0	0	3	6.0419998	2.4949999	8.5620003
1	2011-08-17 00:38:15.303+09	xlog	1285	0	0	3	9.0620003	2.2539999	11.34
1	2011-08-17 00:38:50.421+09	xlog	1387	0	0	3	6.8709998	1.08	8.0430002
1	2011-08-17 00:39:20.479+09	xlog	1281	0	0	3	9.7019997	1.24	10.959
1	2011-08-17 00:39:53.899+09	xlog	1168	0	0	3	5.6490002	2.927	8.5939999
1	2011-08-17 00:40:24.891+09	xlog	1277	0	0	3	9.2670002	2.457	11.738
1	2011-08-17 00:40:59.357+09	xlog	1148	0	0	3	6.7090001	0.88700002	7.6110001
1	2011-08-17 00:41:29.885+09	xlog	1286	0	0	3	9.8610001	0.35600001	10.24
1	2011-08-17 00:42:03.464+09	xlog	1128	0	0	3	5.8449998	3.3540001	9.2229996
1	2011-08-17 00:42:34.12+09	xlog	1235	0	0	3	8.8590002	2.336	11.214
1	2011-08-17 00:43:08.59+09	xlog	1100	0	0	3	5.855	2.517	8.3929996
1	2011-08-17 00:43:38.115+09	xlog	1124	0	0	3	5.243	2.507	7.7670002
1	2011-08-17 00:44:07.425+09	xlog	1190	0	0	3	8.2580004	2.424	10.705
1	2011-08-17 00:44:41.432+09	xlog	1222	0	0	3	6.244	2.332	8.592
1	2011-08-17 00:45:12.325+09	xlog	1187	0	0	3	8.4659996	2.52	11.01
1	2011-08-17 00:45:46.523+09	xlog	1181	0	0	3	5.848	2.6600001	8.5310001
1	2011-08-17 00:46:16.058+09	xlog	1290	0	0	3	9.0579996	2.2869999	11.361
1	2011-08-17 00:46:49.931+09	xlog	1120	0	0	3	5.8460002	3.1159999	8.9809999
1	2011-08-17 00:47:20.605+09	xlog	1267	0	0	3	9.0620003	1.873	10.95
1	2011-08-17 00:47:55.056+09	xlog	1296	0	0	3	6.0469999	1.3279999	7.3920002
1	2011-08-17 00:48:25.082+09	xlog	1274	0	0	3	9.1300001	0.105	9.2600002
1	2011-08-17 00:48:55.198+09	xlog	1173	0	0	3	8.8610001	2.448	11.325
1	2011-08-17 00:49:29.182+09	xlog	1265	0	0	3	6.2470002	2.4030001	8.6639996
1	2011-08-17 00:49:58.267+09	xlog	1212	0	0	3	8.8610001	3.4130001	12.288
1	2011-08-17 00:50:31.717+09	xlog	1194	0	0	3	5.6469998	2.428	8.0909996
1	2011-08-17 00:51:02.618+09	xlog	1288	0	0	3	9.6619997	2.066	11.748
1	2011-08-17 00:51:35.692+09	xlog	1151	0	0	3	5.6420002	2.326	7.9819999
1	2011-08-17 00:52:06.916+09	xlog	1185	0	0	3	9.2600002	2.3529999	11.637
1	2011-08-17 00:52:41.308+09	xlog	1063	0	0	3	5.6409998	2.378	8.0389996
1	2011-08-17 00:53:12.546+09	xlog	1244	0	0	3	9.665	0.44400001	10.128
1	2011-08-17 00:53:42.344+09	xlog	1188	0	0	3	8.8559999	3.9070001	12.789
1	2011-08-17 00:54:15.204+09	xlog	1182	0	0	3	5.6490002	2.4349999	8.099
1	2011-08-17 00:54:45.07+09	xlog	1157	0	0	3	8.4639997	2.572	11.058
1	2011-08-17 00:55:19.543+09	xlog	1182	0	0	3	5.8449998	2.4000001	8.2639999
1	2011-08-17 00:55:50.065+09	xlog	1106	0	0	3	8.2580004	2.5999999	10.875
1	2011-08-17 00:56:24.933+09	xlog	1287	0	0	3	6.4460001	1.979	8.4630003
1	2011-08-17 00:56:56.678+09	xlog	1387	0	0	3	9.0670004	1.983	11.066
1	2011-08-17 00:57:30.704+09	xlog	1238	0	0	3	5.6459999	2.4130001	8.0760002
1	2011-08-17 00:58:00.683+09	xlog	1147	0	0	3	8.4680004	2.4560001	10.944
1	2011-08-17 00:58:34.524+09	xlog	1238	0	0	3	6.0469999	2.359	8.4329996
1	2011-08-17 00:59:05.54+09	xlog	1203	0	0	3	8.6619997	2.3929999	11.08
1	2011-08-17 00:59:39.407+09	xlog	1116	0	0	3	5.6399999	2.3759999	8.0579996
1	2011-08-17 01:00:10.146+09	xlog	1192	0	0	3	8.6630001	4.073	12.754
1	2011-08-17 01:00:42.954+09	xlog	1067	0	0	3	5.4439998	2.457	7.9190001
1	2011-08-17 01:01:13.772+09	xlog	1203	0	0	3	8.6639996	3.6989999	12.384
1	2011-08-17 01:01:43.719+09	xlog	1174	0	0	3	8.8620005	2.2850001	11.163
1	2011-08-17 01:02:17.406+09	xlog	1185	0	0	3	5.842	2.493	8.3529997
1	2011-08-17 01:02:46.306+09	xlog	1202	0	0	3	8.6660004	2.2520001	10.94
1	2011-08-17 01:03:20.23+09	xlog	1174	0	0	3	5.8460002	2.237	8.0979996
1	2011-08-17 01:03:52.013+09	xlog	1161	0	0	3	8.6630001	2.954	11.634
1	2011-08-17 01:04:26.471+09	xlog	1257	0	0	3	6.2470002	2.3640001	8.6260004
1	2011-08-17 01:04:57.651+09	xlog	1270	0	0	3	10.073	1.155	11.242
1	2011-08-17 01:05:31.85+09	xlog	1275	0	0	3	10.671	0.391	11.084
1	2011-08-17 01:06:02.733+09	xlog	1354	0	0	3	8.8620005	3.6919999	12.569
1	2011-08-17 01:06:36.56+09	xlog	1178	0	0	3	5.8460002	2.5	8.3640003
1	2011-08-17 01:07:06.757+09	xlog	1179	0	0	3	8.8559999	2.493	11.365
1	2011-08-17 01:07:40.80+09	xlog	1125	0	0	3	6.2680001	1.801	8.0869999
1	2011-08-17 01:08:10.502+09	xlog	1215	0	0	3	8.8590002	2.3269999	11.203
1	2011-08-17 01:08:44.725+09	xlog	1127	0	0	3	6.8730001	1.293	8.1809998
1	2011-08-17 01:09:14.887+09	xlog	1197	0	0	3	8.6549997	2.4260001	11.1
1	2011-08-17 01:09:45.886+09	xlog	1217	0	0	3	9.0609999	1.73	10.805
1	2011-08-17 01:10:18.744+09	xlog	1205	0	0	3	5.8449998	2.5650001	8.4250002
1	2011-08-17 01:10:47.685+09	xlog	1197	0	0	3	8.4580002	4.5419998	13.016
1	2011-08-17 01:11:21.325+09	xlog	1160	0	0	3	5.8449998	2.4100001	8.2790003
1	2011-08-17 01:11:52.729+09	xlog	1221	0	0	3	9.6809998	2.2349999	11.937
1	2011-08-17 01:12:26.377+09	xlog	1176	0	0	3	5.8499999	2.52	8.6459999
1	2011-08-17 01:12:57.519+09	xlog	1225	0	0	3	9.4639997	1.956	11.434
1	2011-08-17 01:13:30.973+09	xlog	1132	0	0	3	5.6459999	2.6500001	8.3140001
1	2011-08-17 01:14:02.734+09	xlog	1196	0	0	3	9.0620003	2.1760001	11.266
1	2011-08-17 01:14:38.237+09	xlog	1291	0	0	3	6.4520001	1.925	8.4989996
1	2011-08-17 01:15:09.505+09	xlog	1289	0	0	3	9.2919998	1.023	10.335
1	2011-08-17 01:15:42.903+09	xlog	1173	0	0	3	6.0440001	2.2679999	8.3319998
1	2011-08-17 01:16:13.833+09	xlog	1219	0	0	3	9.0600004	0.90399998	9.9790001
1	2011-08-17 01:16:47.108+09	xlog	1138	0	0	3	6.848	0.93099999	7.7940001
1	2011-08-17 01:17:18.319+09	xlog	1202	0	0	3	8.6960001	0.58399999	9.3039999
1	2011-08-17 01:17:47.829+09	xlog	1181	0	0	3	9.0609999	1.646	10.728
1	2011-08-17 01:18:20.986+09	xlog	1178	0	0	3	5.8460002	2.618	8.4799995
1	2011-08-17 01:18:50.496+09	xlog	1151	0	0	3	8.2589998	2.362	10.648
1	2011-08-17 01:19:24.291+09	xlog	1188	0	0	3	5.645	2.437	8.0970001
1	2011-08-17 01:19:55.744+09	xlog	1205	0	0	3	8.8629999	2.9330001	11.814
1	2011-08-17 01:20:29.604+09	xlog	1222	0	0	3	6.4489999	2.3469999	8.8129997
1	2011-08-17 01:21:00.987+09	xlog	1139	0	0	3	9.2629995	1.4400001	10.726
1	2011-08-17 01:21:34.877+09	xlog	1202	0	0	3	6.2449999	2.5480001	8.8109999
1	2011-08-17 01:22:05.233+09	xlog	1245	0	0	3	9.6990004	0.447	10.162
1	2011-08-17 01:22:38.473+09	xlog	1040	0	0	3	5.447	2.957	8.4180002
1	2011-08-17 01:23:09.79+09	xlog	1191	0	0	3	9.2600002	2.256	11.538
1	2011-08-17 01:23:45.555+09	xlog	1343	0	0	3	6.8509998	1.438	8.3050003
1	2011-08-17 01:24:15.40+09	xlog	1262	0	0	3	9.4630003	1.329	10.807
1	2011-08-17 01:24:48.575+09	xlog	1171	0	0	3	5.8460002	2.4519999	8.3140001
1	2011-08-17 01:25:19.381+09	xlog	1210	0	0	3	8.6590004	1.581	10.258
1	2011-08-17 01:25:48.816+09	xlog	1143	0	0	3	8.6599998	2.3659999	11.05
1	2011-08-17 01:26:23.387+09	xlog	1211	0	0	3	9.0609999	0.024	9.099
1	2011-08-17 01:26:52.147+09	xlog	1168	0	0	3	8.6599998	3.586	12.261
1	2011-08-17 01:27:25.948+09	xlog	1194	0	0	3	5.8429999	2.4200001	8.2889996
1	2011-08-17 01:27:57.357+09	xlog	1255	0	0	3	9.0629997	2.276	11.361
1	2011-08-17 01:28:30.038+09	xlog	1127	0	0	3	5.2449999	2.4170001	7.6869998
1	2011-08-17 01:29:00.861+09	xlog	1215	0	0	3	9.2600002	2.28	11.561
1	2011-08-17 01:29:31.105+09	xlog	1233	0	0	3	8.6630001	3.1029999	11.786
1	2011-08-17 01:30:04.982+09	xlog	1199	0	0	3	8.6599998	1.7029999	10.378
1	2011-08-17 01:30:35.21+09	xlog	1151	0	0	3	8.4569998	2.835	11.33
1	2011-08-17 01:31:10.334+09	xlog	1113	0	0	3	8.6599998	0.059	8.743
1	2011-08-17 01:31:39.185+09	xlog	1128	0	0	3	8.2589998	2.5810001	10.857
1	2011-08-17 01:32:14.114+09	xlog	1283	0	0	3	10.067	2.266	12.354
1	2011-08-17 01:32:50.313+09	xlog	1279	0	0	3	6.447	1.459	7.9320002
1	2011-08-17 01:33:21.556+09	xlog	1333	0	0	3	8.8620005	0.51999998	9.3979998
1	2011-08-17 01:33:50.89+09	xlog	1212	0	0	3	8.8620005	2.283	11.161
1	2011-08-17 01:34:25.724+09	xlog	1220	0	0	3	9.6639996	0.76700002	10.454
1	2011-08-17 01:34:56.203+09	xlog	1212	0	0	3	9.4639997	0.57200003	10.056
1	2011-08-17 01:35:29.10+09	xlog	1202	0	0	3	6.244	2.3840001	8.6450005
1	2011-08-17 01:35:58.796+09	xlog	1212	0	0	3	8.4580002	2.589	11.069
1	2011-08-17 01:36:32.86+09	xlog	1232	0	0	3	6.0440001	2.934	8.993
1	2011-08-17 01:37:02.778+09	xlog	1302	0	0	3	9.4639997	2.306	11.786
1	2011-08-17 01:37:36.771+09	xlog	1174	0	0	3	6.073	2.691	8.8339996
1	2011-08-17 01:38:06.445+09	xlog	1218	0	0	3	8.8610001	2.53	11.409
1	2011-08-17 01:38:41.089+09	xlog	1109	0	0	3	5.6719999	2.5899999	8.276
1	2011-08-17 01:39:11.037+09	xlog	1098	0	0	3	5.0479999	2.392	7.4569998
1	2011-08-17 01:39:40.599+09	xlog	1122	0	0	3	8.0570002	2.5020001	10.587
1	2011-08-17 01:40:14.351+09	xlog	1216	0	0	3	6.046	2.3629999	8.4280005
1	2011-08-17 01:40:44.429+09	xlog	1248	0	0	3	9.2580004	2.3670001	11.651
1	2011-08-17 01:41:19.443+09	xlog	1202	0	0	3	6.046	2.033	8.1009998
1	2011-08-17 01:41:51.757+09	xlog	1304	0	0	3	9.2670002	1.626	10.914
1	2011-08-17 01:42:26.048+09	xlog	1271	0	0	3	9.698	0.39899999	10.113
1	2011-08-17 01:42:55.872+09	xlog	1133	0	0	3	8.4619999	2.405	10.89
1	2011-08-17 01:43:28.58+09	xlog	1138	0	0	3	5.8429999	2.6700001	8.5310001
1	2011-08-17 01:43:59.564+09	xlog	1256	0	0	3	8.8620005	2.55	11.432
1	2011-08-17 01:44:33.597+09	xlog	1141	0	0	3	6.447	1.329	7.7989998
1	2011-08-17 01:45:04.18+09	xlog	1234	0	0	3	9.0640001	2.3210001	11.402
1	2011-08-17 01:45:38.648+09	xlog	1112	0	0	3	6.2740002	0.67500001	6.967
1	2011-08-17 01:46:09.151+09	xlog	1221	0	0	3	9.2609997	0.245	9.5290003
1	2011-08-17 01:46:38.948+09	xlog	1139	0	0	3	8.2600002	3.3280001	11.611
1	2011-08-17 01:47:12.836+09	xlog	1144	0	0	3	5.4419999	2.474	7.9310002
1	2011-08-17 01:47:41.985+09	xlog	1088	0	0	3	8.46	5.408	13.904
1	2011-08-17 01:48:16.01+09	xlog	1209	0	0	3	6.0419998	2.4230001	8.4799995
1	2011-08-17 01:48:47.009+09	xlog	1215	0	0	3	8.6590004	2.6010001	11.287
1	2011-08-17 01:49:21.838+09	xlog	1234	0	0	3	6.4489999	2.279	8.7469997
1	2011-08-17 01:49:54.289+09	xlog	1270	0	0	3	9.0649996	3.849	12.937
1	2011-08-17 01:50:28.184+09	xlog	1243	0	0	3	9.2650003	1.86	11.14
1	2011-08-17 01:51:03.281+09	xlog	1299	0	0	3	6.0500002	2.062	8.1420002
1	2011-08-17 01:51:33.786+09	xlog	1254	0	0	3	8.8660002	3.312	12.193
1	2011-08-17 01:52:04.455+09	xlog	1237	0	0	3	8.8649998	2.678	11.571
1	2011-08-17 01:52:38.944+09	xlog	1175	0	0	3	8.6599998	1.035	9.7180004
1	2011-08-17 01:53:08.095+09	xlog	1148	0	0	3	8.2629995	2.619	10.897
1	2011-08-17 01:53:42.307+09	xlog	1166	0	0	3	5.842	2.714	8.5780001
1	2011-08-17 01:54:11.349+09	xlog	1149	0	0	3	8.4589996	2.931	11.416
1	2011-08-17 01:54:45.641+09	xlog	1159	0	0	3	6.0419998	2.911	8.9820004
1	2011-08-17 01:55:16.18+09	xlog	1217	0	0	3	9.2589998	2.23	11.503
1	2011-08-17 01:55:50.105+09	xlog	1161	0	0	3	6.263	2.3540001	8.6350002
1	2011-08-17 01:56:20.188+09	xlog	1186	0	0	3	8.6619997	2.3800001	11.058
1	2011-08-17 01:56:54.388+09	xlog	1112	0	0	3	6.0580001	2.3299999	8.4069996
1	2011-08-17 01:57:24.473+09	xlog	1193	0	0	3	5.6469998	2.4189999	8.0810003
1	2011-08-17 01:57:53.412+09	xlog	1181	0	0	3	8.6639996	2.3789999	11.071
1	2011-08-17 01:58:28.532+09	xlog	1248	0	0	3	6.4489999	2.3469999	8.8149996
1	2011-08-17 01:58:58.603+09	xlog	1233	0	0	3	8.8570004	3.108	11.982
1	2011-08-17 01:59:33.093+09	xlog	1293	0	0	3	6.4510002	1.883	8.3590002
1	2011-08-17 02:00:05.473+09	xlog	1356	0	0	3	9.7080002	1.256	10.982
1	2011-08-17 02:00:39.725+09	xlog	1141	0	0	3	5.6440001	2.401	8.0740004
1	2011-08-17 02:01:09.449+09	xlog	1175	0	0	3	8.8629999	1.033	9.9139996
1	2011-08-17 02:01:43.232+09	xlog	1110	0	0	3	7.1129999	1.094	8.2229996
1	2011-08-17 02:02:14.786+09	xlog	1222	0	0	3	9.066	0.95300001	10.037
1	2011-08-17 02:02:48.221+09	xlog	1220	0	0	3	7.2839999	0.78799999	8.0930004
1	2011-08-17 02:03:18.647+09	xlog	1257	0	0	3	9.132	0.597	9.7539997
1	2011-08-17 02:03:47.69+09	xlog	1192	0	0	3	8.4569998	3.8629999	12.343
1	2011-08-17 02:04:20.799+09	xlog	1202	0	0	3	5.8449998	2.3940001	8.2589998
1	2011-08-17 02:04:49.993+09	xlog	1207	0	0	3	9.0649996	2.2909999	11.384
1	2011-08-17 02:05:24.09+09	xlog	1222	0	0	3	5.6459999	2.408	8.0719995
1	2011-08-17 02:05:55.002+09	xlog	1245	0	0	3	9.0690002	2.859	11.943
1	2011-08-17 02:06:29.09+09	xlog	1152	0	0	3	5.8439999	2.411	8.2700005
1	2011-08-17 02:07:00.541+09	xlog	1167	0	0	3	9.4680004	1.439	10.923
1	2011-08-17 02:07:33.974+09	xlog	1195	0	0	3	5.8470001	3.0539999	8.9180002
1	2011-08-17 02:08:00.634+09	xlog	1170	0	0	3	4.2399998	2.5420001	6.8099999
1	2011-08-17 02:08:30.484+09	xlog	1305	0	0	3	9.6619997	1.429	11.109
1	2011-08-17 02:09:05.352+09	xlog	1391	0	0	3	7.0679998	0.727	7.8210001
1	2011-08-17 02:09:35.563+09	xlog	1269	0	0	3	9.0609999	2.563	11.639
1	2011-08-17 02:10:09.764+09	xlog	1093	0	0	3	6.6739998	0.52600002	7.223
1	2011-08-17 02:10:39.999+09	xlog	1191	0	0	3	8.8570004	0.108	8.9829998
1	2011-08-17 02:11:08.992+09	xlog	1117	0	0	3	8.2589998	3.079	11.367
1	2011-08-17 02:11:43.519+09	xlog	1138	0	0	3	6.0430002	2.5969999	8.658
1	2011-08-17 02:12:12.47+09	xlog	1138	0	0	3	8.8579998	2.5799999	11.459
1	2011-08-17 02:12:46.312+09	xlog	1162	0	0	3	5.842	2.839	8.7060003
1	2011-08-17 02:13:17.528+09	xlog	1230	0	0	3	8.8620005	2.3399999	11.218
1	2011-08-17 02:13:52.132+09	xlog	1172	0	0	3	6.8870001	0.46000001	7.3730001
1	2011-08-17 02:14:22.868+09	xlog	1178	0	0	3	9.4630003	1.3380001	10.816
1	2011-08-17 02:14:56.035+09	xlog	1173	0	0	3	5.849	2.5940001	8.4589996
1	2011-08-17 02:15:27.132+09	xlog	1211	0	0	3	8.8620005	1.334	10.21
1	2011-08-17 02:15:56.54+09	xlog	1204	0	0	3	8.8579998	2.273	11.147
1	2011-08-17 02:16:30.67+09	xlog	1142	0	0	3	7.8600001	1.6440001	9.5209999
1	2011-08-17 02:17:00.537+09	xlog	1117	0	0	3	8.2589998	2.5109999	10.784
1	2011-08-17 02:17:35.041+09	xlog	1306	0	0	3	9.4639997	1.681	11.169
1	2011-08-17 02:18:06.645+09	xlog	1341	0	0	3	9.2629995	2.168	11.456
1	2011-08-17 02:18:39.555+09	xlog	1224	0	0	3	5.8429999	2.6170001	8.4949999
1	2011-08-17 02:19:08.97+09	xlog	1207	0	0	3	8.658	2.632	11.31
1	2011-08-17 02:19:43.451+09	xlog	1112	0	0	3	6.0780001	2.1919999	8.2860003
1	2011-08-17 02:20:13.96+09	xlog	1182	0	0	3	8.8620005	2.3789999	11.263
1	2011-08-17 02:20:47.939+09	xlog	1159	0	0	3	6.7150002	1.649	8.3789997
1	2011-08-17 02:21:18.114+09	xlog	1247	0	0	3	9.0640001	2.069	11.154
1	2011-08-17 02:21:52.182+09	xlog	1141	0	0	3	6.0450001	2.306	8.3660002
1	2011-08-17 02:22:22.639+09	xlog	1177	0	0	3	8.6590004	2.152	10.828
1	2011-08-17 02:22:56.584+09	xlog	1164	0	0	3	6.4530001	1.88	8.3479996
1	2011-08-17 02:23:27.331+09	xlog	1175	0	0	3	9.066	2.5009999	11.581
1	2011-08-17 02:24:02.12+09	xlog	1108	0	0	3	6.0960002	1.237	7.3579998
1	2011-08-17 02:24:33.016+09	xlog	1261	0	0	3	9.0579996	2.434	11.507
1	2011-08-17 02:25:08.316+09	xlog	1180	0	0	3	6.6760001	0.93800002	7.6430001
1	2011-08-17 02:25:38.444+09	xlog	1227	0	0	3	8.8710003	0.245	9.132
1	2011-08-17 02:26:07.388+09	xlog	1155	0	0	3	8.8629999	2.747	11.629
1	2011-08-17 02:26:41.524+09	xlog	1224	0	0	3	6.25	1.756	8.026
1	2011-08-17 02:27:11.609+09	xlog	1317	0	0	3	9.5229998	0.63599998	10.174
1	2011-08-17 02:27:44.143+09	xlog	1061	0	0	3	5.4429998	2.474	7.9549999
1	2011-08-17 02:28:14.962+09	xlog	1247	0	0	3	9.6850004	0.375	10.079
1	2011-08-17 02:28:44.376+09	xlog	1108	0	0	3	8.4580002	3.26	11.743
1	2011-08-17 02:29:17.50+09	xlog	1159	0	0	3	5.6469998	2.474	8.1379995
1	2011-08-17 02:29:46.739+09	xlog	1220	0	0	3	8.8629999	2.273	11.155
1	2011-08-17 02:30:20.702+09	xlog	1195	0	0	3	6.0469999	2.299	8.3660002
1	2011-08-17 02:30:52.445+09	xlog	1176	0	0	3	8.6639996	2.8670001	11.553
1	2011-08-17 02:31:26.511+09	xlog	1211	0	0	3	6.2490001	2.418	8.6829996
1	2011-08-17 02:31:57.152+09	xlog	1175	0	0	3	8.8620005	2.4489999	11.335
1	2011-08-17 02:32:32.313+09	xlog	1250	0	0	3	8.2639999	0.49000001	8.7729998
1	2011-08-17 02:33:02.649+09	xlog	1096	0	0	3	8.6619997	1.84	10.522
1	2011-08-17 02:33:35.564+09	xlog	1187	0	0	3	6.0469999	2.6500001	8.7180004
1	2011-08-17 02:34:07.754+09	xlog	1176	0	0	3	9.4759998	1.425	10.921
1	2011-08-17 02:34:41.144+09	xlog	1165	0	0	3	5.6500001	2.5780001	8.243
1	2011-08-17 02:35:12.824+09	xlog	1185	0	0	3	10.067	0.54000002	10.63
1	2011-08-17 02:35:47.633+09	xlog	1326	0	0	3	9.46	1.404	10.885
1	2011-08-17 02:36:18.929+09	xlog	1276	0	0	3	9.059	1.215	10.296
1	2011-08-17 02:36:52.54+09	xlog	1239	0	0	3	6.6459999	2.4419999	9.1079998
1	2011-08-17 02:37:23.275+09	xlog	1147	0	0	3	8.8669996	1.132	10.015
1	2011-08-17 02:37:56.87+09	xlog	1202	0	0	3	7.046	0.97000003	8.0389996
1	2011-08-17 02:38:27.836+09	xlog	1206	0	0	3	8.8769999	0.94499999	9.8360004
1	2011-08-17 02:39:00.757+09	xlog	1152	0	0	3	6.651	0.48300001	7.1550002
1	2011-08-17 02:39:31.271+09	xlog	1286	0	0	3	9.4630003	0.68099999	10.166
1	2011-08-17 02:40:01.217+09	xlog	1315	0	0	3	8.8610001	2.652	11.535
1	2011-08-17 02:40:35.392+09	xlog	1204	0	0	3	5.4419999	2.4579999	7.9169998
1	2011-08-17 02:41:03.676+09	xlog	1229	0	0	3	8.6590004	2.2969999	10.984
1	2011-08-17 02:41:37.449+09	xlog	1162	0	0	3	5.848	3.2909999	9.1599998
1	2011-08-17 02:42:07.92+09	xlog	1249	0	0	3	9.0640001	2.154	11.232
1	2011-08-17 02:42:41.881+09	xlog	1075	0	0	3	5.4619999	2.971	8.4510002
1	2011-08-17 02:43:12.285+09	xlog	1165	0	0	3	8.4589996	2.471	10.95
1	2011-08-17 02:43:46.34+09	xlog	1058	0	0	3	5.4850001	2.7579999	8.2589998
1	2011-08-17 02:44:17.159+09	xlog	1241	0	0	3	9.2659998	1.9529999	11.235
1	2011-08-17 02:44:52.885+09	xlog	1284	0	0	3	6.2519999	1.553	7.822
1	2011-08-17 02:45:23.513+09	xlog	1283	0	0	3	8.8850002	0.74400002	9.6450005
1	2011-08-17 02:45:56.593+09	xlog	1126	0	0	3	6.25	2.217	8.4890003
1	2011-08-17 02:46:27.405+09	xlog	1220	0	0	3	9.0640001	1.967	11.048
1	2011-08-17 02:46:56.594+09	xlog	1195	0	0	3	8.4709997	2.4890001	10.979
1	2011-08-17 02:47:30.593+09	xlog	1220	0	0	3	5.8470001	2.3269999	8.1969995
1	2011-08-17 02:48:00.298+09	xlog	1251	0	0	3	9.0600004	2.375	11.453
1	2011-08-17 02:48:34.234+09	xlog	1182	0	0	3	6.0450001	2.365	8.4259996
1	2011-08-17 02:49:03.717+09	xlog	1205	0	0	3	8.6630001	2.4749999	11.16
1	2011-08-17 02:49:38.152+09	xlog	1182	0	0	3	6.0500002	3.5799999	9.6470003
1	2011-08-17 02:50:08.112+09	xlog	1196	0	0	3	8.6619997	2.3280001	11.008
1	2011-08-17 02:50:39.161+09	xlog	1220	0	0	3	8.6680002	3.891	12.578
1	2011-08-17 02:51:12.232+09	xlog	1192	0	0	3	5.6430001	2.4100001	8.0760002
1	2011-08-17 02:51:41.641+09	xlog	1194	0	0	3	9.0579996	2.349	11.423
1	2011-08-17 02:52:16.897+09	xlog	1230	0	0	3	6.2490001	2.221	8.4879999
1	2011-08-17 02:52:46.348+09	xlog	1173	0	0	3	8.8549995	2.263	11.137
1	2011-08-17 02:53:22.067+09	xlog	1240	0	0	3	6.2470002	2.0599999	8.3299999
1	2011-08-17 02:53:52.457+09	xlog	1374	0	0	3	10.068	1.267	11.352
1	2011-08-17 02:54:27.165+09	xlog	1237	0	0	3	6.4460001	1.598	8.1230001
1	2011-08-17 02:54:56.679+09	xlog	1205	0	0	3	9.0609999	0.93699998	10.015
1	2011-08-17 02:55:30.746+09	xlog	1200	0	0	3	7.053	0.91399997	7.9829998
1	2011-08-17 02:56:02.102+09	xlog	1199	0	0	3	8.8690004	0.90200001	9.7880001
1	2011-08-17 02:56:34.879+09	xlog	1110	0	0	3	6.2690001	1.051	7.335
1	2011-08-17 02:57:05.652+09	xlog	1212	0	0	3	9.0579996	2.105	11.185
1	2011-08-17 02:57:40.271+09	xlog	1169	0	0	3	7.204	0.86299998	8.0860004
1	2011-08-17 02:58:11.639+09	xlog	1153	0	0	3	8.6660004	0.65700001	9.3459997
1	2011-08-17 02:58:44.303+09	xlog	1062	0	0	3	6.0879998	1.664	7.7680001
1	2011-08-17 02:59:15.781+09	xlog	1152	0	0	3	8.6599998	2.3050001	10.993
1	2011-08-17 02:59:49.971+09	xlog	1126	0	0	3	6.6630001	0.64399999	7.3210001
1	2011-08-17 03:00:21.039+09	xlog	1220	0	0	3	9.2629995	0.38499999	9.6669998
1	2011-08-17 03:00:50.615+09	xlog	1160	0	0	3	8.7290001	3.425	12.171
1	2011-08-17 03:01:23.802+09	xlog	1227	0	0	3	6.0440001	2.194	8.2530003
1	2011-08-17 03:01:53.534+09	xlog	1231	0	0	3	8.8579998	2.5350001	11.407
1	2011-08-17 03:02:28.407+09	xlog	1280	0	0	3	6.448	2.0899999	8.552
1	2011-08-17 03:03:00.109+09	xlog	1328	0	0	3	9.0640001	1.678	10.763
1	2011-08-17 03:03:33.746+09	xlog	1279	0	0	3	6.4809999	1.654	8.1560001
1	2011-08-17 03:04:03.162+09	xlog	1255	0	0	3	9.2629995	2.454	11.731
1	2011-08-17 03:04:38.234+09	xlog	1224	0	0	3	6.658	1.294	7.9679999
1	2011-08-17 03:05:08.292+09	xlog	1248	0	0	3	8.8610001	2.388	11.266
1	2011-08-17 03:05:43.427+09	xlog	1133	0	0	3	5.448	2.441	7.9159999
1	2011-08-17 03:06:14.704+09	xlog	1071	0	0	3	8.8570004	1.319	10.2
1	2011-08-17 03:06:48.369+09	xlog	1225	0	0	3	7.1160002	1.156	8.3909998
1	2011-08-17 03:07:18.635+09	xlog	1227	0	0	3	8.8669996	0.71899998	9.6009998
1	2011-08-17 03:07:51.083+09	xlog	1094	0	0	3	6.0879998	1.9119999	8.0200005
1	2011-08-17 03:08:20.818+09	xlog	1156	0	0	3	5.645	2.415	8.0839996
1	2011-08-17 03:08:50.513+09	xlog	1118	0	0	3	8.4619999	2.4130001	10.891
1	2011-08-17 03:09:24.736+09	xlog	1179	0	0	3	6.2480001	2.4549999	8.7200003
1	2011-08-17 03:09:54.757+09	xlog	1206	0	0	3	8.651	2.523	11.193
1	2011-08-17 03:10:28.887+09	xlog	1137	0	0	3	6.2449999	2.3789999	8.6400003
1	2011-08-17 03:11:00.569+09	xlog	1172	0	0	3	8.6590004	3.3499999	12.027
1	2011-08-17 03:11:34.831+09	xlog	1278	0	0	3	6.447	1.858	8.3210001
1	2011-08-17 03:12:07.083+09	xlog	1356	0	0	3	9.0600004	2.773	11.858
1	2011-08-17 03:12:41.272+09	xlog	1219	0	0	3	6.2579999	1.99	8.2639999
1	2011-08-17 03:13:10.255+09	xlog	1210	0	0	3	8.6569996	2.388	11.06
1	2011-08-17 03:13:44.874+09	xlog	1125	0	0	3	5.645	2.9679999	8.6269999
1	2011-08-17 03:14:15.445+09	xlog	1196	0	0	3	9.0579996	2.4400001	11.513
1	2011-08-17 03:14:49.733+09	xlog	1174	0	0	3	6.6700001	1.423	8.1110001
1	2011-08-17 03:15:20.12+09	xlog	1262	0	0	3	9.0620003	2.3169999	11.404
1	2011-08-17 03:15:54.031+09	xlog	1137	0	0	3	6.5219998	1.73	8.2729998
1	2011-08-17 03:16:24.551+09	xlog	1204	0	0	3	8.6630001	2.4000001	11.079
1	2011-08-17 03:16:59.251+09	xlog	1200	0	0	3	6.849	1.117	7.9899998
1	2011-08-17 03:17:29.742+09	xlog	1280	0	0	3	9.0609999	2.556	11.641
1	2011-08-17 03:18:04.805+09	xlog	1235	0	0	3	7.467	0.80199999	8.2930002
1	2011-08-17 03:18:35.707+09	xlog	1183	0	0	3	9.0600004	0.51200002	9.5900002
1	2011-08-17 03:19:08.624+09	xlog	1121	0	0	3	6.2449999	3.23	9.4919996
1	2011-08-17 03:19:39.71+09	xlog	1235	0	0	3	8.8629999	2.224	11.103
1	2011-08-17 03:20:14.127+09	xlog	1089	0	0	3	6.467	1.8789999	8.3660002
1	2011-08-17 03:20:45.994+09	xlog	1297	0	0	3	9.4630003	1.544	11.022
1	2011-08-17 03:21:21.292+09	xlog	1272	0	0	3	6.4899998	0.745	7.257
1	2011-08-17 03:21:51.513+09	xlog	1153	0	0	3	9.0620003	2.2980001	11.377
1	2011-08-17 03:22:26.743+09	xlog	1224	0	0	3	10.13	0.847	11.005
1	2011-08-17 03:22:57.242+09	xlog	1077	0	0	3	9.0939999	1.089	10.202
1	2011-08-17 03:23:30.605+09	xlog	1174	0	0	3	5.6430001	2.727	8.3859997
1	2011-08-17 03:24:00.845+09	xlog	1242	0	0	3	9.2620001	2.6400001	11.917
1	2011-08-17 03:24:33.918+09	xlog	1127	0	0	3	6.0479999	2.362	8.4250002
1	2011-08-17 03:25:05.319+09	xlog	1245	0	0	3	9.059	2.339	11.423
1	2011-08-17 03:25:39.534+09	xlog	1104	0	0	3	5.4400001	2.45	7.9060001
1	2011-08-17 03:26:10.512+09	xlog	1317	0	0	3	9.665	1.549	11.23
1	2011-08-17 03:26:43.609+09	xlog	1108	0	0	3	5.2449999	2.385	7.651
1	2011-08-17 03:27:14.365+09	xlog	1152	0	0	3	8.46	2.378	10.856
1	2011-08-17 03:27:45.33+09	xlog	1182	0	0	3	8.46	2.4159999	10.895
1	2011-08-17 03:28:19.847+09	xlog	1184	0	0	3	8.6619997	1.3049999	9.9820004
1	2011-08-17 03:28:49.205+09	xlog	1129	0	0	3	8.46	2.875	11.358
1	2011-08-17 03:29:22.911+09	xlog	1215	0	0	3	6.0450001	2.2739999	8.3439999
1	2011-08-17 03:29:53.464+09	xlog	1303	0	0	3	9.2639999	1.8559999	11.135
1	2011-08-17 03:30:27.524+09	xlog	1260	0	0	3	6.053	2.434	8.5089998
1	2011-08-17 03:30:57.10+09	xlog	1246	0	0	3	8.6610003	3.1949999	11.88
1	2011-08-17 03:31:31.503+09	xlog	1163	0	0	3	5.8509998	2.6440001	8.5209999
1	2011-08-17 03:32:01.199+09	xlog	1202	0	0	3	8.8649998	2.4630001	11.356
1	2011-08-17 03:32:36.283+09	xlog	1200	0	0	3	7.0770001	0.99900001	8.0909996
1	2011-08-17 03:33:07.33+09	xlog	1231	0	0	3	9.2609997	2.076	11.364
1	2011-08-17 03:33:41.951+09	xlog	1188	0	0	3	7.0650001	0.662	7.744
1	2011-08-17 03:34:12.714+09	xlog	1193	0	0	3	9.4659996	4.013	13.498
1	2011-08-17 03:34:48.25+09	xlog	1183	0	0	3	6.29	2.674	8.9770002
1	2011-08-17 03:35:19.135+09	xlog	1292	0	0	3	9.6709995	2.076	11.763
1	2011-08-17 03:35:53.075+09	xlog	1241	0	0	3	6.243	2.5599999	8.8219995
1	2011-08-17 03:36:23.188+09	xlog	1203	0	0	3	9.0620003	2.325	11.41
1	2011-08-17 03:36:56.823+09	xlog	1143	0	0	3	5.849	2.675	8.5419998
1	2011-08-17 03:37:27.965+09	xlog	1223	0	0	3	9.4689999	1.755	11.242
1	2011-08-17 03:38:00.906+09	xlog	1090	0	0	3	5.2420001	2.256	7.5229998
1	2011-08-17 03:38:33.122+09	xlog	1277	0	0	3	9.5030003	0.67199999	10.192
1	2011-08-17 03:39:07.775+09	xlog	1345	0	0	3	6.474	1.367	7.868
1	2011-08-17 03:39:37.652+09	xlog	1248	0	0	3	8.8640003	2.381	11.262
1	2011-08-17 03:40:12.186+09	xlog	1140	0	0	3	5.645	2.674	8.3409996
1	2011-08-17 03:40:43.625+09	xlog	1226	0	0	3	8.658	2.2639999	10.941
1	2011-08-17 03:41:17.863+09	xlog	1194	0	0	3	7.0770001	0.56199998	7.6589999
1	2011-08-17 03:41:47.978+09	xlog	1132	0	0	3	9.2580004	0.91299999	10.197
1	2011-08-17 03:42:20.95+09	xlog	1141	0	0	3	5.8439999	3.006	8.8719997
1	2011-08-17 03:42:51.521+09	xlog	1193	0	0	3	8.8620005	2.9820001	11.863
1	2011-08-17 03:43:21.439+09	xlog	1134	0	0	3	8.4630003	2.3180001	10.803
1	2011-08-17 03:43:56.57+09	xlog	1193	0	0	3	8.6599998	0.63499999	9.3109999
1	2011-08-17 03:44:26.70+09	xlog	1168	0	0	3	8.6610003	3.766	12.45
1	2011-08-17 03:44:59.822+09	xlog	1194	0	0	3	5.6490002	2.48	8.1540003
1	2011-08-17 03:45:30.225+09	xlog	1131	0	0	3	8.257	4.0900002	12.371
1	2011-08-17 03:46:04.71+09	xlog	1198	0	0	3	14.114	2.191	16.323999
1	2011-08-17 03:46:46.766+09	xlog	1142	0	0	3	9.0629997	1.51	10.591
1	2011-08-17 03:47:22.786+09	xlog	1183	0	0	3	6.4489999	1.6	8.0719995
1	2011-08-17 03:47:55.839+09	xlog	1261	0	0	3	8.4610004	1.5700001	11.305
1	2011-08-17 03:48:30.664+09	xlog	1292	0	0	3	8.8590002	1.88	10.754
1	2011-08-17 03:49:04.828+09	xlog	1111	0	0	3	5.6420002	1.807	7.4650002
1	2011-08-17 03:49:36.118+09	xlog	1226	0	0	3	8.8640003	1.8609999	10.748
1	2011-08-17 03:50:10.542+09	xlog	1146	0	0	3	5.645	1.885	7.5479999
1	2011-08-17 03:50:41.638+09	xlog	1252	0	0	3	8.8559999	1.904	10.776
1	2011-08-17 03:51:15.529+09	xlog	1138	0	0	3	5.645	1.955	7.6160002
1	2011-08-17 03:51:46.576+09	xlog	1159	0	0	3	8.4580002	2.0439999	10.527
1	2011-08-17 03:52:20.795+09	xlog	1130	0	0	3	5.6430001	2.2750001	7.9369998
1	2011-08-17 03:52:52.265+09	xlog	1229	0	0	3	8.8570004	2.168	11.051
1	2011-08-17 03:53:26.252+09	xlog	1130	0	0	3	5.645	2.131	7.7930002
1	2011-08-17 03:53:57.131+09	xlog	1240	0	0	3	8.8610001	2.007	10.883
1	2011-08-17 03:54:30.718+09	xlog	1115	0	0	3	5.447	2.0680001	7.533
1	2011-08-17 03:55:02.335+09	xlog	1260	0	0	3	9.2639999	2.1889999	11.476
1	2011-08-17 03:55:36.835+09	xlog	1182	0	0	3	5.8429999	2.3710001	8.2370005
1	2011-08-17 03:56:07.866+09	xlog	1216	0	0	3	8.8620005	3.9860001	12.876
1	2011-08-17 03:56:41.488+09	xlog	1256	0	0	3	7.8520002	0.29499999	8.1630001
1	2011-08-17 03:57:13.207+09	xlog	1322	0	0	3	9.1059999	1.794	10.915
1	2011-08-17 03:57:46.634+09	xlog	1132	0	0	3	5.4460001	2.447	7.9070001
1	2011-08-17 03:58:18.854+09	xlog	1080	0	0	3	8.0880003	1.051	9.1569996
1	2011-08-17 03:58:52.265+09	xlog	1208	0	0	3	7.1069999	0.68099999	7.8109999
1	2011-08-17 03:59:22.826+09	xlog	1230	0	0	3	9.6610003	0.62300003	10.303
1	2011-08-17 03:59:56.93+09	xlog	1192	0	0	3	6.6680002	1.728	8.4139996
1	2011-08-17 04:00:27.838+09	xlog	1184	0	0	3	9.3249998	2.2449999	11.591
1	2011-08-17 04:01:01.316+09	xlog	1129	0	0	3	5.645	2.5350001	8.1949997
1	2011-08-17 04:01:33.151+09	xlog	1235	0	0	3	9.868	0.54000002	10.423
1	2011-08-17 04:02:06.426+09	xlog	1176	0	0	3	5.441	3.279	8.7379999
1	2011-08-17 04:02:37.339+09	xlog	1207	0	0	3	8.8570004	2.6099999	11.484
1	2011-08-17 04:03:11.554+09	xlog	1165	0	0	3	6.6220002	1.286	7.9260001
1	2011-08-17 04:03:41.886+09	xlog	1236	0	0	3	9.0629997	2.141	11.22
1	2011-08-17 04:04:16.101+09	xlog	1096	0	0	3	6.4710002	0.89899999	7.3860002
1	2011-08-17 04:04:46.385+09	xlog	1113	0	0	3	6.658	2.3239999	8.9989996
1	2011-08-17 04:05:15.682+09	xlog	1146	0	0	3	8.6639996	2.829	11.515
1	2011-08-17 04:05:49.993+09	xlog	1290	0	0	3	9.665	1.5089999	12.938
1	2011-08-17 04:06:26.26+09	xlog	1249	0	0	3	6.8639998	1.035	7.914
1	2011-08-17 04:06:56.824+09	xlog	1211	0	0	3	9.2620001	0.245	9.5279999
1	2011-08-17 04:07:26.35+09	xlog	1176	0	0	3	8.4560003	3.2539999	11.728
1	2011-08-17 04:08:00.123+09	xlog	1239	0	0	3	6.4530001	2.461	8.9329996
1	2011-08-17 04:08:30.101+09	xlog	1180	0	0	3	9.0649996	3.0969999	12.177
1	2011-08-17 04:09:04.077+09	xlog	1162	0	0	3	6.046	2.4189999	8.4860001
1	2011-08-17 04:09:35.526+09	xlog	1136	0	0	3	8.717	2.266	10.998
1	2011-08-17 04:10:08.781+09	xlog	1177	0	0	3	5.8460002	2.358	8.2299995
1	2011-08-17 04:10:40.968+09	xlog	1114	0	0	3	8.868	1.223	10.109
1	2011-08-17 04:11:14.129+09	xlog	1156	0	0	3	6.2490001	2.96	9.2329998
1	2011-08-17 04:11:44.279+09	xlog	1233	0	0	3	8.6569996	2.418	11.091
1	2011-08-17 04:12:19.352+09	xlog	1167	0	0	3	6.4710002	1.677	8.1709995
1	2011-08-17 04:12:49.196+09	xlog	1183	0	0	3	8.8579998	2.382	11.256
1	2011-08-17 04:13:23.625+09	xlog	1160	0	0	3	6.0700002	2.1170001	8.2049999
1	2011-08-17 04:13:53.779+09	xlog	1225	0	0	3	9.0550003	2.1789999	11.249
1	2011-08-17 04:14:28.008+09	xlog	1153	0	0	3	6.6760001	1.414	8.1059999
1	2011-08-17 04:14:59.368+09	xlog	1360	0	0	3	9.4610004	0.78899997	10.285
1	2011-08-17 04:15:29.048+09	xlog	1216	0	0	3	9.6669998	0.56999999	10.261
1	2011-08-17 04:16:02.34+09	xlog	1172	0	0	3	5.6500001	2.5539999	8.2209997
1	2011-08-17 04:16:31.226+09	xlog	1219	0	0	3	8.6599998	2.5150001	11.199
1	2011-08-17 04:17:05.447+09	xlog	1139	0	0	3	6.0549998	2.381	8.4519997
1	2011-08-17 04:17:35.342+09	xlog	1201	0	0	3	9.0579996	2.0680001	11.14
1	2011-08-17 04:18:09.447+09	xlog	1079	0	0	3	5.6570001	3.299	8.9759998
1	2011-08-17 04:18:39.82+09	xlog	1244	0	0	3	9.0640001	2.994	12.077
1	2011-08-17 04:19:10.169+09	xlog	1195	0	0	3	8.6669998	2.3329999	11.019
1	2011-08-17 04:19:44.342+09	xlog	1213	0	0	3	8.8579998	1.962	10.852
1	2011-08-17 04:20:13.991+09	xlog	1148	0	0	3	8.4580002	2.392	10.867
1	2011-08-17 04:20:48.24+09	xlog	1148	0	0	3	5.8429999	2.503	8.3830004
1	2011-08-17 04:21:17.717+09	xlog	1141	0	0	3	8.6569996	2.2179999	10.894
1	2011-08-17 04:21:51.157+09	xlog	1138	0	0	3	5.8429999	2.5	8.3649998
1	2011-08-17 04:22:22.411+09	xlog	1234	0	0	3	9.4610004	2.2820001	11.758
1	2011-08-17 04:22:56.388+09	xlog	1142	0	0	3	6.053	2.8440001	8.9139996
1	2011-08-17 04:23:27.634+09	xlog	1230	0	0	3	9.2620001	1.829	11.106
1	2011-08-17 04:24:02.443+09	xlog	1344	0	0	3	6.2470002	1.345	7.612
1	2011-08-17 04:24:32.604+09	xlog	1263	0	0	3	9.6809998	0.64200002	10.341
1	2011-08-17 04:25:05.302+09	xlog	1133	0	0	3	6.4559999	3.141	9.6239996
1	2011-08-17 04:25:36.626+09	xlog	1189	0	0	3	8.6610003	2.309	10.992
1	2011-08-17 04:26:10.964+09	xlog	1121	0	0	3	6.257	1.67	7.9460001
1	2011-08-17 04:26:40.842+09	xlog	1214	0	0	3	8.6610003	2.322	10.997
1	2011-08-17 04:27:10.73+09	xlog	1147	0	0	3	8.46	2.3699999	10.845
1	2011-08-17 04:27:45.122+09	xlog	1212	0	0	3	5.8449998	2.546	8.4069996
1	2011-08-17 04:28:14.133+09	xlog	1239	0	0	3	8.8579998	2.237	11.115
1	2011-08-17 04:28:48.352+09	xlog	1136	0	0	3	5.8460002	2.2750001	8.1470003
1	2011-08-17 04:29:19.496+09	xlog	1164	0	0	3	8.8620005	3.786	12.667
1	2011-08-17 04:29:53.937+09	xlog	1182	0	0	3	6.0419998	2.404	8.46
1	2011-08-17 04:30:24.962+09	xlog	1214	0	0	3	9.2639999	1.8660001	11.147
1	2011-08-17 04:30:58.33+09	xlog	1199	0	0	3	5.849	2.319	8.1870003
1	2011-08-17 04:31:30.584+09	xlog	1181	0	0	3	9.4659996	0.472	9.9580002
1	2011-08-17 04:32:03.629+09	xlog	1253	0	0	3	6.0430002	2.8039999	8.8660002
1	2011-08-17 04:32:33.867+09	xlog	1300	0	0	3	9.6590004	1.928	11.603
1	2011-08-17 04:33:09.677+09	xlog	1360	0	0	3	6.4530001	1.715	8.1949997
1	2011-08-17 04:33:39.135+09	xlog	1239	0	0	3	9.2629995	0.41999999	9.7040005
1	2011-08-17 04:34:08.654+09	xlog	1176	0	0	3	8.4610004	3.063	11.54
1	2011-08-17 04:34:42.328+09	xlog	1183	0	0	3	7.4559999	2.6199999	10.092
1	2011-08-17 04:35:12.661+09	xlog	1139	0	0	3	9.2620001	4.553	13.833
1	2011-08-17 04:35:51.093+09	xlog	1190	0	0	3	11.034	1.9349999	12.986
1	2011-08-17 04:36:29.68+09	xlog	1399	0	0	3	9.4720001	3.0799999	12.572
1	2011-08-17 04:37:05.248+09	xlog	1224	0	0	3	8.059	2.378	10.453
1	2011-08-17 04:37:35.909+09	xlog	1108	0	0	3	8.4569998	1.9	10.372
1	2011-08-17 04:38:10.065+09	xlog	1180	0	0	3	9.4589996	1.387	10.935
1	2011-08-17 04:38:40.666+09	xlog	1181	0	0	3	8.2600002	1.335	9.6239996
1	2011-08-17 04:39:13.913+09	xlog	1217	0	0	3	7.2529998	1.059	8.3280001
1	2011-08-17 04:39:44.648+09	xlog	1200	0	0	3	8.4779997	1.02	9.5129995
1	2011-08-17 04:40:17.798+09	xlog	1143	0	0	3	6.8740001	0.52700001	7.428
1	2011-08-17 04:40:48.028+09	xlog	1168	0	0	3	9.0670004	0.359	9.441
1	2011-08-17 04:41:17.315+09	xlog	1137	0	0	3	8.4589996	2.661	11.137
1	2011-08-17 04:41:53.38+09	xlog	1296	0	0	3	10.072	1.505	11.595
1	2011-08-17 04:42:28.531+09	xlog	1241	0	0	3	5.9200001	2.5969999	8.5319996
1	2011-08-17 04:42:58.495+09	xlog	1253	0	0	3	9.2629995	3.063	12.34
1	2011-08-17 04:43:28.394+09	xlog	1202	0	0	3	8.4560003	2.517	10.995
1	2011-08-17 04:44:02.602+09	xlog	1214	0	0	3	9.0640001	2.931	12.019
1	2011-08-17 04:44:32.515+09	xlog	1236	0	0	3	8.8649998	2.4719999	11.352
1	2011-08-17 04:45:06.81+09	xlog	1222	0	0	3	6.6479998	2.4590001	9.125
1	2011-08-17 04:45:35.621+09	xlog	1240	0	0	3	8.658	3.7520001	12.427
1	2011-08-17 04:46:09.696+09	xlog	1165	0	0	3	5.8439999	2.214	8.0819998
1	2011-08-17 04:46:40.549+09	xlog	1199	0	0	3	9.2600002	2.3710001	11.648
1	2011-08-17 04:47:15.515+09	xlog	1231	0	0	3	6.0510001	2.539	8.6070004
1	2011-08-17 04:47:45.721+09	xlog	1238	0	0	3	9.059	2.5120001	11.588
1	2011-08-17 04:48:20.69+09	xlog	1191	0	0	3	6.6550002	0.98299998	7.6539998
1	2011-08-17 04:48:50.977+09	xlog	1158	0	0	3	9.0579996	2.3080001	11.382
1	2011-08-17 04:49:25.959+09	xlog	1188	0	0	3	6.8649998	0.51200002	7.3979998
1	2011-08-17 04:49:57.906+09	xlog	1127	0	0	3	9.4879999	0.71799999	10.222
1	2011-08-17 04:50:32.493+09	xlog	1229	0	0	3	9.9350004	0.54100001	10.492
1	2011-08-17 04:51:04.07+09	xlog	1357	0	0	3	9.2629995	1.557	10.846
1	2011-08-17 04:51:38.133+09	xlog	1217	0	0	3	9.0769997	0.177	9.2720003
1	2011-08-17 04:52:07.156+09	xlog	1103	0	0	3	8.6619997	3.3759999	12.055
1	2011-08-17 04:52:41.501+09	xlog	1246	0	0	3	6.2480001	2.5239999	8.7869997
1	2011-08-17 04:53:11.535+09	xlog	1201	0	0	3	9.2639999	2.256	11.534
1	2011-08-17 04:53:44.681+09	xlog	1184	0	0	3	5.8460002	2.517	8.3780003
1	2011-08-17 04:54:16.337+09	xlog	1203	0	0	3	8.8669996	2.3929999	11.276
1	2011-08-17 04:54:50.861+09	xlog	1142	0	0	3	6.053	2.467	8.5439997
1	2011-08-17 04:55:21.555+09	xlog	1155	0	0	3	8.6549997	2.2460001	10.917
1	2011-08-17 04:55:55.436+09	xlog	1222	0	0	3	6.8470001	1.511	8.3760004
1	2011-08-17 04:56:25.002+09	xlog	1214	0	0	3	8.8620005	2.474	11.362
1	2011-08-17 04:56:59.766+09	xlog	1155	0	0	3	6.4660001	1.839	8.3290005
1	2011-08-17 04:57:30.243+09	xlog	1202	0	0	3	9.0609999	2.497	11.581
1	2011-08-17 04:58:04.916+09	xlog	1160	0	0	3	6.448	1.233	7.7049999
1	2011-08-17 04:58:35.366+09	xlog	1250	0	0	3	9.0679998	2.424	11.51
1	2011-08-17 04:59:09.932+09	xlog	1158	0	0	3	7.0760002	0.51599997	7.612
1	2011-08-17 04:59:41.115+09	xlog	1324	0	0	3	9.6630001	1.822	11.5
1	2011-08-17 05:00:16.537+09	xlog	1361	0	0	3	6.8769999	0.80800003	7.7030001
1	2011-08-17 05:00:46.595+09	xlog	1228	0	0	3	9.2609997	2.0220001	11.308
1	2011-08-17 05:01:20.105+09	xlog	1142	0	0	3	5.6430001	2.3900001	8.0509996
1	2011-08-17 05:01:51.592+09	xlog	1104	0	0	3	9.0740004	0.98400003	10.084
1	2011-08-17 05:02:25.733+09	xlog	1161	0	0	3	6.0450001	3.0599999	9.1199999
1	2011-08-17 05:02:56.105+09	xlog	1202	0	0	3	9.0600004	2.138	11.216
1	2011-08-17 05:03:31.258+09	xlog	1210	0	0	3	6.6760001	1.294	7.9850001
1	2011-08-17 05:04:01.889+09	xlog	1171	0	0	3	9.0600004	2.0439999	11.12
1	2011-08-17 05:04:35.084+09	xlog	1119	0	0	3	5.4439998	2.4449999	7.9060001
1	2011-08-17 05:05:05.713+09	xlog	1193	0	0	3	8.6619997	2.5580001	11.235
1	2011-08-17 05:05:39.919+09	xlog	1133	0	0	3	5.4460001	2.441	7.9109998
1	2011-08-17 05:06:11.114+09	xlog	1250	0	0	3	9.0649996	2.608	11.697
1	2011-08-17 05:06:45.601+09	xlog	1184	0	0	3	5.645	2.375	8.0410004
1	2011-08-17 05:07:16.742+09	xlog	1216	0	0	3	8.8620005	2.174	11.053
1	2011-08-17 05:07:50.421+09	xlog	1061	0	0	3	5.243	2.5139999	7.7740002
1	2011-08-17 05:08:21.828+09	xlog	1228	0	0	3	9.0600004	2.5109999	11.592
1	2011-08-17 05:08:58.432+09	xlog	1300	0	0	3	10.071	1.212	11.304
1	2011-08-17 05:09:30.332+09	xlog	1263	0	0	3	9.0710001	3.109	12.203
1	2011-08-17 05:10:03.643+09	xlog	1215	0	0	3	5.8499999	2.549	8.415
1	2011-08-17 05:10:32.772+09	xlog	1229	0	0	3	8.6619997	2.3469999	11.027
1	2011-08-17 05:11:08.125+09	xlog	1235	0	0	3	6.256	2.2620001	8.5410004
1	2011-08-17 05:11:37.688+09	xlog	1182	0	0	3	8.6630001	2.829	11.511
1	2011-08-17 05:12:11.643+09	xlog	1193	0	0	3	6.0450001	2.566	8.6260004
1	2011-08-17 05:12:42.027+09	xlog	1233	0	0	3	8.8640003	2.3410001	11.223
1	2011-08-17 05:13:16.096+09	xlog	1118	0	0	3	6.2600002	1.85	8.125
1	2011-08-17 05:13:46.748+09	xlog	1215	0	0	3	8.8599997	2.3889999	11.271
1	2011-08-17 05:14:21.425+09	xlog	1180	0	0	3	6.8870001	0.48699999	7.3889999
1	2011-08-17 05:14:51.913+09	xlog	1180	0	0	3	8.8590002	1.283	10.158
1	2011-08-17 05:15:21.547+09	xlog	1174	0	0	3	8.6560001	2.622	11.295
1	2011-08-17 05:15:55.563+09	xlog	1187	0	0	3	9.0799999	1.001	10.105
1	2011-08-17 05:16:24.803+09	xlog	1117	0	0	3	8.4589996	2.3440001	10.825
1	2011-08-17 05:16:59.302+09	xlog	1196	0	0	3	6.2509999	2.244	8.5100002
1	2011-08-17 05:17:29.328+09	xlog	1229	0	0	3	8.8599997	3.3169999	12.192
1	2011-08-17 05:18:05.084+09	xlog	1361	0	0	3	11.072	0.43399999	11.524
1	2011-08-17 05:18:36.549+09	xlog	1210	0	0	3	9.3290005	1.122	10.468
1	2011-08-17 05:19:10.845+09	xlog	1175	0	0	3	9.7130003	0.38699999	10.116
1	2011-08-17 05:19:40.794+09	xlog	1172	0	0	3	9.4969997	1.439	10.952
1	2011-08-17 05:20:13.969+09	xlog	1225	0	0	3	6.2480001	2.6500001	8.9139996
1	2011-08-17 05:20:44.554+09	xlog	1226	0	0	3	8.6569996	2.3299999	11.002
1	2011-08-17 05:21:18.983+09	xlog	1181	0	0	3	6.4629998	1.5319999	8.0120001
1	2011-08-17 05:21:48.912+09	xlog	1204	0	0	3	8.8610001	3.1900001	12.074
1	2011-08-17 05:22:22.072+09	xlog	1141	0	0	3	5.6430001	2.3310001	7.9899998
1	2011-08-17 05:22:53.521+09	xlog	1099	0	0	3	9.2600002	1.929	11.205
1	2011-08-17 05:23:23.523+09	xlog	1168	0	0	3	8.6590004	2.9119999	11.588
1	2011-08-17 05:23:57.606+09	xlog	1237	0	0	3	4.0339999	2.402	6.5349998
1	2011-08-17 05:24:25.89+09	xlog	1206	0	0	3	8.8620005	2.5209999	11.402
1	2011-08-17 05:25:00.472+09	xlog	1231	0	0	3	6.4460001	2.3789999	8.8409996
1	2011-08-17 05:25:30.991+09	xlog	1209	0	0	3	8.6599998	2.336	11.016
1	2011-08-17 05:26:05.78+09	xlog	1224	0	0	3	6.6719999	2.368	9.059
1	2011-08-17 05:26:36.504+09	xlog	1266	0	0	3	9.2679996	1.943	11.233
1	2011-08-17 05:27:13.395+09	xlog	1379	0	0	3	9.4680004	1.729	11.221
1	2011-08-17 05:27:47.483+09	xlog	1118	0	0	3	6.25	1.01	7.277
1	2011-08-17 05:28:18.556+09	xlog	1160	0	0	3	8.8789997	0.366	9.2629995
1	2011-08-17 05:28:48.317+09	xlog	1117	0	0	3	8.6619997	2.0899999	10.767
1	2011-08-17 05:29:21.616+09	xlog	1204	0	0	3	6.0489998	2.4579999	8.5319996
1	2011-08-17 05:29:51.327+09	xlog	1175	0	0	3	8.8590002	2.7179999	11.591
1	2011-08-17 05:30:24.527+09	xlog	1135	0	0	3	5.6459999	2.7	8.3719997
1	2011-08-17 05:30:55.663+09	xlog	1222	0	0	3	9.0649996	2.352	11.434
1	2011-08-17 05:31:30.12+09	xlog	1170	0	0	3	5.8499999	2.5739999	8.4399996
1	2011-08-17 05:32:00.828+09	xlog	1244	0	0	3	9.0620003	2.398	11.475
1	2011-08-17 05:32:35.227+09	xlog	1134	0	0	3	6.0560002	1.858	7.9330001
1	2011-08-17 05:33:06.205+09	xlog	1211	0	0	3	8.4549999	2.3610001	10.84
1	2011-08-17 05:33:41.251+09	xlog	1203	0	0	3	7.072	0.773	7.8639998
1	2011-08-17 05:34:11.93+09	xlog	1181	0	0	3	8.8590002	0.583	9.467
1	2011-08-17 05:34:44.999+09	xlog	1148	0	0	3	6.053	2.8399999	8.9099998
1	2011-08-17 05:35:15.127+09	xlog	1228	0	0	3	8.8599997	2.3199999	11.194
1	2011-08-17 05:35:50.16+09	xlog	1142	0	0	3	5.8509998	1.735	7.6079998
1	2011-08-17 05:36:21.579+09	xlog	1306	0	0	3	9.283	0.71399999	10.024
1	2011-08-17 05:36:54.419+09	xlog	1049	0	0	3	5.4429998	2.3299999	7.789
1	2011-08-17 05:37:25.681+09	xlog	1242	0	0	3	9.868	0.98000002	10.866
1	2011-08-17 05:37:59.357+09	xlog	1145	0	0	3	6.8909998	0.93000001	7.8559999
1	2011-08-17 05:38:30.254+09	xlog	1208	0	0	3	8.8780003	0.236	9.1330004
1	2011-08-17 05:38:59.757+09	xlog	1163	0	0	3	8.8579998	1.8890001	10.767
1	2011-08-17 05:39:32.907+09	xlog	1226	0	0	3	6.0469999	2.362	8.4250002
1	2011-08-17 05:40:03.59+09	xlog	1206	0	0	3	8.6669998	3.0369999	11.719
1	2011-08-17 05:40:37.079+09	xlog	1178	0	0	3	5.8410001	2.4690001	8.3260002
1	2011-08-17 05:41:08.113+09	xlog	1187	0	0	3	8.8590002	2.5139999	11.389
1	2011-08-17 05:41:41.871+09	xlog	1191	0	0	3	5.8429999	2.8469999	8.71
1	2011-08-17 05:42:12.617+09	xlog	1246	0	0	3	8.8590002	2.776	11.654
1	2011-08-17 05:42:51.99+09	xlog	1219	0	0	3	10.665	1.675	12.479
1	2011-08-17 05:43:33.046+09	xlog	1418	0	0	3	9.8660002	3.4449999	13.517
1	2011-08-17 05:44:09.805+09	xlog	1273	0	0	3	8.8610001	1.776	10.654
1	2011-08-17 05:44:44.927+09	xlog	1230	0	0	3	6.4439998	2.0320001	8.4940004
1	2011-08-17 05:45:17.812+09	xlog	1255	0	0	3	8.46	1.997	10.474
1	2011-08-17 05:45:52.35+09	xlog	1091	0	0	3	5.4450002	2.1429999	7.605
1	2011-08-17 05:46:21.768+09	xlog	993	0	0	3	7.8579998	2.0109999	9.8850002
1	2011-08-17 05:46:56.231+09	xlog	1196	0	0	3	9.4580002	2.0669999	11.549
1	2011-08-17 05:47:28.091+09	xlog	1183	0	0	3	9.0649996	2.0650001	11.144
1	2011-08-17 05:48:02.952+09	xlog	1152	0	0	3	8.677	2.355	11.058
1	2011-08-17 05:48:33.854+09	xlog	1198	0	0	3	8.6569996	2.2550001	10.938
1	2011-08-17 05:49:07.979+09	xlog	1190	0	0	3	8.8579998	2.6889999	11.564
1	2011-08-17 05:49:42.507+09	xlog	1074	0	0	3	5.6440001	2.3199999	7.9809999
1	2011-08-17 05:50:14.038+09	xlog	1216	0	0	3	9.0579996	0.42199999	9.5039997
1	2011-08-17 05:50:43.576+09	xlog	1150	0	0	3	8.4610004	3.3770001	11.861
1	2011-08-17 05:51:17.012+09	xlog	1173	0	0	3	6.6459999	2.4089999	9.0690002
1	2011-08-17 05:51:46.435+09	xlog	1210	0	0	3	9.2589998	3.2839999	12.561
1	2011-08-17 05:52:20.035+09	xlog	1108	0	0	3	6.0479999	2.434	8.5050001
1	2011-08-17 05:52:51.50+09	xlog	1113	0	0	3	8.6599998	2.263	10.943
1	2011-08-17 05:53:25.548+09	xlog	1244	0	0	3	6.4429998	2.405	8.868
1	2011-08-17 05:53:56.938+09	xlog	1259	0	0	3	9.0620003	1.573	10.656
1	2011-08-17 05:54:30.322+09	xlog	1218	0	0	3	5.4499998	3.391	8.8620005
1	2011-08-17 05:55:00.466+09	xlog	1212	0	0	3	9.0649996	3.5	12.582
1	2011-08-17 05:55:34.459+09	xlog	1124	0	0	3	5.8520002	2.3770001	8.2530003
1	2011-08-17 05:56:05.875+09	xlog	1244	0	0	3	8.8590002	2.434	11.317
1	2011-08-17 05:56:39.852+09	xlog	1195	0	0	3	5.849	2.6010001	8.4650002
1	2011-08-17 05:57:10.879+09	xlog	1240	0	0	3	9.6730003	2.0350001	11.724
1	2011-08-17 05:57:43.886+09	xlog	1151	0	0	3	5.6430001	2.5439999	8.2019997
1	2011-08-17 05:58:14.837+09	xlog	1189	0	0	3	8.8620005	2.6370001	11.524
1	2011-08-17 05:58:48.868+09	xlog	1132	0	0	3	5.4450002	2.1600001	7.6199999
1	2011-08-17 05:59:20.065+09	xlog	1176	0	0	3	9.0640001	2.2950001	11.38
1	2011-08-17 05:59:50.217+09	xlog	1132	0	0	3	8.46	2.5550001	11.035
1	2011-08-17 06:00:25.776+09	xlog	1176	0	0	3	8.6590004	2.766	11.442
1	2011-08-17 06:01:00.234+09	xlog	1176	0	0	3	6.0469999	3.01	9.0790005
1	2011-08-17 06:01:30.681+09	xlog	1222	0	0	3	8.8570004	2.2839999	11.158
1	2011-08-17 06:02:04.318+09	xlog	1107	0	0	3	5.4450002	3.3399999	8.802
1	2011-08-17 06:02:35.132+09	xlog	1313	0	0	3	9.4630003	1.768	11.247
1	2011-08-17 06:03:10.779+09	xlog	1306	0	0	3	6.2519999	1.505	7.7729998
1	2011-08-17 06:03:41.413+09	xlog	1268	0	0	3	8.8760004	0.72600001	9.6269999
1	2011-08-17 06:04:11.086+09	xlog	1191	0	0	3	9.0629997	2.418	11.496
1	2011-08-17 06:04:44.366+09	xlog	1196	0	0	3	9.059	2.3989999	11.473
1	2011-08-17 06:05:15.172+09	xlog	1181	0	0	3	8.8620005	2.2390001	11.117
1	2011-08-17 06:05:48.193+09	xlog	1245	0	0	3	5.8499999	2.47	8.3360004
1	2011-08-17 06:06:18.006+09	xlog	1202	0	0	3	9.059	2.829	11.911
1	2011-08-17 06:06:51.785+09	xlog	1133	0	0	3	5.4439998	2.2420001	7.7010002
1	2011-08-17 06:07:22.861+09	xlog	1184	0	0	3	8.8579998	2.6500001	11.528
1	2011-08-17 06:07:57.197+09	xlog	1188	0	0	3	6.2449999	2.7149999	8.9759998
1	2011-08-17 06:08:27.882+09	xlog	1252	0	0	3	8.8730001	2.128	11.016
1	2011-08-17 06:09:02.299+09	xlog	1150	0	0	3	6.46	1.902	8.3850002
1	2011-08-17 06:09:32.57+09	xlog	1205	0	0	3	8.8590002	2.4979999	11.381
1	2011-08-17 06:10:07.008+09	xlog	1149	0	0	3	6.902	1.245	8.1630001
1	2011-08-17 06:10:37.679+09	xlog	1287	0	0	3	9.0649996	2.257	11.337
1	2011-08-17 06:11:11.809+09	xlog	1142	0	0	3	6.6960001	1.2460001	7.9590001
1	2011-08-17 06:11:42.648+09	xlog	1358	0	0	3	9.6669998	1.466	11.151
1	2011-08-17 06:12:17.06+09	xlog	1304	0	0	3	5.8449998	2.931	8.7959995
1	2011-08-17 06:12:46.946+09	xlog	1238	0	0	3	8.8629999	2.5020001	11.38
1	2011-08-17 06:13:21.802+09	xlog	1122	0	0	3	5.4429998	2.3069999	7.776
1	2011-08-17 06:13:52.494+09	xlog	1160	0	0	3	8.6590004	3.55	12.224
1	2011-08-17 06:14:25.773+09	xlog	1100	0	0	3	5.441	2.3829999	7.8379998
1	2011-08-17 06:14:56.895+09	xlog	1182	0	0	3	9.2609997	2.184	11.461
1	2011-08-17 06:15:26.471+09	xlog	1181	0	0	3	9.0579996	2.4059999	11.48
1	2011-08-17 06:16:01.715+09	xlog	1170	0	0	3	8.6560001	1.215	9.8900003
1	2011-08-17 06:16:31.265+09	xlog	1177	0	0	3	8.4589996	2.694	11.175
1	2011-08-17 06:17:06.04+09	xlog	1149	0	0	3	5.6440001	2.3889999	8.0489998
1	2011-08-17 06:17:35.795+09	xlog	1168	0	0	3	9.2639999	1.814	11.096
1	2011-08-17 06:18:08.992+09	xlog	1208	0	0	3	5.8439999	2.5380001	8.4060001
1	2011-08-17 06:18:39.646+09	xlog	1207	0	0	3	9.2609997	2.437	11.714
1	2011-08-17 06:19:12.88+09	xlog	1132	0	0	3	5.6479998	2.3859999	8.0500002
1	2011-08-17 06:19:44.03+09	xlog	1257	0	0	3	9.2629995	2.359	11.64
1	2011-08-17 06:20:18.742+09	xlog	1125	0	0	3	5.8439999	2.744	8.6070004
1	2011-08-17 06:20:50.558+09	xlog	1271	0	0	3	9.4689999	1.424	10.909
1	2011-08-17 06:21:25.729+09	xlog	1263	0	0	3	9.8999996	0.145	10.06
1	2011-08-17 06:21:56.394+09	xlog	1059	0	0	3	8.46	2.29	10.765
1	2011-08-17 06:22:30.63+09	xlog	1265	0	0	3	10.28	0.68099999	10.977
1	2011-08-17 06:23:00.826+09	xlog	1175	0	0	3	9.3129997	1.057	10.392
1	2011-08-17 06:23:33.602+09	xlog	1176	0	0	3	6.0469999	2.8369999	8.8999996
1	2011-08-17 06:24:04.598+09	xlog	1252	0	0	3	9.2620001	2.45	11.728
1	2011-08-17 06:24:38.953+09	xlog	1207	0	0	3	6.671	1.332	8.0179996
1	2011-08-17 06:25:09.349+09	xlog	1255	0	0	3	8.8570004	2.543	11.417
1	2011-08-17 06:25:43.666+09	xlog	1159	0	0	3	6.869	1.272	8.158
1	2011-08-17 06:26:14.485+09	xlog	1239	0	0	3	9.2580004	2.168	11.443
1	2011-08-17 06:26:49.468+09	xlog	1176	0	0	3	6.8909998	0.61799997	7.5370002
1	2011-08-17 06:27:20.224+09	xlog	1149	0	0	3	9.3059998	0.48199999	9.8039999
1	2011-08-17 06:27:53.979+09	xlog	1117	0	0	3	5.8649998	2.651	8.5389996
1	2011-08-17 06:28:25.041+09	xlog	1231	0	0	3	9.4639997	1.8789999	11.372
1	2011-08-17 06:28:54.597+09	xlog	1139	0	0	3	8.4580002	2.3729999	10.856
1	2011-08-17 06:29:29.266+09	xlog	1251	0	0	3	9.4659996	1.161	10.645
1	2011-08-17 06:30:03.304+09	xlog	1230	0	0	3	7.4629998	0.49399999	7.9720001
1	2011-08-17 06:30:35.464+09	xlog	1256	0	0	3	9.0670004	0.90799999	9.9910002
1	2011-08-17 06:31:08.822+09	xlog	1163	0	0	3	6.8470001	0.65799999	7.52
1	2011-08-17 06:31:39.677+09	xlog	1259	0	0	3	9.0629997	0.39899999	9.4899998
1	2011-08-17 06:32:08.816+09	xlog	1176	0	0	3	8.6639996	3.2279999	11.909
1	2011-08-17 06:32:42.277+09	xlog	1265	0	0	3	6.2490001	2.4419999	8.7130003
1	2011-08-17 06:33:12.377+09	xlog	1171	0	0	3	8.6599998	2.365	11.041
1	2011-08-17 06:33:46.893+09	xlog	1206	0	0	3	6.447	1.624	8.0889997
1	2011-08-17 06:34:16.352+09	xlog	1233	0	0	3	8.8559999	2.5050001	11.378
1	2011-08-17 06:34:50.516+09	xlog	1147	0	0	3	6.4460001	1.926	8.3909998
1	2011-08-17 06:35:21.461+09	xlog	1169	0	0	3	8.4589996	2.425	10.903
1	2011-08-17 06:35:55.558+09	xlog	1103	0	0	3	6.8590002	1.204	8.0830002
1	2011-08-17 06:36:26.216+09	xlog	1206	0	0	3	10.277	1.152	11.447
1	2011-08-17 06:37:00.096+09	xlog	1104	0	0	3	5.8460002	3.0999999	8.96
1	2011-08-17 06:37:31.371+09	xlog	1248	0	0	3	9.2659998	2.369	11.653
1	2011-08-17 06:38:06.543+09	xlog	1198	0	0	3	6.6830001	0.40200001	7.1020002
1	2011-08-17 06:38:37.118+09	xlog	1289	0	0	3	9.6599998	0.67400002	10.359
1	2011-08-17 06:39:12.081+09	xlog	1370	0	0	3	6.5120001	1.497	8.0240002
1	2011-08-17 06:39:43.275+09	xlog	1173	0	0	3	8.9160004	0.94	9.8730001
1	2011-08-17 06:40:16.708+09	xlog	1169	0	0	3	7.2880001	0.61400002	7.9159999
1	2011-08-17 06:40:48.359+09	xlog	1158	0	0	3	9.4639997	0.86400002	10.342
1	2011-08-17 06:41:21.368+09	xlog	1151	0	0	3	5.8449998	2.589	8.4499998
1	2011-08-17 06:41:52.042+09	xlog	1195	0	0	3	8.6590004	2.2349999	10.917
1	2011-08-17 06:42:25.962+09	xlog	1166	0	0	3	6.0710001	2.0369999	8.1289997
1	2011-08-17 06:42:55.301+09	xlog	1128	0	0	3	8.4569998	3.5780001	12.055
1	2011-08-17 06:43:25.629+09	xlog	1212	0	0	3	8.8570004	2.392	11.269
1	2011-08-17 06:43:59.514+09	xlog	1150	0	0	3	5.8400002	2.444	8.2989998
1	2011-08-17 06:44:28.834+09	xlog	1191	0	0	3	8.6549997	2.401	11.084
1	2011-08-17 06:45:03.36+09	xlog	1189	0	0	3	6.2579999	1.739	8.026
1	2011-08-17 06:45:33.116+09	xlog	1160	0	0	3	8.4589996	2.323	10.799
1	2011-08-17 06:46:07.875+09	xlog	1205	0	0	3	6.671	1.181	7.8670001
1	2011-08-17 06:46:38.426+09	xlog	1233	0	0	3	9.2659998	2.2709999	11.562
1	2011-08-17 06:47:12.451+09	xlog	1174	0	0	3	6.5019999	1.201	7.7210002
1	2011-08-17 06:47:42.907+09	xlog	1317	0	0	3	9.4709997	1.848	11.34
1	2011-08-17 06:48:19.175+09	xlog	1364	0	0	3	6.2540002	2.112	8.3879995
1	2011-08-17 06:48:49.435+09	xlog	1186	0	0	3	8.6610003	2.3210001	10.996
1	2011-08-17 06:49:23.912+09	xlog	1186	0	0	3	5.8429999	2.1559999	8.0150003
1	2011-08-17 06:49:53.706+09	xlog	1235	0	0	3	8.8660002	2.3329999	11.219
1	2011-08-17 06:50:27.331+09	xlog	1126	0	0	3	5.6399999	2.243	7.901
1	2011-08-17 06:50:58.684+09	xlog	1181	0	0	3	9.2609997	2.5039999	11.789
1	2011-08-17 06:51:32.193+09	xlog	1145	0	0	3	5.6430001	2.3800001	8.0369997
1	2011-08-17 06:52:03.739+09	xlog	1231	0	0	3	8.8579998	2.421	11.298
1	2011-08-17 06:52:38.846+09	xlog	1197	0	0	3	6.046	2.431	8.493
1	2011-08-17 06:53:09.729+09	xlog	1172	0	0	3	8.4569998	2.7539999	11.231
1	2011-08-17 06:53:44.502+09	xlog	1183	0	0	3	6.2529998	2.6289999	8.9040003
1	2011-08-17 06:54:14.706+09	xlog	1185	0	0	3	8.8620005	2.2309999	11.109
1	2011-08-17 06:54:49.946+09	xlog	1238	0	0	3	10.136	0.28	10.432
1	2011-08-17 06:55:20.20+09	xlog	1177	0	0	3	9.0609999	1.87	10.948
1	2011-08-17 06:55:53.828+09	xlog	1194	0	0	3	5.8460002	2.5320001	8.4040003
1	2011-08-17 06:56:24.736+09	xlog	1130	0	0	3	10.291	3.01	13.328
1	2011-08-17 06:57:05.222+09	xlog	1296	0	0	3	12.878	1.408	14.3
1	2011-08-17 06:57:50.983+09	xlog	1458	0	0	3	7.2589998	2.6789999	10.106
1	2011-08-17 06:58:28.139+09	xlog	1422	0	0	3	7.257	2.1340001	9.4060001
1	2011-08-17 06:59:00.373+09	xlog	1292	0	0	3	9.0609999	1.854	10.936
1	2011-08-17 06:59:35.064+09	xlog	1178	0	0	3	6.448	2.109	8.573
1	2011-08-17 07:00:07.575+09	xlog	1030	0	0	3	7.658	1.969	9.6520004
1	2011-08-17 07:00:41.982+09	xlog	1250	0	0	3	6.0489998	2.2509999	8.3240004
1	2011-08-17 07:01:11.615+09	xlog	1222	0	0	3	8.8610001	2.125	11.003
1	2011-08-17 07:01:45.665+09	xlog	1203	0	0	3	5.8499999	2.2290001	8.0979996
1	2011-08-17 07:02:16.441+09	xlog	1174	0	0	3	8.4610004	2.1889999	10.667
1	2011-08-17 07:02:50.491+09	xlog	1216	0	0	3	6.0450001	2.3269999	8.3909998
1	2011-08-17 07:03:20.939+09	xlog	1173	0	0	3	8.4569998	2.3540001	10.829
1	2011-08-17 07:03:55.496+09	xlog	1135	0	0	3	6.0469999	2.414	8.4779997
1	2011-08-17 07:04:27.226+09	xlog	1191	0	0	3	9.0620003	2.2390001	11.329
1	2011-08-17 07:05:02.498+09	xlog	1119	0	0	3	9.9110003	0.67299998	10.604
1	2011-08-17 07:05:33.428+09	xlog	1187	0	0	3	9.6689997	0.537	10.228
1	2011-08-17 07:06:06.90+09	xlog	1262	0	0	3	6.243	2.4100001	8.6739998
1	2011-08-17 07:06:36.436+09	xlog	1262	0	0	3	8.8599997	1.897	10.772
1	2011-08-17 07:07:11.228+09	xlog	1305	0	0	3	6.0479999	1.3660001	7.5029998
1	2011-08-17 07:07:41.792+09	xlog	1264	0	0	3	8.9040003	0.89200002	9.8199997
1	2011-08-17 07:08:14.604+09	xlog	1073	0	0	3	5.8569999	2.2690001	8.1450005
1	2011-08-17 07:08:44.517+09	xlog	1143	0	0	3	5.4429998	2.438	7.901
1	2011-08-17 07:09:13.977+09	xlog	1136	0	0	3	8.2639999	2.2679999	10.546
1	2011-08-17 07:09:48.281+09	xlog	1215	0	0	3	6.0489998	2.402	8.4770002
1	2011-08-17 07:10:17.992+09	xlog	1243	0	0	3	8.8590002	2.9949999	11.874
1	2011-08-17 07:10:52.126+09	xlog	1178	0	0	3	5.8499999	2.3929999	8.257
1	2011-08-17 07:11:23.205+09	xlog	1202	0	0	3	9.2639999	1.715	10.997
1	2011-08-17 07:11:56.78+09	xlog	1118	0	0	3	5.6430001	2.6919999	8.349
1	2011-08-17 07:12:27.656+09	xlog	1244	0	0	3	9.4729996	2.029	11.524
1	2011-08-17 07:13:01.244+09	xlog	1077	0	0	3	5.848	2.767	8.6300001
1	2011-08-17 07:13:33.281+09	xlog	1200	0	0	3	8.8599997	2.335	11.209
1	2011-08-17 07:14:07.554+09	xlog	1163	0	0	3	6.8610001	0.55000001	7.4330001
1	2011-08-17 07:14:37.821+09	xlog	1222	0	0	3	9.2989998	0.47099999	9.7880001
1	2011-08-17 07:15:07.432+09	xlog	1179	0	0	3	8.6619997	3.2460001	11.924
1	2011-08-17 07:15:41.862+09	xlog	1254	0	0	3	9.2609997	1.878	11.158
1	2011-08-17 07:16:17.115+09	xlog	1398	0	0	3	7.0809999	0.53200001	7.6409998
1	2011-08-17 07:16:47.673+09	xlog	1300	0	0	3	9.2679996	2.2609999	11.544
1	2011-08-17 07:17:22.818+09	xlog	1115	0	0	3	6.8470001	1.058	7.9239998
1	2011-08-17 07:17:54.386+09	xlog	1084	0	0	3	8.0579996	1.091	9.165
1	2011-08-17 07:18:27.215+09	xlog	1181	0	0	3	6.8670001	0.64700001	7.5359998
1	2011-08-17 07:18:57.638+09	xlog	1162	0	0	3	8.8649998	0.126	9.007
1	2011-08-17 07:19:27.211+09	xlog	1124	0	0	3	8.6590004	3.4949999	12.176
1	2011-08-17 07:20:00.70+09	xlog	1155	0	0	3	5.8439999	2.5320001	8.3990002
1	2011-08-17 07:20:29.665+09	xlog	1229	0	0	3	9.2609997	2.4909999	11.774
1	2011-08-17 07:21:04.592+09	xlog	1232	0	0	3	7.0479999	2.1960001	9.2589998
1	2011-08-17 07:21:34.586+09	xlog	1215	0	0	3	8.6560001	2.2279999	10.903
1	2011-08-17 07:22:09.101+09	xlog	1158	0	0	3	6.448	2.2420001	8.7049999
1	2011-08-17 07:22:41.257+09	xlog	1169	0	0	3	8.4560003	2.8989999	11.376
1	2011-08-17 07:23:15.275+09	xlog	1241	0	0	3	6.2449999	2.3889999	8.6490002
1	2011-08-17 07:23:45.097+09	xlog	1223	0	0	3	8.8649998	3.424	12.305
1	2011-08-17 07:24:18.512+09	xlog	1156	0	0	3	5.645	2.447	8.1140003
1	2011-08-17 07:24:51.004+09	xlog	1263	0	0	3	10.472	1.233	11.73
1	2011-08-17 07:25:27.533+09	xlog	1314	0	0	3	9.6630001	0.51499999	10.194
1	2011-08-17 07:25:57.395+09	xlog	1145	0	0	3	8.2589998	2.2739999	10.557
1	2011-08-17 07:26:31.182+09	xlog	1132	0	0	3	9.4799995	0.85699999	10.458
1	2011-08-17 07:27:01.984+09	xlog	1160	0	0	3	9.7130003	0.75199997	10.49
1	2011-08-17 07:27:35.219+09	xlog	1199	0	0	3	5.862	2.5610001	8.4370003
1	2011-08-17 07:28:04.753+09	xlog	1249	0	0	3	9.0579996	3.7479999	12.811
1	2011-08-17 07:28:38.198+09	xlog	1124	0	0	3	5.6409998	2.4719999	8.1309996
1	2011-08-17 07:29:10.698+09	xlog	1101	0	0	3	9.2639999	1.482	10.769
1	2011-08-17 07:29:44.378+09	xlog	1194	0	0	3	5.8449998	2.4419999	8.3079996
1	2011-08-17 07:30:15.728+09	xlog	1190	0	0	3	9.6630001	0.43799999	10.12
1	2011-08-17 07:30:49.063+09	xlog	1174	0	0	3	5.8509998	3.3099999	9.1870003
1	2011-08-17 07:31:18.959+09	xlog	1190	0	0	3	8.4580002	3.279	11.753
1	2011-08-17 07:31:49.391+09	xlog	1182	0	0	3	8.8610001	2.655	11.538
1	2011-08-17 07:32:23.858+09	xlog	1177	0	0	3	8.8599997	1.216	10.095
1	2011-08-17 07:32:53.255+09	xlog	1127	0	0	3	8.2580004	2.3729999	10.647
1	2011-08-17 07:33:28.379+09	xlog	1236	0	0	3	9.665	2.859	12.539
1	2011-08-17 07:34:04.299+09	xlog	1266	0	0	3	7.6570001	0.50999999	8.1820002
1	2011-08-17 07:34:36.623+09	xlog	1239	0	0	3	8.8649998	1.149	10.029
1	2011-08-17 07:35:09.767+09	xlog	1172	0	0	3	6.5040002	0.84299999	7.3850002
1	2011-08-17 07:35:40.058+09	xlog	1213	0	0	3	8.8579998	0.41299999	9.2880001
1	2011-08-17 07:36:08.705+09	xlog	1147	0	0	3	8.4639997	3.48	11.962
1	2011-08-17 07:36:42.212+09	xlog	1220	0	0	3	6.2509999	2.4059999	8.6719999
1	2011-08-17 07:37:11.639+09	xlog	1208	0	0	3	8.6599998	3.744	12.42
1	2011-08-17 07:37:44.527+09	xlog	1114	0	0	3	5.8460002	2.418	8.2779999
1	2011-08-17 07:38:16.29+09	xlog	1267	0	0	3	9.4630003	1.868	11.347
1	2011-08-17 07:38:49.626+09	xlog	1110	0	0	3	5.6459999	2.6530001	8.3190002
1	2011-08-17 07:39:21.441+09	xlog	1241	0	0	3	9.4610004	0.30899999	9.7950001
1	2011-08-17 07:39:54.673+09	xlog	1087	0	0	3	5.6469998	3.8510001	9.5159998
1	2011-08-17 07:40:25.278+09	xlog	1199	0	0	3	8.4589996	2.5380001	11.022
1	2011-08-17 07:40:56.093+09	xlog	1113	0	0	3	8.4580002	3.428	11.908
1	2011-08-17 07:41:29.411+09	xlog	1138	0	0	3	5.6479998	2.332	7.9970002
1	2011-08-17 07:41:58.511+09	xlog	1177	0	0	3	8.6639996	2.5469999	11.238
1	2011-08-17 07:42:33.193+09	xlog	1250	0	0	3	6.2459998	2.0090001	8.2790003
1	2011-08-17 07:43:05.007+09	xlog	1262	0	0	3	9.6619997	1.533	11.216
1	2011-08-17 07:43:39.90+09	xlog	1231	0	0	3	9.0889997	0.15800001	9.2639999
1	2011-08-17 07:44:09.513+09	xlog	1110	0	0	3	9.0629997	2.388	11.467
1	2011-08-17 07:44:44.278+09	xlog	1223	0	0	3	6.0479999	2.365	8.4359999
1	2011-08-17 07:45:13.938+09	xlog	1194	0	0	3	9.2770004	1.659	10.96
1	2011-08-17 07:45:47.675+09	xlog	1157	0	0	3	6.0500002	2.3829999	8.4569998
1	2011-08-17 07:46:19.508+09	xlog	1150	0	0	3	9.4639997	1.609	11.09
1	2011-08-17 07:46:53.046+09	xlog	1192	0	0	3	6.0469999	2.4849999	8.5480003
1	2011-08-17 07:47:24.106+09	xlog	1206	0	0	3	9.4899998	1.024	10.53
1	2011-08-17 07:47:57.245+09	xlog	1103	0	0	3	5.4450002	2.3310001	7.7989998
1	2011-08-17 07:48:28.411+09	xlog	1203	0	0	3	9.8590002	0.36700001	10.242
1	2011-08-17 07:49:01.30+09	xlog	1063	0	0	3	5.6399999	3.0769999	8.7329998
1	2011-08-17 07:49:32.903+09	xlog	1226	0	0	3	9.0579996	2.365	11.438
1	2011-08-17 07:50:07.611+09	xlog	1161	0	0	3	7.0799999	0.58099997	7.6799998
1	2011-08-17 07:50:38.674+09	xlog	1222	0	0	3	9.1059999	0.67299998	9.7989998
1	2011-08-17 07:51:11.599+09	xlog	1090	0	0	3	6.2509999	2.6429999	8.9130001
1	2011-08-17 07:51:42.941+09	xlog	1301	0	0	3	9.2609997	1.841	11.121
1	2011-08-17 07:52:18.274+09	xlog	1292	0	0	3	6.0489998	2.0239999	8.0959997
1	2011-08-17 07:52:48.843+09	xlog	1234	0	0	3	9.0699997	0.92400002	10.012
1	2011-08-17 07:53:21.425+09	xlog	1088	0	0	3	6.2919998	1.26	7.5710001
1	2011-08-17 07:53:51.521+09	xlog	1162	0	0	3	5.447	2.576	8.0410004
1	2011-08-17 07:54:20.695+09	xlog	1140	0	0	3	8.2559996	2.684	10.959
1	2011-08-17 07:54:54.996+09	xlog	1225	0	0	3	6.0469999	2.7260001	8.7980003
1	2011-08-17 07:55:24.777+09	xlog	1221	0	0	3	8.8549995	2.4330001	11.302
1	2011-08-17 07:55:59.358+09	xlog	1134	0	0	3	5.8460002	3.099	8.9610004
1	2011-08-17 07:56:29.475+09	xlog	1188	0	0	3	9.0629997	2.2969999	11.375
1	2011-08-17 07:57:03.598+09	xlog	1135	0	0	3	6.2690001	2.4590001	8.75
1	2011-08-17 07:57:33.756+09	xlog	1176	0	0	3	9.066	3.352	12.434
1	2011-08-17 07:58:04.132+09	xlog	1190	0	0	3	8.8570004	2.3859999	11.265
1	2011-08-17 07:58:38.134+09	xlog	1153	0	0	3	5.448	2.3959999	7.8639998
1	2011-08-17 07:59:06.782+09	xlog	1234	0	0	3	8.6569996	2.329	11.007
1	2011-08-17 07:59:41.012+09	xlog	1170	0	0	3	6.0479999	2.256	8.3190002
1	2011-08-17 08:00:11.862+09	xlog	1205	0	0	3	8.6549997	2.3080001	10.984
1	2011-08-17 08:00:46.948+09	xlog	1285	0	0	3	6.448	1.494	7.9650002
1	2011-08-17 08:01:19.127+09	xlog	1300	0	0	3	9.9110003	1.143	11.075
1	2011-08-17 08:01:53.583+09	xlog	1232	0	0	3	9.0640001	2.47	11.551
1	2011-08-17 08:02:28.35+09	xlog	1129	0	0	3	5.651	1.51	7.184
1	2011-08-17 08:03:00.455+09	xlog	1166	0	0	3	8.8559999	1.498	10.37
1	2011-08-17 08:03:34.941+09	xlog	1192	0	0	3	6.0510001	1.564	7.6360002
1	2011-08-17 08:04:06.709+09	xlog	1137	0	0	3	8.6630001	1.592	10.281
1	2011-08-17 08:04:40.672+09	xlog	1159	0	0	3	5.6440001	1.607	7.2659998
1	2011-08-17 08:05:12.903+09	xlog	1097	0	0	3	8.0670004	1.66	9.7410002
1	2011-08-17 08:05:46.643+09	xlog	1198	0	0	3	6.0469999	1.725	7.7880001
1	2011-08-17 08:06:17.708+09	xlog	1168	0	0	3	8.6619997	1.714	10.399
1	2011-08-17 08:06:51.491+09	xlog	1202	0	0	3	6.046	1.659	7.7189999
1	2011-08-17 08:07:22.482+09	xlog	1165	0	0	3	9.066	1.697	10.78
1	2011-08-17 08:07:56.421+09	xlog	1216	0	0	3	6.0440001	1.686	7.744
1	2011-08-17 08:08:27.812+09	xlog	1174	0	0	3	8.8629999	1.626	10.505
1	2011-08-17 08:09:01.914+09	xlog	1134	0	0	3	5.8460002	1.766	7.6399999
1	2011-08-17 08:09:33.272+09	xlog	1164	0	0	3	8.4580002	1.692	10.171
1	2011-08-17 08:10:08.328+09	xlog	1239	0	0	3	9.2659998	1.749	11.029
1	2011-08-17 08:10:39.996+09	xlog	1219	0	0	3	8.4580002	1.865	10.347
1	2011-08-17 08:11:14.087+09	xlog	1227	0	0	3	9.0579996	1.7460001	10.827
1	2011-08-17 08:11:48.638+09	xlog	1098	0	0	3	5.4450002	1.874	7.335
1	2011-08-17 08:12:19.227+09	xlog	1193	0	0	3	8.8610001	1.735	10.614
1	2011-08-17 08:12:53.547+09	xlog	1113	0	0	3	5.4499998	1.877	7.3410001
1	2011-08-17 08:13:25.286+09	xlog	1256	0	0	3	9.4709997	1.7869999	11.276
1	2011-08-17 08:14:00.791+09	xlog	1145	0	0	3	5.645	2.0840001	7.7449999
1	2011-08-17 08:14:32.528+09	xlog	1102	0	0	3	8.6569996	2.1329999	10.808
1	2011-08-17 08:15:07.629+09	xlog	1143	0	0	3	6.8509998	2.3710001	9.243
1	2011-08-17 08:15:37.534+09	xlog	1120	0	0	3	8.257	2.1760001	10.459
1	2011-08-17 08:16:11.517+09	xlog	1222	0	0	3	6.4510002	2.1600001	8.6459999
1	2011-08-17 08:16:42.77+09	xlog	1115	0	0	3	8.2589998	2.3399999	10.623
1	2011-08-17 08:17:16.835+09	xlog	1239	0	0	3	6.2509999	2.2739999	8.5469999
1	2011-08-17 08:17:46.39+09	xlog	1217	0	0	3	8.8660002	3.9119999	12.792
1	2011-08-17 08:18:20.113+09	xlog	1167	0	0	3	5.8460002	2.4519999	8.3120003
1	2011-08-17 08:19:00.306+09	xlog	1258	0	0	3	11.671	0.035999998	11.814
1	2011-08-17 08:19:40.468+09	xlog	1344	0	0	3	10.078	2.069	12.787
1	2011-08-17 08:20:20.35+09	xlog	1443	0	0	3	10.265	2.224	12.574
1	2011-08-17 08:20:58.227+09	xlog	1396	0	0	3	6.2509999	1.702	7.9720001
1	2011-08-17 08:21:30.112+09	xlog	1112	0	0	3	8.8610001	1.989	10.874
1	2011-08-17 08:22:05.752+09	xlog	1190	0	0	3	9.0620003	2.0650001	11.161
1	2011-08-17 08:22:40.253+09	xlog	1110	0	0	3	6.0489998	2.1210001	8.1859999
1	2011-08-17 08:23:11.811+09	xlog	1207	0	0	3	9.0530005	2.2290001	11.298
1	2011-08-17 08:23:46.804+09	xlog	1177	0	0	3	6.4460001	2.2479999	8.7159996
1	2011-08-17 08:24:18.309+09	xlog	1196	0	0	3	8.6590004	3.0369999	11.711
1	2011-08-17 08:24:52.574+09	xlog	1189	0	0	3	7.0479999	2.346	9.4200001
1	2011-08-17 08:25:23.635+09	xlog	1106	0	0	3	8.8599997	1.711	10.586
1	2011-08-17 08:25:57.174+09	xlog	1170	0	0	3	6.651	3.007	9.677
1	2011-08-17 08:26:27.936+09	xlog	1191	0	0	3	8.8640003	2.5409999	11.427
1	2011-08-17 08:27:03.308+09	xlog	1114	0	0	3	6.8709998	0.78600001	7.6760001
1	2011-08-17 08:27:33.936+09	xlog	1160	0	0	3	8.4610004	2.286	10.762
1	2011-08-17 08:28:07.643+09	xlog	1184	0	0	3	7.2989998	0.67299998	7.9889998
1	2011-08-17 08:28:38.049+09	xlog	1215	0	0	3	9.4619999	1.279	10.757
1	2011-08-17 08:29:10.904+09	xlog	1072	0	0	3	5.4429998	2.4579999	7.9200001
1	2011-08-17 08:29:42.331+09	xlog	1332	0	0	3	9.6639996	0.43799999	10.124
1	2011-08-17 08:30:16.338+09	xlog	1227	0	0	3	6.072	1.693	7.7789998
1	2011-08-17 08:30:47.261+09	xlog	1307	0	0	3	9.6780005	0.59600002	10.29
1	2011-08-17 08:31:17.599+09	xlog	1187	0	0	3	9.1070004	1.85	10.973
1	2011-08-17 08:31:50.812+09	xlog	1197	0	0	3	6.0440001	2.325	8.3940001
1	2011-08-17 08:32:20.419+09	xlog	1077	0	0	3	8.4779997	3.79	12.282
1	2011-08-17 08:32:54.347+09	xlog	1173	0	0	3	6.0440001	2.3499999	8.4090004
1	2011-08-17 08:33:25.965+09	xlog	1199	0	0	3	9.8640003	1.085	10.965
1	2011-08-17 08:33:59.638+09	xlog	1196	0	0	3	5.8439999	2.2780001	8.1400003
1	2011-08-17 08:34:30.006+09	xlog	1229	0	0	3	9.2670002	2.1059999	11.391
1	2011-08-17 08:35:03.218+09	xlog	1067	0	0	3	5.8460002	2.777	8.6429996
1	2011-08-17 08:35:34.733+09	xlog	1223	0	0	3	9.0629997	1.858	10.938
1	2011-08-17 08:36:08.607+09	xlog	1145	0	0	3	6.4780002	1.794	8.2939997
1	2011-08-17 08:36:38.855+09	xlog	1187	0	0	3	8.8590002	2.079	10.955
1	2011-08-17 08:37:13.089+09	xlog	1096	0	0	3	6.0669999	2.177	8.2620001
1	2011-08-17 08:37:43.217+09	xlog	1232	0	0	3	8.8599997	2.0409999	10.925
1	2011-08-17 08:38:17.611+09	xlog	1140	0	0	3	6.2789998	1.7359999	8.0299997
1	2011-08-17 08:38:47.884+09	xlog	1241	0	0	3	4.0380001	2.4330001	6.4860001
1	2011-08-17 08:39:13.022+09	xlog	1301	0	0	3	5.6469998	1.895	7.5560002
1	2011-08-17 08:39:38.858+09	xlog	1276	0	0	3	6.0479999	2.5320001	8.6029997
1	2011-08-17 08:40:08.466+09	xlog	1226	0	0	3	8.8629999	4.059	12.94
1	2011-08-17 08:40:42.353+09	xlog	1137	0	0	3	5.4439998	2.533	7.9980001
1	2011-08-17 08:41:13.046+09	xlog	1243	0	0	3	9.0629997	3.4100001	12.489
1	2011-08-17 08:41:46.717+09	xlog	1102	0	0	3	5.6440001	2.3399999	8.0010004
1	2011-08-17 08:42:17.87+09	xlog	1236	0	0	3	9.46	2.306	11.786
1	2011-08-17 08:42:47.709+09	xlog	1168	0	0	3	8.4720001	2.3759999	10.863
1	2011-08-17 08:43:21.819+09	xlog	1182	0	0	3	9.0620003	2.299	11.365
1	2011-08-17 08:43:51.76+09	xlog	1126	0	0	3	8.4589996	2.4489999	10.923
1	2011-08-17 08:44:26.565+09	xlog	1153	0	0	3	8.6630001	2.3840001	11.071
1	2011-08-17 08:45:01.191+09	xlog	1023	0	0	3	5.2410002	3.102	8.3690004
1	2011-08-17 08:45:32.566+09	xlog	1174	0	0	3	9.0600004	2.2030001	11.277
1	2011-08-17 08:46:07.017+09	xlog	1147	0	0	3	6.862	0.442	7.3280001
1	2011-08-17 08:46:37.382+09	xlog	1226	0	0	3	9.2629995	0.37599999	9.6569996
1	2011-08-17 08:47:06.556+09	xlog	1100	0	0	3	8.2539997	2.5929999	10.87
1	2011-08-17 08:47:40.823+09	xlog	1275	0	0	3	6.2459998	2.1830001	8.4449997
1	2011-08-17 08:48:12.232+09	xlog	1243	0	0	3	9.5249996	1.342	10.886
1	2011-08-17 08:48:46.729+09	xlog	1250	0	0	3	9.2880001	0.131	9.4440002
1	2011-08-17 08:49:16.186+09	xlog	1122	0	0	3	8.46	3.155	11.635
1	2011-08-17 08:49:49.789+09	xlog	1134	0	0	3	5.6440001	2.4070001	8.073
1	2011-08-17 08:50:20.921+09	xlog	1206	0	0	3	9.5080004	1.977	11.501
1	2011-08-17 08:50:54.206+09	xlog	1120	0	0	3	5.8439999	2.4820001	8.3409996
1	2011-08-17 08:51:25.305+09	xlog	1197	0	0	3	9.46	1.7130001	11.189
1	2011-08-17 08:51:58.388+09	xlog	1130	0	0	3	5.4419999	2.3429999	7.8039999
1	2011-08-17 08:52:29.229+09	xlog	1186	0	0	3	8.8620005	2.448	11.326
1	2011-08-17 08:53:03.29+09	xlog	1092	0	0	3	5.4429998	2.506	7.9650002
1	2011-08-17 08:53:34.144+09	xlog	1185	0	0	3	8.6639996	2.6259999	11.308
1	2011-08-17 08:54:04.198+09	xlog	1044	0	0	3	8.2559996	2.7179999	10.989
1	2011-08-17 08:54:38.686+09	xlog	1162	0	0	3	8.8620005	2.493	11.375
1	2011-08-17 08:55:13.196+09	xlog	1121	0	0	3	5.6469998	2.375	8.0450001
1	2011-08-17 08:55:44.95+09	xlog	1210	0	0	3	8.6599998	3.105	11.791
1	2011-08-17 08:56:18.983+09	xlog	1121	0	0	3	5.4450002	2.316	7.777
1	2011-08-17 08:56:51.482+09	xlog	1253	0	0	3	10.069	1.622	11.708
1	2011-08-17 08:57:29.166+09	xlog	1305	0	0	3	9.8769999	0.78600001	10.678
1	2011-08-17 08:58:03.258+09	xlog	1101	0	0	3	6.8540001	1.099	8.0459995
1	2011-08-17 08:58:34.443+09	xlog	1223	0	0	3	9.2679996	0.84200001	10.129
1	2011-08-17 08:59:07.429+09	xlog	1060	0	0	3	6.6669998	0.49900001	7.1810002
1	2011-08-17 08:59:37.966+09	xlog	1152	0	0	3	8.4619999	0.0070000002	8.4899998
1	2011-08-17 09:00:07.382+09	xlog	1120	0	0	3	8.6569996	3.431	12.113
1	2011-08-17 09:00:40.754+09	xlog	1188	0	0	3	6.2509999	2.507	8.7810001
1	2011-08-17 09:01:11.592+09	xlog	1141	0	0	3	8.2559996	2.4949999	10.78
1	2011-08-17 09:01:45.905+09	xlog	1208	0	0	3	7.0679998	0.708	7.8010001
1	2011-08-17 09:02:16.60+09	xlog	1250	0	0	3	9.2629995	1.801	11.094
1	2011-08-17 09:02:50.058+09	xlog	1165	0	0	3	6.0539999	2.352	8.4250002
1	2011-08-17 09:03:22.493+09	xlog	1153	0	0	3	9.7159996	0.63200003	10.367
1	2011-08-17 09:03:56.461+09	xlog	1217	0	0	3	6.6500001	1.852	8.5159998
1	2011-08-17 09:04:26.695+09	xlog	1141	0	0	3	8.2609997	2.418	10.698
1	2011-08-17 09:05:01.053+09	xlog	1186	0	0	3	6.4679999	1.4450001	7.9369998
1	2011-08-17 09:05:31.444+09	xlog	1253	0	0	3	9.4619999	2.1099999	11.587
1	2011-08-17 09:06:06.801+09	xlog	1272	0	0	3	9.4619999	1.35	10.907
1	2011-08-17 09:06:38.855+09	xlog	1251	0	0	3	9.9119997	0.461	10.402
1	2011-08-17 09:07:12.134+09	xlog	1192	0	0	3	5.842	2.461	8.3190002
1	2011-08-17 09:07:42.036+09	xlog	1205	0	0	3	9.1040001	1.901	11.024
1	2011-08-17 09:08:14.901+09	xlog	1095	0	0	3	5.4460001	2.3570001	7.8189998
1	2011-08-17 09:08:46.389+09	xlog	1212	0	0	3	8.8599997	2.4590001	11.337
1	2011-08-17 09:09:20.735+09	xlog	1141	0	0	3	5.8410001	2.2909999	8.1540003
1	2011-08-17 09:09:52.529+09	xlog	1191	0	0	3	8.4630003	2.72	11.199
1	2011-08-17 09:10:27.386+09	xlog	1167	0	0	3	6.0430002	2.5079999	8.573
1	2011-08-17 09:10:57.70+09	xlog	1109	0	0	3	9.0670004	1.393	10.478
1	2011-08-17 09:11:31.236+09	xlog	1231	0	0	3	6.0440001	2.437	8.5
1	2011-08-17 09:12:02.076+09	xlog	1156	0	0	3	9.3030005	1.002	10.33
1	2011-08-17 09:12:34.964+09	xlog	1104	0	0	3	5.4450002	2.882	8.3450003
1	2011-08-17 09:13:06.795+09	xlog	1148	0	0	3	9.875	0.56400001	10.458
1	2011-08-17 09:13:40.901+09	xlog	1178	0	0	3	6.4489999	2.7509999	9.2220001
1	2011-08-17 09:14:10.82+09	xlog	1233	0	0	3	8.8649998	2.369	11.258
1	2011-08-17 09:14:45.347+09	xlog	1154	0	0	3	7.0050001	1.484	8.5030003
1	2011-08-17 09:15:18.375+09	xlog	1312	0	0	3	10.674	1.117	11.816
1	2011-08-17 09:15:54.376+09	xlog	1264	0	0	3	8.6619997	1.575	10.253
1	2011-08-17 09:16:24.759+09	xlog	1154	0	0	3	8.8649998	1.48	10.445
1	2011-08-17 09:16:59.473+09	xlog	1183	0	0	3	9.0640001	1.49	10.568
1	2011-08-17 09:17:30.541+09	xlog	1133	0	0	3	8.46	1.415	9.9549999
1	2011-08-17 09:18:04.734+09	xlog	1117	0	0	3	8.6569996	1.427	10.156
1	2011-08-17 09:18:35.175+09	xlog	1178	0	0	3	8.6560001	1.401	10.234
1	2011-08-17 09:19:09.383+09	xlog	1144	0	0	3	9.2620001	1.3559999	10.706
1	2011-08-17 09:19:40.103+09	xlog	1207	0	0	3	8.6590004	1.323	9.9989996
1	2011-08-17 09:20:13.522+09	xlog	1229	0	0	3	9.6630001	1.2029999	10.943
1	2011-08-17 09:20:44.291+09	xlog	1113	0	0	3	8.4639997	1.151	9.6339998
1	2011-08-17 09:21:18.083+09	xlog	1165	0	0	3	10.059	1.175	11.25
1	2011-08-17 09:21:49.976+09	xlog	1195	0	0	3	9.0740004	1.1720001	10.266
1	2011-08-17 09:22:24.109+09	xlog	1180	0	0	3	9.868	1.094	10.981
1	2011-08-17 09:22:55.283+09	xlog	1158	0	0	3	8.6719999	1.175	9.8640003
1	2011-08-17 09:23:29.616+09	xlog	1141	0	0	3	9.8640003	1.063	10.953
1	2011-08-17 09:24:04.337+09	xlog	1242	0	0	3	7.4499998	1.454	8.9209995
1	2011-08-17 09:24:36.718+09	xlog	1191	0	0	3	9.0710001	1.029	10.124
1	2011-08-17 09:25:10.802+09	xlog	1173	0	0	3	7.0440001	1.086	8.2049999
1	2011-08-17 09:25:41.725+09	xlog	1183	0	0	3	8.8640003	0.86799997	9.7530003
1	2011-08-17 09:26:14.412+09	xlog	1129	0	0	3	6.6459999	0.55500001	7.224
1	2011-08-17 09:26:45.086+09	xlog	1177	0	0	3	9.0629997	0.045000002	9.125
1	2011-08-17 09:27:14.918+09	xlog	1086	0	0	3	8.2589998	3.303	11.576
1	2011-08-17 09:27:48.999+09	xlog	1196	0	0	3	8.8610001	2.293	11.172
1	2011-08-17 09:28:19.889+09	xlog	1155	0	0	3	9.2770004	1.558	10.851
1	2011-08-17 09:28:53.569+09	xlog	1204	0	0	3	6.0489998	2.5580001	8.625
1	2011-08-17 09:29:23.825+09	xlog	1122	0	0	3	8.6639996	1.816	10.498
1	2011-08-17 09:29:57.344+09	xlog	1187	0	0	3	5.8600001	3.046	8.9289999
1	2011-08-17 09:30:27.265+09	xlog	1158	0	0	3	8.6669998	2.8180001	11.501
1	2011-08-17 09:31:01.867+09	xlog	1167	0	0	3	5.8410001	3.2049999	9.0679998
1	2011-08-17 09:31:32.238+09	xlog	1211	0	0	3	9.4639997	2.852	12.331
1	2011-08-17 09:32:02.529+09	xlog	1142	0	0	3	8.6599998	2.4820001	11.159
1	2011-08-17 09:32:37.253+09	xlog	1244	0	0	3	9.2650003	1.405	10.691
1	2011-08-17 09:33:11.222+09	xlog	1250	0	0	3	6.448	1.1950001	7.6589999
1	2011-08-17 09:33:41.631+09	xlog	1233	0	0	3	8.8579998	0.107	8.9890003
1	2011-08-17 09:34:11.021+09	xlog	1091	0	0	3	9.2639999	2.924	12.202
1	2011-08-17 09:34:45.24+09	xlog	1209	0	0	3	6.0570002	2.6329999	8.7040005
1	2011-08-17 09:35:15.662+09	xlog	1041	0	0	3	8.2639999	3.4979999	11.779
1	2011-08-17 09:35:49.457+09	xlog	1186	0	0	3	6.046	3.0969999	9.1610003
1	2011-08-17 09:36:19.607+09	xlog	1223	0	0	3	9.0570002	2.618	11.696
1	2011-08-17 09:36:52.668+09	xlog	1098	0	0	3	5.645	2.296	7.961
1	2011-08-17 09:37:24.028+09	xlog	1193	0	0	3	9.257	2.0350001	11.318
1	2011-08-17 09:37:53.791+09	xlog	1168	0	0	3	8.4589996	2.3740001	10.848
1	2011-08-17 09:38:27.977+09	xlog	1135	0	0	3	8.658	1.423	10.101
1	2011-08-17 09:38:58.156+09	xlog	1109	0	0	3	8.2580004	2.5710001	10.844
1	2011-08-17 09:39:32.395+09	xlog	1168	0	0	3	8.8629999	0.0099999998	8.8909998
1	2011-08-17 09:40:01.492+09	xlog	1125	0	0	3	8.2589998	3.572	11.852
1	2011-08-17 09:40:34.603+09	xlog	1145	0	0	3	5.6440001	2.6070001	8.2700005
1	2011-08-17 09:41:05.94+09	xlog	1209	0	0	3	9.677	1.752	11.451
1	2011-08-17 09:41:39.28+09	xlog	1209	0	0	3	6.0479999	2.1429999	8.2159996
1	2011-08-17 09:42:11.617+09	xlog	1286	0	0	3	9.4619999	1.275	10.752
1	2011-08-17 09:42:45.394+09	xlog	1220	0	0	3	6.6690001	1.35	8.0380001
1	2011-08-17 09:43:16.351+09	xlog	1190	0	0	3	8.908	0.89200002	9.823
1	2011-08-17 09:43:45.272+09	xlog	1154	0	0	3	8.0469999	2.7249999	10.795
1	2011-08-17 09:44:15.978+09	xlog	1160	0	0	3	5.033	2.322	7.3720002
1	2011-08-17 09:44:44.704+09	xlog	1224	0	0	3	9.2650003	2.6889999	11.973
\.


--
-- Data for Name: column; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY "column" (snapid, dbid, tbl, attnum, date, name, type, stattarget, storage, isnotnull, isdropped, avg_width, n_distinct, correlation) FROM stdin;
\.


--
-- Data for Name: column_20110816; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY column_20110816 (snapid, dbid, tbl, attnum, date, name, type, stattarget, storage, isnotnull, isdropped, avg_width, n_distinct, correlation) FROM stdin;
1	11874	1255	1	2011-08-16	proname	name	-1	p	t	f	64	-0.81640798	0.22111399
1	11874	1255	2	2011-08-16	pronamespace	oid	-1	p	t	f	4	2	0.99999899
1	11874	1255	3	2011-08-16	proowner	oid	-1	p	t	f	4	1	1
1	11874	1255	4	2011-08-16	prolang	oid	-1	p	t	f	4	3	0.96455598
1	11874	1255	5	2011-08-16	procost	real	-1	p	t	f	4	5	0.99089301
1	11874	1255	6	2011-08-16	prorows	real	-1	p	t	f	4	10	0.98529398
1	11874	1255	7	2011-08-16	provariadic	oid	-1	p	t	f	4	1	1
1	11874	1255	8	2011-08-16	proisagg	boolean	-1	p	t	f	1	2	0.96914399
1	11874	1255	9	2011-08-16	proiswindow	boolean	-1	p	t	f	1	2	0.99989802
1	11874	1255	10	2011-08-16	prosecdef	boolean	-1	p	t	f	1	1	1
1	11874	1255	11	2011-08-16	proisstrict	boolean	-1	p	t	f	1	2	0.78557801
1	11874	1255	12	2011-08-16	proretset	boolean	-1	p	t	f	1	2	0.98536599
1	11874	1255	13	2011-08-16	provolatile	"char"	-1	p	t	f	1	3	0.75940597
1	11874	1255	14	2011-08-16	pronargs	smallint	-1	p	t	f	2	8	0.35542199
1	11874	1255	15	2011-08-16	pronargdefaults	smallint	-1	p	t	f	2	2	0.99999398
1	11874	1255	16	2011-08-16	prorettype	oid	-1	p	t	f	4	78	0.33539501
1	11874	1255	17	2011-08-16	proargtypes	oidvector	-1	p	t	f	31	-0.16585401	0.131202
1	11874	1255	18	2011-08-16	proallargtypes	oid[]	-1	x	f	f	44	-1	0.20609801
1	11874	1255	19	2011-08-16	proargmodes	"char"[]	-1	x	f	f	26	14	-0.47713199
1	11874	1255	20	2011-08-16	proargnames	text[]	-1	x	f	f	80	30	0.222289
1	11874	1255	21	2011-08-16	proargdefaults	text	-1	x	f	f	141	-1	\N
1	11874	1255	22	2011-08-16	prosrc	text	-1	x	f	f	16	-0.89490002	0.16789301
1	11874	1255	23	2011-08-16	probin	text	-1	x	f	f	23	28	0.83976901
1	11874	1255	24	2011-08-16	proconfig	text[]	-1	x	f	f	0	0	\N
1	11874	1255	25	2011-08-16	proacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	1247	1	2011-08-16	typname	name	-1	p	t	f	64	-1	0.3863
1	11874	1247	2	2011-08-16	typnamespace	oid	-1	p	t	f	4	3	0.99332702
1	11874	1247	3	2011-08-16	typowner	oid	-1	p	t	f	4	1	1
1	11874	1247	4	2011-08-16	typlen	smallint	-1	p	t	f	2	12	0.381313
1	11874	1247	5	2011-08-16	typbyval	boolean	-1	p	t	f	1	2	0.58123201
1	11874	1247	6	2011-08-16	typtype	"char"	-1	p	t	f	1	4	0.90001601
1	11874	1247	7	2011-08-16	typcategory	"char"	-1	p	t	f	1	13	0.16261899
1	11874	1247	8	2011-08-16	typispreferred	boolean	-1	p	t	f	1	2	0.87831497
1	11874	1247	9	2011-08-16	typisdefined	boolean	-1	p	t	f	1	1	1
1	11874	1247	10	2011-08-16	typdelim	"char"	-1	p	t	f	1	2	0.96987098
1	11874	1247	11	2011-08-16	typrelid	oid	-1	p	t	f	4	-0.53310102	0.96858799
1	11874	1247	12	2011-08-16	typelem	oid	-1	p	t	f	4	-0.209059	0.211162
1	11874	1247	13	2011-08-16	typarray	oid	-1	p	t	f	4	-0.209059	0.20806199
1	11874	1247	14	2011-08-16	typinput	regproc	-1	p	t	f	4	-0.250871	0.82135397
1	11874	1247	15	2011-08-16	typoutput	regproc	-1	p	t	f	4	-0.24738701	0.80345798
1	11874	1247	16	2011-08-16	typreceive	regproc	-1	p	t	f	4	-0.21254399	0.195701
1	11874	1247	17	2011-08-16	typsend	regproc	-1	p	t	f	4	-0.209059	0.18141501
1	11874	1247	18	2011-08-16	typmodin	regproc	-1	p	t	f	4	11	0.788158
1	11874	1247	19	2011-08-16	typmodout	regproc	-1	p	t	f	4	11	0.78836697
1	11874	1247	20	2011-08-16	typanalyze	regproc	-1	p	t	f	4	2	0.99200302
1	11874	1247	21	2011-08-16	typalign	"char"	-1	p	t	f	1	4	0.024560301
1	11874	1247	22	2011-08-16	typstorage	"char"	-1	p	t	f	1	3	0.93686098
1	11874	1247	23	2011-08-16	typnotnull	boolean	-1	p	t	f	1	1	1
1	11874	1247	24	2011-08-16	typbasetype	oid	-1	p	t	f	4	4	0.99479401
1	11874	1247	25	2011-08-16	typtypmod	integer	-1	p	t	f	4	3	0.99804902
1	11874	1247	26	2011-08-16	typndims	integer	-1	p	t	f	4	1	1
1	11874	1247	27	2011-08-16	typdefaultbin	text	-1	x	f	f	441	-1	\N
1	11874	1247	28	2011-08-16	typdefault	text	-1	x	f	f	43	-1	\N
1	11874	1249	1	2011-08-16	attrelid	oid	-1	p	t	f	4	-0.130749	0.93989903
1	11874	1249	2	2011-08-16	attname	name	-1	p	t	f	64	-0.38294601	0.0036946801
1	11874	1249	3	2011-08-16	atttypid	oid	-1	p	t	f	4	34	0.60096002
1	11874	1249	4	2011-08-16	attstattarget	integer	-1	p	t	f	4	2	0.42826101
1	11874	1249	5	2011-08-16	attlen	smallint	-1	p	t	f	2	9	-0.064016797
1	11874	1249	6	2011-08-16	attnum	smallint	-1	p	t	f	2	89	0.25127199
1	11874	1249	7	2011-08-16	attndims	integer	-1	p	t	f	4	2	0.91384
1	11874	1249	8	2011-08-16	attcacheoff	integer	-1	p	t	f	4	1	1
1	11874	1249	9	2011-08-16	atttypmod	integer	-1	p	t	f	4	1	1
1	11874	1249	10	2011-08-16	attbyval	boolean	-1	p	t	f	1	2	0.065347202
1	11874	1249	11	2011-08-16	attstorage	"char"	-1	p	t	f	1	3	0.89757299
1	11874	1249	12	2011-08-16	attalign	"char"	-1	p	t	f	1	4	0.66951603
1	11874	1249	13	2011-08-16	attnotnull	boolean	-1	p	t	f	1	2	-0.17658401
1	11874	1249	14	2011-08-16	atthasdef	boolean	-1	p	t	f	1	1	1
1	11874	1249	15	2011-08-16	attisdropped	boolean	-1	p	t	f	1	1	1
1	11874	1249	16	2011-08-16	attislocal	boolean	-1	p	t	f	1	1	1
1	11874	1249	17	2011-08-16	attinhcount	integer	-1	p	t	f	4	1	1
1	11874	1249	18	2011-08-16	attacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	1249	19	2011-08-16	attoptions	text[]	-1	x	f	f	0	0	\N
1	11874	1259	1	2011-08-16	relname	name	-1	p	t	f	64	-1	0.069593102
1	11874	1259	2	2011-08-16	relnamespace	oid	-1	p	t	f	4	3	0.76032102
1	11874	1259	3	2011-08-16	reltype	oid	-1	p	t	f	4	-0.604743	0.80476397
1	11874	1259	4	2011-08-16	reloftype	oid	-1	p	t	f	4	1	1
1	11874	1259	5	2011-08-16	relowner	oid	-1	p	t	f	4	1	1
1	11874	1259	6	2011-08-16	relam	oid	-1	p	t	f	4	2	-0.158712
1	11874	1259	7	2011-08-16	relfilenode	oid	-1	p	t	f	4	-0.84189701	0.68083
1	11874	1259	8	2011-08-16	reltablespace	oid	-1	p	t	f	4	2	0.69740403
1	11874	1259	9	2011-08-16	relpages	integer	-1	p	t	f	4	14	-0.23059499
1	11874	1259	10	2011-08-16	reltuples	real	-1	p	t	f	4	20	0.289942
1	11874	1259	11	2011-08-16	reltoastrelid	oid	-1	p	t	f	4	18	0.93993998
1	11874	1259	12	2011-08-16	reltoastidxid	oid	-1	p	t	f	4	18	0.78708398
1	11874	1259	13	2011-08-16	relhasindex	boolean	-1	p	t	f	1	2	0.68597198
1	11874	1259	14	2011-08-16	relisshared	boolean	-1	p	t	f	1	2	0.69740403
1	11874	1259	15	2011-08-16	relistemp	boolean	-1	p	t	f	1	1	1
1	11874	1259	16	2011-08-16	relkind	"char"	-1	p	t	f	1	4	0.78044999
1	11874	1259	17	2011-08-16	relnatts	smallint	-1	p	t	f	2	-0.106719	0.61371702
1	11874	1259	18	2011-08-16	relchecks	smallint	-1	p	t	f	2	1	1
1	11874	1259	19	2011-08-16	relhasoids	boolean	-1	p	t	f	1	2	0.89500701
1	11874	1259	20	2011-08-16	relhaspkey	boolean	-1	p	t	f	1	2	0.99300599
1	11874	1259	21	2011-08-16	relhasexclusion	boolean	-1	p	t	f	1	1	1
1	11874	1259	22	2011-08-16	relhasrules	boolean	-1	p	t	f	1	2	0.90881997
1	11874	1259	23	2011-08-16	relhastriggers	boolean	-1	p	t	f	1	1	1
1	11874	1259	24	2011-08-16	relhassubclass	boolean	-1	p	t	f	1	1	1
1	11874	1259	25	2011-08-16	relfrozenxid	xid	-1	p	t	f	4	3	\N
1	11874	1259	26	2011-08-16	relacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	1259	27	2011-08-16	reloptions	text[]	-1	x	f	f	0	0	\N
1	11874	2604	1	2011-08-16	adrelid	oid	-1	p	t	f	\N	\N	\N
1	11874	2604	2	2011-08-16	adnum	smallint	-1	p	t	f	\N	\N	\N
1	11874	2604	3	2011-08-16	adbin	text	-1	x	f	f	\N	\N	\N
1	11874	2604	4	2011-08-16	adsrc	text	-1	x	f	f	\N	\N	\N
1	11874	2606	1	2011-08-16	conname	name	-1	p	t	f	64	-1	1
1	11874	2606	2	2011-08-16	connamespace	oid	-1	p	t	f	4	-0.5	1
1	11874	2606	3	2011-08-16	contype	"char"	-1	p	t	f	1	-0.5	1
1	11874	2606	4	2011-08-16	condeferrable	boolean	-1	p	t	f	1	-0.5	1
1	11874	2606	5	2011-08-16	condeferred	boolean	-1	p	t	f	1	-0.5	1
1	11874	2606	6	2011-08-16	conrelid	oid	-1	p	t	f	4	-0.5	1
1	11874	2606	7	2011-08-16	contypid	oid	-1	p	t	f	4	-1	1
1	11874	2606	8	2011-08-16	conindid	oid	-1	p	t	f	4	-0.5	1
1	11874	2606	9	2011-08-16	confrelid	oid	-1	p	t	f	4	-0.5	1
1	11874	2606	10	2011-08-16	confupdtype	"char"	-1	p	t	f	1	-0.5	1
1	11874	2606	11	2011-08-16	confdeltype	"char"	-1	p	t	f	1	-0.5	1
1	11874	2606	12	2011-08-16	confmatchtype	"char"	-1	p	t	f	1	-0.5	1
1	11874	2606	13	2011-08-16	conislocal	boolean	-1	p	t	f	1	-0.5	1
1	11874	2606	14	2011-08-16	coninhcount	integer	-1	p	t	f	4	-0.5	1
1	11874	2606	15	2011-08-16	conkey	smallint[]	-1	x	f	f	0	0	\N
1	11874	2606	16	2011-08-16	confkey	smallint[]	-1	x	f	f	0	0	\N
1	11874	2606	17	2011-08-16	conpfeqop	oid[]	-1	x	f	f	0	0	\N
1	11874	2606	18	2011-08-16	conppeqop	oid[]	-1	x	f	f	0	0	\N
1	11874	2606	19	2011-08-16	conffeqop	oid[]	-1	x	f	f	0	0	\N
1	11874	2606	20	2011-08-16	conexclop	oid[]	-1	x	f	f	0	0	\N
1	11874	2606	21	2011-08-16	conbin	text	-1	x	f	f	498	-1	1
1	11874	2606	22	2011-08-16	consrc	text	-1	x	f	f	52	-1	-1
1	11874	2611	1	2011-08-16	inhrelid	oid	-1	p	t	f	\N	\N	\N
1	11874	2611	2	2011-08-16	inhparent	oid	-1	p	t	f	\N	\N	\N
1	11874	2611	3	2011-08-16	inhseqno	integer	-1	p	t	f	\N	\N	\N
1	11874	2610	1	2011-08-16	indexrelid	oid	-1	p	t	f	4	-1	0.23200899
1	11874	2610	2	2011-08-16	indrelid	oid	-1	p	t	f	4	-0.60395998	0.20038401
1	11874	2610	3	2011-08-16	indnatts	smallint	-1	p	t	f	2	4	0.32738501
1	11874	2610	4	2011-08-16	indisunique	boolean	-1	p	t	f	1	2	0.865789
1	11874	2610	5	2011-08-16	indisprimary	boolean	-1	p	t	f	1	2	0.54012799
1	11874	2610	6	2011-08-16	indimmediate	boolean	-1	p	t	f	1	1	1
1	11874	2610	7	2011-08-16	indisclustered	boolean	-1	p	t	f	1	1	1
1	11874	2610	8	2011-08-16	indisvalid	boolean	-1	p	t	f	1	1	1
1	11874	2610	9	2011-08-16	indcheckxmin	boolean	-1	p	t	f	1	1	1
1	11874	2610	10	2011-08-16	indisready	boolean	-1	p	t	f	1	1	1
1	11874	2610	11	2011-08-16	indkey	int2vector	-1	p	t	f	27	-0.17821801	0.13946401
1	11874	2610	12	2011-08-16	indclass	oidvector	-1	p	t	f	30	-0.16831701	0.163238
1	11874	2610	13	2011-08-16	indoption	int2vector	-1	p	t	f	27	4	0.32738501
1	11874	2610	14	2011-08-16	indexprs	text	-1	x	f	f	0	0	\N
1	11874	2610	15	2011-08-16	indpred	text	-1	x	f	f	0	0	\N
1	11874	2617	1	2011-08-16	oprname	name	-1	p	t	f	64	67	0.195003
1	11874	2617	2	2011-08-16	oprnamespace	oid	-1	p	t	f	4	1	1
1	11874	2617	3	2011-08-16	oprowner	oid	-1	p	t	f	4	1	1
1	11874	2617	4	2011-08-16	oprkind	"char"	-1	p	t	f	1	3	0.880925
1	11874	2617	5	2011-08-16	oprcanmerge	boolean	-1	p	t	f	1	2	0.85338402
1	11874	2617	6	2011-08-16	oprcanhash	boolean	-1	p	t	f	1	2	0.84083802
1	11874	2617	7	2011-08-16	oprleft	oid	-1	p	t	f	4	50	0.48025399
1	11874	2617	8	2011-08-16	oprright	oid	-1	p	t	f	4	49	0.52515399
1	11874	2617	9	2011-08-16	oprresult	oid	-1	p	t	f	4	29	0.46232501
1	11874	2617	10	2011-08-16	oprcom	oid	-1	p	t	f	4	-0.66524798	0.556723
1	11874	2617	11	2011-08-16	oprnegate	oid	-1	p	t	f	4	-0.500709	0.483677
1	11874	2617	12	2011-08-16	oprcode	regproc	-1	p	t	f	4	-0.96879399	0.798738
1	11874	2617	13	2011-08-16	oprrest	regproc	-1	p	t	f	4	17	0.25424901
1	11874	2617	14	2011-08-16	oprjoin	regproc	-1	p	t	f	4	17	0.25424901
1	11874	2753	1	2011-08-16	opfmethod	oid	-1	p	t	f	4	4	0.72316402
1	11874	2753	2	2011-08-16	opfname	name	-1	p	t	f	64	-0.62318802	0.44504899
1	11874	2753	3	2011-08-16	opfnamespace	oid	-1	p	t	f	4	1	1
1	11874	2753	4	2011-08-16	opfowner	oid	-1	p	t	f	4	1	1
1	11874	2616	1	2011-08-16	opcmethod	oid	-1	p	t	f	4	4	0.80080801
1	11874	2616	2	2011-08-16	opcname	name	-1	p	t	f	64	-0.69642901	-0.197919
1	11874	2616	3	2011-08-16	opcnamespace	oid	-1	p	t	f	4	1	1
1	11874	2616	4	2011-08-16	opcowner	oid	-1	p	t	f	4	1	1
1	11874	2616	5	2011-08-16	opcfamily	oid	-1	p	t	f	4	-0.61607099	0.94508302
1	11874	2616	6	2011-08-16	opcintype	oid	-1	p	t	f	4	-0.65178603	0.43914601
1	11874	2616	7	2011-08-16	opcdefault	boolean	-1	p	t	f	1	2	0.89918703
1	11874	2616	8	2011-08-16	opckeytype	oid	-1	p	t	f	4	-0.30357099	0.913315
1	11874	2601	1	2011-08-16	amname	name	-1	p	t	f	64	-1	0.2
1	11874	2601	2	2011-08-16	amstrategies	smallint	-1	p	t	f	2	-0.75	-0.80000001
1	11874	2601	3	2011-08-16	amsupport	smallint	-1	p	t	f	2	-0.75	0.80000001
1	11874	2601	4	2011-08-16	amcanorder	boolean	-1	p	t	f	1	-0.5	-0.2
1	11874	2601	5	2011-08-16	amcanbackward	boolean	-1	p	t	f	1	-0.5	-0.60000002
1	11874	2601	6	2011-08-16	amcanunique	boolean	-1	p	t	f	1	-0.5	-0.2
1	11874	2601	7	2011-08-16	amcanmulticol	boolean	-1	p	t	f	1	-0.5	0.80000001
1	11874	2601	8	2011-08-16	amoptionalkey	boolean	-1	p	t	f	1	-0.5	0.80000001
1	11874	2601	9	2011-08-16	amindexnulls	boolean	-1	p	t	f	1	-0.5	0
1	11874	2601	10	2011-08-16	amsearchnulls	boolean	-1	p	t	f	1	-0.5	0
1	11874	2601	11	2011-08-16	amstorage	boolean	-1	p	t	f	1	-0.5	1
1	11874	2601	12	2011-08-16	amclusterable	boolean	-1	p	t	f	1	-0.5	0
1	11874	2601	13	2011-08-16	amkeytype	oid	-1	p	t	f	4	-0.5	0.40000001
1	11874	2601	14	2011-08-16	aminsert	regproc	-1	p	t	f	4	-1	1
1	11874	2601	15	2011-08-16	ambeginscan	regproc	-1	p	t	f	4	-1	1
1	11874	2601	16	2011-08-16	amgettuple	regproc	-1	p	t	f	4	-1	-0.2
1	11874	2601	17	2011-08-16	amgetbitmap	regproc	-1	p	t	f	4	-1	1
1	11874	2601	18	2011-08-16	amrescan	regproc	-1	p	t	f	4	-1	1
1	11874	2601	19	2011-08-16	amendscan	regproc	-1	p	t	f	4	-1	1
1	11874	2601	20	2011-08-16	ammarkpos	regproc	-1	p	t	f	4	-1	1
1	11874	2601	21	2011-08-16	amrestrpos	regproc	-1	p	t	f	4	-1	1
1	11874	2601	22	2011-08-16	ambuild	regproc	-1	p	t	f	4	-1	1
1	11874	2601	23	2011-08-16	ambulkdelete	regproc	-1	p	t	f	4	-1	1
1	11874	2601	24	2011-08-16	amvacuumcleanup	regproc	-1	p	t	f	4	-1	0.80000001
1	11874	2601	25	2011-08-16	amcostestimate	regproc	-1	p	t	f	4	-1	0.40000001
1	11874	2601	26	2011-08-16	amoptions	regproc	-1	p	t	f	4	-1	1
1	11874	2602	1	2011-08-16	amopfamily	oid	-1	p	t	f	4	-0.193277	0.55816799
1	11874	2602	2	2011-08-16	amoplefttype	oid	-1	p	t	f	4	-0.120448	0.446706
1	11874	2602	3	2011-08-16	amoprighttype	oid	-1	p	t	f	4	-0.120448	0.446367
1	11874	2602	4	2011-08-16	amopstrategy	smallint	-1	p	t	f	2	20	0.243038
1	11874	2602	5	2011-08-16	amopopr	oid	-1	p	t	f	4	-0.88795501	0.319125
1	11874	2602	6	2011-08-16	amopmethod	oid	-1	p	t	f	4	4	0.97767502
1	11874	2603	1	2011-08-16	amprocfamily	oid	-1	p	t	f	4	-0.27599999	0.79009902
1	11874	2603	2	2011-08-16	amproclefttype	oid	-1	p	t	f	4	-0.292	0.37271899
1	11874	2603	3	2011-08-16	amprocrighttype	oid	-1	p	t	f	4	-0.292	0.37262201
1	11874	2603	4	2011-08-16	amprocnum	smallint	-1	p	t	f	2	7	0.680502
1	11874	2603	5	2011-08-16	amproc	regproc	-1	p	t	f	4	-0.43599999	0.481682
1	11874	2612	1	2011-08-16	lanname	name	-1	p	t	f	64	-1	0.60000002
1	11874	2612	2	2011-08-16	lanowner	oid	-1	p	t	f	4	-0.25	1
1	11874	2612	3	2011-08-16	lanispl	boolean	-1	p	t	f	1	-0.5	1
1	11874	2612	4	2011-08-16	lanpltrusted	boolean	-1	p	t	f	1	-0.5	1
1	11874	2612	5	2011-08-16	lanplcallfoid	oid	-1	p	t	f	4	-0.5	1
1	11874	2612	6	2011-08-16	laninline	oid	-1	p	t	f	4	-0.5	1
1	11874	2612	7	2011-08-16	lanvalidator	oid	-1	p	t	f	4	-1	1
1	11874	2612	8	2011-08-16	lanacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	2995	1	2011-08-16	lomowner	oid	-1	p	t	f	\N	\N	\N
1	11874	2995	2	2011-08-16	lomacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	2613	1	2011-08-16	loid	oid	-1	p	t	f	\N	\N	\N
1	11874	2613	2	2011-08-16	pageno	integer	-1	p	t	f	\N	\N	\N
1	11874	2613	3	2011-08-16	data	bytea	-1	x	f	f	\N	\N	\N
1	11874	2600	1	2011-08-16	aggfnoid	regproc	-1	p	t	f	4	-1	0.76783198
1	11874	2600	2	2011-08-16	aggtransfn	regproc	-1	p	t	f	4	-0.621849	0.377745
1	11874	2600	3	2011-08-16	aggfinalfn	regproc	-1	p	t	f	4	-0.21848699	0.65095401
1	11874	2600	4	2011-08-16	aggsortop	oid	-1	p	t	f	4	-0.344538	0.0269264
1	11874	2600	5	2011-08-16	aggtranstype	oid	-1	p	t	f	4	-0.235294	0.0940108
1	11874	2600	6	2011-08-16	agginitval	text	-1	x	f	f	8	5	-0.13890301
1	11874	2619	1	2011-08-16	starelid	oid	-1	p	t	f	\N	\N	\N
1	11874	2619	2	2011-08-16	staattnum	smallint	-1	p	t	f	\N	\N	\N
1	11874	2619	3	2011-08-16	stainherit	boolean	-1	p	t	f	\N	\N	\N
1	11874	2619	4	2011-08-16	stanullfrac	real	-1	p	t	f	\N	\N	\N
1	11874	2619	5	2011-08-16	stawidth	integer	-1	p	t	f	\N	\N	\N
1	11874	2619	6	2011-08-16	stadistinct	real	-1	p	t	f	\N	\N	\N
1	11874	2619	7	2011-08-16	stakind1	smallint	-1	p	t	f	\N	\N	\N
1	11874	2619	8	2011-08-16	stakind2	smallint	-1	p	t	f	\N	\N	\N
1	11874	2619	9	2011-08-16	stakind3	smallint	-1	p	t	f	\N	\N	\N
1	11874	2619	10	2011-08-16	stakind4	smallint	-1	p	t	f	\N	\N	\N
1	11874	2619	11	2011-08-16	staop1	oid	-1	p	t	f	\N	\N	\N
1	11874	2619	12	2011-08-16	staop2	oid	-1	p	t	f	\N	\N	\N
1	11874	2619	13	2011-08-16	staop3	oid	-1	p	t	f	\N	\N	\N
1	11874	2619	14	2011-08-16	staop4	oid	-1	p	t	f	\N	\N	\N
1	11874	2619	15	2011-08-16	stanumbers1	real[]	-1	x	f	f	\N	\N	\N
1	11874	2619	16	2011-08-16	stanumbers2	real[]	-1	x	f	f	\N	\N	\N
1	11874	2619	17	2011-08-16	stanumbers3	real[]	-1	x	f	f	\N	\N	\N
1	11874	2619	18	2011-08-16	stanumbers4	real[]	-1	x	f	f	\N	\N	\N
1	11874	2619	19	2011-08-16	stavalues1	anyarray	-1	x	f	f	\N	\N	\N
1	11874	2619	20	2011-08-16	stavalues2	anyarray	-1	x	f	f	\N	\N	\N
1	11874	2619	21	2011-08-16	stavalues3	anyarray	-1	x	f	f	\N	\N	\N
1	11874	2619	22	2011-08-16	stavalues4	anyarray	-1	x	f	f	\N	\N	\N
1	11874	2618	1	2011-08-16	rulename	name	-1	p	t	f	64	3	0.891976
1	11874	2618	2	2011-08-16	ev_class	oid	-1	p	t	f	4	-0.976744	0.98898101
1	11874	2618	3	2011-08-16	ev_attr	smallint	-1	p	t	f	2	1	1
1	11874	2618	4	2011-08-16	ev_type	"char"	-1	p	t	f	1	2	0.89216501
1	11874	2618	5	2011-08-16	ev_enabled	"char"	-1	p	t	f	1	1	1
1	11874	2618	6	2011-08-16	is_instead	boolean	-1	p	t	f	1	2	0.999717
1	11874	2618	7	2011-08-16	ev_qual	text	-1	x	f	f	6	2	0.93886501
1	11874	2618	8	2011-08-16	ev_action	text	-1	x	f	f	\N	\N	\N
1	11874	2620	1	2011-08-16	tgrelid	oid	-1	p	t	f	\N	\N	\N
1	11874	2620	2	2011-08-16	tgname	name	-1	p	t	f	\N	\N	\N
1	11874	2620	3	2011-08-16	tgfoid	oid	-1	p	t	f	\N	\N	\N
1	11874	2620	4	2011-08-16	tgtype	smallint	-1	p	t	f	\N	\N	\N
1	11874	2620	5	2011-08-16	tgenabled	"char"	-1	p	t	f	\N	\N	\N
1	11874	2620	6	2011-08-16	tgisinternal	boolean	-1	p	t	f	\N	\N	\N
1	11874	2620	7	2011-08-16	tgconstrrelid	oid	-1	p	t	f	\N	\N	\N
1	11874	2620	8	2011-08-16	tgconstrindid	oid	-1	p	t	f	\N	\N	\N
1	11874	2620	9	2011-08-16	tgconstraint	oid	-1	p	t	f	\N	\N	\N
1	11874	2620	10	2011-08-16	tgdeferrable	boolean	-1	p	t	f	\N	\N	\N
1	11874	2620	11	2011-08-16	tginitdeferred	boolean	-1	p	t	f	\N	\N	\N
1	11874	2620	12	2011-08-16	tgnargs	smallint	-1	p	t	f	\N	\N	\N
1	11874	2620	13	2011-08-16	tgattr	int2vector	-1	p	t	f	\N	\N	\N
1	11874	2620	14	2011-08-16	tgargs	bytea	-1	x	f	f	\N	\N	\N
1	11874	2620	15	2011-08-16	tgqual	text	-1	x	f	f	\N	\N	\N
1	11874	2609	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	0.85105699
1	11874	2609	2	2011-08-16	classoid	oid	-1	p	t	f	4	10	0.88925201
1	11874	2609	3	2011-08-16	objsubid	integer	-1	p	t	f	4	1	1
1	11874	2609	4	2011-08-16	description	text	-1	x	f	f	24	-0.53037798	-0.0348415
1	11874	2605	1	2011-08-16	castsource	oid	-1	p	t	f	4	-0.204188	0.26684299
1	11874	2605	2	2011-08-16	casttarget	oid	-1	p	t	f	4	-0.209424	0.204877
1	11874	2605	3	2011-08-16	castfunc	oid	-1	p	t	f	4	-0.52879602	0.378775
1	11874	2605	4	2011-08-16	castcontext	"char"	-1	p	t	f	1	3	0.231236
1	11874	2605	5	2011-08-16	castmethod	"char"	-1	p	t	f	1	2	0.70448101
1	11874	3501	1	2011-08-16	enumtypid	oid	-1	p	t	f	\N	\N	\N
1	11874	3501	2	2011-08-16	enumlabel	name	-1	p	t	f	\N	\N	\N
1	11874	2615	1	2011-08-16	nspname	name	-1	p	t	f	64	-1	-0.25714299
1	11874	2615	2	2011-08-16	nspowner	oid	-1	p	t	f	4	-0.166667	1
1	11874	2615	3	2011-08-16	nspacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	2607	1	2011-08-16	conname	name	-1	p	t	f	64	-1	0.034192
1	11874	2607	2	2011-08-16	connamespace	oid	-1	p	t	f	4	1	1
1	11874	2607	3	2011-08-16	conowner	oid	-1	p	t	f	4	1	1
1	11874	2607	4	2011-08-16	conforencoding	integer	-1	p	t	f	4	-0.31818199	-0.055730902
1	11874	2607	5	2011-08-16	contoencoding	integer	-1	p	t	f	4	-0.31818199	-0.063536704
1	11874	2607	6	2011-08-16	conproc	regproc	-1	p	t	f	4	-0.66666698	0.9946
1	11874	2607	7	2011-08-16	condefault	boolean	-1	p	t	f	1	1	1
1	11874	2608	1	2011-08-16	classid	oid	-1	p	t	f	4	11	0.985008
1	11874	2608	2	2011-08-16	objid	oid	-1	p	t	f	4	436	0.99999899
1	11874	2608	3	2011-08-16	objsubid	integer	-1	p	t	f	4	83	0.99429399
1	11874	2608	4	2011-08-16	refclassid	oid	-1	p	t	f	4	15	0.221155
1	11874	2608	5	2011-08-16	refobjid	oid	-1	p	t	f	4	-0.78687602	0.818048
1	11874	2608	6	2011-08-16	refobjsubid	integer	-1	p	t	f	4	23	0.99375898
1	11874	2608	7	2011-08-16	deptype	"char"	-1	p	t	f	1	4	-0.138106
1	11874	1262	1	2011-08-16	datname	name	-1	p	t	f	64	-1	\N
1	11874	1262	2	2011-08-16	datdba	oid	-1	p	t	f	4	-1	\N
1	11874	1262	3	2011-08-16	encoding	integer	-1	p	t	f	4	-1	\N
1	11874	1262	4	2011-08-16	datcollate	name	-1	p	t	f	64	-1	\N
1	11874	1262	5	2011-08-16	datctype	name	-1	p	t	f	64	-1	\N
1	11874	1262	6	2011-08-16	datistemplate	boolean	-1	p	t	f	1	-1	\N
1	11874	1262	7	2011-08-16	datallowconn	boolean	-1	p	t	f	1	-1	\N
1	11874	1262	8	2011-08-16	datconnlimit	integer	-1	p	t	f	4	-1	\N
1	11874	1262	9	2011-08-16	datlastsysoid	oid	-1	p	t	f	4	-1	\N
1	11874	1262	10	2011-08-16	datfrozenxid	xid	-1	p	t	f	4	-1	\N
1	11874	1262	11	2011-08-16	dattablespace	oid	-1	p	t	f	4	-1	\N
1	11874	1262	12	2011-08-16	datacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	2964	1	2011-08-16	setdatabase	oid	-1	p	t	f	\N	\N	\N
1	11874	2964	2	2011-08-16	setrole	oid	-1	p	t	f	\N	\N	\N
1	11874	2964	3	2011-08-16	setconfig	text[]	-1	x	f	f	\N	\N	\N
1	11874	1213	1	2011-08-16	spcname	name	-1	p	t	f	64	-1	1
1	11874	1213	2	2011-08-16	spcowner	oid	-1	p	t	f	4	-0.5	1
1	11874	1213	3	2011-08-16	spclocation	text	-1	x	f	f	1	-0.5	1
1	11874	1213	4	2011-08-16	spcacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	1213	5	2011-08-16	spcoptions	text[]	-1	x	f	f	0	0	\N
1	11874	1136	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	-0.071428597
1	11874	1136	2	2011-08-16	tmpltrusted	boolean	-1	p	t	f	1	-0.25	-0.26190501
1	11874	1136	3	2011-08-16	tmpldbacreate	boolean	-1	p	t	f	1	-0.25	-0.26190501
1	11874	1136	4	2011-08-16	tmplhandler	text	-1	x	f	f	20	-0.75	-0.071428597
1	11874	1136	5	2011-08-16	tmplinline	text	-1	x	f	f	23	-0.5	0.657143
1	11874	1136	6	2011-08-16	tmplvalidator	text	-1	x	f	f	17	-0.25	-0.5
1	11874	1136	7	2011-08-16	tmpllibrary	text	-1	x	f	f	15	-0.75	0
1	11874	1136	8	2011-08-16	tmplacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	1260	1	2011-08-16	rolname	name	-1	p	t	f	64	-1	\N
1	11874	1260	2	2011-08-16	rolsuper	boolean	-1	p	t	f	1	-1	\N
1	11874	1260	3	2011-08-16	rolinherit	boolean	-1	p	t	f	1	-1	\N
1	11874	1260	4	2011-08-16	rolcreaterole	boolean	-1	p	t	f	1	-1	\N
1	11874	1260	5	2011-08-16	rolcreatedb	boolean	-1	p	t	f	1	-1	\N
1	11874	1260	6	2011-08-16	rolcatupdate	boolean	-1	p	t	f	1	-1	\N
1	11874	1260	7	2011-08-16	rolcanlogin	boolean	-1	p	t	f	1	-1	\N
1	11874	1260	8	2011-08-16	rolconnlimit	integer	-1	p	t	f	4	-1	\N
1	11874	1260	9	2011-08-16	rolpassword	text	-1	x	f	f	0	0	\N
1	11874	1260	10	2011-08-16	rolvaliduntil	timestamp with time zone	-1	p	f	f	8	0	\N
1	11874	1261	1	2011-08-16	roleid	oid	-1	p	t	f	\N	\N	\N
1	11874	1261	2	2011-08-16	member	oid	-1	p	t	f	\N	\N	\N
1	11874	1261	3	2011-08-16	grantor	oid	-1	p	t	f	\N	\N	\N
1	11874	1261	4	2011-08-16	admin_option	boolean	-1	p	t	f	\N	\N	\N
1	11874	1214	1	2011-08-16	dbid	oid	-1	p	t	f	4	-1	\N
1	11874	1214	2	2011-08-16	classid	oid	-1	p	t	f	4	-1	\N
1	11874	1214	3	2011-08-16	objid	oid	-1	p	t	f	4	-1	\N
1	11874	1214	4	2011-08-16	objsubid	integer	-1	p	t	f	4	-1	\N
1	11874	1214	5	2011-08-16	refclassid	oid	-1	p	t	f	4	-1	\N
1	11874	1214	6	2011-08-16	refobjid	oid	-1	p	t	f	4	-1	\N
1	11874	1214	7	2011-08-16	deptype	"char"	-1	p	t	f	1	-1	\N
1	11874	2396	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	\N
1	11874	2396	2	2011-08-16	classoid	oid	-1	p	t	f	4	-1	\N
1	11874	2396	3	2011-08-16	description	text	-1	x	f	f	26	-1	\N
1	11874	3602	1	2011-08-16	cfgname	name	-1	p	t	f	64	-1	0.77058798
1	11874	3602	2	2011-08-16	cfgnamespace	oid	-1	p	t	f	4	1	1
1	11874	3602	3	2011-08-16	cfgowner	oid	-1	p	t	f	4	1	1
1	11874	3602	4	2011-08-16	cfgparser	oid	-1	p	t	f	4	1	1
1	11874	3603	1	2011-08-16	mapcfg	oid	-1	p	t	f	4	16	1
1	11874	3603	2	2011-08-16	maptokentype	integer	-1	p	t	f	4	19	0.0575522
1	11874	3603	3	2011-08-16	mapseqno	integer	-1	p	t	f	4	1	1
1	11874	3603	4	2011-08-16	mapdict	oid	-1	p	t	f	4	16	0.67357898
1	11874	3600	1	2011-08-16	dictname	name	-1	p	t	f	64	-1	0.77058798
1	11874	3600	2	2011-08-16	dictnamespace	oid	-1	p	t	f	4	1	1
1	11874	3600	3	2011-08-16	dictowner	oid	-1	p	t	f	4	1	1
1	11874	3600	4	2011-08-16	dicttemplate	oid	-1	p	t	f	4	-0.125	1
1	11874	3600	5	2011-08-16	dictinitoption	text	-1	x	f	f	42	-1	1
1	11874	3601	1	2011-08-16	prsname	name	-1	p	t	f	64	-1	\N
1	11874	3601	2	2011-08-16	prsnamespace	oid	-1	p	t	f	4	-1	\N
1	11874	3601	3	2011-08-16	prsstart	regproc	-1	p	t	f	4	-1	\N
1	11874	3601	4	2011-08-16	prstoken	regproc	-1	p	t	f	4	-1	\N
1	11874	3601	5	2011-08-16	prsend	regproc	-1	p	t	f	4	-1	\N
1	11874	3601	6	2011-08-16	prsheadline	regproc	-1	p	t	f	4	-1	\N
1	11874	3601	7	2011-08-16	prslextype	regproc	-1	p	t	f	4	-1	\N
1	11874	3764	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	0.30000001
1	11874	3764	2	2011-08-16	tmplnamespace	oid	-1	p	t	f	4	-0.2	1
1	11874	3764	3	2011-08-16	tmplinit	regproc	-1	p	t	f	4	-1	1
1	11874	3764	4	2011-08-16	tmpllexize	regproc	-1	p	t	f	4	-1	1
1	11874	2328	1	2011-08-16	fdwname	name	-1	p	t	f	\N	\N	\N
1	11874	2328	2	2011-08-16	fdwowner	oid	-1	p	t	f	\N	\N	\N
1	11874	2328	3	2011-08-16	fdwvalidator	oid	-1	p	t	f	\N	\N	\N
1	11874	2328	4	2011-08-16	fdwacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	2328	5	2011-08-16	fdwoptions	text[]	-1	x	f	f	\N	\N	\N
1	11874	1417	1	2011-08-16	srvname	name	-1	p	t	f	\N	\N	\N
1	11874	1417	2	2011-08-16	srvowner	oid	-1	p	t	f	\N	\N	\N
1	11874	1417	3	2011-08-16	srvfdw	oid	-1	p	t	f	\N	\N	\N
1	11874	1417	4	2011-08-16	srvtype	text	-1	x	f	f	\N	\N	\N
1	11874	1417	5	2011-08-16	srvversion	text	-1	x	f	f	\N	\N	\N
1	11874	1417	6	2011-08-16	srvacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	1417	7	2011-08-16	srvoptions	text[]	-1	x	f	f	\N	\N	\N
1	11874	1418	1	2011-08-16	umuser	oid	-1	p	t	f	\N	\N	\N
1	11874	1418	2	2011-08-16	umserver	oid	-1	p	t	f	\N	\N	\N
1	11874	1418	3	2011-08-16	umoptions	text[]	-1	x	f	f	\N	\N	\N
1	11874	826	1	2011-08-16	defaclrole	oid	-1	p	t	f	\N	\N	\N
1	11874	826	2	2011-08-16	defaclnamespace	oid	-1	p	t	f	\N	\N	\N
1	11874	826	3	2011-08-16	defaclobjtype	"char"	-1	p	t	f	\N	\N	\N
1	11874	826	4	2011-08-16	defaclacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	11874	2830	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2830	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2830	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2832	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2832	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2832	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2834	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2834	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2834	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2836	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2836	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2836	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2838	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2838	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2838	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2840	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2840	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2840	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2336	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2336	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2336	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2844	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2844	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2844	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2846	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2846	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2846	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	2966	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	2966	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	2966	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	11454	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	5	-0.70769203	0.983832
1	11874	11454	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	27	-0.70923102	0.37094799
1	11874	11454	3	2011-08-16	sub_feature_id	information_schema.character_data	-1	x	f	f	1	18	0.042565402
1	11874	11454	4	2011-08-16	sub_feature_name	information_schema.character_data	-1	x	f	f	9	-0.292308	0.04391
1	11874	11454	5	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	2	0.057943199
1	11874	11454	6	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
1	11874	11454	7	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	11	0.97430003
1	11874	11456	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	11456	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	11456	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	11459	1	2011-08-16	implementation_info_id	information_schema.character_data	-1	x	f	f	3	-1	0.55244797
1	11874	11459	2	2011-08-16	implementation_info_name	information_schema.character_data	-1	x	f	f	17	-1	0.85314697
1	11874	11459	3	2011-08-16	integer_value	information_schema.cardinal_number	-1	p	f	f	4	-0.33333299	0.2
1	11874	11459	4	2011-08-16	character_value	information_schema.character_data	-1	x	f	f	4	-0.33333299	0.035714298
1	11874	11459	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	29	-1	-0.178571
1	11874	11461	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	11461	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	11461	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	11464	1	2011-08-16	sql_language_source	information_schema.character_data	-1	x	f	f	9	-0.25	1
1	11874	11464	2	2011-08-16	sql_language_year	information_schema.character_data	-1	x	f	f	5	-0.5	1
1	11874	11464	3	2011-08-16	sql_language_conformance	information_schema.character_data	-1	x	f	f	5	-0.25	1
1	11874	11464	4	2011-08-16	sql_language_integrity	information_schema.character_data	-1	x	f	f	0	0	\N
1	11874	11464	5	2011-08-16	sql_language_implementation	information_schema.character_data	-1	x	f	f	0	0	\N
1	11874	11464	6	2011-08-16	sql_language_binding_style	information_schema.character_data	-1	x	f	f	8	-0.5	0.80000001
1	11874	11464	7	2011-08-16	sql_language_programming_language	information_schema.character_data	-1	x	f	f	2	-0.25	1
1	11874	11466	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	11466	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	11466	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	11469	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	7	-1	1
1	11874	11469	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	15	-1	-0.090909101
1	11874	11469	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.2	0.563636
1	11874	11469	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
1	11874	11469	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	4	-0.40000001	0.69696999
1	11874	11471	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	11471	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	11471	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	11474	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	2	-1	-0.0666667
1	11874	11474	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	38	-1	0.783333
1	11874	11474	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.222222	1
1	11874	11474	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
1	11874	11474	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	-0.111111	1
1	11874	11476	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	11476	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	11476	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	11479	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	4	-1	0.26581001
1	11874	11479	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	28	-1	0.479249
1	11874	11479	3	2011-08-16	supported_value	information_schema.cardinal_number	-1	p	f	f	4	-0.173913	0.55087698
1	11874	11479	4	2011-08-16	comments	information_schema.character_data	-1	x	f	f	43	1	1
1	11874	11481	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	11481	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	11481	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	11874	11484	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
1	11874	11484	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	\N	\N	\N
1	11874	11484	3	2011-08-16	profile_id	information_schema.character_data	-1	x	f	f	\N	\N	\N
1	11874	11484	4	2011-08-16	required_value	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
1	11874	11484	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	\N	\N	\N
1	11874	11486	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	11874	11486	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	11874	11486	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	1255	1	2011-08-16	proname	name	-1	p	t	f	64	-0.81640798	0.22111399
1	16384	1255	2	2011-08-16	pronamespace	oid	-1	p	t	f	4	2	0.99999899
1	16384	1255	3	2011-08-16	proowner	oid	-1	p	t	f	4	1	1
1	16384	1255	4	2011-08-16	prolang	oid	-1	p	t	f	4	3	0.96455598
1	16384	1255	5	2011-08-16	procost	real	-1	p	t	f	4	5	0.99089301
1	16384	1255	6	2011-08-16	prorows	real	-1	p	t	f	4	10	0.98529398
1	16384	1255	7	2011-08-16	provariadic	oid	-1	p	t	f	4	1	1
1	16384	1255	8	2011-08-16	proisagg	boolean	-1	p	t	f	1	2	0.96914399
1	16384	1255	9	2011-08-16	proiswindow	boolean	-1	p	t	f	1	2	0.99989802
1	16384	1255	10	2011-08-16	prosecdef	boolean	-1	p	t	f	1	1	1
1	16384	1255	11	2011-08-16	proisstrict	boolean	-1	p	t	f	1	2	0.78557801
1	16384	1255	12	2011-08-16	proretset	boolean	-1	p	t	f	1	2	0.98536599
1	16384	1255	13	2011-08-16	provolatile	"char"	-1	p	t	f	1	3	0.75940597
1	16384	1255	14	2011-08-16	pronargs	smallint	-1	p	t	f	2	8	0.35542199
1	16384	1255	15	2011-08-16	pronargdefaults	smallint	-1	p	t	f	2	2	0.99999398
1	16384	1255	16	2011-08-16	prorettype	oid	-1	p	t	f	4	78	0.33539501
1	16384	1255	17	2011-08-16	proargtypes	oidvector	-1	p	t	f	31	-0.16585401	0.131202
1	16384	1255	18	2011-08-16	proallargtypes	oid[]	-1	x	f	f	44	-1	0.20609801
1	16384	1255	19	2011-08-16	proargmodes	"char"[]	-1	x	f	f	26	14	-0.47713199
1	16384	1255	20	2011-08-16	proargnames	text[]	-1	x	f	f	80	30	0.222289
1	16384	1255	21	2011-08-16	proargdefaults	text	-1	x	f	f	141	-1	\N
1	16384	1255	22	2011-08-16	prosrc	text	-1	x	f	f	16	-0.89490002	0.16789301
1	16384	1255	23	2011-08-16	probin	text	-1	x	f	f	23	28	0.83976901
1	16384	1255	24	2011-08-16	proconfig	text[]	-1	x	f	f	0	0	\N
1	16384	1255	25	2011-08-16	proacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	1247	1	2011-08-16	typname	name	-1	p	t	f	64	-1	0.3863
1	16384	1247	2	2011-08-16	typnamespace	oid	-1	p	t	f	4	3	0.99332702
1	16384	1247	3	2011-08-16	typowner	oid	-1	p	t	f	4	1	1
1	16384	1247	4	2011-08-16	typlen	smallint	-1	p	t	f	2	12	0.381313
1	16384	1247	5	2011-08-16	typbyval	boolean	-1	p	t	f	1	2	0.58123201
1	16384	1247	6	2011-08-16	typtype	"char"	-1	p	t	f	1	4	0.90001601
1	16384	1247	7	2011-08-16	typcategory	"char"	-1	p	t	f	1	13	0.16261899
1	16384	1247	8	2011-08-16	typispreferred	boolean	-1	p	t	f	1	2	0.87831497
1	16384	1247	9	2011-08-16	typisdefined	boolean	-1	p	t	f	1	1	1
1	16384	1247	10	2011-08-16	typdelim	"char"	-1	p	t	f	1	2	0.96987098
1	16384	1247	11	2011-08-16	typrelid	oid	-1	p	t	f	4	-0.53310102	0.96858799
1	16384	1247	12	2011-08-16	typelem	oid	-1	p	t	f	4	-0.209059	0.211162
1	16384	1247	13	2011-08-16	typarray	oid	-1	p	t	f	4	-0.209059	0.20806199
1	16384	1247	14	2011-08-16	typinput	regproc	-1	p	t	f	4	-0.250871	0.82135397
1	16384	1247	15	2011-08-16	typoutput	regproc	-1	p	t	f	4	-0.24738701	0.80345798
1	16384	1247	16	2011-08-16	typreceive	regproc	-1	p	t	f	4	-0.21254399	0.195701
1	16384	1247	17	2011-08-16	typsend	regproc	-1	p	t	f	4	-0.209059	0.18141501
1	16384	1247	18	2011-08-16	typmodin	regproc	-1	p	t	f	4	11	0.788158
1	16384	1247	19	2011-08-16	typmodout	regproc	-1	p	t	f	4	11	0.78836697
1	16384	1247	20	2011-08-16	typanalyze	regproc	-1	p	t	f	4	2	0.99200302
1	16384	1247	21	2011-08-16	typalign	"char"	-1	p	t	f	1	4	0.024560301
1	16384	1247	22	2011-08-16	typstorage	"char"	-1	p	t	f	1	3	0.93686098
1	16384	1247	23	2011-08-16	typnotnull	boolean	-1	p	t	f	1	1	1
1	16384	1247	24	2011-08-16	typbasetype	oid	-1	p	t	f	4	4	0.99479401
1	16384	1247	25	2011-08-16	typtypmod	integer	-1	p	t	f	4	3	0.99804902
1	16384	1247	26	2011-08-16	typndims	integer	-1	p	t	f	4	1	1
1	16384	1247	27	2011-08-16	typdefaultbin	text	-1	x	f	f	441	-1	\N
1	16384	1247	28	2011-08-16	typdefault	text	-1	x	f	f	43	-1	\N
1	16384	1249	1	2011-08-16	attrelid	oid	-1	p	t	f	4	-0.130749	0.93989903
1	16384	1249	2	2011-08-16	attname	name	-1	p	t	f	64	-0.38294601	0.0036946801
1	16384	1249	3	2011-08-16	atttypid	oid	-1	p	t	f	4	34	0.60096002
1	16384	1249	4	2011-08-16	attstattarget	integer	-1	p	t	f	4	2	0.42826101
1	16384	1249	5	2011-08-16	attlen	smallint	-1	p	t	f	2	9	-0.064016797
1	16384	1249	6	2011-08-16	attnum	smallint	-1	p	t	f	2	89	0.25127199
1	16384	1249	7	2011-08-16	attndims	integer	-1	p	t	f	4	2	0.91384
1	16384	1249	8	2011-08-16	attcacheoff	integer	-1	p	t	f	4	1	1
1	16384	1249	9	2011-08-16	atttypmod	integer	-1	p	t	f	4	1	1
1	16384	1249	10	2011-08-16	attbyval	boolean	-1	p	t	f	1	2	0.065347202
1	16384	1249	11	2011-08-16	attstorage	"char"	-1	p	t	f	1	3	0.89757299
1	16384	1249	12	2011-08-16	attalign	"char"	-1	p	t	f	1	4	0.66951603
1	16384	1249	13	2011-08-16	attnotnull	boolean	-1	p	t	f	1	2	-0.17658401
1	16384	1249	14	2011-08-16	atthasdef	boolean	-1	p	t	f	1	1	1
1	16384	1249	15	2011-08-16	attisdropped	boolean	-1	p	t	f	1	1	1
1	16384	1249	16	2011-08-16	attislocal	boolean	-1	p	t	f	1	1	1
1	16384	1249	17	2011-08-16	attinhcount	integer	-1	p	t	f	4	1	1
1	16384	1249	18	2011-08-16	attacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	1249	19	2011-08-16	attoptions	text[]	-1	x	f	f	0	0	\N
1	16384	1259	1	2011-08-16	relname	name	-1	p	t	f	64	-1	0.069593102
1	16384	1259	2	2011-08-16	relnamespace	oid	-1	p	t	f	4	3	0.76032102
1	16384	1259	3	2011-08-16	reltype	oid	-1	p	t	f	4	-0.604743	0.80476397
1	16384	1259	4	2011-08-16	reloftype	oid	-1	p	t	f	4	1	1
1	16384	1259	5	2011-08-16	relowner	oid	-1	p	t	f	4	1	1
1	16384	1259	6	2011-08-16	relam	oid	-1	p	t	f	4	2	-0.158712
1	16384	1259	7	2011-08-16	relfilenode	oid	-1	p	t	f	4	-0.84189701	0.68083
1	16384	1259	8	2011-08-16	reltablespace	oid	-1	p	t	f	4	2	0.69740403
1	16384	1259	9	2011-08-16	relpages	integer	-1	p	t	f	4	14	-0.23059499
1	16384	1259	10	2011-08-16	reltuples	real	-1	p	t	f	4	20	0.289942
1	16384	1259	11	2011-08-16	reltoastrelid	oid	-1	p	t	f	4	18	0.93993998
1	16384	1259	12	2011-08-16	reltoastidxid	oid	-1	p	t	f	4	18	0.78708398
1	16384	1259	13	2011-08-16	relhasindex	boolean	-1	p	t	f	1	2	0.68597198
1	16384	1259	14	2011-08-16	relisshared	boolean	-1	p	t	f	1	2	0.69740403
1	16384	1259	15	2011-08-16	relistemp	boolean	-1	p	t	f	1	1	1
1	16384	1259	16	2011-08-16	relkind	"char"	-1	p	t	f	1	4	0.78044999
1	16384	1259	17	2011-08-16	relnatts	smallint	-1	p	t	f	2	-0.106719	0.61371702
1	16384	1259	18	2011-08-16	relchecks	smallint	-1	p	t	f	2	1	1
1	16384	1259	19	2011-08-16	relhasoids	boolean	-1	p	t	f	1	2	0.89500701
1	16384	1259	20	2011-08-16	relhaspkey	boolean	-1	p	t	f	1	2	0.99300599
1	16384	1259	21	2011-08-16	relhasexclusion	boolean	-1	p	t	f	1	1	1
1	16384	1259	22	2011-08-16	relhasrules	boolean	-1	p	t	f	1	2	0.90881997
1	16384	1259	23	2011-08-16	relhastriggers	boolean	-1	p	t	f	1	1	1
1	16384	1259	24	2011-08-16	relhassubclass	boolean	-1	p	t	f	1	1	1
1	16384	1259	25	2011-08-16	relfrozenxid	xid	-1	p	t	f	4	3	\N
1	16384	1259	26	2011-08-16	relacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	1259	27	2011-08-16	reloptions	text[]	-1	x	f	f	0	0	\N
1	16384	2604	1	2011-08-16	adrelid	oid	-1	p	t	f	\N	\N	\N
1	16384	2604	2	2011-08-16	adnum	smallint	-1	p	t	f	\N	\N	\N
1	16384	2604	3	2011-08-16	adbin	text	-1	x	f	f	\N	\N	\N
1	16384	2604	4	2011-08-16	adsrc	text	-1	x	f	f	\N	\N	\N
1	16384	2606	1	2011-08-16	conname	name	-1	p	t	f	64	-1	1
1	16384	2606	2	2011-08-16	connamespace	oid	-1	p	t	f	4	-0.5	1
1	16384	2606	3	2011-08-16	contype	"char"	-1	p	t	f	1	-0.5	1
1	16384	2606	4	2011-08-16	condeferrable	boolean	-1	p	t	f	1	-0.5	1
1	16384	2606	5	2011-08-16	condeferred	boolean	-1	p	t	f	1	-0.5	1
1	16384	2606	6	2011-08-16	conrelid	oid	-1	p	t	f	4	-0.5	1
1	16384	2606	7	2011-08-16	contypid	oid	-1	p	t	f	4	-1	1
1	16384	2606	8	2011-08-16	conindid	oid	-1	p	t	f	4	-0.5	1
1	16384	2606	9	2011-08-16	confrelid	oid	-1	p	t	f	4	-0.5	1
1	16384	2606	10	2011-08-16	confupdtype	"char"	-1	p	t	f	1	-0.5	1
1	16384	2606	11	2011-08-16	confdeltype	"char"	-1	p	t	f	1	-0.5	1
1	16384	2606	12	2011-08-16	confmatchtype	"char"	-1	p	t	f	1	-0.5	1
1	16384	2606	13	2011-08-16	conislocal	boolean	-1	p	t	f	1	-0.5	1
1	16384	2606	14	2011-08-16	coninhcount	integer	-1	p	t	f	4	-0.5	1
1	16384	2606	15	2011-08-16	conkey	smallint[]	-1	x	f	f	0	0	\N
1	16384	2606	16	2011-08-16	confkey	smallint[]	-1	x	f	f	0	0	\N
1	16384	2606	17	2011-08-16	conpfeqop	oid[]	-1	x	f	f	0	0	\N
1	16384	2606	18	2011-08-16	conppeqop	oid[]	-1	x	f	f	0	0	\N
1	16384	2606	19	2011-08-16	conffeqop	oid[]	-1	x	f	f	0	0	\N
1	16384	2606	20	2011-08-16	conexclop	oid[]	-1	x	f	f	0	0	\N
1	16384	2606	21	2011-08-16	conbin	text	-1	x	f	f	498	-1	1
1	16384	2606	22	2011-08-16	consrc	text	-1	x	f	f	52	-1	-1
1	16384	2611	1	2011-08-16	inhrelid	oid	-1	p	t	f	\N	\N	\N
1	16384	2611	2	2011-08-16	inhparent	oid	-1	p	t	f	\N	\N	\N
1	16384	2611	3	2011-08-16	inhseqno	integer	-1	p	t	f	\N	\N	\N
1	16384	2610	1	2011-08-16	indexrelid	oid	-1	p	t	f	4	-1	0.23200899
1	16384	2610	2	2011-08-16	indrelid	oid	-1	p	t	f	4	-0.60395998	0.20038401
1	16384	2610	3	2011-08-16	indnatts	smallint	-1	p	t	f	2	4	0.32738501
1	16384	2610	4	2011-08-16	indisunique	boolean	-1	p	t	f	1	2	0.865789
1	16384	2610	5	2011-08-16	indisprimary	boolean	-1	p	t	f	1	2	0.54012799
1	16384	2610	6	2011-08-16	indimmediate	boolean	-1	p	t	f	1	1	1
1	16384	2610	7	2011-08-16	indisclustered	boolean	-1	p	t	f	1	1	1
1	16384	2610	8	2011-08-16	indisvalid	boolean	-1	p	t	f	1	1	1
1	16384	2610	9	2011-08-16	indcheckxmin	boolean	-1	p	t	f	1	1	1
1	16384	2610	10	2011-08-16	indisready	boolean	-1	p	t	f	1	1	1
1	16384	2610	11	2011-08-16	indkey	int2vector	-1	p	t	f	27	-0.17821801	0.13946401
1	16384	2610	12	2011-08-16	indclass	oidvector	-1	p	t	f	30	-0.16831701	0.163238
1	16384	2610	13	2011-08-16	indoption	int2vector	-1	p	t	f	27	4	0.32738501
1	16384	2610	14	2011-08-16	indexprs	text	-1	x	f	f	0	0	\N
1	16384	2610	15	2011-08-16	indpred	text	-1	x	f	f	0	0	\N
1	16384	2617	1	2011-08-16	oprname	name	-1	p	t	f	64	67	0.195003
1	16384	2617	2	2011-08-16	oprnamespace	oid	-1	p	t	f	4	1	1
1	16384	2617	3	2011-08-16	oprowner	oid	-1	p	t	f	4	1	1
1	16384	2617	4	2011-08-16	oprkind	"char"	-1	p	t	f	1	3	0.880925
1	16384	2617	5	2011-08-16	oprcanmerge	boolean	-1	p	t	f	1	2	0.85338402
1	16384	2617	6	2011-08-16	oprcanhash	boolean	-1	p	t	f	1	2	0.84083802
1	16384	2617	7	2011-08-16	oprleft	oid	-1	p	t	f	4	50	0.48025399
1	16384	2617	8	2011-08-16	oprright	oid	-1	p	t	f	4	49	0.52515399
1	16384	2617	9	2011-08-16	oprresult	oid	-1	p	t	f	4	29	0.46232501
1	16384	2617	10	2011-08-16	oprcom	oid	-1	p	t	f	4	-0.66524798	0.556723
1	16384	2617	11	2011-08-16	oprnegate	oid	-1	p	t	f	4	-0.500709	0.483677
1	16384	2617	12	2011-08-16	oprcode	regproc	-1	p	t	f	4	-0.96879399	0.798738
1	16384	2617	13	2011-08-16	oprrest	regproc	-1	p	t	f	4	17	0.25424901
1	16384	2617	14	2011-08-16	oprjoin	regproc	-1	p	t	f	4	17	0.25424901
1	16384	2753	1	2011-08-16	opfmethod	oid	-1	p	t	f	4	4	0.72316402
1	16384	2753	2	2011-08-16	opfname	name	-1	p	t	f	64	-0.62318802	0.44504899
1	16384	2753	3	2011-08-16	opfnamespace	oid	-1	p	t	f	4	1	1
1	16384	2753	4	2011-08-16	opfowner	oid	-1	p	t	f	4	1	1
1	16384	2616	1	2011-08-16	opcmethod	oid	-1	p	t	f	4	4	0.80080801
1	16384	2616	2	2011-08-16	opcname	name	-1	p	t	f	64	-0.69642901	-0.197919
1	16384	2616	3	2011-08-16	opcnamespace	oid	-1	p	t	f	4	1	1
1	16384	2616	4	2011-08-16	opcowner	oid	-1	p	t	f	4	1	1
1	16384	2616	5	2011-08-16	opcfamily	oid	-1	p	t	f	4	-0.61607099	0.94508302
1	16384	2616	6	2011-08-16	opcintype	oid	-1	p	t	f	4	-0.65178603	0.43914601
1	16384	2616	7	2011-08-16	opcdefault	boolean	-1	p	t	f	1	2	0.89918703
1	16384	2616	8	2011-08-16	opckeytype	oid	-1	p	t	f	4	-0.30357099	0.913315
1	16384	2601	1	2011-08-16	amname	name	-1	p	t	f	64	-1	0.2
1	16384	2601	2	2011-08-16	amstrategies	smallint	-1	p	t	f	2	-0.75	-0.80000001
1	16384	2601	3	2011-08-16	amsupport	smallint	-1	p	t	f	2	-0.75	0.80000001
1	16384	2601	4	2011-08-16	amcanorder	boolean	-1	p	t	f	1	-0.5	-0.2
1	16384	2601	5	2011-08-16	amcanbackward	boolean	-1	p	t	f	1	-0.5	-0.60000002
1	16384	2601	6	2011-08-16	amcanunique	boolean	-1	p	t	f	1	-0.5	-0.2
1	16384	2601	7	2011-08-16	amcanmulticol	boolean	-1	p	t	f	1	-0.5	0.80000001
1	16384	2601	8	2011-08-16	amoptionalkey	boolean	-1	p	t	f	1	-0.5	0.80000001
1	16384	2601	9	2011-08-16	amindexnulls	boolean	-1	p	t	f	1	-0.5	0
1	16384	2601	10	2011-08-16	amsearchnulls	boolean	-1	p	t	f	1	-0.5	0
1	16384	2601	11	2011-08-16	amstorage	boolean	-1	p	t	f	1	-0.5	1
1	16384	2601	12	2011-08-16	amclusterable	boolean	-1	p	t	f	1	-0.5	0
1	16384	2601	13	2011-08-16	amkeytype	oid	-1	p	t	f	4	-0.5	0.40000001
1	16384	2601	14	2011-08-16	aminsert	regproc	-1	p	t	f	4	-1	1
1	16384	2601	15	2011-08-16	ambeginscan	regproc	-1	p	t	f	4	-1	1
1	16384	2601	16	2011-08-16	amgettuple	regproc	-1	p	t	f	4	-1	-0.2
1	16384	2601	17	2011-08-16	amgetbitmap	regproc	-1	p	t	f	4	-1	1
1	16384	2601	18	2011-08-16	amrescan	regproc	-1	p	t	f	4	-1	1
1	16384	2601	19	2011-08-16	amendscan	regproc	-1	p	t	f	4	-1	1
1	16384	2601	20	2011-08-16	ammarkpos	regproc	-1	p	t	f	4	-1	1
1	16384	2601	21	2011-08-16	amrestrpos	regproc	-1	p	t	f	4	-1	1
1	16384	2601	22	2011-08-16	ambuild	regproc	-1	p	t	f	4	-1	1
1	16384	2601	23	2011-08-16	ambulkdelete	regproc	-1	p	t	f	4	-1	1
1	16384	2601	24	2011-08-16	amvacuumcleanup	regproc	-1	p	t	f	4	-1	0.80000001
1	16384	2601	25	2011-08-16	amcostestimate	regproc	-1	p	t	f	4	-1	0.40000001
1	16384	2601	26	2011-08-16	amoptions	regproc	-1	p	t	f	4	-1	1
1	16384	2602	1	2011-08-16	amopfamily	oid	-1	p	t	f	4	-0.193277	0.55816799
1	16384	2602	2	2011-08-16	amoplefttype	oid	-1	p	t	f	4	-0.120448	0.446706
1	16384	2602	3	2011-08-16	amoprighttype	oid	-1	p	t	f	4	-0.120448	0.446367
1	16384	2602	4	2011-08-16	amopstrategy	smallint	-1	p	t	f	2	20	0.243038
1	16384	2602	5	2011-08-16	amopopr	oid	-1	p	t	f	4	-0.88795501	0.319125
1	16384	2602	6	2011-08-16	amopmethod	oid	-1	p	t	f	4	4	0.97767502
1	16384	2603	1	2011-08-16	amprocfamily	oid	-1	p	t	f	4	-0.27599999	0.79009902
1	16384	2603	2	2011-08-16	amproclefttype	oid	-1	p	t	f	4	-0.292	0.37271899
1	16384	2603	3	2011-08-16	amprocrighttype	oid	-1	p	t	f	4	-0.292	0.37262201
1	16384	2603	4	2011-08-16	amprocnum	smallint	-1	p	t	f	2	7	0.680502
1	16384	2603	5	2011-08-16	amproc	regproc	-1	p	t	f	4	-0.43599999	0.481682
1	16384	2612	1	2011-08-16	lanname	name	-1	p	t	f	64	-1	0.60000002
1	16384	2612	2	2011-08-16	lanowner	oid	-1	p	t	f	4	-0.25	1
1	16384	2612	3	2011-08-16	lanispl	boolean	-1	p	t	f	1	-0.5	1
1	16384	2612	4	2011-08-16	lanpltrusted	boolean	-1	p	t	f	1	-0.5	1
1	16384	2612	5	2011-08-16	lanplcallfoid	oid	-1	p	t	f	4	-0.5	1
1	16384	2612	6	2011-08-16	laninline	oid	-1	p	t	f	4	-0.5	1
1	16384	2612	7	2011-08-16	lanvalidator	oid	-1	p	t	f	4	-1	1
1	16384	2612	8	2011-08-16	lanacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	2995	1	2011-08-16	lomowner	oid	-1	p	t	f	\N	\N	\N
1	16384	2995	2	2011-08-16	lomacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	2613	1	2011-08-16	loid	oid	-1	p	t	f	\N	\N	\N
1	16384	2613	2	2011-08-16	pageno	integer	-1	p	t	f	\N	\N	\N
1	16384	2613	3	2011-08-16	data	bytea	-1	x	f	f	\N	\N	\N
1	16384	2600	1	2011-08-16	aggfnoid	regproc	-1	p	t	f	4	-1	0.76783198
1	16384	2600	2	2011-08-16	aggtransfn	regproc	-1	p	t	f	4	-0.621849	0.377745
1	16384	2600	3	2011-08-16	aggfinalfn	regproc	-1	p	t	f	4	-0.21848699	0.65095401
1	16384	2600	4	2011-08-16	aggsortop	oid	-1	p	t	f	4	-0.344538	0.0269264
1	16384	2600	5	2011-08-16	aggtranstype	oid	-1	p	t	f	4	-0.235294	0.0940108
1	16384	2600	6	2011-08-16	agginitval	text	-1	x	f	f	8	5	-0.13890301
1	16384	2619	1	2011-08-16	starelid	oid	-1	p	t	f	\N	\N	\N
1	16384	2619	2	2011-08-16	staattnum	smallint	-1	p	t	f	\N	\N	\N
1	16384	2619	3	2011-08-16	stainherit	boolean	-1	p	t	f	\N	\N	\N
1	16384	2619	4	2011-08-16	stanullfrac	real	-1	p	t	f	\N	\N	\N
1	16384	2619	5	2011-08-16	stawidth	integer	-1	p	t	f	\N	\N	\N
1	16384	2619	6	2011-08-16	stadistinct	real	-1	p	t	f	\N	\N	\N
1	16384	2619	7	2011-08-16	stakind1	smallint	-1	p	t	f	\N	\N	\N
1	16384	2619	8	2011-08-16	stakind2	smallint	-1	p	t	f	\N	\N	\N
1	16384	2619	9	2011-08-16	stakind3	smallint	-1	p	t	f	\N	\N	\N
1	16384	2619	10	2011-08-16	stakind4	smallint	-1	p	t	f	\N	\N	\N
1	16384	2619	11	2011-08-16	staop1	oid	-1	p	t	f	\N	\N	\N
1	16384	2619	12	2011-08-16	staop2	oid	-1	p	t	f	\N	\N	\N
1	16384	2619	13	2011-08-16	staop3	oid	-1	p	t	f	\N	\N	\N
1	16384	2619	14	2011-08-16	staop4	oid	-1	p	t	f	\N	\N	\N
1	16384	2619	15	2011-08-16	stanumbers1	real[]	-1	x	f	f	\N	\N	\N
1	16384	2619	16	2011-08-16	stanumbers2	real[]	-1	x	f	f	\N	\N	\N
1	16384	2619	17	2011-08-16	stanumbers3	real[]	-1	x	f	f	\N	\N	\N
1	16384	2619	18	2011-08-16	stanumbers4	real[]	-1	x	f	f	\N	\N	\N
1	16384	2619	19	2011-08-16	stavalues1	anyarray	-1	x	f	f	\N	\N	\N
1	16384	2619	20	2011-08-16	stavalues2	anyarray	-1	x	f	f	\N	\N	\N
1	16384	2619	21	2011-08-16	stavalues3	anyarray	-1	x	f	f	\N	\N	\N
1	16384	2619	22	2011-08-16	stavalues4	anyarray	-1	x	f	f	\N	\N	\N
1	16384	2618	1	2011-08-16	rulename	name	-1	p	t	f	64	3	0.891976
1	16384	2618	2	2011-08-16	ev_class	oid	-1	p	t	f	4	-0.976744	0.98898101
1	16384	2618	3	2011-08-16	ev_attr	smallint	-1	p	t	f	2	1	1
1	16384	2618	4	2011-08-16	ev_type	"char"	-1	p	t	f	1	2	0.89216501
1	16384	2618	5	2011-08-16	ev_enabled	"char"	-1	p	t	f	1	1	1
1	16384	2618	6	2011-08-16	is_instead	boolean	-1	p	t	f	1	2	0.999717
1	16384	2618	7	2011-08-16	ev_qual	text	-1	x	f	f	6	2	0.93886501
1	16384	2618	8	2011-08-16	ev_action	text	-1	x	f	f	\N	\N	\N
1	16384	2620	1	2011-08-16	tgrelid	oid	-1	p	t	f	\N	\N	\N
1	16384	2620	2	2011-08-16	tgname	name	-1	p	t	f	\N	\N	\N
1	16384	2620	3	2011-08-16	tgfoid	oid	-1	p	t	f	\N	\N	\N
1	16384	2620	4	2011-08-16	tgtype	smallint	-1	p	t	f	\N	\N	\N
1	16384	2620	5	2011-08-16	tgenabled	"char"	-1	p	t	f	\N	\N	\N
1	16384	2620	6	2011-08-16	tgisinternal	boolean	-1	p	t	f	\N	\N	\N
1	16384	2620	7	2011-08-16	tgconstrrelid	oid	-1	p	t	f	\N	\N	\N
1	16384	2620	8	2011-08-16	tgconstrindid	oid	-1	p	t	f	\N	\N	\N
1	16384	2620	9	2011-08-16	tgconstraint	oid	-1	p	t	f	\N	\N	\N
1	16384	2620	10	2011-08-16	tgdeferrable	boolean	-1	p	t	f	\N	\N	\N
1	16384	2620	11	2011-08-16	tginitdeferred	boolean	-1	p	t	f	\N	\N	\N
1	16384	2620	12	2011-08-16	tgnargs	smallint	-1	p	t	f	\N	\N	\N
1	16384	2620	13	2011-08-16	tgattr	int2vector	-1	p	t	f	\N	\N	\N
1	16384	2620	14	2011-08-16	tgargs	bytea	-1	x	f	f	\N	\N	\N
1	16384	2620	15	2011-08-16	tgqual	text	-1	x	f	f	\N	\N	\N
1	16384	2609	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	0.85105699
1	16384	2609	2	2011-08-16	classoid	oid	-1	p	t	f	4	10	0.88925201
1	16384	2609	3	2011-08-16	objsubid	integer	-1	p	t	f	4	1	1
1	16384	2609	4	2011-08-16	description	text	-1	x	f	f	24	-0.53037798	-0.0348415
1	16384	2605	1	2011-08-16	castsource	oid	-1	p	t	f	4	-0.204188	0.26684299
1	16384	2605	2	2011-08-16	casttarget	oid	-1	p	t	f	4	-0.209424	0.204877
1	16384	2605	3	2011-08-16	castfunc	oid	-1	p	t	f	4	-0.52879602	0.378775
1	16384	2605	4	2011-08-16	castcontext	"char"	-1	p	t	f	1	3	0.231236
1	16384	2605	5	2011-08-16	castmethod	"char"	-1	p	t	f	1	2	0.70448101
1	16384	3501	1	2011-08-16	enumtypid	oid	-1	p	t	f	\N	\N	\N
1	16384	3501	2	2011-08-16	enumlabel	name	-1	p	t	f	\N	\N	\N
1	16384	2615	1	2011-08-16	nspname	name	-1	p	t	f	64	-1	-0.25714299
1	16384	2615	2	2011-08-16	nspowner	oid	-1	p	t	f	4	-0.166667	1
1	16384	2615	3	2011-08-16	nspacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	2607	1	2011-08-16	conname	name	-1	p	t	f	64	-1	0.034192
1	16384	2607	2	2011-08-16	connamespace	oid	-1	p	t	f	4	1	1
1	16384	2607	3	2011-08-16	conowner	oid	-1	p	t	f	4	1	1
1	16384	2607	4	2011-08-16	conforencoding	integer	-1	p	t	f	4	-0.31818199	-0.055730902
1	16384	2607	5	2011-08-16	contoencoding	integer	-1	p	t	f	4	-0.31818199	-0.063536704
1	16384	2607	6	2011-08-16	conproc	regproc	-1	p	t	f	4	-0.66666698	0.9946
1	16384	2607	7	2011-08-16	condefault	boolean	-1	p	t	f	1	1	1
1	16384	2608	1	2011-08-16	classid	oid	-1	p	t	f	4	11	0.985008
1	16384	2608	2	2011-08-16	objid	oid	-1	p	t	f	4	436	0.99999899
1	16384	2608	3	2011-08-16	objsubid	integer	-1	p	t	f	4	83	0.99429399
1	16384	2608	4	2011-08-16	refclassid	oid	-1	p	t	f	4	15	0.221155
1	16384	2608	5	2011-08-16	refobjid	oid	-1	p	t	f	4	-0.78687602	0.818048
1	16384	2608	6	2011-08-16	refobjsubid	integer	-1	p	t	f	4	23	0.99375898
1	16384	2608	7	2011-08-16	deptype	"char"	-1	p	t	f	1	4	-0.138106
1	16384	1262	1	2011-08-16	datname	name	-1	p	t	f	64	-1	\N
1	16384	1262	2	2011-08-16	datdba	oid	-1	p	t	f	4	-1	\N
1	16384	1262	3	2011-08-16	encoding	integer	-1	p	t	f	4	-1	\N
1	16384	1262	4	2011-08-16	datcollate	name	-1	p	t	f	64	-1	\N
1	16384	1262	5	2011-08-16	datctype	name	-1	p	t	f	64	-1	\N
1	16384	1262	6	2011-08-16	datistemplate	boolean	-1	p	t	f	1	-1	\N
1	16384	1262	7	2011-08-16	datallowconn	boolean	-1	p	t	f	1	-1	\N
1	16384	1262	8	2011-08-16	datconnlimit	integer	-1	p	t	f	4	-1	\N
1	16384	1262	9	2011-08-16	datlastsysoid	oid	-1	p	t	f	4	-1	\N
1	16384	1262	10	2011-08-16	datfrozenxid	xid	-1	p	t	f	4	-1	\N
1	16384	1262	11	2011-08-16	dattablespace	oid	-1	p	t	f	4	-1	\N
1	16384	1262	12	2011-08-16	datacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	2964	1	2011-08-16	setdatabase	oid	-1	p	t	f	\N	\N	\N
1	16384	2964	2	2011-08-16	setrole	oid	-1	p	t	f	\N	\N	\N
1	16384	2964	3	2011-08-16	setconfig	text[]	-1	x	f	f	\N	\N	\N
1	16384	1213	1	2011-08-16	spcname	name	-1	p	t	f	64	-1	1
1	16384	1213	2	2011-08-16	spcowner	oid	-1	p	t	f	4	-0.5	1
1	16384	1213	3	2011-08-16	spclocation	text	-1	x	f	f	1	-0.5	1
1	16384	1213	4	2011-08-16	spcacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	1213	5	2011-08-16	spcoptions	text[]	-1	x	f	f	0	0	\N
1	16384	1136	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	-0.071428597
1	16384	1136	2	2011-08-16	tmpltrusted	boolean	-1	p	t	f	1	-0.25	-0.26190501
1	16384	1136	3	2011-08-16	tmpldbacreate	boolean	-1	p	t	f	1	-0.25	-0.26190501
1	16384	1136	4	2011-08-16	tmplhandler	text	-1	x	f	f	20	-0.75	-0.071428597
1	16384	1136	5	2011-08-16	tmplinline	text	-1	x	f	f	23	-0.5	0.657143
1	16384	1136	6	2011-08-16	tmplvalidator	text	-1	x	f	f	17	-0.25	-0.5
1	16384	1136	7	2011-08-16	tmpllibrary	text	-1	x	f	f	15	-0.75	0
1	16384	1136	8	2011-08-16	tmplacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	1260	1	2011-08-16	rolname	name	-1	p	t	f	64	-1	\N
1	16384	1260	2	2011-08-16	rolsuper	boolean	-1	p	t	f	1	-1	\N
1	16384	1260	3	2011-08-16	rolinherit	boolean	-1	p	t	f	1	-1	\N
1	16384	1260	4	2011-08-16	rolcreaterole	boolean	-1	p	t	f	1	-1	\N
1	16384	1260	5	2011-08-16	rolcreatedb	boolean	-1	p	t	f	1	-1	\N
1	16384	1260	6	2011-08-16	rolcatupdate	boolean	-1	p	t	f	1	-1	\N
1	16384	1260	7	2011-08-16	rolcanlogin	boolean	-1	p	t	f	1	-1	\N
1	16384	1260	8	2011-08-16	rolconnlimit	integer	-1	p	t	f	4	-1	\N
1	16384	1260	9	2011-08-16	rolpassword	text	-1	x	f	f	0	0	\N
1	16384	1260	10	2011-08-16	rolvaliduntil	timestamp with time zone	-1	p	f	f	8	0	\N
1	16384	1261	1	2011-08-16	roleid	oid	-1	p	t	f	\N	\N	\N
1	16384	1261	2	2011-08-16	member	oid	-1	p	t	f	\N	\N	\N
1	16384	1261	3	2011-08-16	grantor	oid	-1	p	t	f	\N	\N	\N
1	16384	1261	4	2011-08-16	admin_option	boolean	-1	p	t	f	\N	\N	\N
1	16384	1214	1	2011-08-16	dbid	oid	-1	p	t	f	4	-1	\N
1	16384	1214	2	2011-08-16	classid	oid	-1	p	t	f	4	-1	\N
1	16384	1214	3	2011-08-16	objid	oid	-1	p	t	f	4	-1	\N
1	16384	1214	4	2011-08-16	objsubid	integer	-1	p	t	f	4	-1	\N
1	16384	1214	5	2011-08-16	refclassid	oid	-1	p	t	f	4	-1	\N
1	16384	1214	6	2011-08-16	refobjid	oid	-1	p	t	f	4	-1	\N
1	16384	1214	7	2011-08-16	deptype	"char"	-1	p	t	f	1	-1	\N
1	16384	2396	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	\N
1	16384	2396	2	2011-08-16	classoid	oid	-1	p	t	f	4	-1	\N
1	16384	2396	3	2011-08-16	description	text	-1	x	f	f	26	-1	\N
1	16384	3602	1	2011-08-16	cfgname	name	-1	p	t	f	64	-1	0.77058798
1	16384	3602	2	2011-08-16	cfgnamespace	oid	-1	p	t	f	4	1	1
1	16384	3602	3	2011-08-16	cfgowner	oid	-1	p	t	f	4	1	1
1	16384	3602	4	2011-08-16	cfgparser	oid	-1	p	t	f	4	1	1
1	16384	3603	1	2011-08-16	mapcfg	oid	-1	p	t	f	4	16	1
1	16384	3603	2	2011-08-16	maptokentype	integer	-1	p	t	f	4	19	0.0575522
1	16384	3603	3	2011-08-16	mapseqno	integer	-1	p	t	f	4	1	1
1	16384	3603	4	2011-08-16	mapdict	oid	-1	p	t	f	4	16	0.67357898
1	16384	3600	1	2011-08-16	dictname	name	-1	p	t	f	64	-1	0.77058798
1	16384	3600	2	2011-08-16	dictnamespace	oid	-1	p	t	f	4	1	1
1	16384	3600	3	2011-08-16	dictowner	oid	-1	p	t	f	4	1	1
1	16384	3600	4	2011-08-16	dicttemplate	oid	-1	p	t	f	4	-0.125	1
1	16384	3600	5	2011-08-16	dictinitoption	text	-1	x	f	f	42	-1	1
1	16384	3601	1	2011-08-16	prsname	name	-1	p	t	f	64	-1	\N
1	16384	3601	2	2011-08-16	prsnamespace	oid	-1	p	t	f	4	-1	\N
1	16384	3601	3	2011-08-16	prsstart	regproc	-1	p	t	f	4	-1	\N
1	16384	3601	4	2011-08-16	prstoken	regproc	-1	p	t	f	4	-1	\N
1	16384	3601	5	2011-08-16	prsend	regproc	-1	p	t	f	4	-1	\N
1	16384	3601	6	2011-08-16	prsheadline	regproc	-1	p	t	f	4	-1	\N
1	16384	3601	7	2011-08-16	prslextype	regproc	-1	p	t	f	4	-1	\N
1	16384	3764	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	0.30000001
1	16384	3764	2	2011-08-16	tmplnamespace	oid	-1	p	t	f	4	-0.2	1
1	16384	3764	3	2011-08-16	tmplinit	regproc	-1	p	t	f	4	-1	1
1	16384	3764	4	2011-08-16	tmpllexize	regproc	-1	p	t	f	4	-1	1
1	16384	2328	1	2011-08-16	fdwname	name	-1	p	t	f	\N	\N	\N
1	16384	2328	2	2011-08-16	fdwowner	oid	-1	p	t	f	\N	\N	\N
1	16384	2328	3	2011-08-16	fdwvalidator	oid	-1	p	t	f	\N	\N	\N
1	16384	2328	4	2011-08-16	fdwacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	2328	5	2011-08-16	fdwoptions	text[]	-1	x	f	f	\N	\N	\N
1	16384	1417	1	2011-08-16	srvname	name	-1	p	t	f	\N	\N	\N
1	16384	1417	2	2011-08-16	srvowner	oid	-1	p	t	f	\N	\N	\N
1	16384	1417	3	2011-08-16	srvfdw	oid	-1	p	t	f	\N	\N	\N
1	16384	1417	4	2011-08-16	srvtype	text	-1	x	f	f	\N	\N	\N
1	16384	1417	5	2011-08-16	srvversion	text	-1	x	f	f	\N	\N	\N
1	16384	1417	6	2011-08-16	srvacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	1417	7	2011-08-16	srvoptions	text[]	-1	x	f	f	\N	\N	\N
1	16384	1418	1	2011-08-16	umuser	oid	-1	p	t	f	\N	\N	\N
1	16384	1418	2	2011-08-16	umserver	oid	-1	p	t	f	\N	\N	\N
1	16384	1418	3	2011-08-16	umoptions	text[]	-1	x	f	f	\N	\N	\N
1	16384	826	1	2011-08-16	defaclrole	oid	-1	p	t	f	\N	\N	\N
1	16384	826	2	2011-08-16	defaclnamespace	oid	-1	p	t	f	\N	\N	\N
1	16384	826	3	2011-08-16	defaclobjtype	"char"	-1	p	t	f	\N	\N	\N
1	16384	826	4	2011-08-16	defaclacl	aclitem[]	-1	x	f	f	\N	\N	\N
1	16384	2830	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2830	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2830	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2832	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2832	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2832	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2834	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2834	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2834	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2836	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2836	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2836	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2838	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2838	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2838	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2840	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2840	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2840	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2336	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2336	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2336	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2844	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2844	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2844	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2846	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2846	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2846	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	2966	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	2966	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	2966	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	11454	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	5	-0.70769203	0.983832
1	16384	11454	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	27	-0.70923102	0.37094799
1	16384	11454	3	2011-08-16	sub_feature_id	information_schema.character_data	-1	x	f	f	1	18	0.042565402
1	16384	11454	4	2011-08-16	sub_feature_name	information_schema.character_data	-1	x	f	f	9	-0.292308	0.04391
1	16384	11454	5	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	2	0.057943199
1	16384	11454	6	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
1	16384	11454	7	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	11	0.97430003
1	16384	11456	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	11456	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	11456	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	11459	1	2011-08-16	implementation_info_id	information_schema.character_data	-1	x	f	f	3	-1	0.55244797
1	16384	11459	2	2011-08-16	implementation_info_name	information_schema.character_data	-1	x	f	f	17	-1	0.85314697
1	16384	11459	3	2011-08-16	integer_value	information_schema.cardinal_number	-1	p	f	f	4	-0.33333299	0.2
1	16384	11459	4	2011-08-16	character_value	information_schema.character_data	-1	x	f	f	4	-0.33333299	0.035714298
1	16384	11459	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	29	-1	-0.178571
1	16384	11461	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	11461	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	11461	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	11464	1	2011-08-16	sql_language_source	information_schema.character_data	-1	x	f	f	9	-0.25	1
1	16384	11464	2	2011-08-16	sql_language_year	information_schema.character_data	-1	x	f	f	5	-0.5	1
1	16384	11464	3	2011-08-16	sql_language_conformance	information_schema.character_data	-1	x	f	f	5	-0.25	1
1	16384	11464	4	2011-08-16	sql_language_integrity	information_schema.character_data	-1	x	f	f	0	0	\N
1	16384	11464	5	2011-08-16	sql_language_implementation	information_schema.character_data	-1	x	f	f	0	0	\N
1	16384	11464	6	2011-08-16	sql_language_binding_style	information_schema.character_data	-1	x	f	f	8	-0.5	0.80000001
1	16384	11464	7	2011-08-16	sql_language_programming_language	information_schema.character_data	-1	x	f	f	2	-0.25	1
1	16384	11466	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	11466	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	11466	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	11469	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	7	-1	1
1	16384	11469	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	15	-1	-0.090909101
1	16384	11469	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.2	0.563636
1	16384	11469	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
1	16384	11469	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	4	-0.40000001	0.69696999
1	16384	11471	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	11471	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	11471	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	11474	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	2	-1	-0.0666667
1	16384	11474	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	38	-1	0.783333
1	16384	11474	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.222222	1
1	16384	11474	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
1	16384	11474	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	-0.111111	1
1	16384	11476	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	11476	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	11476	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	11479	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	4	-1	0.26581001
1	16384	11479	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	28	-1	0.479249
1	16384	11479	3	2011-08-16	supported_value	information_schema.cardinal_number	-1	p	f	f	4	-0.173913	0.55087698
1	16384	11479	4	2011-08-16	comments	information_schema.character_data	-1	x	f	f	43	1	1
1	16384	11481	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	11481	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	11481	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	11484	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
1	16384	11484	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	\N	\N	\N
1	16384	11484	3	2011-08-16	profile_id	information_schema.character_data	-1	x	f	f	\N	\N	\N
1	16384	11484	4	2011-08-16	required_value	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
1	16384	11484	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	\N	\N	\N
1	16384	11486	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
1	16384	11486	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
1	16384	11486	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
1	16384	16385	1	2011-08-16	bid	integer	-1	p	t	f	4	-1	1
1	16384	16385	2	2011-08-16	bbalance	integer	-1	p	f	f	4	1	1
1	16384	16385	3	2011-08-16	filler	character(88)	-1	x	f	f	0	0	\N
1	16384	16388	1	2011-08-16	tid	integer	-1	p	t	f	4	-1	1
1	16384	16388	2	2011-08-16	bid	integer	-1	p	f	f	4	10	1
1	16384	16388	3	2011-08-16	tbalance	integer	-1	p	f	f	4	1	1
1	16384	16388	4	2011-08-16	filler	character(84)	-1	x	f	f	0	0	\N
1	16384	16391	1	2011-08-16	aid	integer	-1	p	t	f	4	-1	1
1	16384	16391	2	2011-08-16	bid	integer	-1	p	f	f	4	10	1
1	16384	16391	3	2011-08-16	abalance	integer	-1	p	f	f	4	1	1
1	16384	16391	4	2011-08-16	filler	character(84)	-1	x	f	f	85	1	1
1	16384	16394	1	2011-08-16	tid	integer	-1	p	f	f	\N	\N	\N
1	16384	16394	2	2011-08-16	bid	integer	-1	p	f	f	\N	\N	\N
1	16384	16394	3	2011-08-16	aid	integer	-1	p	f	f	\N	\N	\N
1	16384	16394	4	2011-08-16	delta	integer	-1	p	f	f	\N	\N	\N
1	16384	16394	5	2011-08-16	mtime	timestamp without time zone	-1	p	f	f	\N	\N	\N
1	16384	16394	6	2011-08-16	filler	character(22)	-1	x	f	f	\N	\N	\N
2	11874	1255	1	2011-08-16	proname	name	-1	p	t	f	64	-0.81640798	0.22111399
2	11874	1255	2	2011-08-16	pronamespace	oid	-1	p	t	f	4	2	0.99999899
2	11874	1255	3	2011-08-16	proowner	oid	-1	p	t	f	4	1	1
2	11874	1255	4	2011-08-16	prolang	oid	-1	p	t	f	4	3	0.96455598
2	11874	1255	5	2011-08-16	procost	real	-1	p	t	f	4	5	0.99089301
2	11874	1255	6	2011-08-16	prorows	real	-1	p	t	f	4	10	0.98529398
2	11874	1255	7	2011-08-16	provariadic	oid	-1	p	t	f	4	1	1
2	11874	1255	8	2011-08-16	proisagg	boolean	-1	p	t	f	1	2	0.96914399
2	11874	1255	9	2011-08-16	proiswindow	boolean	-1	p	t	f	1	2	0.99989802
2	11874	1255	10	2011-08-16	prosecdef	boolean	-1	p	t	f	1	1	1
2	11874	1255	11	2011-08-16	proisstrict	boolean	-1	p	t	f	1	2	0.78557801
2	11874	1255	12	2011-08-16	proretset	boolean	-1	p	t	f	1	2	0.98536599
2	11874	1255	13	2011-08-16	provolatile	"char"	-1	p	t	f	1	3	0.75940597
2	11874	1255	14	2011-08-16	pronargs	smallint	-1	p	t	f	2	8	0.35542199
2	11874	1255	15	2011-08-16	pronargdefaults	smallint	-1	p	t	f	2	2	0.99999398
2	11874	1255	16	2011-08-16	prorettype	oid	-1	p	t	f	4	78	0.33539501
2	11874	1255	17	2011-08-16	proargtypes	oidvector	-1	p	t	f	31	-0.16585401	0.131202
2	11874	1255	18	2011-08-16	proallargtypes	oid[]	-1	x	f	f	44	-1	0.20609801
2	11874	1255	19	2011-08-16	proargmodes	"char"[]	-1	x	f	f	26	14	-0.47713199
2	11874	1255	20	2011-08-16	proargnames	text[]	-1	x	f	f	80	30	0.222289
2	11874	1255	21	2011-08-16	proargdefaults	text	-1	x	f	f	141	-1	\N
2	11874	1255	22	2011-08-16	prosrc	text	-1	x	f	f	16	-0.89490002	0.16789301
2	11874	1255	23	2011-08-16	probin	text	-1	x	f	f	23	28	0.83976901
2	11874	1255	24	2011-08-16	proconfig	text[]	-1	x	f	f	0	0	\N
2	11874	1255	25	2011-08-16	proacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	1247	1	2011-08-16	typname	name	-1	p	t	f	64	-1	0.3863
2	11874	1247	2	2011-08-16	typnamespace	oid	-1	p	t	f	4	3	0.99332702
2	11874	1247	3	2011-08-16	typowner	oid	-1	p	t	f	4	1	1
2	11874	1247	4	2011-08-16	typlen	smallint	-1	p	t	f	2	12	0.381313
2	11874	1247	5	2011-08-16	typbyval	boolean	-1	p	t	f	1	2	0.58123201
2	11874	1247	6	2011-08-16	typtype	"char"	-1	p	t	f	1	4	0.90001601
2	11874	1247	7	2011-08-16	typcategory	"char"	-1	p	t	f	1	13	0.16261899
2	11874	1247	8	2011-08-16	typispreferred	boolean	-1	p	t	f	1	2	0.87831497
2	11874	1247	9	2011-08-16	typisdefined	boolean	-1	p	t	f	1	1	1
2	11874	1247	10	2011-08-16	typdelim	"char"	-1	p	t	f	1	2	0.96987098
2	11874	1247	11	2011-08-16	typrelid	oid	-1	p	t	f	4	-0.53310102	0.96858799
2	11874	1247	12	2011-08-16	typelem	oid	-1	p	t	f	4	-0.209059	0.211162
2	11874	1247	13	2011-08-16	typarray	oid	-1	p	t	f	4	-0.209059	0.20806199
2	11874	1247	14	2011-08-16	typinput	regproc	-1	p	t	f	4	-0.250871	0.82135397
2	11874	1247	15	2011-08-16	typoutput	regproc	-1	p	t	f	4	-0.24738701	0.80345798
2	11874	1247	16	2011-08-16	typreceive	regproc	-1	p	t	f	4	-0.21254399	0.195701
2	11874	1247	17	2011-08-16	typsend	regproc	-1	p	t	f	4	-0.209059	0.18141501
2	11874	1247	18	2011-08-16	typmodin	regproc	-1	p	t	f	4	11	0.788158
2	11874	1247	19	2011-08-16	typmodout	regproc	-1	p	t	f	4	11	0.78836697
2	11874	1247	20	2011-08-16	typanalyze	regproc	-1	p	t	f	4	2	0.99200302
2	11874	1247	21	2011-08-16	typalign	"char"	-1	p	t	f	1	4	0.024560301
2	11874	1247	22	2011-08-16	typstorage	"char"	-1	p	t	f	1	3	0.93686098
2	11874	1247	23	2011-08-16	typnotnull	boolean	-1	p	t	f	1	1	1
2	11874	1247	24	2011-08-16	typbasetype	oid	-1	p	t	f	4	4	0.99479401
2	11874	1247	25	2011-08-16	typtypmod	integer	-1	p	t	f	4	3	0.99804902
2	11874	1247	26	2011-08-16	typndims	integer	-1	p	t	f	4	1	1
2	11874	1247	27	2011-08-16	typdefaultbin	text	-1	x	f	f	441	-1	\N
2	11874	1247	28	2011-08-16	typdefault	text	-1	x	f	f	43	-1	\N
2	11874	1249	1	2011-08-16	attrelid	oid	-1	p	t	f	4	-0.130749	0.93989903
2	11874	1249	2	2011-08-16	attname	name	-1	p	t	f	64	-0.38294601	0.0036946801
2	11874	1249	3	2011-08-16	atttypid	oid	-1	p	t	f	4	34	0.60096002
2	11874	1249	4	2011-08-16	attstattarget	integer	-1	p	t	f	4	2	0.42826101
2	11874	1249	5	2011-08-16	attlen	smallint	-1	p	t	f	2	9	-0.064016797
2	11874	1249	6	2011-08-16	attnum	smallint	-1	p	t	f	2	89	0.25127199
2	11874	1249	7	2011-08-16	attndims	integer	-1	p	t	f	4	2	0.91384
2	11874	1249	8	2011-08-16	attcacheoff	integer	-1	p	t	f	4	1	1
2	11874	1249	9	2011-08-16	atttypmod	integer	-1	p	t	f	4	1	1
2	11874	1249	10	2011-08-16	attbyval	boolean	-1	p	t	f	1	2	0.065347202
2	11874	1249	11	2011-08-16	attstorage	"char"	-1	p	t	f	1	3	0.89757299
2	11874	1249	12	2011-08-16	attalign	"char"	-1	p	t	f	1	4	0.66951603
2	11874	1249	13	2011-08-16	attnotnull	boolean	-1	p	t	f	1	2	-0.17658401
2	11874	1249	14	2011-08-16	atthasdef	boolean	-1	p	t	f	1	1	1
2	11874	1249	15	2011-08-16	attisdropped	boolean	-1	p	t	f	1	1	1
2	11874	1249	16	2011-08-16	attislocal	boolean	-1	p	t	f	1	1	1
2	11874	1249	17	2011-08-16	attinhcount	integer	-1	p	t	f	4	1	1
2	11874	1249	18	2011-08-16	attacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	1249	19	2011-08-16	attoptions	text[]	-1	x	f	f	0	0	\N
2	11874	1259	1	2011-08-16	relname	name	-1	p	t	f	64	-1	0.069593102
2	11874	1259	2	2011-08-16	relnamespace	oid	-1	p	t	f	4	3	0.76032102
2	11874	1259	3	2011-08-16	reltype	oid	-1	p	t	f	4	-0.604743	0.80476397
2	11874	1259	4	2011-08-16	reloftype	oid	-1	p	t	f	4	1	1
2	11874	1259	5	2011-08-16	relowner	oid	-1	p	t	f	4	1	1
2	11874	1259	6	2011-08-16	relam	oid	-1	p	t	f	4	2	-0.158712
2	11874	1259	7	2011-08-16	relfilenode	oid	-1	p	t	f	4	-0.84189701	0.68083
2	11874	1259	8	2011-08-16	reltablespace	oid	-1	p	t	f	4	2	0.69740403
2	11874	1259	9	2011-08-16	relpages	integer	-1	p	t	f	4	14	-0.23059499
2	11874	1259	10	2011-08-16	reltuples	real	-1	p	t	f	4	20	0.289942
2	11874	1259	11	2011-08-16	reltoastrelid	oid	-1	p	t	f	4	18	0.93993998
2	11874	1259	12	2011-08-16	reltoastidxid	oid	-1	p	t	f	4	18	0.78708398
2	11874	1259	13	2011-08-16	relhasindex	boolean	-1	p	t	f	1	2	0.68597198
2	11874	1259	14	2011-08-16	relisshared	boolean	-1	p	t	f	1	2	0.69740403
2	11874	1259	15	2011-08-16	relistemp	boolean	-1	p	t	f	1	1	1
2	11874	1259	16	2011-08-16	relkind	"char"	-1	p	t	f	1	4	0.78044999
2	11874	1259	17	2011-08-16	relnatts	smallint	-1	p	t	f	2	-0.106719	0.61371702
2	11874	1259	18	2011-08-16	relchecks	smallint	-1	p	t	f	2	1	1
2	11874	1259	19	2011-08-16	relhasoids	boolean	-1	p	t	f	1	2	0.89500701
2	11874	1259	20	2011-08-16	relhaspkey	boolean	-1	p	t	f	1	2	0.99300599
2	11874	1259	21	2011-08-16	relhasexclusion	boolean	-1	p	t	f	1	1	1
2	11874	1259	22	2011-08-16	relhasrules	boolean	-1	p	t	f	1	2	0.90881997
2	11874	1259	23	2011-08-16	relhastriggers	boolean	-1	p	t	f	1	1	1
2	11874	1259	24	2011-08-16	relhassubclass	boolean	-1	p	t	f	1	1	1
2	11874	1259	25	2011-08-16	relfrozenxid	xid	-1	p	t	f	4	3	\N
2	11874	1259	26	2011-08-16	relacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	1259	27	2011-08-16	reloptions	text[]	-1	x	f	f	0	0	\N
2	11874	2604	1	2011-08-16	adrelid	oid	-1	p	t	f	\N	\N	\N
2	11874	2604	2	2011-08-16	adnum	smallint	-1	p	t	f	\N	\N	\N
2	11874	2604	3	2011-08-16	adbin	text	-1	x	f	f	\N	\N	\N
2	11874	2604	4	2011-08-16	adsrc	text	-1	x	f	f	\N	\N	\N
2	11874	2606	1	2011-08-16	conname	name	-1	p	t	f	64	-1	1
2	11874	2606	2	2011-08-16	connamespace	oid	-1	p	t	f	4	-0.5	1
2	11874	2606	3	2011-08-16	contype	"char"	-1	p	t	f	1	-0.5	1
2	11874	2606	4	2011-08-16	condeferrable	boolean	-1	p	t	f	1	-0.5	1
2	11874	2606	5	2011-08-16	condeferred	boolean	-1	p	t	f	1	-0.5	1
2	11874	2606	6	2011-08-16	conrelid	oid	-1	p	t	f	4	-0.5	1
2	11874	2606	7	2011-08-16	contypid	oid	-1	p	t	f	4	-1	1
2	11874	2606	8	2011-08-16	conindid	oid	-1	p	t	f	4	-0.5	1
2	11874	2606	9	2011-08-16	confrelid	oid	-1	p	t	f	4	-0.5	1
2	11874	2606	10	2011-08-16	confupdtype	"char"	-1	p	t	f	1	-0.5	1
2	11874	2606	11	2011-08-16	confdeltype	"char"	-1	p	t	f	1	-0.5	1
2	11874	2606	12	2011-08-16	confmatchtype	"char"	-1	p	t	f	1	-0.5	1
2	11874	2606	13	2011-08-16	conislocal	boolean	-1	p	t	f	1	-0.5	1
2	11874	2606	14	2011-08-16	coninhcount	integer	-1	p	t	f	4	-0.5	1
2	11874	2606	15	2011-08-16	conkey	smallint[]	-1	x	f	f	0	0	\N
2	11874	2606	16	2011-08-16	confkey	smallint[]	-1	x	f	f	0	0	\N
2	11874	2606	17	2011-08-16	conpfeqop	oid[]	-1	x	f	f	0	0	\N
2	11874	2606	18	2011-08-16	conppeqop	oid[]	-1	x	f	f	0	0	\N
2	11874	2606	19	2011-08-16	conffeqop	oid[]	-1	x	f	f	0	0	\N
2	11874	2606	20	2011-08-16	conexclop	oid[]	-1	x	f	f	0	0	\N
2	11874	2606	21	2011-08-16	conbin	text	-1	x	f	f	498	-1	1
2	11874	2606	22	2011-08-16	consrc	text	-1	x	f	f	52	-1	-1
2	11874	2611	1	2011-08-16	inhrelid	oid	-1	p	t	f	\N	\N	\N
2	11874	2611	2	2011-08-16	inhparent	oid	-1	p	t	f	\N	\N	\N
2	11874	2611	3	2011-08-16	inhseqno	integer	-1	p	t	f	\N	\N	\N
2	11874	2610	1	2011-08-16	indexrelid	oid	-1	p	t	f	4	-1	0.23200899
2	11874	2610	2	2011-08-16	indrelid	oid	-1	p	t	f	4	-0.60395998	0.20038401
2	11874	2610	3	2011-08-16	indnatts	smallint	-1	p	t	f	2	4	0.32738501
2	11874	2610	4	2011-08-16	indisunique	boolean	-1	p	t	f	1	2	0.865789
2	11874	2610	5	2011-08-16	indisprimary	boolean	-1	p	t	f	1	2	0.54012799
2	11874	2610	6	2011-08-16	indimmediate	boolean	-1	p	t	f	1	1	1
2	11874	2610	7	2011-08-16	indisclustered	boolean	-1	p	t	f	1	1	1
2	11874	2610	8	2011-08-16	indisvalid	boolean	-1	p	t	f	1	1	1
2	11874	2610	9	2011-08-16	indcheckxmin	boolean	-1	p	t	f	1	1	1
2	11874	2610	10	2011-08-16	indisready	boolean	-1	p	t	f	1	1	1
2	11874	2610	11	2011-08-16	indkey	int2vector	-1	p	t	f	27	-0.17821801	0.13946401
2	11874	2610	12	2011-08-16	indclass	oidvector	-1	p	t	f	30	-0.16831701	0.163238
2	11874	2610	13	2011-08-16	indoption	int2vector	-1	p	t	f	27	4	0.32738501
2	11874	2610	14	2011-08-16	indexprs	text	-1	x	f	f	0	0	\N
2	11874	2610	15	2011-08-16	indpred	text	-1	x	f	f	0	0	\N
2	11874	2617	1	2011-08-16	oprname	name	-1	p	t	f	64	67	0.195003
2	11874	2617	2	2011-08-16	oprnamespace	oid	-1	p	t	f	4	1	1
2	11874	2617	3	2011-08-16	oprowner	oid	-1	p	t	f	4	1	1
2	11874	2617	4	2011-08-16	oprkind	"char"	-1	p	t	f	1	3	0.880925
2	11874	2617	5	2011-08-16	oprcanmerge	boolean	-1	p	t	f	1	2	0.85338402
2	11874	2617	6	2011-08-16	oprcanhash	boolean	-1	p	t	f	1	2	0.84083802
2	11874	2617	7	2011-08-16	oprleft	oid	-1	p	t	f	4	50	0.48025399
2	11874	2617	8	2011-08-16	oprright	oid	-1	p	t	f	4	49	0.52515399
2	11874	2617	9	2011-08-16	oprresult	oid	-1	p	t	f	4	29	0.46232501
2	11874	2617	10	2011-08-16	oprcom	oid	-1	p	t	f	4	-0.66524798	0.556723
2	11874	2617	11	2011-08-16	oprnegate	oid	-1	p	t	f	4	-0.500709	0.483677
2	11874	2617	12	2011-08-16	oprcode	regproc	-1	p	t	f	4	-0.96879399	0.798738
2	11874	2617	13	2011-08-16	oprrest	regproc	-1	p	t	f	4	17	0.25424901
2	11874	2617	14	2011-08-16	oprjoin	regproc	-1	p	t	f	4	17	0.25424901
2	11874	2753	1	2011-08-16	opfmethod	oid	-1	p	t	f	4	4	0.72316402
2	11874	2753	2	2011-08-16	opfname	name	-1	p	t	f	64	-0.62318802	0.44504899
2	11874	2753	3	2011-08-16	opfnamespace	oid	-1	p	t	f	4	1	1
2	11874	2753	4	2011-08-16	opfowner	oid	-1	p	t	f	4	1	1
2	11874	2616	1	2011-08-16	opcmethod	oid	-1	p	t	f	4	4	0.80080801
2	11874	2616	2	2011-08-16	opcname	name	-1	p	t	f	64	-0.69642901	-0.197919
2	11874	2616	3	2011-08-16	opcnamespace	oid	-1	p	t	f	4	1	1
2	11874	2616	4	2011-08-16	opcowner	oid	-1	p	t	f	4	1	1
2	11874	2616	5	2011-08-16	opcfamily	oid	-1	p	t	f	4	-0.61607099	0.94508302
2	11874	2616	6	2011-08-16	opcintype	oid	-1	p	t	f	4	-0.65178603	0.43914601
2	11874	2616	7	2011-08-16	opcdefault	boolean	-1	p	t	f	1	2	0.89918703
2	11874	2616	8	2011-08-16	opckeytype	oid	-1	p	t	f	4	-0.30357099	0.913315
2	11874	2601	1	2011-08-16	amname	name	-1	p	t	f	64	-1	0.2
2	11874	2601	2	2011-08-16	amstrategies	smallint	-1	p	t	f	2	-0.75	-0.80000001
2	11874	2601	3	2011-08-16	amsupport	smallint	-1	p	t	f	2	-0.75	0.80000001
2	11874	2601	4	2011-08-16	amcanorder	boolean	-1	p	t	f	1	-0.5	-0.2
2	11874	2601	5	2011-08-16	amcanbackward	boolean	-1	p	t	f	1	-0.5	-0.60000002
2	11874	2601	6	2011-08-16	amcanunique	boolean	-1	p	t	f	1	-0.5	-0.2
2	11874	2601	7	2011-08-16	amcanmulticol	boolean	-1	p	t	f	1	-0.5	0.80000001
2	11874	2601	8	2011-08-16	amoptionalkey	boolean	-1	p	t	f	1	-0.5	0.80000001
2	11874	2601	9	2011-08-16	amindexnulls	boolean	-1	p	t	f	1	-0.5	0
2	11874	2601	10	2011-08-16	amsearchnulls	boolean	-1	p	t	f	1	-0.5	0
2	11874	2601	11	2011-08-16	amstorage	boolean	-1	p	t	f	1	-0.5	1
2	11874	2601	12	2011-08-16	amclusterable	boolean	-1	p	t	f	1	-0.5	0
2	11874	2601	13	2011-08-16	amkeytype	oid	-1	p	t	f	4	-0.5	0.40000001
2	11874	2601	14	2011-08-16	aminsert	regproc	-1	p	t	f	4	-1	1
2	11874	2601	15	2011-08-16	ambeginscan	regproc	-1	p	t	f	4	-1	1
2	11874	2601	16	2011-08-16	amgettuple	regproc	-1	p	t	f	4	-1	-0.2
2	11874	2601	17	2011-08-16	amgetbitmap	regproc	-1	p	t	f	4	-1	1
2	11874	2601	18	2011-08-16	amrescan	regproc	-1	p	t	f	4	-1	1
2	11874	2601	19	2011-08-16	amendscan	regproc	-1	p	t	f	4	-1	1
2	11874	2601	20	2011-08-16	ammarkpos	regproc	-1	p	t	f	4	-1	1
2	11874	2601	21	2011-08-16	amrestrpos	regproc	-1	p	t	f	4	-1	1
2	11874	2601	22	2011-08-16	ambuild	regproc	-1	p	t	f	4	-1	1
2	11874	2601	23	2011-08-16	ambulkdelete	regproc	-1	p	t	f	4	-1	1
2	11874	2601	24	2011-08-16	amvacuumcleanup	regproc	-1	p	t	f	4	-1	0.80000001
2	11874	2601	25	2011-08-16	amcostestimate	regproc	-1	p	t	f	4	-1	0.40000001
2	11874	2601	26	2011-08-16	amoptions	regproc	-1	p	t	f	4	-1	1
2	11874	2602	1	2011-08-16	amopfamily	oid	-1	p	t	f	4	-0.193277	0.55816799
2	11874	2602	2	2011-08-16	amoplefttype	oid	-1	p	t	f	4	-0.120448	0.446706
2	11874	2602	3	2011-08-16	amoprighttype	oid	-1	p	t	f	4	-0.120448	0.446367
2	11874	2602	4	2011-08-16	amopstrategy	smallint	-1	p	t	f	2	20	0.243038
2	11874	2602	5	2011-08-16	amopopr	oid	-1	p	t	f	4	-0.88795501	0.319125
2	11874	2602	6	2011-08-16	amopmethod	oid	-1	p	t	f	4	4	0.97767502
2	11874	2603	1	2011-08-16	amprocfamily	oid	-1	p	t	f	4	-0.27599999	0.79009902
2	11874	2603	2	2011-08-16	amproclefttype	oid	-1	p	t	f	4	-0.292	0.37271899
2	11874	2603	3	2011-08-16	amprocrighttype	oid	-1	p	t	f	4	-0.292	0.37262201
2	11874	2603	4	2011-08-16	amprocnum	smallint	-1	p	t	f	2	7	0.680502
2	11874	2603	5	2011-08-16	amproc	regproc	-1	p	t	f	4	-0.43599999	0.481682
2	11874	2612	1	2011-08-16	lanname	name	-1	p	t	f	64	-1	0.60000002
2	11874	2612	2	2011-08-16	lanowner	oid	-1	p	t	f	4	-0.25	1
2	11874	2612	3	2011-08-16	lanispl	boolean	-1	p	t	f	1	-0.5	1
2	11874	2612	4	2011-08-16	lanpltrusted	boolean	-1	p	t	f	1	-0.5	1
2	11874	2612	5	2011-08-16	lanplcallfoid	oid	-1	p	t	f	4	-0.5	1
2	11874	2612	6	2011-08-16	laninline	oid	-1	p	t	f	4	-0.5	1
2	11874	2612	7	2011-08-16	lanvalidator	oid	-1	p	t	f	4	-1	1
2	11874	2612	8	2011-08-16	lanacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	2995	1	2011-08-16	lomowner	oid	-1	p	t	f	\N	\N	\N
2	11874	2995	2	2011-08-16	lomacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	2613	1	2011-08-16	loid	oid	-1	p	t	f	\N	\N	\N
2	11874	2613	2	2011-08-16	pageno	integer	-1	p	t	f	\N	\N	\N
2	11874	2613	3	2011-08-16	data	bytea	-1	x	f	f	\N	\N	\N
2	11874	2600	1	2011-08-16	aggfnoid	regproc	-1	p	t	f	4	-1	0.76783198
2	11874	2600	2	2011-08-16	aggtransfn	regproc	-1	p	t	f	4	-0.621849	0.377745
2	11874	2600	3	2011-08-16	aggfinalfn	regproc	-1	p	t	f	4	-0.21848699	0.65095401
2	11874	2600	4	2011-08-16	aggsortop	oid	-1	p	t	f	4	-0.344538	0.0269264
2	11874	2600	5	2011-08-16	aggtranstype	oid	-1	p	t	f	4	-0.235294	0.0940108
2	11874	2600	6	2011-08-16	agginitval	text	-1	x	f	f	8	5	-0.13890301
2	11874	2619	1	2011-08-16	starelid	oid	-1	p	t	f	\N	\N	\N
2	11874	2619	2	2011-08-16	staattnum	smallint	-1	p	t	f	\N	\N	\N
2	11874	2619	3	2011-08-16	stainherit	boolean	-1	p	t	f	\N	\N	\N
2	11874	2619	4	2011-08-16	stanullfrac	real	-1	p	t	f	\N	\N	\N
2	11874	2619	5	2011-08-16	stawidth	integer	-1	p	t	f	\N	\N	\N
2	11874	2619	6	2011-08-16	stadistinct	real	-1	p	t	f	\N	\N	\N
2	11874	2619	7	2011-08-16	stakind1	smallint	-1	p	t	f	\N	\N	\N
2	11874	2619	8	2011-08-16	stakind2	smallint	-1	p	t	f	\N	\N	\N
2	11874	2619	9	2011-08-16	stakind3	smallint	-1	p	t	f	\N	\N	\N
2	11874	2619	10	2011-08-16	stakind4	smallint	-1	p	t	f	\N	\N	\N
2	11874	2619	11	2011-08-16	staop1	oid	-1	p	t	f	\N	\N	\N
2	11874	2619	12	2011-08-16	staop2	oid	-1	p	t	f	\N	\N	\N
2	11874	2619	13	2011-08-16	staop3	oid	-1	p	t	f	\N	\N	\N
2	11874	2619	14	2011-08-16	staop4	oid	-1	p	t	f	\N	\N	\N
2	11874	2619	15	2011-08-16	stanumbers1	real[]	-1	x	f	f	\N	\N	\N
2	11874	2619	16	2011-08-16	stanumbers2	real[]	-1	x	f	f	\N	\N	\N
2	11874	2619	17	2011-08-16	stanumbers3	real[]	-1	x	f	f	\N	\N	\N
2	11874	2619	18	2011-08-16	stanumbers4	real[]	-1	x	f	f	\N	\N	\N
2	11874	2619	19	2011-08-16	stavalues1	anyarray	-1	x	f	f	\N	\N	\N
2	11874	2619	20	2011-08-16	stavalues2	anyarray	-1	x	f	f	\N	\N	\N
2	11874	2619	21	2011-08-16	stavalues3	anyarray	-1	x	f	f	\N	\N	\N
2	11874	2619	22	2011-08-16	stavalues4	anyarray	-1	x	f	f	\N	\N	\N
2	11874	2618	1	2011-08-16	rulename	name	-1	p	t	f	64	3	0.891976
2	11874	2618	2	2011-08-16	ev_class	oid	-1	p	t	f	4	-0.976744	0.98898101
2	11874	2618	3	2011-08-16	ev_attr	smallint	-1	p	t	f	2	1	1
2	11874	2618	4	2011-08-16	ev_type	"char"	-1	p	t	f	1	2	0.89216501
2	11874	2618	5	2011-08-16	ev_enabled	"char"	-1	p	t	f	1	1	1
2	11874	2618	6	2011-08-16	is_instead	boolean	-1	p	t	f	1	2	0.999717
2	11874	2618	7	2011-08-16	ev_qual	text	-1	x	f	f	6	2	0.93886501
2	11874	2618	8	2011-08-16	ev_action	text	-1	x	f	f	\N	\N	\N
2	11874	2620	1	2011-08-16	tgrelid	oid	-1	p	t	f	\N	\N	\N
2	11874	2620	2	2011-08-16	tgname	name	-1	p	t	f	\N	\N	\N
2	11874	2620	3	2011-08-16	tgfoid	oid	-1	p	t	f	\N	\N	\N
2	11874	2620	4	2011-08-16	tgtype	smallint	-1	p	t	f	\N	\N	\N
2	11874	2620	5	2011-08-16	tgenabled	"char"	-1	p	t	f	\N	\N	\N
2	11874	2620	6	2011-08-16	tgisinternal	boolean	-1	p	t	f	\N	\N	\N
2	11874	2620	7	2011-08-16	tgconstrrelid	oid	-1	p	t	f	\N	\N	\N
2	11874	2620	8	2011-08-16	tgconstrindid	oid	-1	p	t	f	\N	\N	\N
2	11874	2620	9	2011-08-16	tgconstraint	oid	-1	p	t	f	\N	\N	\N
2	11874	2620	10	2011-08-16	tgdeferrable	boolean	-1	p	t	f	\N	\N	\N
2	11874	2620	11	2011-08-16	tginitdeferred	boolean	-1	p	t	f	\N	\N	\N
2	11874	2620	12	2011-08-16	tgnargs	smallint	-1	p	t	f	\N	\N	\N
2	11874	2620	13	2011-08-16	tgattr	int2vector	-1	p	t	f	\N	\N	\N
2	11874	2620	14	2011-08-16	tgargs	bytea	-1	x	f	f	\N	\N	\N
2	11874	2620	15	2011-08-16	tgqual	text	-1	x	f	f	\N	\N	\N
2	11874	2609	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	0.85105699
2	11874	2609	2	2011-08-16	classoid	oid	-1	p	t	f	4	10	0.88925201
2	11874	2609	3	2011-08-16	objsubid	integer	-1	p	t	f	4	1	1
2	11874	2609	4	2011-08-16	description	text	-1	x	f	f	24	-0.53037798	-0.0348415
2	11874	2605	1	2011-08-16	castsource	oid	-1	p	t	f	4	-0.204188	0.26684299
2	11874	2605	2	2011-08-16	casttarget	oid	-1	p	t	f	4	-0.209424	0.204877
2	11874	2605	3	2011-08-16	castfunc	oid	-1	p	t	f	4	-0.52879602	0.378775
2	11874	2605	4	2011-08-16	castcontext	"char"	-1	p	t	f	1	3	0.231236
2	11874	2605	5	2011-08-16	castmethod	"char"	-1	p	t	f	1	2	0.70448101
2	11874	3501	1	2011-08-16	enumtypid	oid	-1	p	t	f	\N	\N	\N
2	11874	3501	2	2011-08-16	enumlabel	name	-1	p	t	f	\N	\N	\N
2	11874	2615	1	2011-08-16	nspname	name	-1	p	t	f	64	-1	-0.25714299
2	11874	2615	2	2011-08-16	nspowner	oid	-1	p	t	f	4	-0.166667	1
2	11874	2615	3	2011-08-16	nspacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	2607	1	2011-08-16	conname	name	-1	p	t	f	64	-1	0.034192
2	11874	2607	2	2011-08-16	connamespace	oid	-1	p	t	f	4	1	1
2	11874	2607	3	2011-08-16	conowner	oid	-1	p	t	f	4	1	1
2	11874	2607	4	2011-08-16	conforencoding	integer	-1	p	t	f	4	-0.31818199	-0.055730902
2	11874	2607	5	2011-08-16	contoencoding	integer	-1	p	t	f	4	-0.31818199	-0.063536704
2	11874	2607	6	2011-08-16	conproc	regproc	-1	p	t	f	4	-0.66666698	0.9946
2	11874	2607	7	2011-08-16	condefault	boolean	-1	p	t	f	1	1	1
2	11874	2608	1	2011-08-16	classid	oid	-1	p	t	f	4	11	0.985008
2	11874	2608	2	2011-08-16	objid	oid	-1	p	t	f	4	436	0.99999899
2	11874	2608	3	2011-08-16	objsubid	integer	-1	p	t	f	4	83	0.99429399
2	11874	2608	4	2011-08-16	refclassid	oid	-1	p	t	f	4	15	0.221155
2	11874	2608	5	2011-08-16	refobjid	oid	-1	p	t	f	4	-0.78687602	0.818048
2	11874	2608	6	2011-08-16	refobjsubid	integer	-1	p	t	f	4	23	0.99375898
2	11874	2608	7	2011-08-16	deptype	"char"	-1	p	t	f	1	4	-0.138106
2	11874	1262	1	2011-08-16	datname	name	-1	p	t	f	64	-1	\N
2	11874	1262	2	2011-08-16	datdba	oid	-1	p	t	f	4	-1	\N
2	11874	1262	3	2011-08-16	encoding	integer	-1	p	t	f	4	-1	\N
2	11874	1262	4	2011-08-16	datcollate	name	-1	p	t	f	64	-1	\N
2	11874	1262	5	2011-08-16	datctype	name	-1	p	t	f	64	-1	\N
2	11874	1262	6	2011-08-16	datistemplate	boolean	-1	p	t	f	1	-1	\N
2	11874	1262	7	2011-08-16	datallowconn	boolean	-1	p	t	f	1	-1	\N
2	11874	1262	8	2011-08-16	datconnlimit	integer	-1	p	t	f	4	-1	\N
2	11874	1262	9	2011-08-16	datlastsysoid	oid	-1	p	t	f	4	-1	\N
2	11874	1262	10	2011-08-16	datfrozenxid	xid	-1	p	t	f	4	-1	\N
2	11874	1262	11	2011-08-16	dattablespace	oid	-1	p	t	f	4	-1	\N
2	11874	1262	12	2011-08-16	datacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	2964	1	2011-08-16	setdatabase	oid	-1	p	t	f	\N	\N	\N
2	11874	2964	2	2011-08-16	setrole	oid	-1	p	t	f	\N	\N	\N
2	11874	2964	3	2011-08-16	setconfig	text[]	-1	x	f	f	\N	\N	\N
2	11874	1213	1	2011-08-16	spcname	name	-1	p	t	f	64	-1	1
2	11874	1213	2	2011-08-16	spcowner	oid	-1	p	t	f	4	-0.5	1
2	11874	1213	3	2011-08-16	spclocation	text	-1	x	f	f	1	-0.5	1
2	11874	1213	4	2011-08-16	spcacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	1213	5	2011-08-16	spcoptions	text[]	-1	x	f	f	0	0	\N
2	11874	1136	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	-0.071428597
2	11874	1136	2	2011-08-16	tmpltrusted	boolean	-1	p	t	f	1	-0.25	-0.26190501
2	11874	1136	3	2011-08-16	tmpldbacreate	boolean	-1	p	t	f	1	-0.25	-0.26190501
2	11874	1136	4	2011-08-16	tmplhandler	text	-1	x	f	f	20	-0.75	-0.071428597
2	11874	1136	5	2011-08-16	tmplinline	text	-1	x	f	f	23	-0.5	0.657143
2	11874	1136	6	2011-08-16	tmplvalidator	text	-1	x	f	f	17	-0.25	-0.5
2	11874	1136	7	2011-08-16	tmpllibrary	text	-1	x	f	f	15	-0.75	0
2	11874	1136	8	2011-08-16	tmplacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	1260	1	2011-08-16	rolname	name	-1	p	t	f	64	-1	\N
2	11874	1260	2	2011-08-16	rolsuper	boolean	-1	p	t	f	1	-1	\N
2	11874	1260	3	2011-08-16	rolinherit	boolean	-1	p	t	f	1	-1	\N
2	11874	1260	4	2011-08-16	rolcreaterole	boolean	-1	p	t	f	1	-1	\N
2	11874	1260	5	2011-08-16	rolcreatedb	boolean	-1	p	t	f	1	-1	\N
2	11874	1260	6	2011-08-16	rolcatupdate	boolean	-1	p	t	f	1	-1	\N
2	11874	1260	7	2011-08-16	rolcanlogin	boolean	-1	p	t	f	1	-1	\N
2	11874	1260	8	2011-08-16	rolconnlimit	integer	-1	p	t	f	4	-1	\N
2	11874	1260	9	2011-08-16	rolpassword	text	-1	x	f	f	0	0	\N
2	11874	1260	10	2011-08-16	rolvaliduntil	timestamp with time zone	-1	p	f	f	8	0	\N
2	11874	1261	1	2011-08-16	roleid	oid	-1	p	t	f	\N	\N	\N
2	11874	1261	2	2011-08-16	member	oid	-1	p	t	f	\N	\N	\N
2	11874	1261	3	2011-08-16	grantor	oid	-1	p	t	f	\N	\N	\N
2	11874	1261	4	2011-08-16	admin_option	boolean	-1	p	t	f	\N	\N	\N
2	11874	1214	1	2011-08-16	dbid	oid	-1	p	t	f	4	-1	\N
2	11874	1214	2	2011-08-16	classid	oid	-1	p	t	f	4	-1	\N
2	11874	1214	3	2011-08-16	objid	oid	-1	p	t	f	4	-1	\N
2	11874	1214	4	2011-08-16	objsubid	integer	-1	p	t	f	4	-1	\N
2	11874	1214	5	2011-08-16	refclassid	oid	-1	p	t	f	4	-1	\N
2	11874	1214	6	2011-08-16	refobjid	oid	-1	p	t	f	4	-1	\N
2	11874	1214	7	2011-08-16	deptype	"char"	-1	p	t	f	1	-1	\N
2	11874	2396	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	\N
2	11874	2396	2	2011-08-16	classoid	oid	-1	p	t	f	4	-1	\N
2	11874	2396	3	2011-08-16	description	text	-1	x	f	f	26	-1	\N
2	11874	3602	1	2011-08-16	cfgname	name	-1	p	t	f	64	-1	0.77058798
2	11874	3602	2	2011-08-16	cfgnamespace	oid	-1	p	t	f	4	1	1
2	11874	3602	3	2011-08-16	cfgowner	oid	-1	p	t	f	4	1	1
2	11874	3602	4	2011-08-16	cfgparser	oid	-1	p	t	f	4	1	1
2	11874	3603	1	2011-08-16	mapcfg	oid	-1	p	t	f	4	16	1
2	11874	3603	2	2011-08-16	maptokentype	integer	-1	p	t	f	4	19	0.0575522
2	11874	3603	3	2011-08-16	mapseqno	integer	-1	p	t	f	4	1	1
2	11874	3603	4	2011-08-16	mapdict	oid	-1	p	t	f	4	16	0.67357898
2	11874	3600	1	2011-08-16	dictname	name	-1	p	t	f	64	-1	0.77058798
2	11874	3600	2	2011-08-16	dictnamespace	oid	-1	p	t	f	4	1	1
2	11874	3600	3	2011-08-16	dictowner	oid	-1	p	t	f	4	1	1
2	11874	3600	4	2011-08-16	dicttemplate	oid	-1	p	t	f	4	-0.125	1
2	11874	3600	5	2011-08-16	dictinitoption	text	-1	x	f	f	42	-1	1
2	11874	3601	1	2011-08-16	prsname	name	-1	p	t	f	64	-1	\N
2	11874	3601	2	2011-08-16	prsnamespace	oid	-1	p	t	f	4	-1	\N
2	11874	3601	3	2011-08-16	prsstart	regproc	-1	p	t	f	4	-1	\N
2	11874	3601	4	2011-08-16	prstoken	regproc	-1	p	t	f	4	-1	\N
2	11874	3601	5	2011-08-16	prsend	regproc	-1	p	t	f	4	-1	\N
2	11874	3601	6	2011-08-16	prsheadline	regproc	-1	p	t	f	4	-1	\N
2	11874	3601	7	2011-08-16	prslextype	regproc	-1	p	t	f	4	-1	\N
2	11874	3764	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	0.30000001
2	11874	3764	2	2011-08-16	tmplnamespace	oid	-1	p	t	f	4	-0.2	1
2	11874	3764	3	2011-08-16	tmplinit	regproc	-1	p	t	f	4	-1	1
2	11874	3764	4	2011-08-16	tmpllexize	regproc	-1	p	t	f	4	-1	1
2	11874	2328	1	2011-08-16	fdwname	name	-1	p	t	f	\N	\N	\N
2	11874	2328	2	2011-08-16	fdwowner	oid	-1	p	t	f	\N	\N	\N
2	11874	2328	3	2011-08-16	fdwvalidator	oid	-1	p	t	f	\N	\N	\N
2	11874	2328	4	2011-08-16	fdwacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	2328	5	2011-08-16	fdwoptions	text[]	-1	x	f	f	\N	\N	\N
2	11874	1417	1	2011-08-16	srvname	name	-1	p	t	f	\N	\N	\N
2	11874	1417	2	2011-08-16	srvowner	oid	-1	p	t	f	\N	\N	\N
2	11874	1417	3	2011-08-16	srvfdw	oid	-1	p	t	f	\N	\N	\N
2	11874	1417	4	2011-08-16	srvtype	text	-1	x	f	f	\N	\N	\N
2	11874	1417	5	2011-08-16	srvversion	text	-1	x	f	f	\N	\N	\N
2	11874	1417	6	2011-08-16	srvacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	1417	7	2011-08-16	srvoptions	text[]	-1	x	f	f	\N	\N	\N
2	11874	1418	1	2011-08-16	umuser	oid	-1	p	t	f	\N	\N	\N
2	11874	1418	2	2011-08-16	umserver	oid	-1	p	t	f	\N	\N	\N
2	11874	1418	3	2011-08-16	umoptions	text[]	-1	x	f	f	\N	\N	\N
2	11874	826	1	2011-08-16	defaclrole	oid	-1	p	t	f	\N	\N	\N
2	11874	826	2	2011-08-16	defaclnamespace	oid	-1	p	t	f	\N	\N	\N
2	11874	826	3	2011-08-16	defaclobjtype	"char"	-1	p	t	f	\N	\N	\N
2	11874	826	4	2011-08-16	defaclacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	11874	2830	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2830	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2830	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2832	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2832	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2832	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2834	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2834	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2834	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2836	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2836	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2836	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2838	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2838	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2838	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2840	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2840	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2840	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2336	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2336	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2336	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2844	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2844	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2844	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2846	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2846	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2846	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	2966	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	2966	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	2966	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	11454	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	5	-0.70769203	0.983832
2	11874	11454	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	27	-0.70923102	0.37094799
2	11874	11454	3	2011-08-16	sub_feature_id	information_schema.character_data	-1	x	f	f	1	18	0.042565402
2	11874	11454	4	2011-08-16	sub_feature_name	information_schema.character_data	-1	x	f	f	9	-0.292308	0.04391
2	11874	11454	5	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	2	0.057943199
2	11874	11454	6	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
2	11874	11454	7	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	11	0.97430003
2	11874	11456	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	11456	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	11456	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	11459	1	2011-08-16	implementation_info_id	information_schema.character_data	-1	x	f	f	3	-1	0.55244797
2	11874	11459	2	2011-08-16	implementation_info_name	information_schema.character_data	-1	x	f	f	17	-1	0.85314697
2	11874	11459	3	2011-08-16	integer_value	information_schema.cardinal_number	-1	p	f	f	4	-0.33333299	0.2
2	11874	11459	4	2011-08-16	character_value	information_schema.character_data	-1	x	f	f	4	-0.33333299	0.035714298
2	11874	11459	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	29	-1	-0.178571
2	11874	11461	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	11461	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	11461	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	11464	1	2011-08-16	sql_language_source	information_schema.character_data	-1	x	f	f	9	-0.25	1
2	11874	11464	2	2011-08-16	sql_language_year	information_schema.character_data	-1	x	f	f	5	-0.5	1
2	11874	11464	3	2011-08-16	sql_language_conformance	information_schema.character_data	-1	x	f	f	5	-0.25	1
2	11874	11464	4	2011-08-16	sql_language_integrity	information_schema.character_data	-1	x	f	f	0	0	\N
2	11874	11464	5	2011-08-16	sql_language_implementation	information_schema.character_data	-1	x	f	f	0	0	\N
2	11874	11464	6	2011-08-16	sql_language_binding_style	information_schema.character_data	-1	x	f	f	8	-0.5	0.80000001
2	11874	11464	7	2011-08-16	sql_language_programming_language	information_schema.character_data	-1	x	f	f	2	-0.25	1
2	11874	11466	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	11466	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	11466	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	11469	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	7	-1	1
2	11874	11469	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	15	-1	-0.090909101
2	11874	11469	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.2	0.563636
2	11874	11469	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
2	11874	11469	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	4	-0.40000001	0.69696999
2	11874	11471	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	11471	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	11471	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	11474	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	2	-1	-0.0666667
2	11874	11474	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	38	-1	0.783333
2	11874	11474	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.222222	1
2	11874	11474	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
2	11874	11474	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	-0.111111	1
2	11874	11476	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	11476	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	11476	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	11479	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	4	-1	0.26581001
2	11874	11479	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	28	-1	0.479249
2	11874	11479	3	2011-08-16	supported_value	information_schema.cardinal_number	-1	p	f	f	4	-0.173913	0.55087698
2	11874	11479	4	2011-08-16	comments	information_schema.character_data	-1	x	f	f	43	1	1
2	11874	11481	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	11481	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	11481	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	11874	11484	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
2	11874	11484	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	\N	\N	\N
2	11874	11484	3	2011-08-16	profile_id	information_schema.character_data	-1	x	f	f	\N	\N	\N
2	11874	11484	4	2011-08-16	required_value	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
2	11874	11484	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	\N	\N	\N
2	11874	11486	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	11874	11486	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	11874	11486	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	1255	1	2011-08-16	proname	name	-1	p	t	f	64	-0.81640798	0.22111399
2	16384	1255	2	2011-08-16	pronamespace	oid	-1	p	t	f	4	2	0.99999899
2	16384	1255	3	2011-08-16	proowner	oid	-1	p	t	f	4	1	1
2	16384	1255	4	2011-08-16	prolang	oid	-1	p	t	f	4	3	0.96455598
2	16384	1255	5	2011-08-16	procost	real	-1	p	t	f	4	5	0.99089301
2	16384	1255	6	2011-08-16	prorows	real	-1	p	t	f	4	10	0.98529398
2	16384	1255	7	2011-08-16	provariadic	oid	-1	p	t	f	4	1	1
2	16384	1255	8	2011-08-16	proisagg	boolean	-1	p	t	f	1	2	0.96914399
2	16384	1255	9	2011-08-16	proiswindow	boolean	-1	p	t	f	1	2	0.99989802
2	16384	1255	10	2011-08-16	prosecdef	boolean	-1	p	t	f	1	1	1
2	16384	1255	11	2011-08-16	proisstrict	boolean	-1	p	t	f	1	2	0.78557801
2	16384	1255	12	2011-08-16	proretset	boolean	-1	p	t	f	1	2	0.98536599
2	16384	1255	13	2011-08-16	provolatile	"char"	-1	p	t	f	1	3	0.75940597
2	16384	1255	14	2011-08-16	pronargs	smallint	-1	p	t	f	2	8	0.35542199
2	16384	1255	15	2011-08-16	pronargdefaults	smallint	-1	p	t	f	2	2	0.99999398
2	16384	1255	16	2011-08-16	prorettype	oid	-1	p	t	f	4	78	0.33539501
2	16384	1255	17	2011-08-16	proargtypes	oidvector	-1	p	t	f	31	-0.16585401	0.131202
2	16384	1255	18	2011-08-16	proallargtypes	oid[]	-1	x	f	f	44	-1	0.20609801
2	16384	1255	19	2011-08-16	proargmodes	"char"[]	-1	x	f	f	26	14	-0.47713199
2	16384	1255	20	2011-08-16	proargnames	text[]	-1	x	f	f	80	30	0.222289
2	16384	1255	21	2011-08-16	proargdefaults	text	-1	x	f	f	141	-1	\N
2	16384	1255	22	2011-08-16	prosrc	text	-1	x	f	f	16	-0.89490002	0.16789301
2	16384	1255	23	2011-08-16	probin	text	-1	x	f	f	23	28	0.83976901
2	16384	1255	24	2011-08-16	proconfig	text[]	-1	x	f	f	0	0	\N
2	16384	1255	25	2011-08-16	proacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	1247	1	2011-08-16	typname	name	-1	p	t	f	64	-1	0.3863
2	16384	1247	2	2011-08-16	typnamespace	oid	-1	p	t	f	4	3	0.99332702
2	16384	1247	3	2011-08-16	typowner	oid	-1	p	t	f	4	1	1
2	16384	1247	4	2011-08-16	typlen	smallint	-1	p	t	f	2	12	0.381313
2	16384	1247	5	2011-08-16	typbyval	boolean	-1	p	t	f	1	2	0.58123201
2	16384	1247	6	2011-08-16	typtype	"char"	-1	p	t	f	1	4	0.90001601
2	16384	1247	7	2011-08-16	typcategory	"char"	-1	p	t	f	1	13	0.16261899
2	16384	1247	8	2011-08-16	typispreferred	boolean	-1	p	t	f	1	2	0.87831497
2	16384	1247	9	2011-08-16	typisdefined	boolean	-1	p	t	f	1	1	1
2	16384	1247	10	2011-08-16	typdelim	"char"	-1	p	t	f	1	2	0.96987098
2	16384	1247	11	2011-08-16	typrelid	oid	-1	p	t	f	4	-0.53310102	0.96858799
2	16384	1247	12	2011-08-16	typelem	oid	-1	p	t	f	4	-0.209059	0.211162
2	16384	1247	13	2011-08-16	typarray	oid	-1	p	t	f	4	-0.209059	0.20806199
2	16384	1247	14	2011-08-16	typinput	regproc	-1	p	t	f	4	-0.250871	0.82135397
2	16384	1247	15	2011-08-16	typoutput	regproc	-1	p	t	f	4	-0.24738701	0.80345798
2	16384	1247	16	2011-08-16	typreceive	regproc	-1	p	t	f	4	-0.21254399	0.195701
2	16384	1247	17	2011-08-16	typsend	regproc	-1	p	t	f	4	-0.209059	0.18141501
2	16384	1247	18	2011-08-16	typmodin	regproc	-1	p	t	f	4	11	0.788158
2	16384	1247	19	2011-08-16	typmodout	regproc	-1	p	t	f	4	11	0.78836697
2	16384	1247	20	2011-08-16	typanalyze	regproc	-1	p	t	f	4	2	0.99200302
2	16384	1247	21	2011-08-16	typalign	"char"	-1	p	t	f	1	4	0.024560301
2	16384	1247	22	2011-08-16	typstorage	"char"	-1	p	t	f	1	3	0.93686098
2	16384	1247	23	2011-08-16	typnotnull	boolean	-1	p	t	f	1	1	1
2	16384	1247	24	2011-08-16	typbasetype	oid	-1	p	t	f	4	4	0.99479401
2	16384	1247	25	2011-08-16	typtypmod	integer	-1	p	t	f	4	3	0.99804902
2	16384	1247	26	2011-08-16	typndims	integer	-1	p	t	f	4	1	1
2	16384	1247	27	2011-08-16	typdefaultbin	text	-1	x	f	f	441	-1	\N
2	16384	1247	28	2011-08-16	typdefault	text	-1	x	f	f	43	-1	\N
2	16384	1249	1	2011-08-16	attrelid	oid	-1	p	t	f	4	-0.130749	0.93989903
2	16384	1249	2	2011-08-16	attname	name	-1	p	t	f	64	-0.38294601	0.0036946801
2	16384	1249	3	2011-08-16	atttypid	oid	-1	p	t	f	4	34	0.60096002
2	16384	1249	4	2011-08-16	attstattarget	integer	-1	p	t	f	4	2	0.42826101
2	16384	1249	5	2011-08-16	attlen	smallint	-1	p	t	f	2	9	-0.064016797
2	16384	1249	6	2011-08-16	attnum	smallint	-1	p	t	f	2	89	0.25127199
2	16384	1249	7	2011-08-16	attndims	integer	-1	p	t	f	4	2	0.91384
2	16384	1249	8	2011-08-16	attcacheoff	integer	-1	p	t	f	4	1	1
2	16384	1249	9	2011-08-16	atttypmod	integer	-1	p	t	f	4	1	1
2	16384	1249	10	2011-08-16	attbyval	boolean	-1	p	t	f	1	2	0.065347202
2	16384	1249	11	2011-08-16	attstorage	"char"	-1	p	t	f	1	3	0.89757299
2	16384	1249	12	2011-08-16	attalign	"char"	-1	p	t	f	1	4	0.66951603
2	16384	1249	13	2011-08-16	attnotnull	boolean	-1	p	t	f	1	2	-0.17658401
2	16384	1249	14	2011-08-16	atthasdef	boolean	-1	p	t	f	1	1	1
2	16384	1249	15	2011-08-16	attisdropped	boolean	-1	p	t	f	1	1	1
2	16384	1249	16	2011-08-16	attislocal	boolean	-1	p	t	f	1	1	1
2	16384	1249	17	2011-08-16	attinhcount	integer	-1	p	t	f	4	1	1
2	16384	1249	18	2011-08-16	attacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	1249	19	2011-08-16	attoptions	text[]	-1	x	f	f	0	0	\N
2	16384	1259	1	2011-08-16	relname	name	-1	p	t	f	64	-1	0.069593102
2	16384	1259	2	2011-08-16	relnamespace	oid	-1	p	t	f	4	3	0.76032102
2	16384	1259	3	2011-08-16	reltype	oid	-1	p	t	f	4	-0.604743	0.80476397
2	16384	1259	4	2011-08-16	reloftype	oid	-1	p	t	f	4	1	1
2	16384	1259	5	2011-08-16	relowner	oid	-1	p	t	f	4	1	1
2	16384	1259	6	2011-08-16	relam	oid	-1	p	t	f	4	2	-0.158712
2	16384	1259	7	2011-08-16	relfilenode	oid	-1	p	t	f	4	-0.84189701	0.68083
2	16384	1259	8	2011-08-16	reltablespace	oid	-1	p	t	f	4	2	0.69740403
2	16384	1259	9	2011-08-16	relpages	integer	-1	p	t	f	4	14	-0.23059499
2	16384	1259	10	2011-08-16	reltuples	real	-1	p	t	f	4	20	0.289942
2	16384	1259	11	2011-08-16	reltoastrelid	oid	-1	p	t	f	4	18	0.93993998
2	16384	1259	12	2011-08-16	reltoastidxid	oid	-1	p	t	f	4	18	0.78708398
2	16384	1259	13	2011-08-16	relhasindex	boolean	-1	p	t	f	1	2	0.68597198
2	16384	1259	14	2011-08-16	relisshared	boolean	-1	p	t	f	1	2	0.69740403
2	16384	1259	15	2011-08-16	relistemp	boolean	-1	p	t	f	1	1	1
2	16384	1259	16	2011-08-16	relkind	"char"	-1	p	t	f	1	4	0.78044999
2	16384	1259	17	2011-08-16	relnatts	smallint	-1	p	t	f	2	-0.106719	0.61371702
2	16384	1259	18	2011-08-16	relchecks	smallint	-1	p	t	f	2	1	1
2	16384	1259	19	2011-08-16	relhasoids	boolean	-1	p	t	f	1	2	0.89500701
2	16384	1259	20	2011-08-16	relhaspkey	boolean	-1	p	t	f	1	2	0.99300599
2	16384	1259	21	2011-08-16	relhasexclusion	boolean	-1	p	t	f	1	1	1
2	16384	1259	22	2011-08-16	relhasrules	boolean	-1	p	t	f	1	2	0.90881997
2	16384	1259	23	2011-08-16	relhastriggers	boolean	-1	p	t	f	1	1	1
2	16384	1259	24	2011-08-16	relhassubclass	boolean	-1	p	t	f	1	1	1
2	16384	1259	25	2011-08-16	relfrozenxid	xid	-1	p	t	f	4	3	\N
2	16384	1259	26	2011-08-16	relacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	1259	27	2011-08-16	reloptions	text[]	-1	x	f	f	0	0	\N
2	16384	2604	1	2011-08-16	adrelid	oid	-1	p	t	f	\N	\N	\N
2	16384	2604	2	2011-08-16	adnum	smallint	-1	p	t	f	\N	\N	\N
2	16384	2604	3	2011-08-16	adbin	text	-1	x	f	f	\N	\N	\N
2	16384	2604	4	2011-08-16	adsrc	text	-1	x	f	f	\N	\N	\N
2	16384	2606	1	2011-08-16	conname	name	-1	p	t	f	64	-1	1
2	16384	2606	2	2011-08-16	connamespace	oid	-1	p	t	f	4	-0.5	1
2	16384	2606	3	2011-08-16	contype	"char"	-1	p	t	f	1	-0.5	1
2	16384	2606	4	2011-08-16	condeferrable	boolean	-1	p	t	f	1	-0.5	1
2	16384	2606	5	2011-08-16	condeferred	boolean	-1	p	t	f	1	-0.5	1
2	16384	2606	6	2011-08-16	conrelid	oid	-1	p	t	f	4	-0.5	1
2	16384	2606	7	2011-08-16	contypid	oid	-1	p	t	f	4	-1	1
2	16384	2606	8	2011-08-16	conindid	oid	-1	p	t	f	4	-0.5	1
2	16384	2606	9	2011-08-16	confrelid	oid	-1	p	t	f	4	-0.5	1
2	16384	2606	10	2011-08-16	confupdtype	"char"	-1	p	t	f	1	-0.5	1
2	16384	2606	11	2011-08-16	confdeltype	"char"	-1	p	t	f	1	-0.5	1
2	16384	2606	12	2011-08-16	confmatchtype	"char"	-1	p	t	f	1	-0.5	1
2	16384	2606	13	2011-08-16	conislocal	boolean	-1	p	t	f	1	-0.5	1
2	16384	2606	14	2011-08-16	coninhcount	integer	-1	p	t	f	4	-0.5	1
2	16384	2606	15	2011-08-16	conkey	smallint[]	-1	x	f	f	0	0	\N
2	16384	2606	16	2011-08-16	confkey	smallint[]	-1	x	f	f	0	0	\N
2	16384	2606	17	2011-08-16	conpfeqop	oid[]	-1	x	f	f	0	0	\N
2	16384	2606	18	2011-08-16	conppeqop	oid[]	-1	x	f	f	0	0	\N
2	16384	2606	19	2011-08-16	conffeqop	oid[]	-1	x	f	f	0	0	\N
2	16384	2606	20	2011-08-16	conexclop	oid[]	-1	x	f	f	0	0	\N
2	16384	2606	21	2011-08-16	conbin	text	-1	x	f	f	498	-1	1
2	16384	2606	22	2011-08-16	consrc	text	-1	x	f	f	52	-1	-1
2	16384	2611	1	2011-08-16	inhrelid	oid	-1	p	t	f	\N	\N	\N
2	16384	2611	2	2011-08-16	inhparent	oid	-1	p	t	f	\N	\N	\N
2	16384	2611	3	2011-08-16	inhseqno	integer	-1	p	t	f	\N	\N	\N
2	16384	2610	1	2011-08-16	indexrelid	oid	-1	p	t	f	4	-1	0.23200899
2	16384	2610	2	2011-08-16	indrelid	oid	-1	p	t	f	4	-0.60395998	0.20038401
2	16384	2610	3	2011-08-16	indnatts	smallint	-1	p	t	f	2	4	0.32738501
2	16384	2610	4	2011-08-16	indisunique	boolean	-1	p	t	f	1	2	0.865789
2	16384	2610	5	2011-08-16	indisprimary	boolean	-1	p	t	f	1	2	0.54012799
2	16384	2610	6	2011-08-16	indimmediate	boolean	-1	p	t	f	1	1	1
2	16384	2610	7	2011-08-16	indisclustered	boolean	-1	p	t	f	1	1	1
2	16384	2610	8	2011-08-16	indisvalid	boolean	-1	p	t	f	1	1	1
2	16384	2610	9	2011-08-16	indcheckxmin	boolean	-1	p	t	f	1	1	1
2	16384	2610	10	2011-08-16	indisready	boolean	-1	p	t	f	1	1	1
2	16384	2610	11	2011-08-16	indkey	int2vector	-1	p	t	f	27	-0.17821801	0.13946401
2	16384	2610	12	2011-08-16	indclass	oidvector	-1	p	t	f	30	-0.16831701	0.163238
2	16384	2610	13	2011-08-16	indoption	int2vector	-1	p	t	f	27	4	0.32738501
2	16384	2610	14	2011-08-16	indexprs	text	-1	x	f	f	0	0	\N
2	16384	2610	15	2011-08-16	indpred	text	-1	x	f	f	0	0	\N
2	16384	2617	1	2011-08-16	oprname	name	-1	p	t	f	64	67	0.195003
2	16384	2617	2	2011-08-16	oprnamespace	oid	-1	p	t	f	4	1	1
2	16384	2617	3	2011-08-16	oprowner	oid	-1	p	t	f	4	1	1
2	16384	2617	4	2011-08-16	oprkind	"char"	-1	p	t	f	1	3	0.880925
2	16384	2617	5	2011-08-16	oprcanmerge	boolean	-1	p	t	f	1	2	0.85338402
2	16384	2617	6	2011-08-16	oprcanhash	boolean	-1	p	t	f	1	2	0.84083802
2	16384	2617	7	2011-08-16	oprleft	oid	-1	p	t	f	4	50	0.48025399
2	16384	2617	8	2011-08-16	oprright	oid	-1	p	t	f	4	49	0.52515399
2	16384	2617	9	2011-08-16	oprresult	oid	-1	p	t	f	4	29	0.46232501
2	16384	2617	10	2011-08-16	oprcom	oid	-1	p	t	f	4	-0.66524798	0.556723
2	16384	2617	11	2011-08-16	oprnegate	oid	-1	p	t	f	4	-0.500709	0.483677
2	16384	2617	12	2011-08-16	oprcode	regproc	-1	p	t	f	4	-0.96879399	0.798738
2	16384	2617	13	2011-08-16	oprrest	regproc	-1	p	t	f	4	17	0.25424901
2	16384	2617	14	2011-08-16	oprjoin	regproc	-1	p	t	f	4	17	0.25424901
2	16384	2753	1	2011-08-16	opfmethod	oid	-1	p	t	f	4	4	0.72316402
2	16384	2753	2	2011-08-16	opfname	name	-1	p	t	f	64	-0.62318802	0.44504899
2	16384	2753	3	2011-08-16	opfnamespace	oid	-1	p	t	f	4	1	1
2	16384	2753	4	2011-08-16	opfowner	oid	-1	p	t	f	4	1	1
2	16384	2616	1	2011-08-16	opcmethod	oid	-1	p	t	f	4	4	0.80080801
2	16384	2616	2	2011-08-16	opcname	name	-1	p	t	f	64	-0.69642901	-0.197919
2	16384	2616	3	2011-08-16	opcnamespace	oid	-1	p	t	f	4	1	1
2	16384	2616	4	2011-08-16	opcowner	oid	-1	p	t	f	4	1	1
2	16384	2616	5	2011-08-16	opcfamily	oid	-1	p	t	f	4	-0.61607099	0.94508302
2	16384	2616	6	2011-08-16	opcintype	oid	-1	p	t	f	4	-0.65178603	0.43914601
2	16384	2616	7	2011-08-16	opcdefault	boolean	-1	p	t	f	1	2	0.89918703
2	16384	2616	8	2011-08-16	opckeytype	oid	-1	p	t	f	4	-0.30357099	0.913315
2	16384	2601	1	2011-08-16	amname	name	-1	p	t	f	64	-1	0.2
2	16384	2601	2	2011-08-16	amstrategies	smallint	-1	p	t	f	2	-0.75	-0.80000001
2	16384	2601	3	2011-08-16	amsupport	smallint	-1	p	t	f	2	-0.75	0.80000001
2	16384	2601	4	2011-08-16	amcanorder	boolean	-1	p	t	f	1	-0.5	-0.2
2	16384	2601	5	2011-08-16	amcanbackward	boolean	-1	p	t	f	1	-0.5	-0.60000002
2	16384	2601	6	2011-08-16	amcanunique	boolean	-1	p	t	f	1	-0.5	-0.2
2	16384	2601	7	2011-08-16	amcanmulticol	boolean	-1	p	t	f	1	-0.5	0.80000001
2	16384	2601	8	2011-08-16	amoptionalkey	boolean	-1	p	t	f	1	-0.5	0.80000001
2	16384	2601	9	2011-08-16	amindexnulls	boolean	-1	p	t	f	1	-0.5	0
2	16384	2601	10	2011-08-16	amsearchnulls	boolean	-1	p	t	f	1	-0.5	0
2	16384	2601	11	2011-08-16	amstorage	boolean	-1	p	t	f	1	-0.5	1
2	16384	2601	12	2011-08-16	amclusterable	boolean	-1	p	t	f	1	-0.5	0
2	16384	2601	13	2011-08-16	amkeytype	oid	-1	p	t	f	4	-0.5	0.40000001
2	16384	2601	14	2011-08-16	aminsert	regproc	-1	p	t	f	4	-1	1
2	16384	2601	15	2011-08-16	ambeginscan	regproc	-1	p	t	f	4	-1	1
2	16384	2601	16	2011-08-16	amgettuple	regproc	-1	p	t	f	4	-1	-0.2
2	16384	2601	17	2011-08-16	amgetbitmap	regproc	-1	p	t	f	4	-1	1
2	16384	2601	18	2011-08-16	amrescan	regproc	-1	p	t	f	4	-1	1
2	16384	2601	19	2011-08-16	amendscan	regproc	-1	p	t	f	4	-1	1
2	16384	2601	20	2011-08-16	ammarkpos	regproc	-1	p	t	f	4	-1	1
2	16384	2601	21	2011-08-16	amrestrpos	regproc	-1	p	t	f	4	-1	1
2	16384	2601	22	2011-08-16	ambuild	regproc	-1	p	t	f	4	-1	1
2	16384	2601	23	2011-08-16	ambulkdelete	regproc	-1	p	t	f	4	-1	1
2	16384	2601	24	2011-08-16	amvacuumcleanup	regproc	-1	p	t	f	4	-1	0.80000001
2	16384	2601	25	2011-08-16	amcostestimate	regproc	-1	p	t	f	4	-1	0.40000001
2	16384	2601	26	2011-08-16	amoptions	regproc	-1	p	t	f	4	-1	1
2	16384	2602	1	2011-08-16	amopfamily	oid	-1	p	t	f	4	-0.193277	0.55816799
2	16384	2602	2	2011-08-16	amoplefttype	oid	-1	p	t	f	4	-0.120448	0.446706
2	16384	2602	3	2011-08-16	amoprighttype	oid	-1	p	t	f	4	-0.120448	0.446367
2	16384	2602	4	2011-08-16	amopstrategy	smallint	-1	p	t	f	2	20	0.243038
2	16384	2602	5	2011-08-16	amopopr	oid	-1	p	t	f	4	-0.88795501	0.319125
2	16384	2602	6	2011-08-16	amopmethod	oid	-1	p	t	f	4	4	0.97767502
2	16384	2603	1	2011-08-16	amprocfamily	oid	-1	p	t	f	4	-0.27599999	0.79009902
2	16384	2603	2	2011-08-16	amproclefttype	oid	-1	p	t	f	4	-0.292	0.37271899
2	16384	2603	3	2011-08-16	amprocrighttype	oid	-1	p	t	f	4	-0.292	0.37262201
2	16384	2603	4	2011-08-16	amprocnum	smallint	-1	p	t	f	2	7	0.680502
2	16384	2603	5	2011-08-16	amproc	regproc	-1	p	t	f	4	-0.43599999	0.481682
2	16384	2612	1	2011-08-16	lanname	name	-1	p	t	f	64	-1	0.60000002
2	16384	2612	2	2011-08-16	lanowner	oid	-1	p	t	f	4	-0.25	1
2	16384	2612	3	2011-08-16	lanispl	boolean	-1	p	t	f	1	-0.5	1
2	16384	2612	4	2011-08-16	lanpltrusted	boolean	-1	p	t	f	1	-0.5	1
2	16384	2612	5	2011-08-16	lanplcallfoid	oid	-1	p	t	f	4	-0.5	1
2	16384	2612	6	2011-08-16	laninline	oid	-1	p	t	f	4	-0.5	1
2	16384	2612	7	2011-08-16	lanvalidator	oid	-1	p	t	f	4	-1	1
2	16384	2612	8	2011-08-16	lanacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	2995	1	2011-08-16	lomowner	oid	-1	p	t	f	\N	\N	\N
2	16384	2995	2	2011-08-16	lomacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	2613	1	2011-08-16	loid	oid	-1	p	t	f	\N	\N	\N
2	16384	2613	2	2011-08-16	pageno	integer	-1	p	t	f	\N	\N	\N
2	16384	2613	3	2011-08-16	data	bytea	-1	x	f	f	\N	\N	\N
2	16384	2600	1	2011-08-16	aggfnoid	regproc	-1	p	t	f	4	-1	0.76783198
2	16384	2600	2	2011-08-16	aggtransfn	regproc	-1	p	t	f	4	-0.621849	0.377745
2	16384	2600	3	2011-08-16	aggfinalfn	regproc	-1	p	t	f	4	-0.21848699	0.65095401
2	16384	2600	4	2011-08-16	aggsortop	oid	-1	p	t	f	4	-0.344538	0.0269264
2	16384	2600	5	2011-08-16	aggtranstype	oid	-1	p	t	f	4	-0.235294	0.0940108
2	16384	2600	6	2011-08-16	agginitval	text	-1	x	f	f	8	5	-0.13890301
2	16384	2619	1	2011-08-16	starelid	oid	-1	p	t	f	\N	\N	\N
2	16384	2619	2	2011-08-16	staattnum	smallint	-1	p	t	f	\N	\N	\N
2	16384	2619	3	2011-08-16	stainherit	boolean	-1	p	t	f	\N	\N	\N
2	16384	2619	4	2011-08-16	stanullfrac	real	-1	p	t	f	\N	\N	\N
2	16384	2619	5	2011-08-16	stawidth	integer	-1	p	t	f	\N	\N	\N
2	16384	2619	6	2011-08-16	stadistinct	real	-1	p	t	f	\N	\N	\N
2	16384	2619	7	2011-08-16	stakind1	smallint	-1	p	t	f	\N	\N	\N
2	16384	2619	8	2011-08-16	stakind2	smallint	-1	p	t	f	\N	\N	\N
2	16384	2619	9	2011-08-16	stakind3	smallint	-1	p	t	f	\N	\N	\N
2	16384	2619	10	2011-08-16	stakind4	smallint	-1	p	t	f	\N	\N	\N
2	16384	2619	11	2011-08-16	staop1	oid	-1	p	t	f	\N	\N	\N
2	16384	2619	12	2011-08-16	staop2	oid	-1	p	t	f	\N	\N	\N
2	16384	2619	13	2011-08-16	staop3	oid	-1	p	t	f	\N	\N	\N
2	16384	2619	14	2011-08-16	staop4	oid	-1	p	t	f	\N	\N	\N
2	16384	2619	15	2011-08-16	stanumbers1	real[]	-1	x	f	f	\N	\N	\N
2	16384	2619	16	2011-08-16	stanumbers2	real[]	-1	x	f	f	\N	\N	\N
2	16384	2619	17	2011-08-16	stanumbers3	real[]	-1	x	f	f	\N	\N	\N
2	16384	2619	18	2011-08-16	stanumbers4	real[]	-1	x	f	f	\N	\N	\N
2	16384	2619	19	2011-08-16	stavalues1	anyarray	-1	x	f	f	\N	\N	\N
2	16384	2619	20	2011-08-16	stavalues2	anyarray	-1	x	f	f	\N	\N	\N
2	16384	2619	21	2011-08-16	stavalues3	anyarray	-1	x	f	f	\N	\N	\N
2	16384	2619	22	2011-08-16	stavalues4	anyarray	-1	x	f	f	\N	\N	\N
2	16384	2618	1	2011-08-16	rulename	name	-1	p	t	f	64	3	0.891976
2	16384	2618	2	2011-08-16	ev_class	oid	-1	p	t	f	4	-0.976744	0.98898101
2	16384	2618	3	2011-08-16	ev_attr	smallint	-1	p	t	f	2	1	1
2	16384	2618	4	2011-08-16	ev_type	"char"	-1	p	t	f	1	2	0.89216501
2	16384	2618	5	2011-08-16	ev_enabled	"char"	-1	p	t	f	1	1	1
2	16384	2618	6	2011-08-16	is_instead	boolean	-1	p	t	f	1	2	0.999717
2	16384	2618	7	2011-08-16	ev_qual	text	-1	x	f	f	6	2	0.93886501
2	16384	2618	8	2011-08-16	ev_action	text	-1	x	f	f	\N	\N	\N
2	16384	2620	1	2011-08-16	tgrelid	oid	-1	p	t	f	\N	\N	\N
2	16384	2620	2	2011-08-16	tgname	name	-1	p	t	f	\N	\N	\N
2	16384	2620	3	2011-08-16	tgfoid	oid	-1	p	t	f	\N	\N	\N
2	16384	2620	4	2011-08-16	tgtype	smallint	-1	p	t	f	\N	\N	\N
2	16384	2620	5	2011-08-16	tgenabled	"char"	-1	p	t	f	\N	\N	\N
2	16384	2620	6	2011-08-16	tgisinternal	boolean	-1	p	t	f	\N	\N	\N
2	16384	2620	7	2011-08-16	tgconstrrelid	oid	-1	p	t	f	\N	\N	\N
2	16384	2620	8	2011-08-16	tgconstrindid	oid	-1	p	t	f	\N	\N	\N
2	16384	2620	9	2011-08-16	tgconstraint	oid	-1	p	t	f	\N	\N	\N
2	16384	2620	10	2011-08-16	tgdeferrable	boolean	-1	p	t	f	\N	\N	\N
2	16384	2620	11	2011-08-16	tginitdeferred	boolean	-1	p	t	f	\N	\N	\N
2	16384	2620	12	2011-08-16	tgnargs	smallint	-1	p	t	f	\N	\N	\N
2	16384	2620	13	2011-08-16	tgattr	int2vector	-1	p	t	f	\N	\N	\N
2	16384	2620	14	2011-08-16	tgargs	bytea	-1	x	f	f	\N	\N	\N
2	16384	2620	15	2011-08-16	tgqual	text	-1	x	f	f	\N	\N	\N
2	16384	2609	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	0.85105699
2	16384	2609	2	2011-08-16	classoid	oid	-1	p	t	f	4	10	0.88925201
2	16384	2609	3	2011-08-16	objsubid	integer	-1	p	t	f	4	1	1
2	16384	2609	4	2011-08-16	description	text	-1	x	f	f	24	-0.53037798	-0.0348415
2	16384	2605	1	2011-08-16	castsource	oid	-1	p	t	f	4	-0.204188	0.26684299
2	16384	2605	2	2011-08-16	casttarget	oid	-1	p	t	f	4	-0.209424	0.204877
2	16384	2605	3	2011-08-16	castfunc	oid	-1	p	t	f	4	-0.52879602	0.378775
2	16384	2605	4	2011-08-16	castcontext	"char"	-1	p	t	f	1	3	0.231236
2	16384	2605	5	2011-08-16	castmethod	"char"	-1	p	t	f	1	2	0.70448101
2	16384	3501	1	2011-08-16	enumtypid	oid	-1	p	t	f	\N	\N	\N
2	16384	3501	2	2011-08-16	enumlabel	name	-1	p	t	f	\N	\N	\N
2	16384	2615	1	2011-08-16	nspname	name	-1	p	t	f	64	-1	-0.25714299
2	16384	2615	2	2011-08-16	nspowner	oid	-1	p	t	f	4	-0.166667	1
2	16384	2615	3	2011-08-16	nspacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	2607	1	2011-08-16	conname	name	-1	p	t	f	64	-1	0.034192
2	16384	2607	2	2011-08-16	connamespace	oid	-1	p	t	f	4	1	1
2	16384	2607	3	2011-08-16	conowner	oid	-1	p	t	f	4	1	1
2	16384	2607	4	2011-08-16	conforencoding	integer	-1	p	t	f	4	-0.31818199	-0.055730902
2	16384	2607	5	2011-08-16	contoencoding	integer	-1	p	t	f	4	-0.31818199	-0.063536704
2	16384	2607	6	2011-08-16	conproc	regproc	-1	p	t	f	4	-0.66666698	0.9946
2	16384	2607	7	2011-08-16	condefault	boolean	-1	p	t	f	1	1	1
2	16384	2608	1	2011-08-16	classid	oid	-1	p	t	f	4	11	0.985008
2	16384	2608	2	2011-08-16	objid	oid	-1	p	t	f	4	436	0.99999899
2	16384	2608	3	2011-08-16	objsubid	integer	-1	p	t	f	4	83	0.99429399
2	16384	2608	4	2011-08-16	refclassid	oid	-1	p	t	f	4	15	0.221155
2	16384	2608	5	2011-08-16	refobjid	oid	-1	p	t	f	4	-0.78687602	0.818048
2	16384	2608	6	2011-08-16	refobjsubid	integer	-1	p	t	f	4	23	0.99375898
2	16384	2608	7	2011-08-16	deptype	"char"	-1	p	t	f	1	4	-0.138106
2	16384	1262	1	2011-08-16	datname	name	-1	p	t	f	64	-1	\N
2	16384	1262	2	2011-08-16	datdba	oid	-1	p	t	f	4	-1	\N
2	16384	1262	3	2011-08-16	encoding	integer	-1	p	t	f	4	-1	\N
2	16384	1262	4	2011-08-16	datcollate	name	-1	p	t	f	64	-1	\N
2	16384	1262	5	2011-08-16	datctype	name	-1	p	t	f	64	-1	\N
2	16384	1262	6	2011-08-16	datistemplate	boolean	-1	p	t	f	1	-1	\N
2	16384	1262	7	2011-08-16	datallowconn	boolean	-1	p	t	f	1	-1	\N
2	16384	1262	8	2011-08-16	datconnlimit	integer	-1	p	t	f	4	-1	\N
2	16384	1262	9	2011-08-16	datlastsysoid	oid	-1	p	t	f	4	-1	\N
2	16384	1262	10	2011-08-16	datfrozenxid	xid	-1	p	t	f	4	-1	\N
2	16384	1262	11	2011-08-16	dattablespace	oid	-1	p	t	f	4	-1	\N
2	16384	1262	12	2011-08-16	datacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	2964	1	2011-08-16	setdatabase	oid	-1	p	t	f	\N	\N	\N
2	16384	2964	2	2011-08-16	setrole	oid	-1	p	t	f	\N	\N	\N
2	16384	2964	3	2011-08-16	setconfig	text[]	-1	x	f	f	\N	\N	\N
2	16384	1213	1	2011-08-16	spcname	name	-1	p	t	f	64	-1	1
2	16384	1213	2	2011-08-16	spcowner	oid	-1	p	t	f	4	-0.5	1
2	16384	1213	3	2011-08-16	spclocation	text	-1	x	f	f	1	-0.5	1
2	16384	1213	4	2011-08-16	spcacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	1213	5	2011-08-16	spcoptions	text[]	-1	x	f	f	0	0	\N
2	16384	1136	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	-0.071428597
2	16384	1136	2	2011-08-16	tmpltrusted	boolean	-1	p	t	f	1	-0.25	-0.26190501
2	16384	1136	3	2011-08-16	tmpldbacreate	boolean	-1	p	t	f	1	-0.25	-0.26190501
2	16384	1136	4	2011-08-16	tmplhandler	text	-1	x	f	f	20	-0.75	-0.071428597
2	16384	1136	5	2011-08-16	tmplinline	text	-1	x	f	f	23	-0.5	0.657143
2	16384	1136	6	2011-08-16	tmplvalidator	text	-1	x	f	f	17	-0.25	-0.5
2	16384	1136	7	2011-08-16	tmpllibrary	text	-1	x	f	f	15	-0.75	0
2	16384	1136	8	2011-08-16	tmplacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	1260	1	2011-08-16	rolname	name	-1	p	t	f	64	-1	\N
2	16384	1260	2	2011-08-16	rolsuper	boolean	-1	p	t	f	1	-1	\N
2	16384	1260	3	2011-08-16	rolinherit	boolean	-1	p	t	f	1	-1	\N
2	16384	1260	4	2011-08-16	rolcreaterole	boolean	-1	p	t	f	1	-1	\N
2	16384	1260	5	2011-08-16	rolcreatedb	boolean	-1	p	t	f	1	-1	\N
2	16384	1260	6	2011-08-16	rolcatupdate	boolean	-1	p	t	f	1	-1	\N
2	16384	1260	7	2011-08-16	rolcanlogin	boolean	-1	p	t	f	1	-1	\N
2	16384	1260	8	2011-08-16	rolconnlimit	integer	-1	p	t	f	4	-1	\N
2	16384	1260	9	2011-08-16	rolpassword	text	-1	x	f	f	0	0	\N
2	16384	1260	10	2011-08-16	rolvaliduntil	timestamp with time zone	-1	p	f	f	8	0	\N
2	16384	1261	1	2011-08-16	roleid	oid	-1	p	t	f	\N	\N	\N
2	16384	1261	2	2011-08-16	member	oid	-1	p	t	f	\N	\N	\N
2	16384	1261	3	2011-08-16	grantor	oid	-1	p	t	f	\N	\N	\N
2	16384	1261	4	2011-08-16	admin_option	boolean	-1	p	t	f	\N	\N	\N
2	16384	1214	1	2011-08-16	dbid	oid	-1	p	t	f	4	-1	\N
2	16384	1214	2	2011-08-16	classid	oid	-1	p	t	f	4	-1	\N
2	16384	1214	3	2011-08-16	objid	oid	-1	p	t	f	4	-1	\N
2	16384	1214	4	2011-08-16	objsubid	integer	-1	p	t	f	4	-1	\N
2	16384	1214	5	2011-08-16	refclassid	oid	-1	p	t	f	4	-1	\N
2	16384	1214	6	2011-08-16	refobjid	oid	-1	p	t	f	4	-1	\N
2	16384	1214	7	2011-08-16	deptype	"char"	-1	p	t	f	1	-1	\N
2	16384	2396	1	2011-08-16	objoid	oid	-1	p	t	f	4	-1	\N
2	16384	2396	2	2011-08-16	classoid	oid	-1	p	t	f	4	-1	\N
2	16384	2396	3	2011-08-16	description	text	-1	x	f	f	26	-1	\N
2	16384	3602	1	2011-08-16	cfgname	name	-1	p	t	f	64	-1	0.77058798
2	16384	3602	2	2011-08-16	cfgnamespace	oid	-1	p	t	f	4	1	1
2	16384	3602	3	2011-08-16	cfgowner	oid	-1	p	t	f	4	1	1
2	16384	3602	4	2011-08-16	cfgparser	oid	-1	p	t	f	4	1	1
2	16384	3603	1	2011-08-16	mapcfg	oid	-1	p	t	f	4	16	1
2	16384	3603	2	2011-08-16	maptokentype	integer	-1	p	t	f	4	19	0.0575522
2	16384	3603	3	2011-08-16	mapseqno	integer	-1	p	t	f	4	1	1
2	16384	3603	4	2011-08-16	mapdict	oid	-1	p	t	f	4	16	0.67357898
2	16384	3600	1	2011-08-16	dictname	name	-1	p	t	f	64	-1	0.77058798
2	16384	3600	2	2011-08-16	dictnamespace	oid	-1	p	t	f	4	1	1
2	16384	3600	3	2011-08-16	dictowner	oid	-1	p	t	f	4	1	1
2	16384	3600	4	2011-08-16	dicttemplate	oid	-1	p	t	f	4	-0.125	1
2	16384	3600	5	2011-08-16	dictinitoption	text	-1	x	f	f	42	-1	1
2	16384	3601	1	2011-08-16	prsname	name	-1	p	t	f	64	-1	\N
2	16384	3601	2	2011-08-16	prsnamespace	oid	-1	p	t	f	4	-1	\N
2	16384	3601	3	2011-08-16	prsstart	regproc	-1	p	t	f	4	-1	\N
2	16384	3601	4	2011-08-16	prstoken	regproc	-1	p	t	f	4	-1	\N
2	16384	3601	5	2011-08-16	prsend	regproc	-1	p	t	f	4	-1	\N
2	16384	3601	6	2011-08-16	prsheadline	regproc	-1	p	t	f	4	-1	\N
2	16384	3601	7	2011-08-16	prslextype	regproc	-1	p	t	f	4	-1	\N
2	16384	3764	1	2011-08-16	tmplname	name	-1	p	t	f	64	-1	0.30000001
2	16384	3764	2	2011-08-16	tmplnamespace	oid	-1	p	t	f	4	-0.2	1
2	16384	3764	3	2011-08-16	tmplinit	regproc	-1	p	t	f	4	-1	1
2	16384	3764	4	2011-08-16	tmpllexize	regproc	-1	p	t	f	4	-1	1
2	16384	2328	1	2011-08-16	fdwname	name	-1	p	t	f	\N	\N	\N
2	16384	2328	2	2011-08-16	fdwowner	oid	-1	p	t	f	\N	\N	\N
2	16384	2328	3	2011-08-16	fdwvalidator	oid	-1	p	t	f	\N	\N	\N
2	16384	2328	4	2011-08-16	fdwacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	2328	5	2011-08-16	fdwoptions	text[]	-1	x	f	f	\N	\N	\N
2	16384	1417	1	2011-08-16	srvname	name	-1	p	t	f	\N	\N	\N
2	16384	1417	2	2011-08-16	srvowner	oid	-1	p	t	f	\N	\N	\N
2	16384	1417	3	2011-08-16	srvfdw	oid	-1	p	t	f	\N	\N	\N
2	16384	1417	4	2011-08-16	srvtype	text	-1	x	f	f	\N	\N	\N
2	16384	1417	5	2011-08-16	srvversion	text	-1	x	f	f	\N	\N	\N
2	16384	1417	6	2011-08-16	srvacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	1417	7	2011-08-16	srvoptions	text[]	-1	x	f	f	\N	\N	\N
2	16384	1418	1	2011-08-16	umuser	oid	-1	p	t	f	\N	\N	\N
2	16384	1418	2	2011-08-16	umserver	oid	-1	p	t	f	\N	\N	\N
2	16384	1418	3	2011-08-16	umoptions	text[]	-1	x	f	f	\N	\N	\N
2	16384	826	1	2011-08-16	defaclrole	oid	-1	p	t	f	\N	\N	\N
2	16384	826	2	2011-08-16	defaclnamespace	oid	-1	p	t	f	\N	\N	\N
2	16384	826	3	2011-08-16	defaclobjtype	"char"	-1	p	t	f	\N	\N	\N
2	16384	826	4	2011-08-16	defaclacl	aclitem[]	-1	x	f	f	\N	\N	\N
2	16384	2830	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2830	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2830	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2832	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2832	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2832	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2834	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2834	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2834	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2836	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2836	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2836	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2838	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2838	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2838	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2840	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2840	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2840	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2336	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2336	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2336	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2844	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2844	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2844	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2846	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2846	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2846	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	2966	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	2966	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	2966	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	11454	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	5	-0.70769203	0.983832
2	16384	11454	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	27	-0.70923102	0.37094799
2	16384	11454	3	2011-08-16	sub_feature_id	information_schema.character_data	-1	x	f	f	1	18	0.042565402
2	16384	11454	4	2011-08-16	sub_feature_name	information_schema.character_data	-1	x	f	f	9	-0.292308	0.04391
2	16384	11454	5	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	2	0.057943199
2	16384	11454	6	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
2	16384	11454	7	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	11	0.97430003
2	16384	11456	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	11456	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	11456	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	11459	1	2011-08-16	implementation_info_id	information_schema.character_data	-1	x	f	f	3	-1	0.55244797
2	16384	11459	2	2011-08-16	implementation_info_name	information_schema.character_data	-1	x	f	f	17	-1	0.85314697
2	16384	11459	3	2011-08-16	integer_value	information_schema.cardinal_number	-1	p	f	f	4	-0.33333299	0.2
2	16384	11459	4	2011-08-16	character_value	information_schema.character_data	-1	x	f	f	4	-0.33333299	0.035714298
2	16384	11459	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	29	-1	-0.178571
2	16384	11461	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	11461	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	11461	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	11464	1	2011-08-16	sql_language_source	information_schema.character_data	-1	x	f	f	9	-0.25	1
2	16384	11464	2	2011-08-16	sql_language_year	information_schema.character_data	-1	x	f	f	5	-0.5	1
2	16384	11464	3	2011-08-16	sql_language_conformance	information_schema.character_data	-1	x	f	f	5	-0.25	1
2	16384	11464	4	2011-08-16	sql_language_integrity	information_schema.character_data	-1	x	f	f	0	0	\N
2	16384	11464	5	2011-08-16	sql_language_implementation	information_schema.character_data	-1	x	f	f	0	0	\N
2	16384	11464	6	2011-08-16	sql_language_binding_style	information_schema.character_data	-1	x	f	f	8	-0.5	0.80000001
2	16384	11464	7	2011-08-16	sql_language_programming_language	information_schema.character_data	-1	x	f	f	2	-0.25	1
2	16384	11466	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	11466	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	11466	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	11469	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	7	-1	1
2	16384	11469	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	15	-1	-0.090909101
2	16384	11469	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.2	0.563636
2	16384	11469	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
2	16384	11469	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	4	-0.40000001	0.69696999
2	16384	11471	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	11471	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	11471	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	11474	1	2011-08-16	feature_id	information_schema.character_data	-1	x	f	f	2	-1	-0.0666667
2	16384	11474	2	2011-08-16	feature_name	information_schema.character_data	-1	x	f	f	38	-1	0.783333
2	16384	11474	3	2011-08-16	is_supported	information_schema.yes_or_no	-1	x	f	f	3	-0.222222	1
2	16384	11474	4	2011-08-16	is_verified_by	information_schema.character_data	-1	x	f	f	0	0	\N
2	16384	11474	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	1	-0.111111	1
2	16384	11476	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	11476	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	11476	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	11479	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	4	-1	0.26581001
2	16384	11479	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	28	-1	0.479249
2	16384	11479	3	2011-08-16	supported_value	information_schema.cardinal_number	-1	p	f	f	4	-0.173913	0.55087698
2	16384	11479	4	2011-08-16	comments	information_schema.character_data	-1	x	f	f	43	1	1
2	16384	11481	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	11481	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	11481	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	11484	1	2011-08-16	sizing_id	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
2	16384	11484	2	2011-08-16	sizing_name	information_schema.character_data	-1	x	f	f	\N	\N	\N
2	16384	11484	3	2011-08-16	profile_id	information_schema.character_data	-1	x	f	f	\N	\N	\N
2	16384	11484	4	2011-08-16	required_value	information_schema.cardinal_number	-1	p	f	f	\N	\N	\N
2	16384	11484	5	2011-08-16	comments	information_schema.character_data	-1	x	f	f	\N	\N	\N
2	16384	11486	1	2011-08-16	chunk_id	oid	-1	p	f	f	\N	\N	\N
2	16384	11486	2	2011-08-16	chunk_seq	integer	-1	p	f	f	\N	\N	\N
2	16384	11486	3	2011-08-16	chunk_data	bytea	-1	p	f	f	\N	\N	\N
2	16384	16385	1	2011-08-16	bid	integer	-1	p	t	f	4	-1	0.33333299
2	16384	16385	2	2011-08-16	bbalance	integer	-1	p	f	f	4	-1	0.51666701
2	16384	16385	3	2011-08-16	filler	character(88)	-1	x	f	f	0	0	\N
2	16384	16388	1	2011-08-16	tid	integer	-1	p	t	f	4	-1	-0.063834399
2	16384	16388	2	2011-08-16	bid	integer	-1	p	f	f	4	10	0.037119702
2	16384	16388	3	2011-08-16	tbalance	integer	-1	p	f	f	4	-1	-0.080648102
2	16384	16388	4	2011-08-16	filler	character(84)	-1	x	f	f	0	0	\N
2	16384	16391	1	2011-08-16	aid	integer	-1	p	t	f	4	-1	0.96048701
2	16384	16391	2	2011-08-16	bid	integer	-1	p	f	f	4	10	0.966214
2	16384	16391	3	2011-08-16	abalance	integer	-1	p	f	f	4	6848	0.48422199
2	16384	16391	4	2011-08-16	filler	character(84)	-1	x	f	f	85	1	1
2	16384	16394	1	2011-08-16	tid	integer	-1	p	f	f	4	100	0.00993222
2	16384	16394	2	2011-08-16	bid	integer	-1	p	f	f	4	10	0.105938
2	16384	16394	3	2011-08-16	aid	integer	-1	p	f	f	4	-0.73838401	0.0090492396
2	16384	16394	4	2011-08-16	delta	integer	-1	p	f	f	4	9952	-0.0027644001
2	16384	16394	5	2011-08-16	mtime	timestamp without time zone	-1	p	f	f	8	-1	1
2	16384	16394	6	2011-08-16	filler	character(22)	-1	x	f	f	0	0	\N
\.


--
-- Data for Name: cpu; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY cpu (snapid, cpu_id, cpu_user, cpu_system, cpu_idle, cpu_iowait) FROM stdin;
1	cpu	478860	273042	9285180	1273692
2	cpu	508614	292579	9324117	1362228
\.


--
-- Data for Name: database; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY database (snapid, dbid, name, size, age, xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched, tup_inserted, tup_updated, tup_deleted) FROM stdin;
1	11874	postgres	5513960	29	23	0	315	2642	2655	1259	66	5	0
1	16384	testdb	162275844	29	38	0	102553	21380	3005340	1001682	1000236	9	32
2	11874	postgres	5513960	387251	96	0	2946	7884	103485	10384	66	5	0
2	16384	testdb	186680040	387251	387873	0	663578	7690196	18308049	2237606	1387381	1161756	32
\.


--
-- Data for Name: device; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY device (snapid, device_major, device_minor, device_name, device_readsector, device_readtime, device_writesector, device_writetime, device_ioqueue, device_iototaltime, device_tblspaces) FROM stdin;
1	253	2	dm-2	587266	67775	121524392	316087488	0	316155468	{pg_default,pg_global}
2	253	2	dm-2	587626	67937	140055008	420784749	0	420853595	{pg_default,pg_global}
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY function (snapid, dbid, funcid, nsp, funcname, argtypes, calls, total_time, self_time) FROM stdin;
1	11874	16419	16418	sample		2	0	0
1	11874	16421	16418	snapshot	comment text	1	1	1
2	11874	16413	2200	pg_stat_statements	OUT userid oid, OUT dbid oid, OUT query text, OUT calls bigint, OUT total_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint	1	0	0
2	11874	16419	16418	sample		362	3	3
2	11874	16420	16418	activity	OUT idle double precision, OUT idle_in_xact double precision, OUT waiting double precision, OUT running double precision, OUT client text, OUT pid integer, OUT start timestamp with time zone, OUT duration double precision, OUT query text	1	0	0
2	11874	16421	16418	snapshot	comment text	2	1	1
2	11874	16424	16418	tablespaces	OUT oid oid, OUT name text, OUT location text, OUT device text, OUT avail bigint, OUT total bigint, OUT spcoptions text[]	2	0	0
2	11874	16430	16418	cpustats	OUT cpu_id text, OUT cpu_user bigint, OUT cpu_system bigint, OUT cpu_idle bigint, OUT cpu_iowait bigint	1	0	0
2	11874	16431	16418	devicestats	OUT device_major text, OUT device_minor text, OUT device_name text, OUT device_readsector bigint, OUT device_readtime bigint, OUT device_writesector bigint, OUT device_writetime bigint, OUT device_ioqueue bigint, OUT device_iototaltime bigint, OUT device_tblspaces name[]	1	1	1
2	11874	16432	16418	profile	OUT processing text, OUT execute bigint, OUT total_exec_time double precision	1	1	1
\.


--
-- Data for Name: index; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY index (snapid, dbid, idx, tbl, date, tbs, name, relam, relpages, reltuples, reloptions, isunique, isprimary, isclustered, isvalid, indkey, indexdef, size, idx_scan, idx_tup_read, idx_tup_fetch, idx_blks_read, idx_blks_hit) FROM stdin;
\.


--
-- Data for Name: index_20110816; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY index_20110816 (snapid, dbid, idx, tbl, date, tbs, name, relam, relpages, reltuples, reloptions, isunique, isprimary, isclustered, isvalid, indkey, indexdef, size, idx_scan, idx_tup_read, idx_tup_fetch, idx_blks_read, idx_blks_hit) FROM stdin;
1	11874	2831	2830	2011-08-16	0	pg_toast_2604_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2604_index ON pg_toast.pg_toast_2604 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2833	2832	2011-08-16	0	pg_toast_2606_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2606_index ON pg_toast.pg_toast_2606 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2664	2606	2011-08-16	0	pg_constraint_conname_nsp_index	403	2	2	\N	f	f	f	t	1 2	CREATE INDEX pg_constraint_conname_nsp_index ON pg_constraint USING btree (conname, connamespace)	16384	0	0	0	0	0
1	11874	2651	2601	2011-08-16	0	pg_am_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_am_name_index ON pg_am USING btree (amname)	16384	0	0	0	0	0
1	11874	2652	2601	2011-08-16	0	pg_am_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_am_oid_index ON pg_am USING btree (oid)	16384	0	0	0	0	0
1	11874	2653	2602	2011-08-16	0	pg_amop_fam_strat_index	403	4	357	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amop_fam_strat_index ON pg_amop USING btree (amopfamily, amoplefttype, amoprighttype, amopstrategy)	32768	19	95	95	9	37
1	11874	2654	2602	2011-08-16	0	pg_amop_opr_fam_index	403	2	357	\N	t	f	f	t	5 1	CREATE UNIQUE INDEX pg_amop_opr_fam_index ON pg_amop USING btree (amopopr, amopfamily)	16384	1	2	2	2	0
1	11874	2756	2602	2011-08-16	0	pg_amop_oid_index	403	2	357	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amop_oid_index ON pg_amop USING btree (oid)	16384	0	0	0	0	0
1	11874	2655	2603	2011-08-16	0	pg_amproc_fam_proc_index	403	2	250	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amproc_fam_proc_index ON pg_amproc USING btree (amprocfamily, amproclefttype, amprocrighttype, amprocnum)	16384	19	19	19	6	21
1	11874	2757	2603	2011-08-16	0	pg_amproc_oid_index	403	2	250	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amproc_oid_index ON pg_amproc USING btree (oid)	16384	0	0	0	0	0
1	11874	2650	2600	2011-08-16	0	pg_aggregate_fnoid_index	403	2	119	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_aggregate_fnoid_index ON pg_aggregate USING btree (aggfnoid)	16384	0	0	0	0	0
1	11874	2839	2838	2011-08-16	0	pg_toast_2618_index	403	2	115	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2618_index ON pg_toast.pg_toast_2618 USING btree (chunk_id, chunk_seq)	16384	0	0	0	0	0
1	11874	2337	2336	2011-08-16	0	pg_toast_2620_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2620_index ON pg_toast.pg_toast_2620 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2835	2834	2011-08-16	0	pg_toast_2609_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2609_index ON pg_toast.pg_toast_2609 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2675	2609	2011-08-16	0	pg_description_o_c_o_index	403	12	2436	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_description_o_c_o_index ON pg_description USING btree (objoid, classoid, objsubid)	98304	0	0	0	0	0
1	11874	2660	2605	2011-08-16	0	pg_cast_oid_index	403	2	191	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_cast_oid_index ON pg_cast USING btree (oid)	16384	0	0	0	0	0
1	11874	2661	2605	2011-08-16	0	pg_cast_source_target_index	403	2	191	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_cast_source_target_index ON pg_cast USING btree (castsource, casttarget)	16384	0	0	0	0	0
1	11874	3502	3501	2011-08-16	0	pg_enum_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_enum_oid_index ON pg_enum USING btree (oid)	8192	0	0	0	0	0
1	11874	2668	2607	2011-08-16	0	pg_conversion_default_index	403	2	132	\N	t	f	f	t	2 4 5 -2	CREATE UNIQUE INDEX pg_conversion_default_index ON pg_conversion USING btree (connamespace, conforencoding, contoencoding, oid)	16384	0	0	0	0	0
1	11874	2669	2607	2011-08-16	0	pg_conversion_name_nsp_index	403	2	132	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_conversion_name_nsp_index ON pg_conversion USING btree (conname, connamespace)	16384	0	0	0	0	0
1	11874	2670	2607	2011-08-16	0	pg_conversion_oid_index	403	2	132	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_conversion_oid_index ON pg_conversion USING btree (oid)	16384	0	0	0	0	0
1	11874	2673	2608	2011-08-16	0	pg_depend_depender_index	403	25	5593	\N	f	f	f	t	1 2 3	CREATE INDEX pg_depend_depender_index ON pg_depend USING btree (classid, objid, objsubid)	204800	0	0	0	10	40
1	11874	2674	2608	2011-08-16	0	pg_depend_reference_index	403	25	5593	\N	f	f	f	t	4 5 6	CREATE INDEX pg_depend_reference_index ON pg_depend USING btree (refclassid, refobjid, refobjsubid)	204800	135	129	127	20	300
1	11874	2967	2966	2011-08-16	1664	pg_toast_2964_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2964_index ON pg_toast.pg_toast_2964 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2694	1261	2011-08-16	1664	pg_auth_members_role_member_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_auth_members_role_member_index ON pg_auth_members USING btree (roleid, member)	8192	0	0	0	0	0
1	11874	2695	1261	2011-08-16	1664	pg_auth_members_member_role_index	403	1	0	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_auth_members_member_role_index ON pg_auth_members USING btree (member, roleid)	8192	0	0	0	0	0
1	11874	2847	2846	2011-08-16	1664	pg_toast_2396_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2396_index ON pg_toast.pg_toast_2396 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2397	2396	2011-08-16	1664	pg_shdescription_o_c_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_shdescription_o_c_index ON pg_shdescription USING btree (objoid, classoid)	16384	0	0	0	0	0
1	11874	2658	1249	2011-08-16	0	pg_attribute_relid_attnam_index	403	14	1935	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attribute_relid_attnam_index ON pg_attribute USING btree (attrelid, attname)	114688	0	0	0	6	38
1	11874	2659	1249	2011-08-16	0	pg_attribute_relid_attnum_index	403	10	1935	\N	t	f	f	t	1 6	CREATE UNIQUE INDEX pg_attribute_relid_attnum_index ON pg_attribute USING btree (attrelid, attnum)	81920	174	587	587	17	381
1	11874	2676	1260	2011-08-16	1664	pg_authid_rolname_index	403	2	1	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_authid_rolname_index ON pg_authid USING btree (rolname)	16384	6	6	6	6	6
1	11874	2677	1260	2011-08-16	1664	pg_authid_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_authid_oid_index ON pg_authid USING btree (oid)	16384	6	6	6	6	6
1	11874	2837	2836	2011-08-16	0	pg_toast_1255_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1255_index ON pg_toast.pg_toast_1255 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2845	2844	2011-08-16	1664	pg_toast_1262_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1262_index ON pg_toast.pg_toast_1262 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2703	1247	2011-08-16	0	pg_type_oid_index	403	2	287	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_type_oid_index ON pg_type USING btree (oid)	16384	23	19	19	4	26
1	11874	2678	2610	2011-08-16	0	pg_index_indrelid_index	403	2	101	\N	f	f	f	t	2	CREATE INDEX pg_index_indrelid_index ON pg_index USING btree (indrelid)	16384	15	30	30	6	12
1	11874	2679	2610	2011-08-16	0	pg_index_indexrelid_index	403	2	101	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_index_indexrelid_index ON pg_index USING btree (indexrelid)	16384	115	115	115	6	117
1	11874	2688	2617	2011-08-16	0	pg_operator_oid_index	403	4	705	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_operator_oid_index ON pg_operator USING btree (oid)	32768	1	1	1	3	0
1	11874	2689	2617	2011-08-16	0	pg_operator_oprname_l_r_n_index	403	5	705	\N	t	f	f	t	1 7 8 2	CREATE UNIQUE INDEX pg_operator_oprname_l_r_n_index ON pg_operator USING btree (oprname, oprleft, oprright, oprnamespace)	40960	1	1	1	3	0
1	11874	2754	2753	2011-08-16	0	pg_opfamily_am_name_nsp_index	403	2	69	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opfamily_am_name_nsp_index ON pg_opfamily USING btree (opfmethod, opfname, opfnamespace)	16384	0	0	0	0	0
1	11874	2755	2753	2011-08-16	0	pg_opfamily_oid_index	403	2	69	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opfamily_oid_index ON pg_opfamily USING btree (oid)	16384	0	0	0	0	0
1	11874	2686	2616	2011-08-16	0	pg_opclass_am_name_nsp_index	403	2	112	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opclass_am_name_nsp_index ON pg_opclass USING btree (opcmethod, opcname, opcnamespace)	16384	0	0	0	0	0
1	11874	2687	2616	2011-08-16	0	pg_opclass_oid_index	403	2	112	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opclass_oid_index ON pg_opclass USING btree (oid)	16384	19	19	19	6	21
1	11874	2681	2612	2011-08-16	0	pg_language_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_language_name_index ON pg_language USING btree (lanname)	16384	2	2	2	4	0
1	11874	2682	2612	2011-08-16	0	pg_language_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_language_oid_index ON pg_language USING btree (oid)	16384	0	0	0	0	0
1	11874	2996	2995	2011-08-16	0	pg_largeobject_metadata_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_largeobject_metadata_oid_index ON pg_largeobject_metadata USING btree (oid)	8192	0	0	0	0	0
1	11874	2692	2618	2011-08-16	0	pg_rewrite_oid_index	403	2	86	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_rewrite_oid_index ON pg_rewrite USING btree (oid)	16384	2	0	0	4	2
1	11874	2693	2618	2011-08-16	0	pg_rewrite_rel_rulename_index	403	2	86	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_rewrite_rel_rulename_index ON pg_rewrite USING btree (ev_class, rulename)	16384	3	1	1	4	3
1	11874	2699	2620	2011-08-16	0	pg_trigger_tgconstraint_index	403	1	0	\N	f	f	f	t	9	CREATE INDEX pg_trigger_tgconstraint_index ON pg_trigger USING btree (tgconstraint)	8192	0	0	0	0	0
1	11874	2701	2620	2011-08-16	0	pg_trigger_tgrelid_tgname_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_trigger_tgrelid_tgname_index ON pg_trigger USING btree (tgrelid, tgname)	8192	0	0	0	0	0
1	11874	3503	3501	2011-08-16	0	pg_enum_typid_label_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_enum_typid_label_index ON pg_enum USING btree (enumtypid, enumlabel)	8192	0	0	0	0	0
1	11874	2684	2615	2011-08-16	0	pg_namespace_nspname_index	403	2	6	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_namespace_nspname_index ON pg_namespace USING btree (nspname)	16384	10	8	8	4	10
1	11874	2685	2615	2011-08-16	0	pg_namespace_oid_index	403	2	6	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_namespace_oid_index ON pg_namespace USING btree (oid)	16384	2	1	1	2	2
1	11874	2697	1213	2011-08-16	1664	pg_tablespace_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_tablespace_oid_index ON pg_tablespace USING btree (oid)	16384	2	2	2	4	0
1	11874	2698	1213	2011-08-16	1664	pg_tablespace_spcname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_tablespace_spcname_index ON pg_tablespace USING btree (spcname)	16384	0	0	0	0	0
1	11874	1137	1136	2011-08-16	1664	pg_pltemplate_name_index	403	2	8	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_pltemplate_name_index ON pg_pltemplate USING btree (tmplname)	16384	0	0	0	0	0
1	11874	1232	1214	2011-08-16	1664	pg_shdepend_depender_index	403	2	1	\N	f	f	f	t	1 2 3 4	CREATE INDEX pg_shdepend_depender_index ON pg_shdepend USING btree (dbid, classid, objid, objsubid)	16384	7	0	0	4	5
1	11874	1233	1214	2011-08-16	1664	pg_shdepend_reference_index	403	2	1	\N	f	f	f	t	5 6	CREATE INDEX pg_shdepend_reference_index ON pg_shdepend USING btree (refclassid, refobjid)	16384	22	22	22	6	21
1	11874	3608	3602	2011-08-16	0	pg_ts_config_cfgname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_config_cfgname_index ON pg_ts_config USING btree (cfgname, cfgnamespace)	16384	0	0	0	0	0
1	11874	3712	3602	2011-08-16	0	pg_ts_config_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_config_oid_index ON pg_ts_config USING btree (oid)	16384	0	0	0	0	0
1	11874	3609	3603	2011-08-16	0	pg_ts_config_map_index	403	4	304	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_ts_config_map_index ON pg_ts_config_map USING btree (mapcfg, maptokentype, mapseqno)	32768	0	0	0	0	0
1	11874	3604	3600	2011-08-16	0	pg_ts_dict_dictname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_dict_dictname_index ON pg_ts_dict USING btree (dictname, dictnamespace)	16384	0	0	0	0	0
1	11874	3605	3600	2011-08-16	0	pg_ts_dict_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_dict_oid_index ON pg_ts_dict USING btree (oid)	16384	0	0	0	0	0
1	11874	3606	3601	2011-08-16	0	pg_ts_parser_prsname_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_parser_prsname_index ON pg_ts_parser USING btree (prsname, prsnamespace)	16384	0	0	0	0	0
1	11874	3607	3601	2011-08-16	0	pg_ts_parser_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_parser_oid_index ON pg_ts_parser USING btree (oid)	16384	0	0	0	0	0
1	11874	3766	3764	2011-08-16	0	pg_ts_template_tmplname_index	403	2	5	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_template_tmplname_index ON pg_ts_template USING btree (tmplname, tmplnamespace)	16384	0	0	0	0	0
1	11874	3767	3764	2011-08-16	0	pg_ts_template_oid_index	403	2	5	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_template_oid_index ON pg_ts_template USING btree (oid)	16384	0	0	0	0	0
1	11874	112	2328	2011-08-16	0	pg_foreign_data_wrapper_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_data_wrapper_oid_index ON pg_foreign_data_wrapper USING btree (oid)	8192	0	0	0	0	0
1	11874	548	2328	2011-08-16	0	pg_foreign_data_wrapper_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_data_wrapper_name_index ON pg_foreign_data_wrapper USING btree (fdwname)	8192	0	0	0	0	0
1	11874	113	1417	2011-08-16	0	pg_foreign_server_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_server_oid_index ON pg_foreign_server USING btree (oid)	8192	0	0	0	0	0
1	11874	549	1417	2011-08-16	0	pg_foreign_server_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_server_name_index ON pg_foreign_server USING btree (srvname)	8192	0	0	0	0	0
1	11874	827	826	2011-08-16	0	pg_default_acl_role_nsp_obj_index	403	1	0	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_default_acl_role_nsp_obj_index ON pg_default_acl USING btree (defaclrole, defaclnamespace, defaclobjtype)	8192	8	0	0	2	6
1	11874	828	826	2011-08-16	0	pg_default_acl_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_default_acl_oid_index ON pg_default_acl USING btree (oid)	8192	0	0	0	0	0
1	11874	2683	2613	2011-08-16	0	pg_largeobject_loid_pn_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_largeobject_loid_pn_index ON pg_largeobject USING btree (loid, pageno)	8192	0	0	0	0	0
1	11874	174	1418	2011-08-16	0	pg_user_mapping_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_user_mapping_oid_index ON pg_user_mapping USING btree (oid)	8192	0	0	0	0	0
1	11874	175	1418	2011-08-16	0	pg_user_mapping_user_server_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_user_mapping_user_server_index ON pg_user_mapping USING btree (umuser, umserver)	8192	0	0	0	0	0
1	11874	2690	1255	2011-08-16	0	pg_proc_oid_index	403	9	2255	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_proc_oid_index ON pg_proc USING btree (oid)	73728	29	17	17	7	80
1	11874	2691	1255	2011-08-16	0	pg_proc_proname_args_nsp_index	403	22	2255	\N	t	f	f	t	1 17 2	CREATE UNIQUE INDEX pg_proc_proname_args_nsp_index ON pg_proc USING btree (proname, proargtypes, pronamespace)	180224	17	6	6	10	53
1	11874	2671	1262	2011-08-16	1664	pg_database_datname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_database_datname_index ON pg_database USING btree (datname)	16384	17	16	16	6	21
1	11874	2965	2964	2011-08-16	1664	pg_db_role_setting_databaseid_rol_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_db_role_setting_databaseid_rol_index ON pg_db_role_setting USING btree (setdatabase, setrole)	8192	33	0	0	3	30
1	11874	11488	11486	2011-08-16	0	pg_toast_11484_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11484_index ON pg_toast.pg_toast_11484 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2672	1262	2011-08-16	1664	pg_database_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_database_oid_index ON pg_database USING btree (oid)	16384	20	19	19	6	26
1	11874	11483	11481	2011-08-16	0	pg_toast_11479_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11479_index ON pg_toast.pg_toast_11479 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	11463	11461	2011-08-16	0	pg_toast_11459_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11459_index ON pg_toast.pg_toast_11459 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2841	2840	2011-08-16	0	pg_toast_2619_index	403	2	9	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2619_index ON pg_toast.pg_toast_2619 USING btree (chunk_id, chunk_seq)	16384	0	0	0	0	0
1	11874	2696	2619	2011-08-16	0	pg_statistic_relid_att_inh_index	403	2	340	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_statistic_relid_att_inh_index ON pg_statistic USING btree (starelid, staattnum, stainherit)	16384	1	1	1	2	0
1	11874	2704	1247	2011-08-16	0	pg_type_typname_nsp_index	403	5	287	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_type_typname_nsp_index ON pg_type USING btree (typname, typnamespace)	40960	20	15	15	10	43
1	11874	2662	1259	2011-08-16	0	pg_class_oid_index	403	2	253	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_class_oid_index ON pg_class USING btree (oid)	16384	193	191	191	6	197
1	11874	2663	1259	2011-08-16	0	pg_class_relname_nsp_index	403	5	253	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_class_relname_nsp_index ON pg_class USING btree (relname, relnamespace)	40960	5	2	2	7	9
1	11874	11468	11466	2011-08-16	0	pg_toast_11464_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11464_index ON pg_toast.pg_toast_11464 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	11473	11471	2011-08-16	0	pg_toast_11469_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11469_index ON pg_toast.pg_toast_11469 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	11478	11476	2011-08-16	0	pg_toast_11474_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11474_index ON pg_toast.pg_toast_11474 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	11874	2656	2604	2011-08-16	0	pg_attrdef_adrelid_adnum_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attrdef_adrelid_adnum_index ON pg_attrdef USING btree (adrelid, adnum)	8192	0	0	0	0	0
1	11874	2657	2604	2011-08-16	0	pg_attrdef_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_attrdef_oid_index ON pg_attrdef USING btree (oid)	8192	0	0	0	0	0
1	11874	2665	2606	2011-08-16	0	pg_constraint_conrelid_index	403	2	2	\N	f	f	f	t	6	CREATE INDEX pg_constraint_conrelid_index ON pg_constraint USING btree (conrelid)	16384	0	0	0	0	0
1	11874	2666	2606	2011-08-16	0	pg_constraint_contypid_index	403	2	2	\N	f	f	f	t	7	CREATE INDEX pg_constraint_contypid_index ON pg_constraint USING btree (contypid)	16384	0	0	0	0	0
1	11874	2667	2606	2011-08-16	0	pg_constraint_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_constraint_oid_index ON pg_constraint USING btree (oid)	16384	0	0	0	0	0
1	11874	2187	2611	2011-08-16	0	pg_inherits_parent_index	403	1	0	\N	f	f	f	t	2	CREATE INDEX pg_inherits_parent_index ON pg_inherits USING btree (inhparent)	8192	0	0	0	0	0
1	11874	2680	2611	2011-08-16	0	pg_inherits_relid_seqno_index	403	1	0	\N	t	f	f	t	1 3	CREATE UNIQUE INDEX pg_inherits_relid_seqno_index ON pg_inherits USING btree (inhrelid, inhseqno)	8192	0	0	0	0	0
1	11874	2702	2620	2011-08-16	0	pg_trigger_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_trigger_oid_index ON pg_trigger USING btree (oid)	8192	0	0	0	0	0
1	11874	11458	11456	2011-08-16	0	pg_toast_11454_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11454_index ON pg_toast.pg_toast_11454 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2831	2830	2011-08-16	0	pg_toast_2604_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2604_index ON pg_toast.pg_toast_2604 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2833	2832	2011-08-16	0	pg_toast_2606_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2606_index ON pg_toast.pg_toast_2606 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2664	2606	2011-08-16	0	pg_constraint_conname_nsp_index	403	2	2	\N	f	f	f	t	1 2	CREATE INDEX pg_constraint_conname_nsp_index ON pg_constraint USING btree (conname, connamespace)	16384	0	0	0	2	2
1	16384	2651	2601	2011-08-16	0	pg_am_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_am_name_index ON pg_am USING btree (amname)	16384	0	0	0	0	0
1	16384	2652	2601	2011-08-16	0	pg_am_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_am_oid_index ON pg_am USING btree (oid)	16384	0	0	0	0	0
1	16384	2653	2602	2011-08-16	0	pg_amop_fam_strat_index	403	4	357	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amop_fam_strat_index ON pg_amop USING btree (amopfamily, amoplefttype, amoprighttype, amopstrategy)	32768	24	56	56	6	45
1	16384	2654	2602	2011-08-16	0	pg_amop_opr_fam_index	403	2	357	\N	t	f	f	t	5 1	CREATE UNIQUE INDEX pg_amop_opr_fam_index ON pg_amop USING btree (amopopr, amopfamily)	16384	10	14	14	4	8
1	16384	2756	2602	2011-08-16	0	pg_amop_oid_index	403	2	357	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amop_oid_index ON pg_amop USING btree (oid)	16384	0	0	0	0	0
1	16384	2655	2603	2011-08-16	0	pg_amproc_fam_proc_index	403	2	250	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amproc_fam_proc_index ON pg_amproc USING btree (amprocfamily, amproclefttype, amprocrighttype, amprocnum)	16384	11	11	11	4	10
1	16384	2757	2603	2011-08-16	0	pg_amproc_oid_index	403	2	250	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amproc_oid_index ON pg_amproc USING btree (oid)	16384	0	0	0	0	0
1	16384	2650	2600	2011-08-16	0	pg_aggregate_fnoid_index	403	2	119	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_aggregate_fnoid_index ON pg_aggregate USING btree (aggfnoid)	16384	1	1	1	2	0
1	16384	2839	2838	2011-08-16	0	pg_toast_2618_index	403	2	115	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2618_index ON pg_toast.pg_toast_2618 USING btree (chunk_id, chunk_seq)	16384	0	0	0	0	0
1	16384	2337	2336	2011-08-16	0	pg_toast_2620_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2620_index ON pg_toast.pg_toast_2620 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2835	2834	2011-08-16	0	pg_toast_2609_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2609_index ON pg_toast.pg_toast_2609 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2675	2609	2011-08-16	0	pg_description_o_c_o_index	403	12	2436	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_description_o_c_o_index ON pg_description USING btree (objoid, classoid, objsubid)	98304	6	0	0	3	10
1	16384	2660	2605	2011-08-16	0	pg_cast_oid_index	403	2	191	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_cast_oid_index ON pg_cast USING btree (oid)	16384	0	0	0	0	0
1	16384	2661	2605	2011-08-16	0	pg_cast_source_target_index	403	2	191	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_cast_source_target_index ON pg_cast USING btree (castsource, casttarget)	16384	71	15	15	4	69
1	16384	3502	3501	2011-08-16	0	pg_enum_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_enum_oid_index ON pg_enum USING btree (oid)	8192	0	0	0	0	0
1	16384	2668	2607	2011-08-16	0	pg_conversion_default_index	403	2	132	\N	t	f	f	t	2 4 5 -2	CREATE UNIQUE INDEX pg_conversion_default_index ON pg_conversion USING btree (connamespace, conforencoding, contoencoding, oid)	16384	0	0	0	0	0
1	16384	2669	2607	2011-08-16	0	pg_conversion_name_nsp_index	403	2	132	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_conversion_name_nsp_index ON pg_conversion USING btree (conname, connamespace)	16384	0	0	0	0	0
1	16384	2670	2607	2011-08-16	0	pg_conversion_oid_index	403	2	132	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_conversion_oid_index ON pg_conversion USING btree (oid)	16384	0	0	0	0	0
1	16384	2673	2608	2011-08-16	0	pg_depend_depender_index	403	25	5593	\N	f	f	f	t	1 2 3	CREATE INDEX pg_depend_depender_index ON pg_depend USING btree (classid, objid, objsubid)	204800	12	12	12	7	67
1	16384	2674	2608	2011-08-16	0	pg_depend_reference_index	403	25	5593	\N	f	f	f	t	4 5 6	CREATE INDEX pg_depend_reference_index ON pg_depend USING btree (refclassid, refobjid, refobjsubid)	204800	106	89	88	17	245
1	16384	2967	2966	2011-08-16	1664	pg_toast_2964_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2964_index ON pg_toast.pg_toast_2964 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2694	1261	2011-08-16	1664	pg_auth_members_role_member_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_auth_members_role_member_index ON pg_auth_members USING btree (roleid, member)	8192	0	0	0	0	0
1	16384	2695	1261	2011-08-16	1664	pg_auth_members_member_role_index	403	1	0	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_auth_members_member_role_index ON pg_auth_members USING btree (member, roleid)	8192	0	0	0	0	0
1	16384	2847	2846	2011-08-16	1664	pg_toast_2396_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2396_index ON pg_toast.pg_toast_2396 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2397	2396	2011-08-16	1664	pg_shdescription_o_c_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_shdescription_o_c_index ON pg_shdescription USING btree (objoid, classoid)	16384	0	0	0	0	0
1	16384	2658	1249	2011-08-16	0	pg_attribute_relid_attnam_index	403	14	1935	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attribute_relid_attnam_index ON pg_attribute USING btree (attrelid, attname)	114688	3	3	3	5	131
1	16384	2659	1249	2011-08-16	0	pg_attribute_relid_attnum_index	403	10	1935	\N	t	f	f	t	1 6	CREATE UNIQUE INDEX pg_attribute_relid_attnum_index ON pg_attribute USING btree (attrelid, attnum)	81920	143	451	451	12	405
1	16384	2676	1260	2011-08-16	1664	pg_authid_rolname_index	403	2	1	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_authid_rolname_index ON pg_authid USING btree (rolname)	16384	6	6	6	6	6
1	16384	2677	1260	2011-08-16	1664	pg_authid_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_authid_oid_index ON pg_authid USING btree (oid)	16384	6	6	6	6	6
1	16384	2837	2836	2011-08-16	0	pg_toast_1255_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1255_index ON pg_toast.pg_toast_1255 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2845	2844	2011-08-16	1664	pg_toast_1262_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1262_index ON pg_toast.pg_toast_1262 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2703	1247	2011-08-16	0	pg_type_oid_index	403	2	287	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_type_oid_index ON pg_type USING btree (oid)	16384	38	26	26	3	49
1	16384	2678	2610	2011-08-16	0	pg_index_indrelid_index	403	2	101	\N	f	f	f	t	2	CREATE INDEX pg_index_indrelid_index ON pg_index USING btree (indrelid)	16384	24	33	33	3	26
1	16384	2679	2610	2011-08-16	0	pg_index_indexrelid_index	403	2	101	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_index_indexrelid_index ON pg_index USING btree (indexrelid)	16384	68	68	68	4	70
1	16384	2688	2617	2011-08-16	0	pg_operator_oid_index	403	4	705	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_operator_oid_index ON pg_operator USING btree (oid)	32768	13	13	13	7	21
1	16384	2689	2617	2011-08-16	0	pg_operator_oprname_l_r_n_index	403	5	705	\N	t	f	f	t	1 7 8 2	CREATE UNIQUE INDEX pg_operator_oprname_l_r_n_index ON pg_operator USING btree (oprname, oprleft, oprright, oprnamespace)	40960	9	9	9	5	14
1	16384	2754	2753	2011-08-16	0	pg_opfamily_am_name_nsp_index	403	2	69	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opfamily_am_name_nsp_index ON pg_opfamily USING btree (opfmethod, opfname, opfnamespace)	16384	0	0	0	0	0
1	16384	2755	2753	2011-08-16	0	pg_opfamily_oid_index	403	2	69	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opfamily_oid_index ON pg_opfamily USING btree (oid)	16384	0	0	0	0	0
1	16384	2686	2616	2011-08-16	0	pg_opclass_am_name_nsp_index	403	2	112	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opclass_am_name_nsp_index ON pg_opclass USING btree (opcmethod, opcname, opcnamespace)	16384	7	280	280	4	5
1	16384	2687	2616	2011-08-16	0	pg_opclass_oid_index	403	2	112	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opclass_oid_index ON pg_opclass USING btree (oid)	16384	12	12	12	4	11
1	16384	2681	2612	2011-08-16	0	pg_language_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_language_name_index ON pg_language USING btree (lanname)	16384	0	0	0	0	0
1	16384	2682	2612	2011-08-16	0	pg_language_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_language_oid_index ON pg_language USING btree (oid)	16384	0	0	0	0	0
1	16384	2996	2995	2011-08-16	0	pg_largeobject_metadata_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_largeobject_metadata_oid_index ON pg_largeobject_metadata USING btree (oid)	8192	0	0	0	0	0
1	16384	2692	2618	2011-08-16	0	pg_rewrite_oid_index	403	2	86	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_rewrite_oid_index ON pg_rewrite USING btree (oid)	16384	0	0	0	0	0
1	16384	2693	2618	2011-08-16	0	pg_rewrite_rel_rulename_index	403	2	86	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_rewrite_rel_rulename_index ON pg_rewrite USING btree (ev_class, rulename)	16384	0	0	0	0	0
1	16384	2699	2620	2011-08-16	0	pg_trigger_tgconstraint_index	403	1	0	\N	f	f	f	t	9	CREATE INDEX pg_trigger_tgconstraint_index ON pg_trigger USING btree (tgconstraint)	8192	0	0	0	0	0
1	16384	2701	2620	2011-08-16	0	pg_trigger_tgrelid_tgname_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_trigger_tgrelid_tgname_index ON pg_trigger USING btree (tgrelid, tgname)	8192	0	0	0	0	0
1	16384	3503	3501	2011-08-16	0	pg_enum_typid_label_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_enum_typid_label_index ON pg_enum USING btree (enumtypid, enumlabel)	8192	0	0	0	0	0
1	16384	2684	2615	2011-08-16	0	pg_namespace_nspname_index	403	2	6	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_namespace_nspname_index ON pg_namespace USING btree (nspname)	16384	6	4	4	3	5
1	16384	2685	2615	2011-08-16	0	pg_namespace_oid_index	403	2	6	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_namespace_oid_index ON pg_namespace USING btree (oid)	16384	1	1	1	2	0
1	16384	2697	1213	2011-08-16	1664	pg_tablespace_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_tablespace_oid_index ON pg_tablespace USING btree (oid)	16384	2	2	2	4	0
1	16384	2698	1213	2011-08-16	1664	pg_tablespace_spcname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_tablespace_spcname_index ON pg_tablespace USING btree (spcname)	16384	0	0	0	0	0
1	16384	1137	1136	2011-08-16	1664	pg_pltemplate_name_index	403	2	8	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_pltemplate_name_index ON pg_pltemplate USING btree (tmplname)	16384	0	0	0	0	0
1	16384	1232	1214	2011-08-16	1664	pg_shdepend_depender_index	403	2	1	\N	f	f	f	t	1 2 3 4	CREATE INDEX pg_shdepend_depender_index ON pg_shdepend USING btree (dbid, classid, objid, objsubid)	16384	7	0	0	4	5
1	16384	1233	1214	2011-08-16	1664	pg_shdepend_reference_index	403	2	1	\N	f	f	f	t	5 6	CREATE INDEX pg_shdepend_reference_index ON pg_shdepend USING btree (refclassid, refobjid)	16384	22	22	22	6	21
1	16384	3608	3602	2011-08-16	0	pg_ts_config_cfgname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_config_cfgname_index ON pg_ts_config USING btree (cfgname, cfgnamespace)	16384	0	0	0	0	0
1	16384	3712	3602	2011-08-16	0	pg_ts_config_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_config_oid_index ON pg_ts_config USING btree (oid)	16384	0	0	0	0	0
1	16384	3609	3603	2011-08-16	0	pg_ts_config_map_index	403	4	304	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_ts_config_map_index ON pg_ts_config_map USING btree (mapcfg, maptokentype, mapseqno)	32768	0	0	0	0	0
1	16384	3604	3600	2011-08-16	0	pg_ts_dict_dictname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_dict_dictname_index ON pg_ts_dict USING btree (dictname, dictnamespace)	16384	0	0	0	0	0
1	16384	3605	3600	2011-08-16	0	pg_ts_dict_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_dict_oid_index ON pg_ts_dict USING btree (oid)	16384	0	0	0	0	0
1	16384	3606	3601	2011-08-16	0	pg_ts_parser_prsname_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_parser_prsname_index ON pg_ts_parser USING btree (prsname, prsnamespace)	16384	0	0	0	0	0
1	16384	3607	3601	2011-08-16	0	pg_ts_parser_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_parser_oid_index ON pg_ts_parser USING btree (oid)	16384	0	0	0	0	0
1	16384	3766	3764	2011-08-16	0	pg_ts_template_tmplname_index	403	2	5	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_template_tmplname_index ON pg_ts_template USING btree (tmplname, tmplnamespace)	16384	0	0	0	0	0
1	16384	3767	3764	2011-08-16	0	pg_ts_template_oid_index	403	2	5	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_template_oid_index ON pg_ts_template USING btree (oid)	16384	0	0	0	0	0
1	16384	112	2328	2011-08-16	0	pg_foreign_data_wrapper_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_data_wrapper_oid_index ON pg_foreign_data_wrapper USING btree (oid)	8192	0	0	0	0	0
1	16384	548	2328	2011-08-16	0	pg_foreign_data_wrapper_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_data_wrapper_name_index ON pg_foreign_data_wrapper USING btree (fdwname)	8192	0	0	0	0	0
1	16384	113	1417	2011-08-16	0	pg_foreign_server_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_server_oid_index ON pg_foreign_server USING btree (oid)	8192	0	0	0	0	0
1	16384	549	1417	2011-08-16	0	pg_foreign_server_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_server_name_index ON pg_foreign_server USING btree (srvname)	8192	0	0	0	0	0
1	16384	827	826	2011-08-16	0	pg_default_acl_role_nsp_obj_index	403	1	0	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_default_acl_role_nsp_obj_index ON pg_default_acl USING btree (defaclrole, defaclnamespace, defaclobjtype)	8192	2	0	0	1	1
1	16384	828	826	2011-08-16	0	pg_default_acl_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_default_acl_oid_index ON pg_default_acl USING btree (oid)	8192	0	0	0	0	0
1	16384	2683	2613	2011-08-16	0	pg_largeobject_loid_pn_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_largeobject_loid_pn_index ON pg_largeobject USING btree (loid, pageno)	8192	0	0	0	0	0
1	16384	174	1418	2011-08-16	0	pg_user_mapping_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_user_mapping_oid_index ON pg_user_mapping USING btree (oid)	8192	0	0	0	0	0
1	16384	175	1418	2011-08-16	0	pg_user_mapping_user_server_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_user_mapping_user_server_index ON pg_user_mapping USING btree (umuser, umserver)	8192	0	0	0	0	0
1	16384	2690	1255	2011-08-16	0	pg_proc_oid_index	403	9	2255	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_proc_oid_index ON pg_proc USING btree (oid)	73728	16	16	16	7	26
1	16384	2691	1255	2011-08-16	0	pg_proc_proname_args_nsp_index	403	22	2255	\N	t	f	f	t	1 17 2	CREATE UNIQUE INDEX pg_proc_proname_args_nsp_index ON pg_proc USING btree (proname, proargtypes, pronamespace)	180224	5	20	20	7	4
1	16384	2671	1262	2011-08-16	1664	pg_database_datname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_database_datname_index ON pg_database USING btree (datname)	16384	17	16	16	6	21
1	16384	2965	2964	2011-08-16	1664	pg_db_role_setting_databaseid_rol_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_db_role_setting_databaseid_rol_index ON pg_db_role_setting USING btree (setdatabase, setrole)	8192	33	0	0	3	30
1	16384	11488	11486	2011-08-16	0	pg_toast_11484_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11484_index ON pg_toast.pg_toast_11484 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2672	1262	2011-08-16	1664	pg_database_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_database_oid_index ON pg_database USING btree (oid)	16384	20	19	19	6	26
1	16384	11483	11481	2011-08-16	0	pg_toast_11479_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11479_index ON pg_toast.pg_toast_11479 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	11463	11461	2011-08-16	0	pg_toast_11459_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11459_index ON pg_toast.pg_toast_11459 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	2841	2840	2011-08-16	0	pg_toast_2619_index	403	2	9	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2619_index ON pg_toast.pg_toast_2619 USING btree (chunk_id, chunk_seq)	16384	0	0	0	0	0
1	16384	2696	2619	2011-08-16	0	pg_statistic_relid_att_inh_index	403	2	340	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_statistic_relid_att_inh_index ON pg_statistic USING btree (starelid, staattnum, stainherit)	16384	22	8	8	4	31
1	16384	2704	1247	2011-08-16	0	pg_type_typname_nsp_index	403	5	287	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_type_typname_nsp_index ON pg_type USING btree (typname, typnamespace)	40960	18	3	3	9	54
1	16384	2662	1259	2011-08-16	0	pg_class_oid_index	403	2	253	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_class_oid_index ON pg_class USING btree (oid)	16384	431	422	422	4	440
1	16384	2663	1259	2011-08-16	0	pg_class_relname_nsp_index	403	5	253	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_class_relname_nsp_index ON pg_class USING btree (relname, relnamespace)	40960	36	16	16	8	86
1	16384	11468	11466	2011-08-16	0	pg_toast_11464_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11464_index ON pg_toast.pg_toast_11464 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	11473	11471	2011-08-16	0	pg_toast_11469_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11469_index ON pg_toast.pg_toast_11469 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	11478	11476	2011-08-16	0	pg_toast_11474_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11474_index ON pg_toast.pg_toast_11474 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
1	16384	16398	16385	2011-08-16	0	pgbench_branches_pkey	403	2	10	\N	t	t	f	t	1	CREATE UNIQUE INDEX pgbench_branches_pkey ON pgbench_branches USING btree (bid)	16384	0	0	0	1	0
1	16384	2656	2604	2011-08-16	0	pg_attrdef_adrelid_adnum_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attrdef_adrelid_adnum_index ON pg_attrdef USING btree (adrelid, adnum)	8192	0	0	0	0	0
1	16384	2657	2604	2011-08-16	0	pg_attrdef_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_attrdef_oid_index ON pg_attrdef USING btree (oid)	8192	0	0	0	0	0
1	16384	16402	16391	2011-08-16	0	pgbench_accounts_pkey	403	2745	1000000	\N	t	t	t	t	1	CREATE UNIQUE INDEX pgbench_accounts_pkey ON pgbench_accounts USING btree (aid)	22487040	1	1000000	1000000	5480	0
1	16384	16400	16388	2011-08-16	0	pgbench_tellers_pkey	403	2	100	\N	t	t	t	t	1	CREATE UNIQUE INDEX pgbench_tellers_pkey ON pgbench_tellers USING btree (tid)	16384	1	100	100	3	0
1	16384	2665	2606	2011-08-16	0	pg_constraint_conrelid_index	403	2	2	\N	f	f	f	t	6	CREATE INDEX pg_constraint_conrelid_index ON pg_constraint USING btree (conrelid)	16384	0	0	0	2	2
1	16384	2666	2606	2011-08-16	0	pg_constraint_contypid_index	403	2	2	\N	f	f	f	t	7	CREATE INDEX pg_constraint_contypid_index ON pg_constraint USING btree (contypid)	16384	0	0	0	2	2
1	16384	2667	2606	2011-08-16	0	pg_constraint_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_constraint_oid_index ON pg_constraint USING btree (oid)	16384	3	0	0	2	5
1	16384	2187	2611	2011-08-16	0	pg_inherits_parent_index	403	1	0	\N	f	f	f	t	2	CREATE INDEX pg_inherits_parent_index ON pg_inherits USING btree (inhparent)	8192	0	0	0	0	0
1	16384	2680	2611	2011-08-16	0	pg_inherits_relid_seqno_index	403	1	0	\N	t	f	f	t	1 3	CREATE UNIQUE INDEX pg_inherits_relid_seqno_index ON pg_inherits USING btree (inhrelid, inhseqno)	8192	2	0	0	1	1
1	16384	2702	2620	2011-08-16	0	pg_trigger_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_trigger_oid_index ON pg_trigger USING btree (oid)	8192	0	0	0	0	0
1	16384	11458	11456	2011-08-16	0	pg_toast_11454_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11454_index ON pg_toast.pg_toast_11454 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2831	2830	2011-08-16	0	pg_toast_2604_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2604_index ON pg_toast.pg_toast_2604 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2833	2832	2011-08-16	0	pg_toast_2606_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2606_index ON pg_toast.pg_toast_2606 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2664	2606	2011-08-16	0	pg_constraint_conname_nsp_index	403	2	2	\N	f	f	f	t	1 2	CREATE INDEX pg_constraint_conname_nsp_index ON pg_constraint USING btree (conname, connamespace)	16384	0	0	0	0	0
2	11874	2651	2601	2011-08-16	0	pg_am_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_am_name_index ON pg_am USING btree (amname)	16384	0	0	0	0	0
2	11874	2652	2601	2011-08-16	0	pg_am_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_am_oid_index ON pg_am USING btree (oid)	16384	0	0	0	0	0
2	11874	2653	2602	2011-08-16	0	pg_amop_fam_strat_index	403	4	357	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amop_fam_strat_index ON pg_amop USING btree (amopfamily, amoplefttype, amoprighttype, amopstrategy)	32768	84	296	296	99	109
2	11874	2654	2602	2011-08-16	0	pg_amop_opr_fam_index	403	2	357	\N	t	f	f	t	5 1	CREATE UNIQUE INDEX pg_amop_opr_fam_index ON pg_amop USING btree (amopopr, amopfamily)	16384	29	43	43	2	29
2	11874	2756	2602	2011-08-16	0	pg_amop_oid_index	403	2	357	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amop_oid_index ON pg_amop USING btree (oid)	16384	0	0	0	0	0
2	11874	2655	2603	2011-08-16	0	pg_amproc_fam_proc_index	403	2	250	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amproc_fam_proc_index ON pg_amproc USING btree (amprocfamily, amproclefttype, amprocrighttype, amprocnum)	16384	64	64	64	66	38
2	11874	2757	2603	2011-08-16	0	pg_amproc_oid_index	403	2	250	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amproc_oid_index ON pg_amproc USING btree (oid)	16384	0	0	0	0	0
2	11874	2650	2600	2011-08-16	0	pg_aggregate_fnoid_index	403	2	119	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_aggregate_fnoid_index ON pg_aggregate USING btree (aggfnoid)	16384	1	1	1	2	0
2	11874	2839	2838	2011-08-16	0	pg_toast_2618_index	403	2	115	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2618_index ON pg_toast.pg_toast_2618 USING btree (chunk_id, chunk_seq)	16384	1	2	2	2	0
2	11874	2337	2336	2011-08-16	0	pg_toast_2620_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2620_index ON pg_toast.pg_toast_2620 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2835	2834	2011-08-16	0	pg_toast_2609_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2609_index ON pg_toast.pg_toast_2609 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2675	2609	2011-08-16	0	pg_description_o_c_o_index	403	12	2436	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_description_o_c_o_index ON pg_description USING btree (objoid, classoid, objsubid)	98304	0	0	0	0	0
2	11874	2660	2605	2011-08-16	0	pg_cast_oid_index	403	2	191	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_cast_oid_index ON pg_cast USING btree (oid)	16384	0	0	0	0	0
2	11874	2661	2605	2011-08-16	0	pg_cast_source_target_index	403	2	191	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_cast_source_target_index ON pg_cast USING btree (castsource, casttarget)	16384	227	24	24	2	226
2	11874	3502	3501	2011-08-16	0	pg_enum_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_enum_oid_index ON pg_enum USING btree (oid)	8192	0	0	0	0	0
2	11874	2668	2607	2011-08-16	0	pg_conversion_default_index	403	2	132	\N	t	f	f	t	2 4 5 -2	CREATE UNIQUE INDEX pg_conversion_default_index ON pg_conversion USING btree (connamespace, conforencoding, contoencoding, oid)	16384	0	0	0	0	0
2	11874	2669	2607	2011-08-16	0	pg_conversion_name_nsp_index	403	2	132	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_conversion_name_nsp_index ON pg_conversion USING btree (conname, connamespace)	16384	0	0	0	0	0
2	11874	2670	2607	2011-08-16	0	pg_conversion_oid_index	403	2	132	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_conversion_oid_index ON pg_conversion USING btree (oid)	16384	0	0	0	0	0
2	11874	2673	2608	2011-08-16	0	pg_depend_depender_index	403	25	5593	\N	f	f	f	t	1 2 3	CREATE INDEX pg_depend_depender_index ON pg_depend USING btree (classid, objid, objsubid)	204800	0	0	0	10	40
2	11874	2674	2608	2011-08-16	0	pg_depend_reference_index	403	25	5593	\N	f	f	f	t	4 5 6	CREATE INDEX pg_depend_reference_index ON pg_depend USING btree (refclassid, refobjid, refobjsubid)	204800	135	129	127	20	300
2	11874	2967	2966	2011-08-16	1664	pg_toast_2964_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2964_index ON pg_toast.pg_toast_2964 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2694	1261	2011-08-16	1664	pg_auth_members_role_member_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_auth_members_role_member_index ON pg_auth_members USING btree (roleid, member)	8192	0	0	0	0	0
2	11874	2695	1261	2011-08-16	1664	pg_auth_members_member_role_index	403	1	0	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_auth_members_member_role_index ON pg_auth_members USING btree (member, roleid)	8192	0	0	0	0	0
2	11874	2847	2846	2011-08-16	1664	pg_toast_2396_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2396_index ON pg_toast.pg_toast_2396 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2397	2396	2011-08-16	1664	pg_shdescription_o_c_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_shdescription_o_c_index ON pg_shdescription USING btree (objoid, classoid)	16384	0	0	0	0	0
2	11874	2658	1249	2011-08-16	0	pg_attribute_relid_attnam_index	403	14	1935	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attribute_relid_attnam_index ON pg_attribute USING btree (attrelid, attname)	114688	0	0	0	6	38
2	11874	2659	1249	2011-08-16	0	pg_attribute_relid_attnum_index	403	10	1935	\N	t	f	f	t	1 6	CREATE UNIQUE INDEX pg_attribute_relid_attnum_index ON pg_attribute USING btree (attrelid, attnum)	81920	575	1260	1260	109	1125
2	11874	2676	1260	2011-08-16	1664	pg_authid_rolname_index	403	2	1	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_authid_rolname_index ON pg_authid USING btree (rolname)	16384	285	285	285	270	300
2	11874	2677	1260	2011-08-16	1664	pg_authid_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_authid_oid_index ON pg_authid USING btree (oid)	16384	315	315	315	242	388
2	11874	2837	2836	2011-08-16	0	pg_toast_1255_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1255_index ON pg_toast.pg_toast_1255 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2845	2844	2011-08-16	1664	pg_toast_1262_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1262_index ON pg_toast.pg_toast_1262 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2703	1247	2011-08-16	0	pg_type_oid_index	403	2	287	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_type_oid_index ON pg_type USING btree (oid)	16384	74	69	69	6	77
2	11874	2678	2610	2011-08-16	0	pg_index_indrelid_index	403	2	101	\N	f	f	f	t	2	CREATE INDEX pg_index_indrelid_index ON pg_index USING btree (indrelid)	16384	22	42	42	6	20
2	11874	2679	2610	2011-08-16	0	pg_index_indexrelid_index	403	2	101	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_index_indexrelid_index ON pg_index USING btree (indexrelid)	16384	243	243	243	66	217
2	11874	2688	2617	2011-08-16	0	pg_operator_oid_index	403	4	705	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_operator_oid_index ON pg_operator USING btree (oid)	32768	21	21	21	3	41
2	11874	2689	2617	2011-08-16	0	pg_operator_oprname_l_r_n_index	403	5	705	\N	t	f	f	t	1 7 8 2	CREATE UNIQUE INDEX pg_operator_oprname_l_r_n_index ON pg_operator USING btree (oprname, oprleft, oprright, oprnamespace)	40960	15	73	73	5	27
2	11874	2754	2753	2011-08-16	0	pg_opfamily_am_name_nsp_index	403	2	69	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opfamily_am_name_nsp_index ON pg_opfamily USING btree (opfmethod, opfname, opfnamespace)	16384	0	0	0	0	0
2	11874	2755	2753	2011-08-16	0	pg_opfamily_oid_index	403	2	69	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opfamily_oid_index ON pg_opfamily USING btree (oid)	16384	0	0	0	0	0
2	11874	2686	2616	2011-08-16	0	pg_opclass_am_name_nsp_index	403	2	112	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opclass_am_name_nsp_index ON pg_opclass USING btree (opcmethod, opcname, opcnamespace)	16384	183	7320	7320	2	182
2	11874	2687	2616	2011-08-16	0	pg_opclass_oid_index	403	2	112	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opclass_oid_index ON pg_opclass USING btree (oid)	16384	64	64	64	66	38
2	11874	2681	2612	2011-08-16	0	pg_language_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_language_name_index ON pg_language USING btree (lanname)	16384	2	2	2	4	0
2	11874	2682	2612	2011-08-16	0	pg_language_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_language_oid_index ON pg_language USING btree (oid)	16384	0	0	0	0	0
2	11874	2996	2995	2011-08-16	0	pg_largeobject_metadata_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_largeobject_metadata_oid_index ON pg_largeobject_metadata USING btree (oid)	8192	0	0	0	0	0
2	11874	2692	2618	2011-08-16	0	pg_rewrite_oid_index	403	2	86	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_rewrite_oid_index ON pg_rewrite USING btree (oid)	16384	2	0	0	4	2
2	11874	2693	2618	2011-08-16	0	pg_rewrite_rel_rulename_index	403	2	86	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_rewrite_rel_rulename_index ON pg_rewrite USING btree (ev_class, rulename)	16384	8	8	8	4	8
2	11874	2699	2620	2011-08-16	0	pg_trigger_tgconstraint_index	403	1	0	\N	f	f	f	t	9	CREATE INDEX pg_trigger_tgconstraint_index ON pg_trigger USING btree (tgconstraint)	8192	0	0	0	0	0
2	11874	2701	2620	2011-08-16	0	pg_trigger_tgrelid_tgname_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_trigger_tgrelid_tgname_index ON pg_trigger USING btree (tgrelid, tgname)	8192	0	0	0	0	0
2	11874	3503	3501	2011-08-16	0	pg_enum_typid_label_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_enum_typid_label_index ON pg_enum USING btree (enumtypid, enumlabel)	8192	0	0	0	0	0
2	11874	2684	2615	2011-08-16	0	pg_namespace_nspname_index	403	2	6	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_namespace_nspname_index ON pg_namespace USING btree (nspname)	16384	20	17	17	6	20
2	11874	2685	2615	2011-08-16	0	pg_namespace_oid_index	403	2	6	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_namespace_oid_index ON pg_namespace USING btree (oid)	16384	4	3	3	2	4
2	11874	2697	1213	2011-08-16	1664	pg_tablespace_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_tablespace_oid_index ON pg_tablespace USING btree (oid)	16384	281	281	281	266	295
2	11874	2698	1213	2011-08-16	1664	pg_tablespace_spcname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_tablespace_spcname_index ON pg_tablespace USING btree (spcname)	16384	0	0	0	0	0
2	11874	1137	1136	2011-08-16	1664	pg_pltemplate_name_index	403	2	8	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_pltemplate_name_index ON pg_pltemplate USING btree (tmplname)	16384	0	0	0	0	0
2	11874	1232	1214	2011-08-16	1664	pg_shdepend_depender_index	403	2	1	\N	f	f	f	t	1 2 3 4	CREATE INDEX pg_shdepend_depender_index ON pg_shdepend USING btree (dbid, classid, objid, objsubid)	16384	7	0	0	4	5
2	11874	1233	1214	2011-08-16	1664	pg_shdepend_reference_index	403	2	1	\N	f	f	f	t	5 6	CREATE INDEX pg_shdepend_reference_index ON pg_shdepend USING btree (refclassid, refobjid)	16384	22	22	22	6	21
2	11874	3608	3602	2011-08-16	0	pg_ts_config_cfgname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_config_cfgname_index ON pg_ts_config USING btree (cfgname, cfgnamespace)	16384	0	0	0	0	0
2	11874	3712	3602	2011-08-16	0	pg_ts_config_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_config_oid_index ON pg_ts_config USING btree (oid)	16384	0	0	0	0	0
2	11874	3609	3603	2011-08-16	0	pg_ts_config_map_index	403	4	304	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_ts_config_map_index ON pg_ts_config_map USING btree (mapcfg, maptokentype, mapseqno)	32768	0	0	0	0	0
2	11874	3604	3600	2011-08-16	0	pg_ts_dict_dictname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_dict_dictname_index ON pg_ts_dict USING btree (dictname, dictnamespace)	16384	0	0	0	0	0
2	11874	3605	3600	2011-08-16	0	pg_ts_dict_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_dict_oid_index ON pg_ts_dict USING btree (oid)	16384	0	0	0	0	0
2	11874	3606	3601	2011-08-16	0	pg_ts_parser_prsname_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_parser_prsname_index ON pg_ts_parser USING btree (prsname, prsnamespace)	16384	0	0	0	0	0
2	11874	3607	3601	2011-08-16	0	pg_ts_parser_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_parser_oid_index ON pg_ts_parser USING btree (oid)	16384	0	0	0	0	0
2	11874	3766	3764	2011-08-16	0	pg_ts_template_tmplname_index	403	2	5	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_template_tmplname_index ON pg_ts_template USING btree (tmplname, tmplnamespace)	16384	0	0	0	0	0
2	11874	3767	3764	2011-08-16	0	pg_ts_template_oid_index	403	2	5	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_template_oid_index ON pg_ts_template USING btree (oid)	16384	0	0	0	0	0
2	11874	112	2328	2011-08-16	0	pg_foreign_data_wrapper_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_data_wrapper_oid_index ON pg_foreign_data_wrapper USING btree (oid)	8192	0	0	0	0	0
2	11874	548	2328	2011-08-16	0	pg_foreign_data_wrapper_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_data_wrapper_name_index ON pg_foreign_data_wrapper USING btree (fdwname)	8192	0	0	0	0	0
2	11874	113	1417	2011-08-16	0	pg_foreign_server_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_server_oid_index ON pg_foreign_server USING btree (oid)	8192	0	0	0	0	0
2	11874	549	1417	2011-08-16	0	pg_foreign_server_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_server_name_index ON pg_foreign_server USING btree (srvname)	8192	0	0	0	0	0
2	11874	827	826	2011-08-16	0	pg_default_acl_role_nsp_obj_index	403	1	0	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_default_acl_role_nsp_obj_index ON pg_default_acl USING btree (defaclrole, defaclnamespace, defaclobjtype)	8192	8	0	0	2	6
2	11874	828	826	2011-08-16	0	pg_default_acl_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_default_acl_oid_index ON pg_default_acl USING btree (oid)	8192	0	0	0	0	0
2	11874	2683	2613	2011-08-16	0	pg_largeobject_loid_pn_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_largeobject_loid_pn_index ON pg_largeobject USING btree (loid, pageno)	8192	0	0	0	0	0
2	11874	174	1418	2011-08-16	0	pg_user_mapping_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_user_mapping_oid_index ON pg_user_mapping USING btree (oid)	8192	0	0	0	0	0
2	11874	175	1418	2011-08-16	0	pg_user_mapping_user_server_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_user_mapping_user_server_index ON pg_user_mapping USING btree (umuser, umserver)	8192	0	0	0	0	0
2	11874	2690	1255	2011-08-16	0	pg_proc_oid_index	403	9	2255	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_proc_oid_index ON pg_proc USING btree (oid)	73728	93	81	81	15	202
2	11874	2691	1255	2011-08-16	0	pg_proc_proname_args_nsp_index	403	22	2255	\N	t	f	f	t	1 17 2	CREATE UNIQUE INDEX pg_proc_proname_args_nsp_index ON pg_proc USING btree (proname, proargtypes, pronamespace)	180224	55	59	59	16	125
2	11874	2671	1262	2011-08-16	1664	pg_database_datname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_database_datname_index ON pg_database USING btree (datname)	16384	635	634	634	106	878
2	11874	2965	2964	2011-08-16	1664	pg_db_role_setting_databaseid_rol_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_db_role_setting_databaseid_rol_index ON pg_db_role_setting USING btree (setdatabase, setrole)	8192	1050	0	0	3	1047
2	11874	11488	11486	2011-08-16	0	pg_toast_11484_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11484_index ON pg_toast.pg_toast_11484 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2672	1262	2011-08-16	1664	pg_database_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_database_oid_index ON pg_database USING btree (oid)	16384	479	478	478	142	688
2	11874	11483	11481	2011-08-16	0	pg_toast_11479_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11479_index ON pg_toast.pg_toast_11479 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	11463	11461	2011-08-16	0	pg_toast_11459_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11459_index ON pg_toast.pg_toast_11459 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2841	2840	2011-08-16	0	pg_toast_2619_index	403	2	9	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2619_index ON pg_toast.pg_toast_2619 USING btree (chunk_id, chunk_seq)	16384	0	0	0	0	0
2	11874	2696	2619	2011-08-16	0	pg_statistic_relid_att_inh_index	403	2	340	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_statistic_relid_att_inh_index ON pg_statistic USING btree (starelid, staattnum, stainherit)	16384	59	35	35	2	59
2	11874	2704	1247	2011-08-16	0	pg_type_typname_nsp_index	403	5	287	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_type_typname_nsp_index ON pg_type USING btree (typname, typnamespace)	40960	24	16	16	13	49
2	11874	2662	1259	2011-08-16	0	pg_class_oid_index	403	2	253	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_class_oid_index ON pg_class USING btree (oid)	16384	501	499	499	66	477
2	11874	2663	1259	2011-08-16	0	pg_class_relname_nsp_index	403	5	253	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_class_relname_nsp_index ON pg_class USING btree (relname, relnamespace)	40960	19	15	15	8	37
2	11874	11468	11466	2011-08-16	0	pg_toast_11464_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11464_index ON pg_toast.pg_toast_11464 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	11473	11471	2011-08-16	0	pg_toast_11469_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11469_index ON pg_toast.pg_toast_11469 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	11478	11476	2011-08-16	0	pg_toast_11474_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11474_index ON pg_toast.pg_toast_11474 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	11874	2656	2604	2011-08-16	0	pg_attrdef_adrelid_adnum_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attrdef_adrelid_adnum_index ON pg_attrdef USING btree (adrelid, adnum)	8192	0	0	0	0	0
2	11874	2657	2604	2011-08-16	0	pg_attrdef_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_attrdef_oid_index ON pg_attrdef USING btree (oid)	8192	0	0	0	0	0
2	11874	2665	2606	2011-08-16	0	pg_constraint_conrelid_index	403	2	2	\N	f	f	f	t	6	CREATE INDEX pg_constraint_conrelid_index ON pg_constraint USING btree (conrelid)	16384	0	0	0	0	0
2	11874	2666	2606	2011-08-16	0	pg_constraint_contypid_index	403	2	2	\N	f	f	f	t	7	CREATE INDEX pg_constraint_contypid_index ON pg_constraint USING btree (contypid)	16384	0	0	0	0	0
2	11874	2667	2606	2011-08-16	0	pg_constraint_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_constraint_oid_index ON pg_constraint USING btree (oid)	16384	0	0	0	0	0
2	11874	2187	2611	2011-08-16	0	pg_inherits_parent_index	403	1	0	\N	f	f	f	t	2	CREATE INDEX pg_inherits_parent_index ON pg_inherits USING btree (inhparent)	8192	0	0	0	0	0
2	11874	2680	2611	2011-08-16	0	pg_inherits_relid_seqno_index	403	1	0	\N	t	f	f	t	1 3	CREATE UNIQUE INDEX pg_inherits_relid_seqno_index ON pg_inherits USING btree (inhrelid, inhseqno)	8192	0	0	0	0	0
2	11874	2702	2620	2011-08-16	0	pg_trigger_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_trigger_oid_index ON pg_trigger USING btree (oid)	8192	0	0	0	0	0
2	11874	11458	11456	2011-08-16	0	pg_toast_11454_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11454_index ON pg_toast.pg_toast_11454 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2831	2830	2011-08-16	0	pg_toast_2604_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2604_index ON pg_toast.pg_toast_2604 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2833	2832	2011-08-16	0	pg_toast_2606_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2606_index ON pg_toast.pg_toast_2606 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2664	2606	2011-08-16	0	pg_constraint_conname_nsp_index	403	2	2	\N	f	f	f	t	1 2	CREATE INDEX pg_constraint_conname_nsp_index ON pg_constraint USING btree (conname, connamespace)	16384	0	0	0	2	2
2	16384	2651	2601	2011-08-16	0	pg_am_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_am_name_index ON pg_am USING btree (amname)	16384	0	0	0	0	0
2	16384	2652	2601	2011-08-16	0	pg_am_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_am_oid_index ON pg_am USING btree (oid)	16384	0	0	0	0	0
2	16384	2653	2602	2011-08-16	0	pg_amop_fam_strat_index	403	4	357	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amop_fam_strat_index ON pg_amop USING btree (amopfamily, amoplefttype, amoprighttype, amopstrategy)	32768	906	3406	3406	125	1997
2	16384	2654	2602	2011-08-16	0	pg_amop_opr_fam_index	403	2	357	\N	t	f	f	t	5 1	CREATE UNIQUE INDEX pg_amop_opr_fam_index ON pg_amop USING btree (amopopr, amopfamily)	16384	251	402	402	258	164
2	16384	2756	2602	2011-08-16	0	pg_amop_oid_index	403	2	357	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amop_oid_index ON pg_amop USING btree (oid)	16384	0	0	0	0	0
2	16384	2655	2603	2011-08-16	0	pg_amproc_fam_proc_index	403	2	250	\N	t	f	f	t	1 2 3 4	CREATE UNIQUE INDEX pg_amproc_fam_proc_index ON pg_amproc USING btree (amprocfamily, amproclefttype, amprocrighttype, amprocnum)	16384	715	715	715	122	903
2	16384	2757	2603	2011-08-16	0	pg_amproc_oid_index	403	2	250	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_amproc_oid_index ON pg_amproc USING btree (oid)	16384	0	0	0	0	0
2	16384	2650	2600	2011-08-16	0	pg_aggregate_fnoid_index	403	2	119	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_aggregate_fnoid_index ON pg_aggregate USING btree (aggfnoid)	16384	140	140	140	278	2
2	16384	2839	2838	2011-08-16	0	pg_toast_2618_index	403	2	115	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2618_index ON pg_toast.pg_toast_2618 USING btree (chunk_id, chunk_seq)	16384	1	2	2	2	0
2	16384	2337	2336	2011-08-16	0	pg_toast_2620_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2620_index ON pg_toast.pg_toast_2620 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2835	2834	2011-08-16	0	pg_toast_2609_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2609_index ON pg_toast.pg_toast_2609 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2675	2609	2011-08-16	0	pg_description_o_c_o_index	403	12	2436	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_description_o_c_o_index ON pg_description USING btree (objoid, classoid, objsubid)	98304	6	0	0	3	10
2	16384	2660	2605	2011-08-16	0	pg_cast_oid_index	403	2	191	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_cast_oid_index ON pg_cast USING btree (oid)	16384	0	0	0	0	0
2	16384	2661	2605	2011-08-16	0	pg_cast_source_target_index	403	2	191	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_cast_source_target_index ON pg_cast USING btree (castsource, casttarget)	16384	1428	441	441	244	1355
2	16384	3502	3501	2011-08-16	0	pg_enum_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_enum_oid_index ON pg_enum USING btree (oid)	8192	0	0	0	0	0
2	16384	2668	2607	2011-08-16	0	pg_conversion_default_index	403	2	132	\N	t	f	f	t	2 4 5 -2	CREATE UNIQUE INDEX pg_conversion_default_index ON pg_conversion USING btree (connamespace, conforencoding, contoencoding, oid)	16384	0	0	0	0	0
2	16384	2669	2607	2011-08-16	0	pg_conversion_name_nsp_index	403	2	132	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_conversion_name_nsp_index ON pg_conversion USING btree (conname, connamespace)	16384	0	0	0	0	0
2	16384	2670	2607	2011-08-16	0	pg_conversion_oid_index	403	2	132	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_conversion_oid_index ON pg_conversion USING btree (oid)	16384	0	0	0	0	0
2	16384	2673	2608	2011-08-16	0	pg_depend_depender_index	403	25	5593	\N	f	f	f	t	1 2 3	CREATE INDEX pg_depend_depender_index ON pg_depend USING btree (classid, objid, objsubid)	204800	12	12	12	7	67
2	16384	2674	2608	2011-08-16	0	pg_depend_reference_index	403	25	5593	\N	f	f	f	t	4 5 6	CREATE INDEX pg_depend_reference_index ON pg_depend USING btree (refclassid, refobjid, refobjsubid)	204800	106	89	88	17	245
2	16384	2967	2966	2011-08-16	1664	pg_toast_2964_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2964_index ON pg_toast.pg_toast_2964 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2694	1261	2011-08-16	1664	pg_auth_members_role_member_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_auth_members_role_member_index ON pg_auth_members USING btree (roleid, member)	8192	0	0	0	0	0
2	16384	2695	1261	2011-08-16	1664	pg_auth_members_member_role_index	403	1	0	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_auth_members_member_role_index ON pg_auth_members USING btree (member, roleid)	8192	0	0	0	0	0
2	16384	2847	2846	2011-08-16	1664	pg_toast_2396_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2396_index ON pg_toast.pg_toast_2396 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2397	2396	2011-08-16	1664	pg_shdescription_o_c_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_shdescription_o_c_index ON pg_shdescription USING btree (objoid, classoid)	16384	0	0	0	0	0
2	16384	2658	1249	2011-08-16	0	pg_attribute_relid_attnam_index	403	14	1935	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attribute_relid_attnam_index ON pg_attribute USING btree (attrelid, attname)	114688	3	3	3	5	131
2	16384	2659	1249	2011-08-16	0	pg_attribute_relid_attnum_index	403	10	1935	\N	t	f	f	t	1 6	CREATE UNIQUE INDEX pg_attribute_relid_attnum_index ON pg_attribute USING btree (attrelid, attnum)	81920	4068	8141	8141	253	8323
2	16384	2676	1260	2011-08-16	1664	pg_authid_rolname_index	403	2	1	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_authid_rolname_index ON pg_authid USING btree (rolname)	16384	285	285	285	270	300
2	16384	2677	1260	2011-08-16	1664	pg_authid_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_authid_oid_index ON pg_authid USING btree (oid)	16384	315	315	315	242	388
2	16384	2837	2836	2011-08-16	0	pg_toast_1255_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1255_index ON pg_toast.pg_toast_1255 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2845	2844	2011-08-16	1664	pg_toast_1262_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_1262_index ON pg_toast.pg_toast_1262 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2703	1247	2011-08-16	0	pg_type_oid_index	403	2	287	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_type_oid_index ON pg_type USING btree (oid)	16384	1282	1270	1270	122	1481
2	16384	2678	2610	2011-08-16	0	pg_index_indrelid_index	403	2	101	\N	f	f	f	t	2	CREATE INDEX pg_index_indrelid_index ON pg_index USING btree (indrelid)	16384	750	746	746	123	939
2	16384	2679	2610	2011-08-16	0	pg_index_indexrelid_index	403	2	101	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_index_indexrelid_index ON pg_index USING btree (indexrelid)	16384	1390	1390	1390	123	1580
2	16384	2688	2617	2011-08-16	0	pg_operator_oid_index	403	4	705	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_operator_oid_index ON pg_operator USING btree (oid)	32768	387	387	387	357	588
2	16384	2689	2617	2011-08-16	0	pg_operator_oprname_l_r_n_index	403	5	705	\N	t	f	f	t	1 7 8 2	CREATE UNIQUE INDEX pg_operator_oprname_l_r_n_index ON pg_operator USING btree (oprname, oprleft, oprright, oprnamespace)	40960	293	293	293	548	178
2	16384	2754	2753	2011-08-16	0	pg_opfamily_am_name_nsp_index	403	2	69	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opfamily_am_name_nsp_index ON pg_opfamily USING btree (opfmethod, opfname, opfnamespace)	16384	0	0	0	0	0
2	16384	2755	2753	2011-08-16	0	pg_opfamily_oid_index	403	2	69	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opfamily_oid_index ON pg_opfamily USING btree (oid)	16384	0	0	0	0	0
2	16384	2686	2616	2011-08-16	0	pg_opclass_am_name_nsp_index	403	2	112	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_opclass_am_name_nsp_index ON pg_opclass USING btree (opcmethod, opcname, opcnamespace)	16384	271	10840	10840	65	239
2	16384	2687	2616	2011-08-16	0	pg_opclass_oid_index	403	2	112	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_opclass_oid_index ON pg_opclass USING btree (oid)	16384	718	718	718	122	906
2	16384	2681	2612	2011-08-16	0	pg_language_name_index	403	2	4	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_language_name_index ON pg_language USING btree (lanname)	16384	0	0	0	0	0
2	16384	2682	2612	2011-08-16	0	pg_language_oid_index	403	2	4	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_language_oid_index ON pg_language USING btree (oid)	16384	0	0	0	0	0
2	16384	2996	2995	2011-08-16	0	pg_largeobject_metadata_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_largeobject_metadata_oid_index ON pg_largeobject_metadata USING btree (oid)	8192	0	0	0	0	0
2	16384	2692	2618	2011-08-16	0	pg_rewrite_oid_index	403	2	86	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_rewrite_oid_index ON pg_rewrite USING btree (oid)	16384	0	0	0	0	0
2	16384	2693	2618	2011-08-16	0	pg_rewrite_rel_rulename_index	403	2	86	\N	t	f	f	t	2 1	CREATE UNIQUE INDEX pg_rewrite_rel_rulename_index ON pg_rewrite USING btree (ev_class, rulename)	16384	1	1	1	2	0
2	16384	2699	2620	2011-08-16	0	pg_trigger_tgconstraint_index	403	1	0	\N	f	f	f	t	9	CREATE INDEX pg_trigger_tgconstraint_index ON pg_trigger USING btree (tgconstraint)	8192	0	0	0	0	0
2	16384	2701	2620	2011-08-16	0	pg_trigger_tgrelid_tgname_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_trigger_tgrelid_tgname_index ON pg_trigger USING btree (tgrelid, tgname)	8192	0	0	0	0	0
2	16384	3503	3501	2011-08-16	0	pg_enum_typid_label_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_enum_typid_label_index ON pg_enum USING btree (enumtypid, enumlabel)	8192	0	0	0	0	0
2	16384	2684	2615	2011-08-16	0	pg_namespace_nspname_index	403	2	6	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_namespace_nspname_index ON pg_namespace USING btree (nspname)	16384	702	424	424	137	844
2	16384	2685	2615	2011-08-16	0	pg_namespace_oid_index	403	2	6	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_namespace_oid_index ON pg_namespace USING btree (oid)	16384	33	33	33	64	1
2	16384	2697	1213	2011-08-16	1664	pg_tablespace_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_tablespace_oid_index ON pg_tablespace USING btree (oid)	16384	281	281	281	266	295
2	16384	2698	1213	2011-08-16	1664	pg_tablespace_spcname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_tablespace_spcname_index ON pg_tablespace USING btree (spcname)	16384	0	0	0	0	0
2	16384	1137	1136	2011-08-16	1664	pg_pltemplate_name_index	403	2	8	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_pltemplate_name_index ON pg_pltemplate USING btree (tmplname)	16384	0	0	0	0	0
2	16384	1232	1214	2011-08-16	1664	pg_shdepend_depender_index	403	2	1	\N	f	f	f	t	1 2 3 4	CREATE INDEX pg_shdepend_depender_index ON pg_shdepend USING btree (dbid, classid, objid, objsubid)	16384	7	0	0	4	5
2	16384	1233	1214	2011-08-16	1664	pg_shdepend_reference_index	403	2	1	\N	f	f	f	t	5 6	CREATE INDEX pg_shdepend_reference_index ON pg_shdepend USING btree (refclassid, refobjid)	16384	22	22	22	6	21
2	16384	3608	3602	2011-08-16	0	pg_ts_config_cfgname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_config_cfgname_index ON pg_ts_config USING btree (cfgname, cfgnamespace)	16384	0	0	0	0	0
2	16384	3712	3602	2011-08-16	0	pg_ts_config_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_config_oid_index ON pg_ts_config USING btree (oid)	16384	0	0	0	0	0
2	16384	3609	3603	2011-08-16	0	pg_ts_config_map_index	403	4	304	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_ts_config_map_index ON pg_ts_config_map USING btree (mapcfg, maptokentype, mapseqno)	32768	0	0	0	0	0
2	16384	3604	3600	2011-08-16	0	pg_ts_dict_dictname_index	403	2	16	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_dict_dictname_index ON pg_ts_dict USING btree (dictname, dictnamespace)	16384	0	0	0	0	0
2	16384	3605	3600	2011-08-16	0	pg_ts_dict_oid_index	403	2	16	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_dict_oid_index ON pg_ts_dict USING btree (oid)	16384	0	0	0	0	0
2	16384	3606	3601	2011-08-16	0	pg_ts_parser_prsname_index	403	2	1	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_parser_prsname_index ON pg_ts_parser USING btree (prsname, prsnamespace)	16384	0	0	0	0	0
2	16384	3607	3601	2011-08-16	0	pg_ts_parser_oid_index	403	2	1	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_parser_oid_index ON pg_ts_parser USING btree (oid)	16384	0	0	0	0	0
2	16384	3766	3764	2011-08-16	0	pg_ts_template_tmplname_index	403	2	5	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_ts_template_tmplname_index ON pg_ts_template USING btree (tmplname, tmplnamespace)	16384	0	0	0	0	0
2	16384	3767	3764	2011-08-16	0	pg_ts_template_oid_index	403	2	5	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_ts_template_oid_index ON pg_ts_template USING btree (oid)	16384	0	0	0	0	0
2	16384	112	2328	2011-08-16	0	pg_foreign_data_wrapper_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_data_wrapper_oid_index ON pg_foreign_data_wrapper USING btree (oid)	8192	0	0	0	0	0
2	16384	548	2328	2011-08-16	0	pg_foreign_data_wrapper_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_data_wrapper_name_index ON pg_foreign_data_wrapper USING btree (fdwname)	8192	0	0	0	0	0
2	16384	113	1417	2011-08-16	0	pg_foreign_server_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_foreign_server_oid_index ON pg_foreign_server USING btree (oid)	8192	0	0	0	0	0
2	16384	549	1417	2011-08-16	0	pg_foreign_server_name_index	403	1	0	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_foreign_server_name_index ON pg_foreign_server USING btree (srvname)	8192	0	0	0	0	0
2	16384	827	826	2011-08-16	0	pg_default_acl_role_nsp_obj_index	403	1	0	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_default_acl_role_nsp_obj_index ON pg_default_acl USING btree (defaclrole, defaclnamespace, defaclobjtype)	8192	2	0	0	1	1
2	16384	828	826	2011-08-16	0	pg_default_acl_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_default_acl_oid_index ON pg_default_acl USING btree (oid)	8192	0	0	0	0	0
2	16384	2683	2613	2011-08-16	0	pg_largeobject_loid_pn_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_largeobject_loid_pn_index ON pg_largeobject USING btree (loid, pageno)	8192	0	0	0	0	0
2	16384	174	1418	2011-08-16	0	pg_user_mapping_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_user_mapping_oid_index ON pg_user_mapping USING btree (oid)	8192	0	0	0	0	0
2	16384	175	1418	2011-08-16	0	pg_user_mapping_user_server_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_user_mapping_user_server_index ON pg_user_mapping USING btree (umuser, umserver)	8192	0	0	0	0	0
2	16384	2690	1255	2011-08-16	0	pg_proc_oid_index	403	9	2255	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_proc_oid_index ON pg_proc USING btree (oid)	73728	742	742	742	685	1077
2	16384	2691	1255	2011-08-16	0	pg_proc_proname_args_nsp_index	403	22	2255	\N	t	f	f	t	1 17 2	CREATE UNIQUE INDEX pg_proc_proname_args_nsp_index ON pg_proc USING btree (proname, proargtypes, pronamespace)	180224	301	463	463	552	328
2	16384	2671	1262	2011-08-16	1664	pg_database_datname_index	403	2	2	\N	t	f	f	t	1	CREATE UNIQUE INDEX pg_database_datname_index ON pg_database USING btree (datname)	16384	635	634	634	106	878
2	16384	2965	2964	2011-08-16	1664	pg_db_role_setting_databaseid_rol_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_db_role_setting_databaseid_rol_index ON pg_db_role_setting USING btree (setdatabase, setrole)	8192	1050	0	0	3	1047
2	16384	11488	11486	2011-08-16	0	pg_toast_11484_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11484_index ON pg_toast.pg_toast_11484 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2672	1262	2011-08-16	1664	pg_database_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_database_oid_index ON pg_database USING btree (oid)	16384	479	478	478	142	688
2	16384	11483	11481	2011-08-16	0	pg_toast_11479_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11479_index ON pg_toast.pg_toast_11479 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	11463	11461	2011-08-16	0	pg_toast_11459_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11459_index ON pg_toast.pg_toast_11459 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	2841	2840	2011-08-16	0	pg_toast_2619_index	403	2	9	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_2619_index ON pg_toast.pg_toast_2619 USING btree (chunk_id, chunk_seq)	16384	0	0	0	0	0
2	16384	2696	2619	2011-08-16	0	pg_statistic_relid_att_inh_index	403	2	340	\N	t	f	f	t	1 2 3	CREATE UNIQUE INDEX pg_statistic_relid_att_inh_index ON pg_statistic USING btree (starelid, staattnum, stainherit)	16384	2511	2058	2058	145	2569
2	16384	2704	1247	2011-08-16	0	pg_type_typname_nsp_index	403	5	287	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_type_typname_nsp_index ON pg_type USING btree (typname, typnamespace)	40960	22	5	5	13	59
2	16384	2662	1259	2011-08-16	0	pg_class_oid_index	403	2	253	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_class_oid_index ON pg_class USING btree (oid)	16384	4036	4027	4027	125	4231
2	16384	2663	1259	2011-08-16	0	pg_class_relname_nsp_index	403	5	253	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_class_relname_nsp_index ON pg_class USING btree (relname, relnamespace)	40960	1468	755	755	145	3090
2	16384	11468	11466	2011-08-16	0	pg_toast_11464_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11464_index ON pg_toast.pg_toast_11464 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	11473	11471	2011-08-16	0	pg_toast_11469_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11469_index ON pg_toast.pg_toast_11469 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	11478	11476	2011-08-16	0	pg_toast_11474_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11474_index ON pg_toast.pg_toast_11474 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
2	16384	16398	16385	2011-08-16	0	pgbench_branches_pkey	403	4	10	\N	t	t	f	t	1	CREATE UNIQUE INDEX pgbench_branches_pkey ON pgbench_branches USING btree (bid)	32768	143892	695278	83648	94	256307
2	16384	2656	2604	2011-08-16	0	pg_attrdef_adrelid_adnum_index	403	1	0	\N	t	f	f	t	1 2	CREATE UNIQUE INDEX pg_attrdef_adrelid_adnum_index ON pg_attrdef USING btree (adrelid, adnum)	8192	0	0	0	0	0
2	16384	2657	2604	2011-08-16	0	pg_attrdef_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_attrdef_oid_index ON pg_attrdef USING btree (oid)	8192	0	0	0	0	0
2	16384	16402	16391	2011-08-16	0	pgbench_accounts_pkey	403	2745	999354	\N	t	t	t	t	1	CREATE UNIQUE INDEX pgbench_accounts_pkey ON pgbench_accounts USING btree (aid)	22487040	774279	1802897	1774278	150290	2250291
2	16384	16400	16388	2011-08-16	0	pgbench_tellers_pkey	403	19	100	\N	t	t	t	t	1	CREATE UNIQUE INDEX pgbench_tellers_pkey ON pgbench_tellers USING btree (tid)	155648	281835	779823	281934	131	633185
2	16384	2665	2606	2011-08-16	0	pg_constraint_conrelid_index	403	2	2	\N	f	f	f	t	6	CREATE INDEX pg_constraint_conrelid_index ON pg_constraint USING btree (conrelid)	16384	0	0	0	2	2
2	16384	2666	2606	2011-08-16	0	pg_constraint_contypid_index	403	2	2	\N	f	f	f	t	7	CREATE INDEX pg_constraint_contypid_index ON pg_constraint USING btree (contypid)	16384	0	0	0	2	2
2	16384	2667	2606	2011-08-16	0	pg_constraint_oid_index	403	2	2	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_constraint_oid_index ON pg_constraint USING btree (oid)	16384	3	0	0	2	5
2	16384	2187	2611	2011-08-16	0	pg_inherits_parent_index	403	1	0	\N	f	f	f	t	2	CREATE INDEX pg_inherits_parent_index ON pg_inherits USING btree (inhparent)	8192	0	0	0	0	0
2	16384	2680	2611	2011-08-16	0	pg_inherits_relid_seqno_index	403	1	0	\N	t	f	f	t	1 3	CREATE UNIQUE INDEX pg_inherits_relid_seqno_index ON pg_inherits USING btree (inhrelid, inhseqno)	8192	2	0	0	1	1
2	16384	2702	2620	2011-08-16	0	pg_trigger_oid_index	403	1	0	\N	t	f	f	t	-2	CREATE UNIQUE INDEX pg_trigger_oid_index ON pg_trigger USING btree (oid)	8192	0	0	0	0	0
2	16384	11458	11456	2011-08-16	0	pg_toast_11454_index	403	1	0	\N	t	t	f	t	1 2	CREATE UNIQUE INDEX pg_toast_11454_index ON pg_toast.pg_toast_11454 USING btree (chunk_id, chunk_seq)	8192	0	0	0	0	0
\.


--
-- Data for Name: inherits; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY inherits (snapid, dbid, inhrelid, inhparent, inhseqno) FROM stdin;
\.


--
-- Data for Name: instance; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY instance (instid, name, hostname, port, pg_version) FROM stdin;
1	5641368943937072110	localhost.localdomain	20200	9.0.4
\.


--
-- Data for Name: profile; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY profile (snapid, processing, execute, total_exec_time) FROM stdin;
1	UNUSED_OR_IDLE	4	-1
1	DATA:READ	0	-1
1	XLOG:INSERT	0	-1
1	CPU	0	-1
1	CPU:PARSE	0	-1
1	CPU:REWRITE	0	-1
1	CPU:EXECUTE	0	-1
1	CPU:PLAN	0	-1
2	UNUSED_OR_IDLE	1920	-1
2	DATA:READ	3	-1
2	XLOG:INSERT	43	-1
2	CPU	817	-1
2	CPU:PARSE	41	-1
2	CPU:REWRITE	45	-1
2	CPU:EXECUTE	147	-1
2	CPU:PLAN	112	-1
2	CPU:SORT-HEAP	0	-1
2	LWLOCK:LELOCK	1	-1
2	DATA:WRITE	0	-1
2	LOCK:HEAVY-LOCK	0	-1
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY role (snapid, userid, name) FROM stdin;
1	10	postgres
2	10	postgres
\.


--
-- Data for Name: schema; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY schema (snapid, dbid, nsp, name) FROM stdin;
1	11874	99	pg_toast
1	11874	11077	pg_temp_1
1	11874	11078	pg_toast_temp_1
1	11874	11	pg_catalog
1	11874	2200	public
1	11874	11342	information_schema
1	11874	16418	statsinfo
1	16384	99	pg_toast
1	16384	11077	pg_temp_1
1	16384	11078	pg_toast_temp_1
1	16384	11	pg_catalog
1	16384	2200	public
1	16384	11342	information_schema
2	11874	99	pg_toast
2	11874	11077	pg_temp_1
2	11874	11078	pg_toast_temp_1
2	11874	11	pg_catalog
2	11874	2200	public
2	11874	11342	information_schema
2	11874	16418	statsinfo
2	16384	99	pg_toast
2	16384	11077	pg_temp_1
2	16384	11078	pg_toast_temp_1
2	16384	11	pg_catalog
2	16384	2200	public
2	16384	11342	information_schema
\.


--
-- Data for Name: setting; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY setting (snapid, name, setting, source) FROM stdin;
1	default_text_search_config	pg_catalog.english	configuration file
1	lc_messages	C	configuration file
1	log_autovacuum_min_duration	0	configuration file
1	log_checkpoints	on	configuration file
1	log_destination	csvlog	override
1	log_timezone	Japan	command line
1	logging_collector	on	override
1	max_stack_depth	2048	environment variable
1	pg_statsinfo.repository_server	port=5444	configuration file
1	pg_statsinfo.snapshot_interval	2592000	configuration file
1	port	20200	environment variable
1	shared_buffers	4096	configuration file
1	shared_preload_libraries	pg_statsinfo, pg_stat_statements	configuration file
1	TimeZone	Japan	command line
1	timezone_abbreviations	Default	command line
1	track_functions	all	configuration file
2	default_text_search_config	pg_catalog.english	configuration file
2	lc_messages	C	configuration file
2	log_autovacuum_min_duration	0	configuration file
2	log_checkpoints	on	configuration file
2	log_destination	csvlog	override
2	log_timezone	Japan	command line
2	logging_collector	on	override
2	max_stack_depth	2048	environment variable
2	pg_statsinfo.repository_server	port=5444	configuration file
2	pg_statsinfo.snapshot_interval	2592000	configuration file
2	port	20200	environment variable
2	shared_buffers	4096	configuration file
2	shared_preload_libraries	pg_statsinfo, pg_stat_statements	configuration file
2	TimeZone	Japan	command line
2	timezone_abbreviations	Default	command line
2	track_functions	all	configuration file
\.


--
-- Data for Name: snapshot; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY snapshot (snapid, instid, "time", comment, exec_time, snapshot_increase_size) FROM stdin;
1	1	2011-08-16 17:36:25.496514+09		00:00:01.122808	565248
2	1	2011-08-16 18:06:25.376961+09		00:00:01.162493	344064
\.


--
-- Data for Name: statement; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY statement (snapid, dbid, userid, query, calls, total_time, rows, shared_blks_hit, shared_blks_read, shared_blks_written, local_blks_hit, local_blks_read, local_blks_written, temp_blks_read, temp_blks_written) FROM stdin;
1	11874	10	SELECT \td.oid AS dbid, \td.datname, \tpg_database_size(d.oid), \tCASE WHEN pg_is_in_recovery() THEN 0 ELSE age(d.datfrozenxid) END, \tpg_stat_get_db_xact_commit(d.oid) AS xact_commit, \tpg_stat_get_db_xact_rollback(d.oid) AS xact_rollback, \tpg_stat_get_db_blocks_fetched(d.oid) - pg_stat_get_db_blocks_hit(d.oid) AS blks_read, \tpg_stat_get_db_blocks_hit(d.oid) AS blks_hit, \tpg_stat_get_db_tuples_returned(d.oid) AS tup_returned, \tpg_stat_get_db_tuples_fetched(d.oid) AS tup_fetched, \tpg_stat_get_db_tuples_inserted(d.oid) AS tup_inserted, \tpg_stat_get_db_tuples_updated(d.oid) AS tup_updated, \tpg_stat_get_db_tuples_deleted(d.oid) AS tup_deleted FROM \tpg_database d WHERE datallowconn   AND datname <> ALL (('{' || $1 || '}')::text[]) ORDER BY 1	1	0.012874999999999999	2	3	0	0	0	0	0	0	0
1	11874	10	/*\n * lib/pg_statsinfo.sql.in\n *\n * Copyright (c) 2010-2011, NIPPON TELEGRAPH AND TELEPHONE CORPORATION\n */\n\n-- Adjust this setting to control where the objects get created.\nSET search_path = public;\n\nBEGIN;\n\nSET LOCAL client_min_messages = WARNING;\n\nCREATE SCHEMA statsinfo;\nREVOKE ALL ON SCHEMA statsinfo FROM PUBLIC;\n\n--\n-- statsinfo.sample()\n--\nCREATE FUNCTION statsinfo.sample() RETURNS void\nAS '$libdir/pg_statsinfo', 'statsinfo_sample'\nLANGUAGE C STRICT;\n\n--\n-- statsinfo.activity()\n--\nCREATE FUNCTION statsinfo.activity(\n\tOUT idle\t\t\tfloat8,\n\tOUT idle_in_xact\tfloat8,\n\tOUT waiting\t\t\tfloat8,\n\tOUT running\t\t\tfloat8,\n\tOUT client\t\t\ttext,\n\tOUT pid\t\t\t\tinteger,\n\tOUT start\t\t\ttimestamptz,\n\tOUT duration\t\tfloat8,\n\tOUT query\t\t\ttext\n)\nAS '$libdir/pg_statsinfo', 'statsinfo_activity'\nLANGUAGE C STRICT;\n\n--\n-- statsinfo.snapshot()\n--\nCREATE FUNCTION statsinfo.snapshot(comment text) RETURNS void\nAS '$libdir/pg_statsinfo', 'statsinfo_snapshot'\nLANGUAGE C;\n\nCREATE FUNCTION statsinfo.snapshot() RETURNS void\nAS '$libdir/pg_statsi	17	0.0090629999999999999	0	628	76	0	0	0	0	0	0
1	11874	10	SELECT statsinfo.snapshot($1)	1	0.0014970000000000001	1	0	0	0	0	0	0	0	0
1	11874	10	SELECT \tname, \tsetting, \tsource FROM \tpg_settings WHERE \tsource NOT IN ('client', 'default', 'session') AND \tsetting <> boot_val	1	0.001256	16	0	0	0	0	0	0	0	0
1	11874	10	SELECT * FROM statsinfo.devicestats()	1	0.001119	1	59	0	0	0	0	0	0	0
1	11874	10	SELECT * FROM statsinfo.profile()	1	0.0010859999999999999	8	0	0	0	0	0	0	0	0
1	11874	10	SELECT * FROM statsinfo.cpustats()	1	0.00050199999999999995	1	0	0	0	0	0	0	0	0
1	11874	10	SELECT * FROM statsinfo.tablespaces	1	0.000185	2	1	0	0	0	0	0	0	0
1	11874	10	SET search_path = 'pg_catalog', 'public'	1	0.000136	0	2	3	0	0	0	0	0	0
1	11874	10	SELECT statsinfo.sample()	2	8.7999999999999998e-05	2	0	0	0	0	0	0	0	0
1	11874	10	SELECT * FROM statsinfo.activity()	1	7.7999999999999999e-05	1	0	0	0	0	0	0	0	0
1	11874	10	SELECT relname FROM pg_class WHERE relname = 'pg_stat_statements' AND relkind = 'v'	1	1.7e-05	1	3	0	0	0	0	0	0	0
1	11874	10	SELECT nspname FROM pg_namespace WHERE nspname = $1	1	1.5e-05	0	1	0	0	0	0	0	0	0
1	11874	10	SELECT \toid, \trolname FROM \tpg_roles	1	1.1e-05	1	1	0	0	0	0	0	0	0
1	11874	10	BEGIN	1	9.9999999999999995e-07	0	0	0	0	0	0	0	0	0
1	11874	10	COMMIT	1	9.9999999999999995e-07	0	0	0	0	0	0	0	0	0
2	16384	10	BEGIN;	387139	0.37234999999707602	0	0	0	0	0	0	0	0	0
2	16384	10	END;	387139	0.33146599999814103	0	0	0	0	0	0	0	0	0
2	11874	10	SELECT \td.oid AS dbid, \td.datname, \tpg_database_size(d.oid), \tCASE WHEN pg_is_in_recovery() THEN 0 ELSE age(d.datfrozenxid) END, \tpg_stat_get_db_xact_commit(d.oid) AS xact_commit, \tpg_stat_get_db_xact_rollback(d.oid) AS xact_rollback, \tpg_stat_get_db_blocks_fetched(d.oid) - pg_stat_get_db_blocks_hit(d.oid) AS blks_read, \tpg_stat_get_db_blocks_hit(d.oid) AS blks_hit, \tpg_stat_get_db_tuples_returned(d.oid) AS tup_returned, \tpg_stat_get_db_tuples_fetched(d.oid) AS tup_fetched, \tpg_stat_get_db_tuples_inserted(d.oid) AS tup_inserted, \tpg_stat_get_db_tuples_updated(d.oid) AS tup_updated, \tpg_stat_get_db_tuples_deleted(d.oid) AS tup_deleted FROM \tpg_database d WHERE datallowconn   AND datname <> ALL (('{' || $1 || '}')::text[]) ORDER BY 1	1	0.013096999999999999	2	3	0	0	0	0	0	0	0
2	11874	10	SELECT \tname, \tsetting, \tsource FROM \tpg_settings WHERE \tsource NOT IN ('client', 'default', 'session') AND \tsetting <> boot_val	1	0.0024599999999999999	16	0	0	0	0	0	0	0	0
2	11874	10	SELECT * FROM statsinfo.cpustats()	1	0.0016310000000000001	1	0	0	0	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 1125 WHERE aid = 770303;	1	0.0014120000000000001	1	3	2	0	0	0	0	0	0
2	11874	10	SELECT * FROM statsinfo.devicestats()	1	0.0013240000000000001	1	58	1	0	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -3547 WHERE aid = 988860;	1	0.001106	1	3	2	2	0	0	0	0	0
2	11874	10	SELECT * FROM statsinfo.profile()	1	0.001065	12	0	0	0	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -3847 WHERE aid = 127730;	1	0.000727	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -3384 WHERE aid = 979471;	1	0.00029300000000000002	1	3	3	1	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -4683 WHERE aid = 173900;	1	0.00024399999999999999	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 1725 WHERE aid = 826099;	1	0.00021699999999999999	1	4	1	0	0	0	0	0	0
2	11874	10	SELECT * FROM statsinfo.tablespaces	1	0.000212	2	1	0	0	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -967 WHERE aid = 297230;	1	0.00020799999999999999	1	5	1	1	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -3905 WHERE aid = 146111;	1	0.000204	1	4	1	1	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -3735 WHERE aid = 623035;	1	0.000202	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -407 WHERE aid = 323785;	1	0.00020000000000000001	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -692 WHERE aid = 36444;	1	0.00019900000000000001	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 4727 WHERE aid = 649753;	1	0.00019900000000000001	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 2550 WHERE aid = 941661;	1	0.00019799999999999999	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 4024 WHERE aid = 267861;	1	0.00019799999999999999	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -4315 WHERE aid = 20057;	1	0.00019699999999999999	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 4923 WHERE aid = 150125;	1	0.00019599999999999999	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 4331 WHERE aid = 564262;	1	0.00019599999999999999	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 224 WHERE aid = 297769;	1	0.000195	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 4399 WHERE aid = 778562;	1	0.000195	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -3439 WHERE aid = 330173;	1	0.000195	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + -4331 WHERE aid = 28993;	1	0.000195	1	3	2	2	0	0	0	0	0
2	16384	10	UPDATE pgbench_accounts SET abalance = abalance + 2202 WHERE aid = 774853;	1	0.000193	1	3	2	2	0	0	0	0	0
\.


--
-- Data for Name: table; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY "table" (snapid, dbid, tbl, nsp, date, tbs, name, toastrelid, toastidxid, relkind, relpages, reltuples, reloptions, size, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, n_tup_upd, n_tup_del, n_tup_hot_upd, n_live_tup, n_dead_tup, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read, toast_blks_hit, tidx_blks_read, tidx_blks_hit, last_vacuum, last_autovacuum, last_analyze, last_autoanalyze) FROM stdin;
\.


--
-- Data for Name: table_20110816; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY table_20110816 (snapid, dbid, tbl, nsp, date, tbs, name, toastrelid, toastidxid, relkind, relpages, reltuples, reloptions, size, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, n_tup_upd, n_tup_del, n_tup_hot_upd, n_live_tup, n_dead_tup, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read, toast_blks_hit, tidx_blks_read, tidx_blks_hit, last_vacuum, last_autovacuum, last_analyze, last_autoanalyze) FROM stdin;
1	11874	826	11	2011-08-16	0	pg_default_acl	0	0	r	0	0	\N	0	0	0	8	0	0	0	0	0	0	0	0	0	2	6	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1136	11	2011-08-16	1664	pg_pltemplate	0	0	r	1	8	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1213	11	2011-08-16	1664	pg_tablespace	0	0	r	1	2	\N	8192	2	4	2	2	0	0	0	0	0	0	3	1	4	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1214	11	2011-08-16	1664	pg_shdepend	0	0	r	1	1	\N	8192	0	0	29	22	0	0	0	0	0	0	3	19	10	26	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1247	11	2011-08-16	0	pg_type	0	0	r	7	287	\N	57344	0	0	43	34	4	0	0	0	4	0	13	31	14	69	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1249	11	2011-08-16	0	pg_attribute	0	0	r	34	1935	\N	286720	28	156	174	587	21	0	0	0	21	0	46	490	23	419	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1255	11	2011-08-16	0	pg_proc	2836	0	r	55	2255	\N	450560	0	0	46	23	12	1	0	0	12	1	11	37	17	133	0	0	0	0	\N	\N	\N	\N
1	11874	1259	11	2011-08-16	0	pg_class	0	0	r	7	253	\N	57344	36	1178	198	193	2	3	0	3	2	1	27	311	13	206	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1260	11	2011-08-16	1664	pg_authid	0	0	r	1	1	\N	8192	4	4	12	12	0	0	0	0	0	0	3	13	12	12	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1261	11	2011-08-16	1664	pg_auth_members	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1262	11	2011-08-16	1664	pg_database	2844	0	r	1	2	\N	8192	11	32	37	35	1	0	0	0	1	0	0	47	12	47	0	0	0	0	\N	\N	\N	\N
1	11874	1417	11	2011-08-16	0	pg_foreign_server	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	1418	11	2011-08-16	0	pg_user_mapping	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2328	11	2011-08-16	0	pg_foreign_data_wrapper	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2336	99	2011-08-16	0	pg_toast_2620	0	2337	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2396	11	2011-08-16	1664	pg_shdescription	2846	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	11874	2600	11	2011-08-16	0	pg_aggregate	0	0	r	1	119	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2601	11	2011-08-16	0	pg_am	0	0	r	1	4	\N	8192	8	8	0	0	0	0	0	0	0	0	3	5	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2602	11	2011-08-16	0	pg_amop	0	0	r	3	357	\N	24576	4	20	20	97	0	0	0	0	0	0	7	26	11	37	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2603	11	2011-08-16	0	pg_amproc	0	0	r	2	250	\N	16384	4	4	19	19	0	0	0	0	0	0	5	22	6	21	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2604	11	2011-08-16	0	pg_attrdef	2830	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	11874	2605	11	2011-08-16	0	pg_cast	0	0	r	2	191	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2606	11	2011-08-16	0	pg_constraint	2832	0	r	1	2	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	11874	2607	11	2011-08-16	0	pg_conversion	0	0	r	3	132	\N	24576	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2608	11	2011-08-16	0	pg_depend	0	0	r	42	5593	\N	344064	0	0	135	127	24	0	0	0	24	0	18	139	30	340	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2609	11	2011-08-16	0	pg_description	2834	0	r	21	2436	\N	172032	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	11874	2610	11	2011-08-16	0	pg_index	0	0	r	2	101	\N	16384	18	18	130	145	0	0	0	0	0	0	6	150	12	129	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2611	11	2011-08-16	0	pg_inherits	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2612	11	2011-08-16	0	pg_language	0	0	r	1	4	\N	8192	0	0	2	2	0	0	0	0	0	0	2	0	4	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2613	11	2011-08-16	0	pg_largeobject	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2615	11	2011-08-16	0	pg_namespace	0	0	r	1	6	\N	8192	1	6	12	9	1	1	0	1	1	1	6	10	6	12	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2616	11	2011-08-16	0	pg_opclass	0	0	r	2	112	\N	16384	4	4	19	19	0	0	0	0	0	0	3	20	6	21	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2617	11	2011-08-16	0	pg_operator	0	0	r	13	705	\N	106496	0	0	2	2	0	0	0	0	0	0	1	1	6	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2618	11	2011-08-16	0	pg_rewrite	2838	0	r	9	86	\N	81920	0	0	5	1	2	0	0	0	2	0	6	2	8	5	0	0	0	0	\N	\N	\N	\N
1	11874	2619	11	2011-08-16	0	pg_statistic	2840	0	r	13	340	\N	106496	0	0	1	1	0	0	0	0	0	0	1	0	2	0	0	0	0	0	\N	\N	\N	\N
1	11874	2620	11	2011-08-16	0	pg_trigger	2336	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	11874	2753	11	2011-08-16	0	pg_opfamily	0	0	r	1	69	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2830	99	2011-08-16	0	pg_toast_2604	0	2831	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2832	99	2011-08-16	0	pg_toast_2606	0	2833	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2834	99	2011-08-16	0	pg_toast_2609	0	2835	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2836	99	2011-08-16	0	pg_toast_1255	0	2837	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2838	99	2011-08-16	0	pg_toast_2618	0	2839	t	26	115	\N	212992	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2840	99	2011-08-16	0	pg_toast_2619	0	2841	t	2	9	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2844	99	2011-08-16	1664	pg_toast_1262	0	2845	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2846	99	2011-08-16	1664	pg_toast_2396	0	2847	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2964	11	2011-08-16	1664	pg_db_role_setting	2966	0	r	0	0	\N	0	0	0	33	0	0	0	0	0	0	0	0	0	3	30	0	0	0	0	\N	\N	\N	\N
1	11874	2966	99	2011-08-16	1664	pg_toast_2964	0	2967	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	2995	11	2011-08-16	0	pg_largeobject_metadata	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	3501	11	2011-08-16	0	pg_enum	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	3600	11	2011-08-16	0	pg_ts_dict	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	3601	11	2011-08-16	0	pg_ts_parser	0	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	3602	11	2011-08-16	0	pg_ts_config	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	3603	11	2011-08-16	0	pg_ts_config_map	0	0	r	2	304	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	3764	11	2011-08-16	0	pg_ts_template	0	0	r	1	5	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	11454	11342	2011-08-16	0	sql_features	11456	0	r	7	650	\N	57344	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	11874	11456	99	2011-08-16	0	pg_toast_11454	0	11458	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	11459	11342	2011-08-16	0	sql_implementation_info	11461	0	r	1	12	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	11874	11461	99	2011-08-16	0	pg_toast_11459	0	11463	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	11464	11342	2011-08-16	0	sql_languages	11466	0	r	1	4	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	11874	11466	99	2011-08-16	0	pg_toast_11464	0	11468	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	11469	11342	2011-08-16	0	sql_packages	11471	0	r	1	10	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	11874	11471	99	2011-08-16	0	pg_toast_11469	0	11473	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	11474	11342	2011-08-16	0	sql_parts	11476	0	r	1	9	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	11874	11476	99	2011-08-16	0	pg_toast_11474	0	11478	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	11479	11342	2011-08-16	0	sql_sizing	11481	0	r	1	23	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	11874	11481	99	2011-08-16	0	pg_toast_11479	0	11483	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	11874	11484	11342	2011-08-16	0	sql_sizing_profiles	11486	0	r	0	0	\N	0	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	11874	11486	99	2011-08-16	0	pg_toast_11484	0	11488	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	826	11	2011-08-16	0	pg_default_acl	0	0	r	0	0	\N	0	0	0	2	0	0	0	0	0	0	0	0	0	1	1	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1136	11	2011-08-16	1664	pg_pltemplate	0	0	r	1	8	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1213	11	2011-08-16	1664	pg_tablespace	0	0	r	1	2	\N	8192	2	4	2	2	0	0	0	0	0	0	3	1	4	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1214	11	2011-08-16	1664	pg_shdepend	0	0	r	1	1	\N	8192	0	0	29	22	0	0	0	0	0	0	3	19	10	26	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1247	11	2011-08-16	0	pg_type	0	0	r	7	287	\N	57344	0	0	56	29	12	0	4	0	8	4	10	41	12	103	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1249	11	2011-08-16	0	pg_attribute	0	0	r	34	1935	\N	286720	14	78	146	454	64	0	20	0	44	20	30	377	17	536	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1255	11	2011-08-16	0	pg_proc	2836	0	r	55	2255	\N	450560	0	0	21	36	0	0	0	0	0	0	15	19	14	30	0	0	0	0	\N	\N	\N	\N
1	16384	1259	11	2011-08-16	0	pg_class	0	0	r	7	253	\N	57344	30	3206	467	438	9	7	2	6	7	6	18	597	12	526	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1260	11	2011-08-16	1664	pg_authid	0	0	r	1	1	\N	8192	4	4	12	12	0	0	0	0	0	0	3	13	12	12	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1261	11	2011-08-16	1664	pg_auth_members	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1262	11	2011-08-16	1664	pg_database	2844	0	r	1	2	\N	8192	11	32	37	35	1	0	0	0	1	0	0	47	12	47	0	0	0	0	\N	\N	\N	\N
1	16384	1417	11	2011-08-16	0	pg_foreign_server	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	1418	11	2011-08-16	0	pg_user_mapping	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2328	11	2011-08-16	0	pg_foreign_data_wrapper	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2336	99	2011-08-16	0	pg_toast_2620	0	2337	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2396	11	2011-08-16	1664	pg_shdescription	2846	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	16384	2600	11	2011-08-16	0	pg_aggregate	0	0	r	1	119	\N	8192	0	0	1	1	0	0	0	0	0	0	1	0	2	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2601	11	2011-08-16	0	pg_am	0	0	r	1	4	\N	8192	4	4	0	0	0	0	0	0	0	0	2	2	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2602	11	2011-08-16	0	pg_amop	0	0	r	3	357	\N	24576	2	10	34	70	0	0	0	0	0	0	6	37	10	53	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2603	11	2011-08-16	0	pg_amproc	0	0	r	2	250	\N	16384	2	2	11	11	0	0	0	0	0	0	3	12	4	10	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2604	11	2011-08-16	0	pg_attrdef	2830	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	16384	2605	11	2011-08-16	0	pg_cast	0	0	r	2	191	\N	16384	0	0	71	15	0	0	0	0	0	0	3	12	4	69	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2606	11	2011-08-16	0	pg_constraint	2832	0	r	1	2	\N	8192	0	0	3	0	3	0	0	0	3	0	5	2	8	11	0	0	0	0	\N	\N	\N	\N
1	16384	2607	11	2011-08-16	0	pg_conversion	0	0	r	3	132	\N	24576	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2608	11	2011-08-16	0	pg_depend	0	0	r	42	5593	\N	344064	0	0	118	100	24	0	6	0	18	6	14	122	24	312	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2609	11	2011-08-16	0	pg_description	2834	0	r	21	2436	\N	172032	0	0	6	0	0	0	0	0	0	0	0	0	3	10	0	0	0	0	\N	\N	\N	\N
1	16384	2610	11	2011-08-16	0	pg_index	0	0	r	2	101	\N	16384	9	9	92	101	3	2	0	2	3	1	7	101	7	96	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2611	11	2011-08-16	0	pg_inherits	0	0	r	0	0	\N	0	0	0	2	0	0	0	0	0	0	0	0	0	1	1	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2612	11	2011-08-16	0	pg_language	0	0	r	1	4	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2613	11	2011-08-16	0	pg_largeobject	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2615	11	2011-08-16	0	pg_namespace	0	0	r	1	6	\N	8192	10	36	7	5	0	0	0	0	0	0	2	9	5	5	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2616	11	2011-08-16	0	pg_opclass	0	0	r	2	112	\N	16384	2	2	19	292	0	0	0	0	0	0	4	59	8	16	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2617	11	2011-08-16	0	pg_operator	0	0	r	13	705	\N	106496	0	0	22	22	0	0	0	0	0	0	6	16	12	35	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2618	11	2011-08-16	0	pg_rewrite	2838	0	r	9	86	\N	73728	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	16384	2619	11	2011-08-16	0	pg_statistic	2840	0	r	13	340	\N	106496	0	0	22	8	11	0	0	0	11	0	11	18	4	31	0	0	0	0	\N	\N	\N	\N
1	16384	2620	11	2011-08-16	0	pg_trigger	2336	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
1	16384	2753	11	2011-08-16	0	pg_opfamily	0	0	r	1	69	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2830	99	2011-08-16	0	pg_toast_2604	0	2831	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2832	99	2011-08-16	0	pg_toast_2606	0	2833	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2834	99	2011-08-16	0	pg_toast_2609	0	2835	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2836	99	2011-08-16	0	pg_toast_1255	0	2837	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2838	99	2011-08-16	0	pg_toast_2618	0	2839	t	26	115	\N	212992	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2840	99	2011-08-16	0	pg_toast_2619	0	2841	t	2	9	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2844	99	2011-08-16	1664	pg_toast_1262	0	2845	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2846	99	2011-08-16	1664	pg_toast_2396	0	2847	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2964	11	2011-08-16	1664	pg_db_role_setting	2966	0	r	0	0	\N	0	0	0	33	0	0	0	0	0	0	0	0	0	3	30	0	0	0	0	\N	\N	\N	\N
1	16384	2966	99	2011-08-16	1664	pg_toast_2964	0	2967	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	2995	11	2011-08-16	0	pg_largeobject_metadata	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	3501	11	2011-08-16	0	pg_enum	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	3600	11	2011-08-16	0	pg_ts_dict	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	3601	11	2011-08-16	0	pg_ts_parser	0	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	3602	11	2011-08-16	0	pg_ts_config	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	3603	11	2011-08-16	0	pg_ts_config_map	0	0	r	2	304	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	3764	11	2011-08-16	0	pg_ts_template	0	0	r	1	5	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	11454	11342	2011-08-16	0	sql_features	11456	0	r	7	650	\N	57344	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	16384	11456	99	2011-08-16	0	pg_toast_11454	0	11458	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	11459	11342	2011-08-16	0	sql_implementation_info	11461	0	r	1	12	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	16384	11461	99	2011-08-16	0	pg_toast_11459	0	11463	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	11464	11342	2011-08-16	0	sql_languages	11466	0	r	1	4	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	16384	11466	99	2011-08-16	0	pg_toast_11464	0	11468	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	11469	11342	2011-08-16	0	sql_packages	11471	0	r	1	10	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	16384	11471	99	2011-08-16	0	pg_toast_11469	0	11473	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	11474	11342	2011-08-16	0	sql_parts	11476	0	r	1	9	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	16384	11476	99	2011-08-16	0	pg_toast_11474	0	11478	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	11479	11342	2011-08-16	0	sql_sizing	11481	0	r	1	23	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	16384	11481	99	2011-08-16	0	pg_toast_11479	0	11483	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	11484	11342	2011-08-16	0	sql_sizing_profiles	11486	0	r	0	0	\N	0	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
1	16384	11486	99	2011-08-16	0	pg_toast_11484	0	11488	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
1	16384	16385	2200	2011-08-16	0	pgbench_branches	0	0	r	1	10	{fillfactor=100}	8192	1	10	0	0	10	0	0	0	10	0	5	13	1	0	\N	\N	\N	\N	2011-08-16 17:33:03.532146+09	\N	2011-08-16 17:33:03.533357+09	\N
1	16384	16388	2200	2011-08-16	0	pgbench_tellers	0	0	r	1	100	{fillfactor=100}	8192	3	300	1	100	100	0	0	0	100	0	7	104	3	0	\N	\N	\N	\N	2011-08-16 17:33:03.535254+09	\N	2011-08-16 17:33:03.535545+09	\N
1	16384	16391	2200	2011-08-16	0	pgbench_accounts	0	0	r	16394	1000000	{fillfactor=100}	134299648	2	2000000	1	1000000	1000000	0	0	0	1000000	0	96772	17994	5480	0	\N	\N	\N	\N	2011-08-16 17:33:05.763186+09	\N	2011-08-16 17:33:05.942256+09	\N
1	16384	16394	2200	2011-08-16	0	pgbench_history	0	0	r	0	0	\N	0	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	2011-08-16 17:33:05.95465+09	\N	2011-08-16 17:33:05.955047+09	\N
2	11874	826	11	2011-08-16	0	pg_default_acl	0	0	r	0	0	\N	0	0	0	8	0	0	0	0	0	0	0	0	0	2	6	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1136	11	2011-08-16	1664	pg_pltemplate	0	0	r	1	8	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1213	11	2011-08-16	1664	pg_tablespace	0	0	r	1	2	\N	8192	4	8	281	281	0	0	0	0	0	0	134	151	266	295	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1214	11	2011-08-16	1664	pg_shdepend	0	0	r	1	1	\N	8192	0	0	29	22	0	0	0	0	0	0	3	19	10	26	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1247	11	2011-08-16	0	pg_type	0	0	r	7	287	\N	57344	0	0	98	85	4	0	0	0	4	0	16	79	19	126	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1249	11	2011-08-16	0	pg_attribute	0	0	r	34	1935	\N	286720	29	2112	575	1260	21	0	0	0	21	0	123	855	115	1163	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1255	11	2011-08-16	0	pg_proc	2836	0	r	55	2255	\N	450560	31	70277	148	140	12	1	0	0	12	1	1714	146	31	327	0	0	0	0	\N	\N	\N	\N
2	11874	1259	11	2011-08-16	0	pg_class	0	0	r	7	253	\N	57344	162	20048	520	514	2	3	0	3	2	0	237	1304	74	514	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1260	11	2011-08-16	1664	pg_authid	0	0	r	1	1	\N	8192	5	5	600	600	0	0	0	0	0	0	3	602	512	688	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1261	11	2011-08-16	1664	pg_auth_members	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1262	11	2011-08-16	1664	pg_database	2844	0	r	1	2	\N	8192	72	276	1114	1112	1	0	0	0	1	0	0	1185	248	1566	0	0	0	0	\N	\N	\N	\N
2	11874	1417	11	2011-08-16	0	pg_foreign_server	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	1418	11	2011-08-16	0	pg_user_mapping	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2328	11	2011-08-16	0	pg_foreign_data_wrapper	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2336	99	2011-08-16	0	pg_toast_2620	0	2337	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2396	11	2011-08-16	1664	pg_shdescription	2846	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	11874	2600	11	2011-08-16	0	pg_aggregate	0	0	r	1	119	\N	8192	0	0	1	1	0	0	0	0	0	0	1	0	2	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2601	11	2011-08-16	0	pg_am	0	0	r	1	4	\N	8192	40	40	0	0	0	0	0	0	0	0	33	7	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2602	11	2011-08-16	0	pg_amop	0	0	r	3	357	\N	24576	4	20	113	339	0	0	0	0	0	0	37	100	101	138	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2603	11	2011-08-16	0	pg_amproc	0	0	r	2	250	\N	16384	4	4	64	64	0	0	0	0	0	0	35	37	66	38	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2604	11	2011-08-16	0	pg_attrdef	2830	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	11874	2605	11	2011-08-16	0	pg_cast	0	0	r	2	191	\N	16384	0	0	227	24	0	0	0	0	0	0	2	22	2	226	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2606	11	2011-08-16	0	pg_constraint	2832	0	r	1	2	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	11874	2607	11	2011-08-16	0	pg_conversion	0	0	r	3	132	\N	24576	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2608	11	2011-08-16	0	pg_depend	0	0	r	42	5593	\N	344064	0	0	135	127	24	0	0	0	24	0	18	139	30	340	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2609	11	2011-08-16	0	pg_description	2834	0	r	21	2436	\N	172032	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	11874	2610	11	2011-08-16	0	pg_index	0	0	r	2	101	\N	16384	20	220	265	285	0	0	0	0	0	0	36	259	72	237	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2611	11	2011-08-16	0	pg_inherits	0	0	r	0	0	\N	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2612	11	2011-08-16	0	pg_language	0	0	r	1	4	\N	8192	0	0	2	2	0	0	0	0	0	0	2	0	4	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2613	11	2011-08-16	0	pg_largeobject	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2615	11	2011-08-16	0	pg_namespace	0	0	r	1	6	\N	8192	5	34	24	20	1	1	0	1	1	1	7	24	8	24	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2616	11	2011-08-16	0	pg_opclass	0	0	r	2	112	\N	16384	4	4	247	7384	0	0	0	0	0	0	34	1315	68	220	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2617	11	2011-08-16	0	pg_operator	0	0	r	13	705	\N	106496	0	0	36	94	0	0	0	0	0	0	13	61	8	68	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2618	11	2011-08-16	0	pg_rewrite	2838	0	r	9	86	\N	81920	0	0	10	8	2	0	0	0	2	0	10	5	8	10	1	0	2	0	\N	\N	\N	\N
2	11874	2619	11	2011-08-16	0	pg_statistic	2840	0	r	13	340	\N	106496	1	340	59	35	0	0	0	0	0	0	13	35	2	59	0	0	0	0	\N	\N	\N	\N
2	11874	2620	11	2011-08-16	0	pg_trigger	2336	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	11874	2753	11	2011-08-16	0	pg_opfamily	0	0	r	1	69	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2830	99	2011-08-16	0	pg_toast_2604	0	2831	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2832	99	2011-08-16	0	pg_toast_2606	0	2833	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2834	99	2011-08-16	0	pg_toast_2609	0	2835	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2836	99	2011-08-16	0	pg_toast_1255	0	2837	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2838	99	2011-08-16	0	pg_toast_2618	0	2839	t	26	115	\N	212992	0	0	1	2	0	0	0	0	0	0	1	0	2	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2840	99	2011-08-16	0	pg_toast_2619	0	2841	t	2	9	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2844	99	2011-08-16	1664	pg_toast_1262	0	2845	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2846	99	2011-08-16	1664	pg_toast_2396	0	2847	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2964	11	2011-08-16	1664	pg_db_role_setting	2966	0	r	0	0	\N	0	0	0	1050	0	0	0	0	0	0	0	0	0	3	1047	0	0	0	0	\N	\N	\N	\N
2	11874	2966	99	2011-08-16	1664	pg_toast_2964	0	2967	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	2995	11	2011-08-16	0	pg_largeobject_metadata	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	3501	11	2011-08-16	0	pg_enum	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	3600	11	2011-08-16	0	pg_ts_dict	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	3601	11	2011-08-16	0	pg_ts_parser	0	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	3602	11	2011-08-16	0	pg_ts_config	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	3603	11	2011-08-16	0	pg_ts_config_map	0	0	r	2	304	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	3764	11	2011-08-16	0	pg_ts_template	0	0	r	1	5	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	11454	11342	2011-08-16	0	sql_features	11456	0	r	7	650	\N	57344	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	11874	11456	99	2011-08-16	0	pg_toast_11454	0	11458	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	11459	11342	2011-08-16	0	sql_implementation_info	11461	0	r	1	12	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	11874	11461	99	2011-08-16	0	pg_toast_11459	0	11463	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	11464	11342	2011-08-16	0	sql_languages	11466	0	r	1	4	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	11874	11466	99	2011-08-16	0	pg_toast_11464	0	11468	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	11469	11342	2011-08-16	0	sql_packages	11471	0	r	1	10	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	11874	11471	99	2011-08-16	0	pg_toast_11469	0	11473	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	11474	11342	2011-08-16	0	sql_parts	11476	0	r	1	9	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	11874	11476	99	2011-08-16	0	pg_toast_11474	0	11478	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	11479	11342	2011-08-16	0	sql_sizing	11481	0	r	1	23	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	11874	11481	99	2011-08-16	0	pg_toast_11479	0	11483	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	11874	11484	11342	2011-08-16	0	sql_sizing_profiles	11486	0	r	0	0	\N	0	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	11874	11486	99	2011-08-16	0	pg_toast_11484	0	11488	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	826	11	2011-08-16	0	pg_default_acl	0	0	r	0	0	\N	0	0	0	2	0	0	0	0	0	0	0	0	0	1	1	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1136	11	2011-08-16	1664	pg_pltemplate	0	0	r	1	8	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1213	11	2011-08-16	1664	pg_tablespace	0	0	r	1	2	\N	8192	4	8	281	281	0	0	0	0	0	0	134	151	266	295	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1214	11	2011-08-16	1664	pg_shdepend	0	0	r	1	1	\N	8192	0	0	29	22	0	0	0	0	0	0	3	19	10	26	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1247	11	2011-08-16	0	pg_type	0	0	r	7	287	\N	57344	0	0	1304	1275	12	0	4	0	8	4	43	1254	135	1540	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1249	11	2011-08-16	0	pg_attribute	0	0	r	34	1935	\N	286720	29	2135	4071	8144	64	0	20	0	44	20	411	4123	258	8454	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1255	11	2011-08-16	0	pg_proc	2836	0	r	55	2255	\N	450560	1	2255	1043	1205	0	0	0	0	0	0	741	371	1237	1405	0	0	0	0	\N	\N	\N	\N
2	16384	1259	11	2011-08-16	0	pg_class	0	0	r	7	253	\N	57344	170	22540	5504	4782	9	7	2	6	7	6	293	5650	270	7321	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1260	11	2011-08-16	1664	pg_authid	0	0	r	1	1	\N	8192	5	5	600	600	0	0	0	0	0	0	3	602	512	688	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1261	11	2011-08-16	1664	pg_auth_members	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1262	11	2011-08-16	1664	pg_database	2844	0	r	1	2	\N	8192	72	276	1114	1112	1	0	0	0	1	0	0	1185	248	1566	0	0	0	0	\N	\N	\N	\N
2	16384	1417	11	2011-08-16	0	pg_foreign_server	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	1418	11	2011-08-16	0	pg_user_mapping	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2328	11	2011-08-16	0	pg_foreign_data_wrapper	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2336	99	2011-08-16	0	pg_toast_2620	0	2337	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2396	11	2011-08-16	1664	pg_shdescription	2846	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	16384	2600	11	2011-08-16	0	pg_aggregate	0	0	r	1	119	\N	8192	0	0	140	140	0	0	0	0	0	0	139	1	278	2	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2601	11	2011-08-16	0	pg_am	0	0	r	1	4	\N	8192	311	311	0	0	0	0	0	0	0	0	120	191	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2602	11	2011-08-16	0	pg_amop	0	0	r	3	357	\N	24576	4	20	1157	3808	0	0	0	0	0	0	144	1174	383	2161	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2603	11	2011-08-16	0	pg_amproc	0	0	r	2	250	\N	16384	4	4	715	715	0	0	0	0	0	0	5	718	122	903	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2604	11	2011-08-16	0	pg_attrdef	2830	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	16384	2605	11	2011-08-16	0	pg_cast	0	0	r	2	191	\N	16384	0	0	1428	441	0	0	0	0	0	0	134	307	244	1355	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2606	11	2011-08-16	0	pg_constraint	2832	0	r	1	2	\N	8192	0	0	3	0	3	0	0	0	3	0	5	2	8	11	0	0	0	0	\N	\N	\N	\N
2	16384	2607	11	2011-08-16	0	pg_conversion	0	0	r	3	132	\N	24576	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2608	11	2011-08-16	0	pg_depend	0	0	r	42	5593	\N	344064	0	0	118	100	24	0	6	0	18	6	14	122	24	312	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2609	11	2011-08-16	0	pg_description	2834	0	r	21	2436	\N	172032	0	0	6	0	0	0	0	0	0	0	0	0	3	10	0	0	0	0	\N	\N	\N	\N
2	16384	2610	11	2011-08-16	0	pg_index	0	0	r	2	101	\N	16384	20	226	2140	2136	3	2	0	2	3	1	125	2029	246	2519	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2611	11	2011-08-16	0	pg_inherits	0	0	r	0	0	\N	0	1	0	2	0	0	0	0	0	0	0	0	0	1	1	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2612	11	2011-08-16	0	pg_language	0	0	r	1	4	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2613	11	2011-08-16	0	pg_largeobject	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2615	11	2011-08-16	0	pg_namespace	0	0	r	1	6	\N	8192	13	42	735	457	0	0	0	0	0	0	50	414	201	845	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2616	11	2011-08-16	0	pg_opclass	0	0	r	2	112	\N	16384	4	4	989	11558	0	0	0	0	0	0	35	2584	187	1145	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2617	11	2011-08-16	0	pg_operator	0	0	r	13	705	\N	106496	0	0	680	680	0	0	0	0	0	0	305	375	905	766	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2618	11	2011-08-16	0	pg_rewrite	2838	0	r	9	86	\N	73728	0	0	1	1	0	0	0	0	0	0	1	0	2	0	1	0	2	0	\N	\N	\N	\N
2	16384	2619	11	2011-08-16	0	pg_statistic	2840	0	r	13	340	\N	147456	1	351	2511	2058	17	330	0	315	17	48	86	2407	145	2569	0	0	0	0	\N	\N	\N	\N
2	16384	2620	11	2011-08-16	0	pg_trigger	2336	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N
2	16384	2753	11	2011-08-16	0	pg_opfamily	0	0	r	1	69	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2830	99	2011-08-16	0	pg_toast_2604	0	2831	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2832	99	2011-08-16	0	pg_toast_2606	0	2833	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2834	99	2011-08-16	0	pg_toast_2609	0	2835	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2836	99	2011-08-16	0	pg_toast_1255	0	2837	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2838	99	2011-08-16	0	pg_toast_2618	0	2839	t	26	115	\N	212992	0	0	1	2	0	0	0	0	0	0	1	0	2	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2840	99	2011-08-16	0	pg_toast_2619	0	2841	t	2	9	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2844	99	2011-08-16	1664	pg_toast_1262	0	2845	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2846	99	2011-08-16	1664	pg_toast_2396	0	2847	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2964	11	2011-08-16	1664	pg_db_role_setting	2966	0	r	0	0	\N	0	0	0	1050	0	0	0	0	0	0	0	0	0	3	1047	0	0	0	0	\N	\N	\N	\N
2	16384	2966	99	2011-08-16	1664	pg_toast_2964	0	2967	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	2995	11	2011-08-16	0	pg_largeobject_metadata	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	3501	11	2011-08-16	0	pg_enum	0	0	r	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	3600	11	2011-08-16	0	pg_ts_dict	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	3601	11	2011-08-16	0	pg_ts_parser	0	0	r	1	1	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	3602	11	2011-08-16	0	pg_ts_config	0	0	r	1	16	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	3603	11	2011-08-16	0	pg_ts_config_map	0	0	r	2	304	\N	16384	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	3764	11	2011-08-16	0	pg_ts_template	0	0	r	1	5	\N	8192	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	11454	11342	2011-08-16	0	sql_features	11456	0	r	7	650	\N	57344	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	16384	11456	99	2011-08-16	0	pg_toast_11454	0	11458	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	11459	11342	2011-08-16	0	sql_implementation_info	11461	0	r	1	12	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	16384	11461	99	2011-08-16	0	pg_toast_11459	0	11463	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	11464	11342	2011-08-16	0	sql_languages	11466	0	r	1	4	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	16384	11466	99	2011-08-16	0	pg_toast_11464	0	11468	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	11469	11342	2011-08-16	0	sql_packages	11471	0	r	1	10	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	16384	11471	99	2011-08-16	0	pg_toast_11469	0	11473	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	11474	11342	2011-08-16	0	sql_parts	11476	0	r	1	9	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	16384	11476	99	2011-08-16	0	pg_toast_11474	0	11478	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	11479	11342	2011-08-16	0	sql_sizing	11481	0	r	1	23	\N	8192	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	16384	11481	99	2011-08-16	0	pg_toast_11479	0	11483	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	11484	11342	2011-08-16	0	sql_sizing_profiles	11486	0	r	0	0	\N	0	0	0	\N	\N	0	0	0	0	0	0	0	0	\N	\N	0	0	0	0	\N	\N	\N	\N
2	16384	11486	99	2011-08-16	0	pg_toast_11484	0	11488	t	0	0	\N	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N
2	16384	16385	2200	2011-08-16	0	pgbench_branches	0	0	r	45	10	{fillfactor=100}	368640	243386	2433860	143892	143892	10	387139	0	385773	10	332	1949	1581996	94	256307	\N	\N	\N	\N	2011-08-16 17:33:03.532146+09	2011-08-16 18:05:50.590252+09	2011-08-16 17:33:03.533357+09	2011-08-16 18:05:51.046639+09
2	16384	16388	2200	2011-08-16	0	pgbench_tellers	0	0	r	49	103	{fillfactor=100}	401408	105308	10530800	281835	281934	100	387139	0	374679	103	477	1342	1603578	131	633185	\N	\N	\N	\N	2011-08-16 17:33:03.535254+09	2011-08-16 18:05:54.593707+09	2011-08-16 17:33:03.535545+09	2011-08-16 18:05:54.640352+09
2	16384	16391	2200	2011-08-16	0	pgbench_accounts	0	0	r	16764	999354	{fillfactor=100}	137338880	2	2000000	774279	1774278	1000000	387139	0	364517	999354	37796	482731	919072	150290	2250291	\N	\N	\N	\N	2011-08-16 17:33:05.763186+09	\N	2011-08-16 17:33:05.942256+09	2011-08-16 18:03:40.194741+09
2	16384	16394	2200	2011-08-16	0	pgbench_history	0	0	r	2423	379469	\N	20201472	0	0	\N	\N	387139	0	0	0	386359	0	19737	392725	\N	\N	\N	\N	\N	\N	2011-08-16 17:33:05.95465+09	\N	2011-08-16 17:33:05.955047+09	2011-08-16 18:05:54.533195+09
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: statsrepo; Owner: postgres
--

COPY tablespace (snapid, tbs, name, location, device, avail, total, spcoptions) FROM stdin;
1	1663	pg_default	/home/senda/var/pgdata	253:2	47912132608	51288186880	\N
1	1664	pg_global	/home/senda/var/pgdata	253:2	47912132608	51288186880	\N
2	1663	pg_default	/home/senda/var/pgdata	253:2	47768621056	51288186880	\N
2	1664	pg_global	/home/senda/var/pgdata	253:2	47768621056	51288186880	\N
\.


--
-- Name: activity_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (snapid);


--
-- Name: column_20110816_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY column_20110816
    ADD CONSTRAINT column_20110816_pkey PRIMARY KEY (snapid, dbid, tbl, attnum);


--
-- Name: column_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "column"
    ADD CONSTRAINT column_pkey PRIMARY KEY (snapid, dbid, tbl, attnum);


--
-- Name: cpu_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cpu
    ADD CONSTRAINT cpu_pkey PRIMARY KEY (snapid, cpu_id);


--
-- Name: database_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY database
    ADD CONSTRAINT database_pkey PRIMARY KEY (snapid, dbid);


--
-- Name: device_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY device
    ADD CONSTRAINT device_pkey PRIMARY KEY (snapid, device_major, device_minor);


--
-- Name: index_20110816_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY index_20110816
    ADD CONSTRAINT index_20110816_pkey PRIMARY KEY (snapid, dbid, idx);


--
-- Name: index_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_pkey PRIMARY KEY (snapid, dbid, idx);


--
-- Name: inherits_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY inherits
    ADD CONSTRAINT inherits_pkey PRIMARY KEY (snapid, dbid, inhrelid, inhseqno);


--
-- Name: instance_name_hostname_port_key; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY instance
    ADD CONSTRAINT instance_name_hostname_port_key UNIQUE (name, hostname, port);


--
-- Name: instance_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY instance
    ADD CONSTRAINT instance_pkey PRIMARY KEY (instid);


--
-- Name: profile_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT profile_pkey PRIMARY KEY (snapid, processing);


--
-- Name: role_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_pkey PRIMARY KEY (snapid, userid);


--
-- Name: schema_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY schema
    ADD CONSTRAINT schema_pkey PRIMARY KEY (snapid, dbid, nsp);


--
-- Name: setting_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY setting
    ADD CONSTRAINT setting_pkey PRIMARY KEY (snapid, name);


--
-- Name: snapshot_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY snapshot
    ADD CONSTRAINT snapshot_pkey PRIMARY KEY (snapid);


--
-- Name: table_20110816_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY table_20110816
    ADD CONSTRAINT table_20110816_pkey PRIMARY KEY (snapid, dbid, tbl);


--
-- Name: table_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_pkey PRIMARY KEY (snapid, dbid, tbl);


--
-- Name: tablespace_pkey; Type: CONSTRAINT; Schema: statsrepo; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tablespace
    ADD CONSTRAINT tablespace_pkey PRIMARY KEY (snapid, name);


--
-- Name: statsrepo_autoanalyze_idx; Type: INDEX; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE INDEX statsrepo_autoanalyze_idx ON autoanalyze USING btree (instid, start);


--
-- Name: statsrepo_autovacuum_idx; Type: INDEX; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE INDEX statsrepo_autovacuum_idx ON autovacuum USING btree (instid, start);


--
-- Name: statsrepo_checkpoint_idx; Type: INDEX; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE INDEX statsrepo_checkpoint_idx ON checkpoint USING btree (instid, start);


--
-- Name: statsrepo_function_idx; Type: INDEX; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE INDEX statsrepo_function_idx ON function USING btree (snapid, dbid);


--
-- Name: statsrepo_statement_idx; Type: INDEX; Schema: statsrepo; Owner: postgres; Tablespace: 
--

CREATE INDEX statsrepo_statement_idx ON statement USING btree (snapid, dbid);


--
-- Name: activity_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY activity
    ADD CONSTRAINT activity_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: autoanalyze_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY autoanalyze
    ADD CONSTRAINT autoanalyze_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: autovacuum_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY autovacuum
    ADD CONSTRAINT autovacuum_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: checkpoint_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY checkpoint
    ADD CONSTRAINT checkpoint_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: column_20110816_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY column_20110816
    ADD CONSTRAINT column_20110816_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: column_20110816_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY column_20110816
    ADD CONSTRAINT column_20110816_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: column_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY "column"
    ADD CONSTRAINT column_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: column_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY "column"
    ADD CONSTRAINT column_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: column_snapid_fkey2; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY "column"
    ADD CONSTRAINT column_snapid_fkey2 FOREIGN KEY (snapid, dbid, tbl) REFERENCES "table"(snapid, dbid, tbl);


--
-- Name: cpu_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY cpu
    ADD CONSTRAINT cpu_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: database_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY database
    ADD CONSTRAINT database_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: device_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY device
    ADD CONSTRAINT device_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: function_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY function
    ADD CONSTRAINT function_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: function_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY function
    ADD CONSTRAINT function_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: index_20110816_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY index_20110816
    ADD CONSTRAINT index_20110816_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: index_20110816_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY index_20110816
    ADD CONSTRAINT index_20110816_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: index_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: index_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: index_snapid_fkey2; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY index
    ADD CONSTRAINT index_snapid_fkey2 FOREIGN KEY (snapid, dbid, tbl) REFERENCES "table"(snapid, dbid, tbl);


--
-- Name: inherits_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY inherits
    ADD CONSTRAINT inherits_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: profile_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT profile_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: role_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: schema_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY schema
    ADD CONSTRAINT schema_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: schema_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY schema
    ADD CONSTRAINT schema_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: setting_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY setting
    ADD CONSTRAINT setting_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: snapshot_instid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY snapshot
    ADD CONSTRAINT snapshot_instid_fkey FOREIGN KEY (instid) REFERENCES instance(instid) ON DELETE CASCADE;


--
-- Name: statement_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY statement
    ADD CONSTRAINT statement_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: statement_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY statement
    ADD CONSTRAINT statement_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: table_20110816_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY table_20110816
    ADD CONSTRAINT table_20110816_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: table_20110816_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY table_20110816
    ADD CONSTRAINT table_20110816_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: table_20110816_snapid_fkey2; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY table_20110816
    ADD CONSTRAINT table_20110816_snapid_fkey2 FOREIGN KEY (snapid, dbid, nsp) REFERENCES schema(snapid, dbid, nsp);


--
-- Name: table_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- Name: table_snapid_fkey1; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_snapid_fkey1 FOREIGN KEY (snapid, dbid) REFERENCES database(snapid, dbid);


--
-- Name: table_snapid_fkey2; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY "table"
    ADD CONSTRAINT table_snapid_fkey2 FOREIGN KEY (snapid, dbid, nsp) REFERENCES schema(snapid, dbid, nsp);


--
-- Name: tablespace_snapid_fkey; Type: FK CONSTRAINT; Schema: statsrepo; Owner: postgres
--

ALTER TABLE ONLY tablespace
    ADD CONSTRAINT tablespace_snapid_fkey FOREIGN KEY (snapid) REFERENCES snapshot(snapid) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

